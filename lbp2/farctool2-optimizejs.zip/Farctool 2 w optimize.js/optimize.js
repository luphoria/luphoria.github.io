class ouint32_t {
  constructor(value, optimized=false) {
    this.value = value;
    if (value.includes('0x')) 
      this.value = parseInt(value.replace(/\s/g,''), 16);
    this.optimized = optimized;
  }

  optimize() {
    if (this.optimized) return;
    let bitArray = this.createBitArray(this.getBits(this.value), 7);
    let oGUID = "";
    bitArray = bitArray.map(x => this.reverse(x.padStart(7, '0')));
    bitArray = this.filterZeroes(bitArray);
    for (var i = 0; i < bitArray.length; i++) {
      if (i == (bitArray.length - 1)) bitArray[i] = "0" + bitArray[i]
      else bitArray[i] = "1" + bitArray[i];
      oGUID += parseInt(bitArray[i], 2).toString(16).padStart(2, '0');
    }
    this.value = parseInt(oGUID, 16);
    this.optimized = true;
  }

  getBits(value) {
    var bitArray = [...Array(32)];
    for (let i = 0; i < 32; i++)
      bitArray[i] = (value >> i) & 1;
    return bitArray.join('');
  }

  filterZeroes(bitArray) {
    return bitArray.filter((data) => { return (parseInt(data, 16) != 0)});
  }

  createBitArray(bits, limit) {
    return bits.match(new RegExp(`.{1,${limit}}`, 'g'));
  }

  standardize() {
    if (!this.optimized) return;
    let bitArray = this.createBitArray(this.getBits(this.value), 8);
    bitArray = bitArray.map(x => this.reverse(x.substr(0, x.length - 1)));
    bitArray = this.filterZeroes(bitArray);
    this.value = parseInt(bitArray.join(''), 2);
    this.optimized = false;
  }

  reverse(str) {
    let reversed = "";
    for (let char of str) reversed = char + reversed;
    return reversed;
  }

  toHex() {
    let hex = this.value.toString(16);
    if (!this.optimized) hex = hex.padStart(8, '0');
    else hex = hex.padEnd(8, '0');
    return '0x' + hex.toUpperCase();
  }
};

if (!process.argv[2] || !process.argv[3]) {
  console.info("Usage: node optimize.js <optimize | standardize> <integer | hex>");
  return;
}

let method = process.argv[2].toLowerCase();
let number = new ouint32_t(process.argv[3]);
if (method == 'optimize' || method == 'optimise') { number.optimized = false; number.optimize(); }
else if (method == 'standardize' || method == 'standardise') { number.optimized = true; number.standardize(); }
else { console.info("Invalid method provided."); return; }
console.log(number.toHex());
return;



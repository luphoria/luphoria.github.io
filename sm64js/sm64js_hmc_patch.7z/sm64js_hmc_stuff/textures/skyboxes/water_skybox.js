export const water_skybox_texture_00000 = []
export const water_skybox_texture_00001 = []
export const water_skybox_texture_00002 = []
export const water_skybox_texture_00003 = []
export const water_skybox_texture_00004 = []
export const water_skybox_texture_00005 = []
export const water_skybox_texture_00006 = []
export const water_skybox_texture_00007 = []
export const water_skybox_texture_00008 = []
export const water_skybox_texture_00009 = []
export const water_skybox_texture_0000A = []
export const water_skybox_texture_0000B = []
export const water_skybox_texture_0000C = []
export const water_skybox_texture_0000D = []
export const water_skybox_texture_0000E = []
export const water_skybox_texture_0000F = []
export const water_skybox_texture_00010 = []
export const water_skybox_texture_00011 = []
export const water_skybox_texture_00012 = []
export const water_skybox_texture_00013 = []
export const water_skybox_texture_00014 = []
export const water_skybox_texture_00015 = []
export const water_skybox_texture_00016 = []
export const water_skybox_texture_00017 = []
export const water_skybox_texture_00018 = []
export const water_skybox_texture_00019 = []
export const water_skybox_texture_0001A = []
export const water_skybox_texture_0001B = []
export const water_skybox_texture_0001C = []
export const water_skybox_texture_0001D = []
export const water_skybox_texture_0001E = []
export const water_skybox_texture_0001F = []
export const water_skybox_texture_00020 = []
export const water_skybox_texture_00021 = []
export const water_skybox_texture_00022 = []
export const water_skybox_texture_00023 = []
export const water_skybox_texture_00024 = []
export const water_skybox_texture_00025 = []
export const water_skybox_texture_00026 = []
export const water_skybox_texture_00027 = []
export const water_skybox_texture_00028 = []
export const water_skybox_texture_00029 = []
export const water_skybox_texture_0002A = []
export const water_skybox_texture_0002B = []
export const water_skybox_texture_0002C = []
export const water_skybox_texture_0002D = []
export const water_skybox_texture_0002E = []
export const water_skybox_texture_0002F = []
export const water_skybox_texture_00030 = []
export const water_skybox_texture_00031 = []
export const water_skybox_texture_00032 = []
export const water_skybox_texture_00033 = []
export const water_skybox_texture_00034 = []
export const water_skybox_texture_00035 = []
export const water_skybox_texture_00036 = []
export const water_skybox_texture_00037 = []
export const water_skybox_texture_00038 = []
export const water_skybox_texture_00039 = []
export const water_skybox_texture_0003A = []
export const water_skybox_texture_0003B = []
export const water_skybox_texture_0003C = []
export const water_skybox_texture_0003D = []
export const water_skybox_texture_0003E = []
export const water_skybox_texture_0003F = []

export const water_skybox_ptrlist = [
    water_skybox_texture_00000,
    water_skybox_texture_00001,
    water_skybox_texture_00002,
    water_skybox_texture_00003,
    water_skybox_texture_00004,
    water_skybox_texture_00005,
    water_skybox_texture_00006,
    water_skybox_texture_00007,
    water_skybox_texture_00000,
    water_skybox_texture_00001,
    water_skybox_texture_00008,
    water_skybox_texture_00009,
    water_skybox_texture_0000A,
    water_skybox_texture_0000B,
    water_skybox_texture_0000C,
    water_skybox_texture_0000D,
    water_skybox_texture_0000E,
    water_skybox_texture_0000F,
    water_skybox_texture_00008,
    water_skybox_texture_00009,
    water_skybox_texture_00010,
    water_skybox_texture_00011,
    water_skybox_texture_00012,
    water_skybox_texture_00013,
    water_skybox_texture_00014,
    water_skybox_texture_00015,
    water_skybox_texture_00016,
    water_skybox_texture_00017,
    water_skybox_texture_00010,
    water_skybox_texture_00011,
    water_skybox_texture_00018,
    water_skybox_texture_00019,
    water_skybox_texture_0001A,
    water_skybox_texture_0001B,
    water_skybox_texture_0001C,
    water_skybox_texture_0001D,
    water_skybox_texture_0001E,
    water_skybox_texture_0001F,
    water_skybox_texture_00018,
    water_skybox_texture_00019,
    water_skybox_texture_00020,
    water_skybox_texture_00021,
    water_skybox_texture_00022,
    water_skybox_texture_00023,
    water_skybox_texture_00024,
    water_skybox_texture_00025,
    water_skybox_texture_00026,
    water_skybox_texture_00027,
    water_skybox_texture_00020,
    water_skybox_texture_00021,
    water_skybox_texture_00028,
    water_skybox_texture_00029,
    water_skybox_texture_0002A,
    water_skybox_texture_0002B,
    water_skybox_texture_0002C,
    water_skybox_texture_0002D,
    water_skybox_texture_0002E,
    water_skybox_texture_0002F,
    water_skybox_texture_00028,
    water_skybox_texture_00029,
    water_skybox_texture_00030,
    water_skybox_texture_00031,
    water_skybox_texture_00032,
    water_skybox_texture_00033,
    water_skybox_texture_00034,
    water_skybox_texture_00035,
    water_skybox_texture_00036,
    water_skybox_texture_00037,
    water_skybox_texture_00030,
    water_skybox_texture_00031,
    water_skybox_texture_00038,
    water_skybox_texture_00039,
    water_skybox_texture_0003A,
    water_skybox_texture_0003B,
    water_skybox_texture_0003C,
    water_skybox_texture_0003D,
    water_skybox_texture_0003E,
    water_skybox_texture_0003F,
    water_skybox_texture_00038,
    water_skybox_texture_00039,
]

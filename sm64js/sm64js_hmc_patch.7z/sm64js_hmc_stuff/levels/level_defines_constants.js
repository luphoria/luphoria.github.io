export const LEVEL_CASTLE_GROUNDS = 16
export const LEVEL_BOB = 9
export const LEVEL_CCM = 5
export const LEVEL_PSS = 27
export const LEVEL_TTM = 36
export const LEVEL_WF = 24
export const LEVEL_HMC = 7

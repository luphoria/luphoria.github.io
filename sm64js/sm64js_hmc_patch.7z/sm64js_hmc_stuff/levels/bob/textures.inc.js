export const bob_seg7_texture_07000000 = []

export const bob_seg7_texture_07000800 = []

export const bob_seg7_texture_07001000 = []

export const bob_seg7_texture_07001800 = []

export const bob_seg7_texture_07002000 = []
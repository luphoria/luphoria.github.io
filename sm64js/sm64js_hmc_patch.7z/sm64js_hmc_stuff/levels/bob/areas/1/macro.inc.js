import { MACRO_GOOMBA, MACRO_GOOMBA_TRIPLET_SPAWNER, MACRO_BOBOMB, MACRO_CHAIN_CHOMP } from "../../../../include/macro_presets"

export const bob_seg7_macro_objs = [
    { preset: MACRO_GOOMBA, yaw: 0, pos: [-2713, 152, 5778], param: 0 },
    { preset: MACRO_GOOMBA, yaw: 0, pos: [-342, 400, 5433], param: 0 },
    { preset: MACRO_GOOMBA_TRIPLET_SPAWNER, yaw: 0, pos: [3640, 768, 6280], param: 0 },
    { preset: MACRO_GOOMBA_TRIPLET_SPAWNER, yaw: 0, pos: [6060, 877, 2000], param: 0 },
    { preset: MACRO_GOOMBA_TRIPLET_SPAWNER, yaw: 0, pos: [-6050, 768, 1250], param: 0 },
    { preset: MACRO_BOBOMB, yaw: 0, pos: [-3080, 0, -5200], param: 0 },
    { preset: MACRO_BOBOMB, yaw: 0, pos: [-3688, 885, -3813], param: 0 },
    { preset: MACRO_BOBOMB, yaw: 0, pos: [-4629, 1024, -1772], param: 0 },
    { preset: MACRO_BOBOMB, yaw: 0, pos: [-3480, 891, -2120], param: 0 },
    { preset: MACRO_BOBOMB, yaw: 0, pos: [-3800, 1024, -460], param: 0 },
    { preset: MACRO_BOBOMB, yaw: 0, pos: [6888, 2002, -5608], param: 0 },
    { preset: MACRO_BOBOMB, yaw: 0, pos: [2350, 757, 3700], param: 0 },

    { preset: MACRO_BOBOMB, yaw: 0, pos: [-1750, 0, -2800], param: 0 },
    { preset: MACRO_BOBOMB, yaw: 0, pos: [-1400, 0, -950], param: 0 },
    { preset: MACRO_BOBOMB, yaw: 0, pos: [-2650, 0, 1750], param: 0 },
    { preset: MACRO_BOBOMB, yaw: 0, pos: [-1900, 0, 3450], param: 0 },

    { preset: MACRO_CHAIN_CHOMP, yaw: 0, pos: [260, 735, 1920], param: 0 },

]
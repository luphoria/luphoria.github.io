var BrowserDetect={init:function(){this.browser=this.searchString(this.dataBrowser)||"An unknown browser";this.version=this.searchVersion(navigator.userAgent)||this.searchVersion(navigator.appVersion)||"an unknown version";this.OS=this.searchString(this.dataOS)||"an unknown OS";this.isChrome=this.browser.indexOf("Chrome")>-1;this.isIE=this.browser.indexOf("Explorer")>-1;this.isCrapIE=this.isIE&&this.version<9;this.isFirefox=this.browser.indexOf("Firefox")>-1;this.isSafari=this.browser.indexOf("Safari")>-1;this.isIOS=this.OS.indexOf("iPad")>-1||this.OS.indexOf("iPhone")>-1;this.isMac=this.OS.indexOf("Mac")>-1;this.isWindows=this.OS.indexOf("Win")>-1;this.isLinux=this.OS.indexOf("Linux")>-1;},searchString:function(data){for(var i=0;i<data.length;i++){var dataString=data[i].string;var dataProp=data[i].prop;this.versionSearchString=data[i].versionSearch||data[i].identity;if(dataString){if(dataString.indexOf(data[i].subString)!=-1){return data[i].identity;}}else{if(dataProp){return data[i].identity;}}}},searchVersion:function(dataString){var index=dataString.indexOf(this.versionSearchString);if(index==-1){return;}return parseFloat(dataString.substring(index+this.versionSearchString.length+1));},dataBrowser:[{string:navigator.userAgent,subString:"Chrome",identity:"Chrome"},{string:navigator.userAgent,subString:"OmniWeb",versionSearch:"OmniWeb/",identity:"OmniWeb"},{string:navigator.vendor,subString:"Apple",identity:"Safari",versionSearch:"Version"},{prop:window.opera,identity:"Opera"},{string:navigator.vendor,subString:"iCab",identity:"iCab"},{string:navigator.vendor,subString:"KDE",identity:"Konqueror"},{string:navigator.userAgent,subString:"Firefox",identity:"Firefox"},{string:navigator.vendor,subString:"Camino",identity:"Camino"},{string:navigator.userAgent,subString:"Netscape",identity:"Netscape"},{string:navigator.userAgent,subString:"MSIE",identity:"Explorer",versionSearch:"MSIE"},{string:navigator.userAgent,subString:"Gecko",identity:"Mozilla",versionSearch:"rv"},{string:navigator.userAgent,subString:"Mozilla",identity:"Netscape",versionSearch:"Mozilla"}],dataOS:[{string:navigator.platform,subString:"Win",identity:"Windows"},{string:navigator.platform,subString:"Mac",identity:"Mac"},{string:navigator.userAgent,subString:"iPad",identity:"iPhone/iPod"},{string:navigator.userAgent,subString:"iPhone",identity:"iPad"},{string:navigator.platform,subString:"Linux",identity:"Linux"}]};BrowserDetect.init();/* Modernizr 2.0.6 (Custom Build) | MIT & BSD
 * Contains: fontface | backgroundsize | borderimage | borderradius | boxshadow | flexbox | hsla | multiplebgs | opacity | rgba | textshadow | cssanimations | csscolumns | generatedcontent | cssgradients | cssreflections | csstransforms | csstransforms3d | csstransitions | applicationcache | canvas | canvastext | draganddrop | hashchange | history | audio | video | indexeddb | input | inputtypes | localstorage | postmessage | sessionstorage | websockets | websqldatabase | webworkers | geolocation | inlinesvg | smil | svg | svgclippaths | touch | webgl | iepp | cssclasses | teststyles | testprop | testallprops | hasevent | prefixes | domprefixes | load
 */
;window.Modernizr=function(a,b,c){function H(){e.input=function(a){for(var b=0,c=a.length;b<c;b++)t[a[b]]=a[b]in l;return t}("autocomplete autofocus list placeholder max min multiple pattern required step".split(" ")),e.inputtypes=function(a){for(var d=0,e,f,h,i=a.length;d<i;d++)l.setAttribute("type",f=a[d]),e=l.type!=="text",e&&(l.value=m,l.style.cssText="position:absolute;visibility:hidden;",/^range$/.test(f)&&l.style.WebkitAppearance!==c?(g.appendChild(l),h=b.defaultView,e=h.getComputedStyle&&h.getComputedStyle(l,null).WebkitAppearance!=="textfield"&&l.offsetHeight!==0,g.removeChild(l)):/^(search|tel)$/.test(f)||(/^(url|email)$/.test(f)?e=l.checkValidity&&l.checkValidity()===!1:/^color$/.test(f)?(g.appendChild(l),g.offsetWidth,e=l.value!=m,g.removeChild(l)):e=l.value!=m)),s[a[d]]=!!e;return s}("search tel url email datetime date month week time datetime-local number range color".split(" "))}function F(a,b){var c=a.charAt(0).toUpperCase()+a.substr(1),d=(a+" "+p.join(c+" ")+c).split(" ");return E(d,b)}function E(a,b){for(var d in a)if(k[a[d]]!==c)return b=="pfx"?a[d]:!0;return!1}function D(a,b){return!!~(""+a).indexOf(b)}function C(a,b){return typeof a===b}function B(a,b){return A(o.join(a+";")+(b||""))}function A(a){k.cssText=a}var d="2.0.6",e={},f=!0,g=b.documentElement,h=b.head||b.getElementsByTagName("head")[0],i="modernizr",j=b.createElement(i),k=j.style,l=b.createElement("input"),m=":)",n=Object.prototype.toString,o=" -webkit- -moz- -o- -ms- -khtml- ".split(" "),p="Webkit Moz O ms Khtml".split(" "),q={svg:"http://www.w3.org/2000/svg"},r={},s={},t={},u=[],v=function(a,c,d,e){var f,h,j,k=b.createElement("div");if(parseInt(d,10))while(d--)j=b.createElement("div"),j.id=e?e[d]:i+(d+1),k.appendChild(j);f=["&shy;","<style>",a,"</style>"].join(""),k.id=i,k.innerHTML+=f,g.appendChild(k),h=c(k,a),k.parentNode.removeChild(k);return!!h},w=function(){function d(d,e){e=e||b.createElement(a[d]||"div"),d="on"+d;var f=d in e;f||(e.setAttribute||(e=b.createElement("div")),e.setAttribute&&e.removeAttribute&&(e.setAttribute(d,""),f=C(e[d],"function"),C(e[d],c)||(e[d]=c),e.removeAttribute(d))),e=null;return f}var a={select:"input",change:"input",submit:"form",reset:"form",error:"img",load:"img",abort:"img"};return d}(),x,y={}.hasOwnProperty,z;!C(y,c)&&!C(y.call,c)?z=function(a,b){return y.call(a,b)}:z=function(a,b){return b in a&&C(a.constructor.prototype[b],c)};var G=function(c,d){var f=c.join(""),g=d.length;v(f,function(c,d){var f=b.styleSheets[b.styleSheets.length-1],h=f.cssRules&&f.cssRules[0]?f.cssRules[0].cssText:f.cssText||"",i=c.childNodes,j={};while(g--)j[i[g].id]=i[g];e.touch="ontouchstart"in a||j.touch.offsetTop===9,e.csstransforms3d=j.csstransforms3d.offsetLeft===9,e.generatedcontent=j.generatedcontent.offsetHeight>=1,e.fontface=/src/i.test(h)&&h.indexOf(d.split(" ")[0])===0},g,d)}(['@font-face {font-family:"font";src:url("https://")}',["@media (",o.join("touch-enabled),("),i,")","{#touch{top:9px;position:absolute}}"].join(""),["@media (",o.join("transform-3d),("),i,")","{#csstransforms3d{left:9px;position:absolute}}"].join(""),['#generatedcontent:after{content:"',m,'";visibility:hidden}'].join("")],["fontface","touch","csstransforms3d","generatedcontent"]);r.flexbox=function(){function c(a,b,c,d){a.style.cssText=o.join(b+":"+c+";")+(d||"")}function a(a,b,c,d){b+=":",a.style.cssText=(b+o.join(c+";"+b)).slice(0,-b.length)+(d||"")}var d=b.createElement("div"),e=b.createElement("div");a(d,"display","box","width:42px;padding:0;"),c(e,"box-flex","1","width:10px;"),d.appendChild(e),g.appendChild(d);var f=e.offsetWidth===42;d.removeChild(e),g.removeChild(d);return f},r.canvas=function(){var a=b.createElement("canvas");return!!a.getContext&&!!a.getContext("2d")},r.canvastext=function(){return!!e.canvas&&!!C(b.createElement("canvas").getContext("2d").fillText,"function")},r.webgl=function(){return!!a.WebGLRenderingContext},r.touch=function(){return e.touch},r.geolocation=function(){return!!navigator.geolocation},r.postmessage=function(){return!!a.postMessage},r.websqldatabase=function(){var b=!!a.openDatabase;return b},r.indexedDB=function(){for(var b=-1,c=p.length;++b<c;)if(a[p[b].toLowerCase()+"IndexedDB"])return!0;return!!a.indexedDB},r.hashchange=function(){return w("hashchange",a)&&(b.documentMode===c||b.documentMode>7)},r.history=function(){return!!a.history&&!!history.pushState},r.draganddrop=function(){return w("dragstart")&&w("drop")},r.websockets=function(){for(var b=-1,c=p.length;++b<c;)if(a[p[b]+"WebSocket"])return!0;return"WebSocket"in a},r.rgba=function(){A("background-color:rgba(150,255,150,.5)");return D(k.backgroundColor,"rgba")},r.hsla=function(){A("background-color:hsla(120,40%,100%,.5)");return D(k.backgroundColor,"rgba")||D(k.backgroundColor,"hsla")},r.multiplebgs=function(){A("background:url(https://),url(https://),red url(https://)");return/(url\s*\(.*?){3}/.test(k.background)},r.backgroundsize=function(){return F("backgroundSize")},r.borderimage=function(){return F("borderImage")},r.borderradius=function(){return F("borderRadius")},r.boxshadow=function(){return F("boxShadow")},r.textshadow=function(){return b.createElement("div").style.textShadow===""},r.opacity=function(){B("opacity:.55");return/^0.55$/.test(k.opacity)},r.cssanimations=function(){return F("animationName")},r.csscolumns=function(){return F("columnCount")},r.cssgradients=function(){var a="background-image:",b="gradient(linear,left top,right bottom,from(#9f9),to(white));",c="linear-gradient(left top,#9f9, white);";A((a+o.join(b+a)+o.join(c+a)).slice(0,-a.length));return D(k.backgroundImage,"gradient")},r.cssreflections=function(){return F("boxReflect")},r.csstransforms=function(){return!!E(["transformProperty","WebkitTransform","MozTransform","OTransform","msTransform"])},r.csstransforms3d=function(){var a=!!E(["perspectiveProperty","WebkitPerspective","MozPerspective","OPerspective","msPerspective"]);a&&"webkitPerspective"in g.style&&(a=e.csstransforms3d);return a},r.csstransitions=function(){return F("transitionProperty")},r.fontface=function(){return e.fontface},r.generatedcontent=function(){return e.generatedcontent},r.video=function(){var a=b.createElement("video"),c=!1;try{if(c=!!a.canPlayType){c=new Boolean(c),c.ogg=a.canPlayType('video/ogg; codecs="theora"');var d='video/mp4; codecs="avc1.42E01E';c.h264=a.canPlayType(d+'"')||a.canPlayType(d+', mp4a.40.2"'),c.webm=a.canPlayType('video/webm; codecs="vp8, vorbis"')}}catch(e){}return c},r.audio=function(){var a=b.createElement("audio"),c=!1;try{if(c=!!a.canPlayType)c=new Boolean(c),c.ogg=a.canPlayType('audio/ogg; codecs="vorbis"'),c.mp3=a.canPlayType("audio/mpeg;"),c.wav=a.canPlayType('audio/wav; codecs="1"'),c.m4a=a.canPlayType("audio/x-m4a;")||a.canPlayType("audio/aac;")}catch(d){}return c},r.localstorage=function(){try{return!!localStorage.getItem}catch(a){return!1}},r.sessionstorage=function(){try{return!!sessionStorage.getItem}catch(a){return!1}},r.webworkers=function(){return!!a.Worker},r.applicationcache=function(){return!!a.applicationCache},r.svg=function(){return!!b.createElementNS&&!!b.createElementNS(q.svg,"svg").createSVGRect},r.inlinesvg=function(){var a=b.createElement("div");a.innerHTML="<svg/>";return(a.firstChild&&a.firstChild.namespaceURI)==q.svg},r.smil=function(){return!!b.createElementNS&&/SVG/.test(n.call(b.createElementNS(q.svg,"animate")))},r.svgclippaths=function(){return!!b.createElementNS&&/SVG/.test(n.call(b.createElementNS(q.svg,"clipPath")))};for(var I in r)z(r,I)&&(x=I.toLowerCase(),e[x]=r[I](),u.push((e[x]?"":"no-")+x));e.input||H(),A(""),j=l=null,a.attachEvent&&function(){var a=b.createElement("div");a.innerHTML="<elem></elem>";return a.childNodes.length!==1}()&&function(a,b){function s(a){var b=-1;while(++b<g)a.createElement(f[b])}a.iepp=a.iepp||{};var d=a.iepp,e=d.html5elements||"abbr|article|aside|audio|canvas|datalist|details|figcaption|figure|footer|header|hgroup|mark|meter|nav|output|progress|section|summary|time|video",f=e.split("|"),g=f.length,h=new RegExp("(^|\\s)("+e+")","gi"),i=new RegExp("<(/*)("+e+")","gi"),j=/^\s*[\{\}]\s*$/,k=new RegExp("(^|[^\\n]*?\\s)("+e+")([^\\n]*)({[\\n\\w\\W]*?})","gi"),l=b.createDocumentFragment(),m=b.documentElement,n=m.firstChild,o=b.createElement("body"),p=b.createElement("style"),q=/print|all/,r;d.getCSS=function(a,b){if(a+""===c)return"";var e=-1,f=a.length,g,h=[];while(++e<f){g=a[e];if(g.disabled)continue;b=g.media||b,q.test(b)&&h.push(d.getCSS(g.imports,b),g.cssText),b="all"}return h.join("")},d.parseCSS=function(a){var b=[],c;while((c=k.exec(a))!=null)b.push(((j.exec(c[1])?"\n":c[1])+c[2]+c[3]).replace(h,"$1.iepp_$2")+c[4]);return b.join("\n")},d.writeHTML=function(){var a=-1;r=r||b.body;while(++a<g){var c=b.getElementsByTagName(f[a]),d=c.length,e=-1;while(++e<d)c[e].className.indexOf("iepp_")<0&&(c[e].className+=" iepp_"+f[a])}l.appendChild(r),m.appendChild(o),o.className=r.className,o.id=r.id,o.innerHTML=r.innerHTML.replace(i,"<$1font")},d._beforePrint=function(){p.styleSheet.cssText=d.parseCSS(d.getCSS(b.styleSheets,"all")),d.writeHTML()},d.restoreHTML=function(){o.innerHTML="",m.removeChild(o),m.appendChild(r)},d._afterPrint=function(){d.restoreHTML(),p.styleSheet.cssText=""},s(b),s(l);d.disablePP||(n.insertBefore(p,n.firstChild),p.media="print",p.className="iepp-printshim",a.attachEvent("onbeforeprint",d._beforePrint),a.attachEvent("onafterprint",d._afterPrint))}(a,b),e._version=d,e._prefixes=o,e._domPrefixes=p,e.hasEvent=w,e.testProp=function(a){return E([a])},e.testAllProps=F,e.testStyles=v,g.className=g.className.replace(/\bno-js\b/,"")+(f?" js "+u.join(" "):"");return e}(this,this.document),function(a,b,c){function k(a){return!a||a=="loaded"||a=="complete"}function j(){var a=1,b=-1;while(p.length- ++b)if(p[b].s&&!(a=p[b].r))break;a&&g()}function i(a){var c=b.createElement("script"),d;c.src=a.s,c.onreadystatechange=c.onload=function(){!d&&k(c.readyState)&&(d=1,j(),c.onload=c.onreadystatechange=null)},m(function(){d||(d=1,j())},H.errorTimeout),a.e?c.onload():n.parentNode.insertBefore(c,n)}function h(a){var c=b.createElement("link"),d;c.href=a.s,c.rel="stylesheet",c.type="text/css";if(!a.e&&(w||r)){var e=function(a){m(function(){if(!d)try{a.sheet.cssRules.length?(d=1,j()):e(a)}catch(b){b.code==1e3||b.message=="security"||b.message=="denied"?(d=1,m(function(){j()},0)):e(a)}},0)};e(c)}else c.onload=function(){d||(d=1,m(function(){j()},0))},a.e&&c.onload();m(function(){d||(d=1,j())},H.errorTimeout),!a.e&&n.parentNode.insertBefore(c,n)}function g(){var a=p.shift();q=1,a?a.t?m(function(){a.t=="c"?h(a):i(a)},0):(a(),j()):q=0}function f(a,c,d,e,f,h){function i(){!o&&k(l.readyState)&&(r.r=o=1,!q&&j(),l.onload=l.onreadystatechange=null,m(function(){u.removeChild(l)},0))}var l=b.createElement(a),o=0,r={t:d,s:c,e:h};l.src=l.data=c,!s&&(l.style.display="none"),l.width=l.height="0",a!="object"&&(l.type=d),l.onload=l.onreadystatechange=i,a=="img"?l.onerror=i:a=="script"&&(l.onerror=function(){r.e=r.r=1,g()}),p.splice(e,0,r),u.insertBefore(l,s?null:n),m(function(){o||(u.removeChild(l),r.r=r.e=o=1,j())},H.errorTimeout)}function e(a,b,c){var d=b=="c"?z:y;q=0,b=b||"j",C(a)?f(d,a,b,this.i++,l,c):(p.splice(this.i++,0,a),p.length==1&&g());return this}function d(){var a=H;a.loader={load:e,i:0};return a}var l=b.documentElement,m=a.setTimeout,n=b.getElementsByTagName("script")[0],o={}.toString,p=[],q=0,r="MozAppearance"in l.style,s=r&&!!b.createRange().compareNode,t=r&&!s,u=s?l:n.parentNode,v=a.opera&&o.call(a.opera)=="[object Opera]",w="webkitAppearance"in l.style,x=w&&"async"in b.createElement("script"),y=r?"object":v||x?"img":"script",z=w?"img":y,A=Array.isArray||function(a){return o.call(a)=="[object Array]"},B=function(a){return Object(a)===a},C=function(a){return typeof a=="string"},D=function(a){return o.call(a)=="[object Function]"},E=[],F={},G,H;H=function(a){function f(a){var b=a.split("!"),c=E.length,d=b.pop(),e=b.length,f={url:d,origUrl:d,prefixes:b},g,h;for(h=0;h<e;h++)g=F[b[h]],g&&(f=g(f));for(h=0;h<c;h++)f=E[h](f);return f}function e(a,b,e,g,h){var i=f(a),j=i.autoCallback;if(!i.bypass){b&&(b=D(b)?b:b[a]||b[g]||b[a.split("/").pop().split("?")[0]]);if(i.instead)return i.instead(a,b,e,g,h);e.load(i.url,i.forceCSS||!i.forceJS&&/css$/.test(i.url)?"c":c,i.noexec),(D(b)||D(j))&&e.load(function(){d(),b&&b(i.origUrl,h,g),j&&j(i.origUrl,h,g)})}}function b(a,b){function c(a){if(C(a))e(a,h,b,0,d);else if(B(a))for(i in a)a.hasOwnProperty(i)&&e(a[i],h,b,i,d)}var d=!!a.test,f=d?a.yep:a.nope,g=a.load||a.both,h=a.callback,i;c(f),c(g),a.complete&&b.load(a.complete)}var g,h,i=this.yepnope.loader;if(C(a))e(a,0,i,0);else if(A(a))for(g=0;g<a.length;g++)h=a[g],C(h)?e(h,0,i,0):A(h)?H(h):B(h)&&b(h,i);else B(a)&&b(a,i)},H.addPrefix=function(a,b){F[a]=b},H.addFilter=function(a){E.push(a)},H.errorTimeout=1e4,b.readyState==null&&b.addEventListener&&(b.readyState="loading",b.addEventListener("DOMContentLoaded",G=function(){b.removeEventListener("DOMContentLoaded",G,0),b.readyState="complete"},0)),a.yepnope=d()}(this,this.document),Modernizr.load=function(){yepnope.apply(window,[].slice.call(arguments,0))};// Three.js r43 - http://github.com/mrdoob/three.js
var THREE=THREE||{};if(!window.Int32Array)window.Int32Array=Array,window.Float32Array=Array;THREE.Color=function(b){b!==void 0&&this.setHex(b);return this};
THREE.Color.prototype={constructor:THREE.Color,r:1,g:1,b:1,copy:function(b){this.r=b.r;this.g=b.g;this.b=b.b;return this},setRGB:function(b,c,e){this.r=b;this.g=c;this.b=e;return this},setHSV:function(b,c,e){var f,g,j;if(e==0)this.r=this.g=this.b=0;else switch(f=Math.floor(b*6),g=b*6-f,b=e*(1-c),j=e*(1-c*g),c=e*(1-c*(1-g)),f){case 1:this.r=j;this.g=e;this.b=b;break;case 2:this.r=b;this.g=e;this.b=c;break;case 3:this.r=b;this.g=j;this.b=e;break;case 4:this.r=c;this.g=b;this.b=e;break;case 5:this.r=
e;this.g=b;this.b=j;break;case 6:case 0:this.r=e,this.g=c,this.b=b}return this},setHex:function(b){b=Math.floor(b);this.r=(b>>16&255)/255;this.g=(b>>8&255)/255;this.b=(b&255)/255;return this},getHex:function(){return~~(this.r*255)<<16^~~(this.g*255)<<8^~~(this.b*255)},getContextStyle:function(){return"rgb("+Math.floor(this.r*255)+","+Math.floor(this.g*255)+","+Math.floor(this.b*255)+")"},clone:function(){return(new THREE.Color).setRGB(this.r,this.g,this.b)}};
THREE.Vector2=function(b,c){this.set(b||0,c||0)};
THREE.Vector2.prototype={constructor:THREE.Vector2,set:function(b,c){this.x=b;this.y=c;return this},copy:function(b){this.x=b.x;this.y=b.y;return this},clone:function(){return new THREE.Vector2(this.x,this.y)},add:function(b,c){this.x=b.x+c.x;this.y=b.y+c.y;return this},addSelf:function(b){this.x+=b.x;this.y+=b.y;return this},sub:function(b,c){this.x=b.x-c.x;this.y=b.y-c.y;return this},subSelf:function(b){this.x-=b.x;this.y-=b.y;return this},multiplyScalar:function(b){this.x*=b;this.y*=b;return this},
divideScalar:function(b){b?(this.x/=b,this.y/=b):this.set(0,0);return this},negate:function(){return this.multiplyScalar(-1)},dot:function(b){return this.x*b.x+this.y*b.y},lengthSq:function(){return this.x*this.x+this.y*this.y},length:function(){return Math.sqrt(this.lengthSq())},normalize:function(){return this.divideScalar(this.length())},distanceTo:function(b){return Math.sqrt(this.distanceToSquared(b))},distanceToSquared:function(b){var c=this.x-b.x,b=this.y-b.y;return c*c+b*b},setLength:function(b){return this.normalize().multiplyScalar(b)},
unit:function(){return this.normalize()},equals:function(b){return b.x==this.x&&b.y==this.y}};THREE.Vector3=function(b,c,e){this.set(b||0,c||0,e||0)};
THREE.Vector3.prototype={constructor:THREE.Vector3,set:function(b,c,e){this.x=b;this.y=c;this.z=e;return this},copy:function(b){this.x=b.x;this.y=b.y;this.z=b.z;return this},clone:function(){return new THREE.Vector3(this.x,this.y,this.z)},add:function(b,c){this.x=b.x+c.x;this.y=b.y+c.y;this.z=b.z+c.z;return this},addSelf:function(b){this.x+=b.x;this.y+=b.y;this.z+=b.z;return this},addScalar:function(b){this.x+=b;this.y+=b;this.z+=b;return this},sub:function(b,c){this.x=b.x-c.x;this.y=b.y-c.y;this.z=
b.z-c.z;return this},subSelf:function(b){this.x-=b.x;this.y-=b.y;this.z-=b.z;return this},multiply:function(b,c){this.x=b.x*c.x;this.y=b.y*c.y;this.z=b.z*c.z;return this},multiplySelf:function(b){this.x*=b.x;this.y*=b.y;this.z*=b.z;return this},multiplyScalar:function(b){this.x*=b;this.y*=b;this.z*=b;return this},divideSelf:function(b){return this.divide(this,b)},divideScalar:function(b){b?(this.x/=b,this.y/=b,this.z/=b):this.set(0,0,0);return this},negate:function(){return this.multiplyScalar(-1)},
dot:function(b){return this.x*b.x+this.y*b.y+this.z*b.z},lengthSq:function(){return this.x*this.x+this.y*this.y+this.z*this.z},length:function(){return Math.sqrt(this.lengthSq())},lengthManhattan:function(){return this.x+this.y+this.z},normalize:function(){return this.divideScalar(this.length())},setLength:function(b){return this.normalize().multiplyScalar(b)},cross:function(b,c){this.x=b.y*c.z-b.z*c.y;this.y=b.z*c.x-b.x*c.z;this.z=b.x*c.y-b.y*c.x;return this},crossSelf:function(b){return this.set(this.y*
b.z-this.z*b.y,this.z*b.x-this.x*b.z,this.x*b.y-this.y*b.x)},distanceTo:function(b){return Math.sqrt(this.distanceToSquared(b))},distanceToSquared:function(b){return(new THREE.Vector3).sub(this,b).lengthSq()},setPositionFromMatrix:function(b){this.x=b.n14;this.y=b.n24;this.z=b.n34},setRotationFromMatrix:function(b){var c=Math.cos(this.y);this.y=Math.asin(b.n13);Math.abs(c)>1.0E-5?(this.x=Math.atan2(-b.n23/c,b.n33/c),this.z=Math.atan2(-b.n12/c,b.n11/c)):(this.x=0,this.z=Math.atan2(b.n21,b.n22))},isZero:function(){return this.lengthSq()<
1.0E-4}};THREE.Vector4=function(b,c,e,f){this.set(b||0,c||0,e||0,f||1)};
THREE.Vector4.prototype={constructor:THREE.Vector4,set:function(b,c,e,f){this.x=b;this.y=c;this.z=e;this.w=f;return this},copy:function(b){return this.set(b.x,b.y,b.z,b.w||1)},clone:function(){return new THREE.Vector4(this.x,this.y,this.z,this.w)},add:function(b,c){this.x=b.x+c.x;this.y=b.y+c.y;this.z=b.z+c.z;this.w=b.w+c.w;return this},addSelf:function(b){this.x+=b.x;this.y+=b.y;this.z+=b.z;this.w+=b.w;return this},sub:function(b,c){this.x=b.x-c.x;this.y=b.y-c.y;this.z=b.z-c.z;this.w=b.w-c.w;return this},
subSelf:function(b){this.x-=b.x;this.y-=b.y;this.z-=b.z;this.w-=b.w;return this},multiplyScalar:function(b){this.x*=b;this.y*=b;this.z*=b;this.w*=b;return this},divideScalar:function(b){b?(this.x/=b,this.y/=b,this.z/=b,this.w/=b):this.set(0,0,0,1);return this},negate:function(){return this.multiplyScalar(-1)},dot:function(b){return this.x*b.x+this.y*b.y+this.z*b.z+this.w*b.w},lengthSq:function(){return this.dot(this)},length:function(){return Math.sqrt(this.lengthSq())},normalize:function(){return this.divideScalar(this.length())},
setLength:function(b){return this.normalize().multiplyScalar(b)},lerpSelf:function(b,c){this.x+=(b.x-this.x)*c;this.y+=(b.y-this.y)*c;this.z+=(b.z-this.z)*c;this.w+=(b.w-this.w)*c;return this}};THREE.Ray=function(b,c){this.origin=b||new THREE.Vector3;this.direction=c||new THREE.Vector3};
THREE.Ray.prototype={constructor:THREE.Ray,intersectScene:function(b){return this.intersectObjects(b.objects)},intersectObjects:function(b){var c,e,f=[];c=0;for(e=b.length;c<e;c++)f=f.concat(this.intersectObject(b[c]));f.sort(function(b,c){return b.distance-c.distance});return f},intersectObject:function(b){function c(b,c,e){var f,e=e.matrixWorld.getPosition();f=e.clone().subSelf(b).dot(c);b=b.clone().addSelf(c.clone().multiplyScalar(f));return e.distanceTo(b)}function e(b,c,e,f){var f=f.clone().subSelf(c),
e=e.clone().subSelf(c),g=b.clone().subSelf(c),b=f.dot(f),c=f.dot(e),f=f.dot(g),h=e.dot(e),e=e.dot(g),g=1/(b*h-c*c),h=(h*f-c*e)*g,b=(b*e-c*f)*g;return h>0&&b>0&&h+b<1}if(b instanceof THREE.Particle){var f=c(this.origin,this.direction,b);if(!f||f>b.scale.x)return[];return[{distance:f,point:b.position,face:null,object:b}]}else if(b instanceof THREE.Mesh){f=c(this.origin,this.direction,b);if(!f||f>b.geometry.boundingSphere.radius*Math.max(b.scale.x,Math.max(b.scale.y,b.scale.z)))return[];var g,j,h,k,
o,m,p,u,v,t,w=b.geometry,x=w.vertices,B=[],f=0;for(g=w.faces.length;f<g;f++)if(j=w.faces[f],v=this.origin.clone(),t=this.direction.clone(),m=b.matrixWorld,h=m.multiplyVector3(x[j.a].position.clone()),k=m.multiplyVector3(x[j.b].position.clone()),o=m.multiplyVector3(x[j.c].position.clone()),m=j instanceof THREE.Face4?m.multiplyVector3(x[j.d].position.clone()):null,p=b.matrixRotationWorld.multiplyVector3(j.normal.clone()),u=t.dot(p),b.doubleSided||(b.flipSided?u>0:u<0))if(p=p.dot((new THREE.Vector3).sub(h,
v))/u,v=v.addSelf(t.multiplyScalar(p)),j instanceof THREE.Face3)e(v,h,k,o)&&(j={distance:this.origin.distanceTo(v),point:v,face:j,object:b},B.push(j));else if(j instanceof THREE.Face4&&(e(v,h,k,m)||e(v,k,o,m)))j={distance:this.origin.distanceTo(v),point:v,face:j,object:b},B.push(j);return B}else return[]}};
THREE.Rectangle=function(){function b(){j=f-c;h=g-e}var c,e,f,g,j,h,k=!0;this.getX=function(){return c};this.getY=function(){return e};this.getWidth=function(){return j};this.getHeight=function(){return h};this.getLeft=function(){return c};this.getTop=function(){return e};this.getRight=function(){return f};this.getBottom=function(){return g};this.set=function(h,j,p,u){k=!1;c=h;e=j;f=p;g=u;b()};this.addPoint=function(h,j){k?(k=!1,c=h,e=j,f=h,g=j):(c=c<h?c:h,e=e<j?e:j,f=f>h?f:h,g=g>j?g:j);b()};this.add3Points=
function(h,j,p,u,v,t){k?(k=!1,c=h<p?h<v?h:v:p<v?p:v,e=j<u?j<t?j:t:u<t?u:t,f=h>p?h>v?h:v:p>v?p:v,g=j>u?j>t?j:t:u>t?u:t):(c=h<p?h<v?h<c?h:c:v<c?v:c:p<v?p<c?p:c:v<c?v:c,e=j<u?j<t?j<e?j:e:t<e?t:e:u<t?u<e?u:e:t<e?t:e,f=h>p?h>v?h>f?h:f:v>f?v:f:p>v?p>f?p:f:v>f?v:f,g=j>u?j>t?j>g?j:g:t>g?t:g:u>t?u>g?u:g:t>g?t:g);b()};this.addRectangle=function(h){k?(k=!1,c=h.getLeft(),e=h.getTop(),f=h.getRight(),g=h.getBottom()):(c=c<h.getLeft()?c:h.getLeft(),e=e<h.getTop()?e:h.getTop(),f=f>h.getRight()?f:h.getRight(),g=g>
h.getBottom()?g:h.getBottom());b()};this.inflate=function(h){c-=h;e-=h;f+=h;g+=h;b()};this.minSelf=function(h){c=c>h.getLeft()?c:h.getLeft();e=e>h.getTop()?e:h.getTop();f=f<h.getRight()?f:h.getRight();g=g<h.getBottom()?g:h.getBottom();b()};this.instersects=function(b){return Math.min(f,b.getRight())-Math.max(c,b.getLeft())>=0&&Math.min(g,b.getBottom())-Math.max(e,b.getTop())>=0};this.empty=function(){k=!0;g=f=e=c=0;b()};this.isEmpty=function(){return k}};THREE.Matrix3=function(){this.m=[]};
THREE.Matrix3.prototype={constructor:THREE.Matrix3,transpose:function(){var b,c=this.m;b=c[1];c[1]=c[3];c[3]=b;b=c[2];c[2]=c[6];c[6]=b;b=c[5];c[5]=c[7];c[7]=b;return this},transposeIntoArray:function(b){var c=this.m;b[0]=c[0];b[1]=c[3];b[2]=c[6];b[3]=c[1];b[4]=c[4];b[5]=c[7];b[6]=c[2];b[7]=c[5];b[8]=c[8];return this}};THREE.Matrix4=function(b,c,e,f,g,j,h,k,o,m,p,u,v,t,w,x){this.set(b||1,c||0,e||0,f||0,g||0,j||1,h||0,k||0,o||0,m||0,p||1,u||0,v||0,t||0,w||0,x||1);this.flat=Array(16);this.m33=new THREE.Matrix3};
THREE.Matrix4.prototype={constructor:THREE.Matrix4,set:function(b,c,e,f,g,j,h,k,o,m,p,u,v,t,w,x){this.n11=b;this.n12=c;this.n13=e;this.n14=f;this.n21=g;this.n22=j;this.n23=h;this.n24=k;this.n31=o;this.n32=m;this.n33=p;this.n34=u;this.n41=v;this.n42=t;this.n43=w;this.n44=x;return this},identity:function(){this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1);return this},copy:function(b){this.set(b.n11,b.n12,b.n13,b.n14,b.n21,b.n22,b.n23,b.n24,b.n31,b.n32,b.n33,b.n34,b.n41,b.n42,b.n43,b.n44);return this},lookAt:function(b,
c,e){var f=THREE.Matrix4.__v1,g=THREE.Matrix4.__v2,j=THREE.Matrix4.__v3;j.sub(b,c).normalize();if(j.length()===0)j.z=1;f.cross(e,j).normalize();f.length()===0&&(j.x+=1.0E-4,f.cross(e,j).normalize());g.cross(j,f).normalize();this.n11=f.x;this.n12=g.x;this.n13=j.x;this.n21=f.y;this.n22=g.y;this.n23=j.y;this.n31=f.z;this.n32=g.z;this.n33=j.z;return this},multiplyVector3:function(b){var c=b.x,e=b.y,f=b.z,g=1/(this.n41*c+this.n42*e+this.n43*f+this.n44);b.x=(this.n11*c+this.n12*e+this.n13*f+this.n14)*g;
b.y=(this.n21*c+this.n22*e+this.n23*f+this.n24)*g;b.z=(this.n31*c+this.n32*e+this.n33*f+this.n34)*g;return b},multiplyVector4:function(b){var c=b.x,e=b.y,f=b.z,g=b.w;b.x=this.n11*c+this.n12*e+this.n13*f+this.n14*g;b.y=this.n21*c+this.n22*e+this.n23*f+this.n24*g;b.z=this.n31*c+this.n32*e+this.n33*f+this.n34*g;b.w=this.n41*c+this.n42*e+this.n43*f+this.n44*g;return b},rotateAxis:function(b){var c=b.x,e=b.y,f=b.z;b.x=c*this.n11+e*this.n12+f*this.n13;b.y=c*this.n21+e*this.n22+f*this.n23;b.z=c*this.n31+
e*this.n32+f*this.n33;b.normalize();return b},crossVector:function(b){var c=new THREE.Vector4;c.x=this.n11*b.x+this.n12*b.y+this.n13*b.z+this.n14*b.w;c.y=this.n21*b.x+this.n22*b.y+this.n23*b.z+this.n24*b.w;c.z=this.n31*b.x+this.n32*b.y+this.n33*b.z+this.n34*b.w;c.w=b.w?this.n41*b.x+this.n42*b.y+this.n43*b.z+this.n44*b.w:1;return c},multiply:function(b,c){var e=b.n11,f=b.n12,g=b.n13,j=b.n14,h=b.n21,k=b.n22,o=b.n23,m=b.n24,p=b.n31,u=b.n32,v=b.n33,t=b.n34,w=b.n41,x=b.n42,B=b.n43,A=b.n44,H=c.n11,y=c.n12,
G=c.n13,I=c.n14,E=c.n21,K=c.n22,D=c.n23,J=c.n24,S=c.n31,X=c.n32,R=c.n33,C=c.n34,n=c.n41,W=c.n42,V=c.n43,fa=c.n44;this.n11=e*H+f*E+g*S+j*n;this.n12=e*y+f*K+g*X+j*W;this.n13=e*G+f*D+g*R+j*V;this.n14=e*I+f*J+g*C+j*fa;this.n21=h*H+k*E+o*S+m*n;this.n22=h*y+k*K+o*X+m*W;this.n23=h*G+k*D+o*R+m*V;this.n24=h*I+k*J+o*C+m*fa;this.n31=p*H+u*E+v*S+t*n;this.n32=p*y+u*K+v*X+t*W;this.n33=p*G+u*D+v*R+t*V;this.n34=p*I+u*J+v*C+t*fa;this.n41=w*H+x*E+B*S+A*n;this.n42=w*y+x*K+B*X+A*W;this.n43=w*G+x*D+B*R+A*V;this.n44=w*
I+x*J+B*C+A*fa;return this},multiplyToArray:function(b,c,e){this.multiply(b,c);e[0]=this.n11;e[1]=this.n21;e[2]=this.n31;e[3]=this.n41;e[4]=this.n12;e[5]=this.n22;e[6]=this.n32;e[7]=this.n42;e[8]=this.n13;e[9]=this.n23;e[10]=this.n33;e[11]=this.n43;e[12]=this.n14;e[13]=this.n24;e[14]=this.n34;e[15]=this.n44;return this},multiplySelf:function(b){this.multiply(this,b);return this},multiplyScalar:function(b){this.n11*=b;this.n12*=b;this.n13*=b;this.n14*=b;this.n21*=b;this.n22*=b;this.n23*=b;this.n24*=
b;this.n31*=b;this.n32*=b;this.n33*=b;this.n34*=b;this.n41*=b;this.n42*=b;this.n43*=b;this.n44*=b;return this},determinant:function(){var b=this.n11,c=this.n12,e=this.n13,f=this.n14,g=this.n21,j=this.n22,h=this.n23,k=this.n24,o=this.n31,m=this.n32,p=this.n33,u=this.n34,v=this.n41,t=this.n42,w=this.n43,x=this.n44;return f*h*m*v-e*k*m*v-f*j*p*v+c*k*p*v+e*j*u*v-c*h*u*v-f*h*o*t+e*k*o*t+f*g*p*t-b*k*p*t-e*g*u*t+b*h*u*t+f*j*o*w-c*k*o*w-f*g*m*w+b*k*m*w+c*g*u*w-b*j*u*w-e*j*o*x+c*h*o*x+e*g*m*x-b*h*m*x-c*g*
p*x+b*j*p*x},transpose:function(){var b;b=this.n21;this.n21=this.n12;this.n12=b;b=this.n31;this.n31=this.n13;this.n13=b;b=this.n32;this.n32=this.n23;this.n23=b;b=this.n41;this.n41=this.n14;this.n14=b;b=this.n42;this.n42=this.n24;this.n24=b;b=this.n43;this.n43=this.n34;this.n43=b;return this},clone:function(){var b=new THREE.Matrix4;b.n11=this.n11;b.n12=this.n12;b.n13=this.n13;b.n14=this.n14;b.n21=this.n21;b.n22=this.n22;b.n23=this.n23;b.n24=this.n24;b.n31=this.n31;b.n32=this.n32;b.n33=this.n33;b.n34=
this.n34;b.n41=this.n41;b.n42=this.n42;b.n43=this.n43;b.n44=this.n44;return b},flatten:function(){this.flat[0]=this.n11;this.flat[1]=this.n21;this.flat[2]=this.n31;this.flat[3]=this.n41;this.flat[4]=this.n12;this.flat[5]=this.n22;this.flat[6]=this.n32;this.flat[7]=this.n42;this.flat[8]=this.n13;this.flat[9]=this.n23;this.flat[10]=this.n33;this.flat[11]=this.n43;this.flat[12]=this.n14;this.flat[13]=this.n24;this.flat[14]=this.n34;this.flat[15]=this.n44;return this.flat},flattenToArray:function(b){b[0]=
this.n11;b[1]=this.n21;b[2]=this.n31;b[3]=this.n41;b[4]=this.n12;b[5]=this.n22;b[6]=this.n32;b[7]=this.n42;b[8]=this.n13;b[9]=this.n23;b[10]=this.n33;b[11]=this.n43;b[12]=this.n14;b[13]=this.n24;b[14]=this.n34;b[15]=this.n44;return b},flattenToArrayOffset:function(b,c){b[c]=this.n11;b[c+1]=this.n21;b[c+2]=this.n31;b[c+3]=this.n41;b[c+4]=this.n12;b[c+5]=this.n22;b[c+6]=this.n32;b[c+7]=this.n42;b[c+8]=this.n13;b[c+9]=this.n23;b[c+10]=this.n33;b[c+11]=this.n43;b[c+12]=this.n14;b[c+13]=this.n24;b[c+14]=
this.n34;b[c+15]=this.n44;return b},setTranslation:function(b,c,e){this.set(1,0,0,b,0,1,0,c,0,0,1,e,0,0,0,1);return this},setScale:function(b,c,e){this.set(b,0,0,0,0,c,0,0,0,0,e,0,0,0,0,1);return this},setRotationX:function(b){var c=Math.cos(b),b=Math.sin(b);this.set(1,0,0,0,0,c,-b,0,0,b,c,0,0,0,0,1);return this},setRotationY:function(b){var c=Math.cos(b),b=Math.sin(b);this.set(c,0,b,0,0,1,0,0,-b,0,c,0,0,0,0,1);return this},setRotationZ:function(b){var c=Math.cos(b),b=Math.sin(b);this.set(c,-b,0,
0,b,c,0,0,0,0,1,0,0,0,0,1);return this},setRotationAxis:function(b,c){var e=Math.cos(c),f=Math.sin(c),g=1-e,j=b.x,h=b.y,k=b.z,o=g*j,m=g*h;this.set(o*j+e,o*h-f*k,o*k+f*h,0,o*h+f*k,m*h+e,m*k-f*j,0,o*k-f*h,m*k+f*j,g*k*k+e,0,0,0,0,1);return this},setPosition:function(b){this.n14=b.x;this.n24=b.y;this.n34=b.z;return this},getPosition:function(){if(!this.position)this.position=new THREE.Vector3;this.position.set(this.n14,this.n24,this.n34);return this.position},getColumnX:function(){if(!this.columnX)this.columnX=
new THREE.Vector3;this.columnX.set(this.n11,this.n21,this.n31);return this.columnX},getColumnY:function(){if(!this.columnY)this.columnY=new THREE.Vector3;this.columnY.set(this.n12,this.n22,this.n32);return this.columnY},getColumnZ:function(){if(!this.columnZ)this.columnZ=new THREE.Vector3;this.columnZ.set(this.n13,this.n23,this.n33);return this.columnZ},setRotationFromEuler:function(b,c){var e=b.x,f=b.y,g=b.z,j=Math.cos(e),e=Math.sin(e),h=Math.cos(f),f=Math.sin(f),k=Math.cos(g),g=Math.sin(g);switch(c){case "YXZ":var o=
h*k,m=h*g,p=f*k,u=f*g;this.n11=o+u*e;this.n12=p*e-m;this.n13=j*f;this.n21=j*g;this.n22=j*k;this.n23=-e;this.n31=m*e-p;this.n32=u+o*e;this.n33=j*h;break;case "ZXY":o=h*k;m=h*g;p=f*k;u=f*g;this.n11=o-u*e;this.n12=-j*g;this.n13=p+m*e;this.n21=m+p*e;this.n22=j*k;this.n23=u-o*e;this.n31=-j*f;this.n32=e;this.n33=j*h;break;case "ZYX":o=j*k;m=j*g;p=e*k;u=e*g;this.n11=h*k;this.n12=p*f-m;this.n13=o*f+u;this.n21=h*g;this.n22=u*f+o;this.n23=m*f-p;this.n31=-f;this.n32=e*h;this.n33=j*h;break;case "YZX":o=j*h;m=
j*f;p=e*h;u=e*f;this.n11=h*k;this.n12=u-o*g;this.n13=p*g+m;this.n21=g;this.n22=j*k;this.n23=-e*k;this.n31=-f*k;this.n32=m*g+p;this.n33=o-u*g;break;case "XZY":o=j*h;m=j*f;p=e*h;u=e*f;this.n11=h*k;this.n12=-g;this.n13=f*k;this.n21=o*g+u;this.n22=j*k;this.n23=m*g-p;this.n31=p*g-m;this.n32=e*k;this.n33=u*g+o;break;default:o=j*k,m=j*g,p=e*k,u=e*g,this.n11=h*k,this.n12=-h*g,this.n13=f,this.n21=m+p*f,this.n22=o-u*f,this.n23=-e*h,this.n31=u-o*f,this.n32=p+m*f,this.n33=j*h}return this},setRotationFromQuaternion:function(b){var c=
b.x,e=b.y,f=b.z,g=b.w,j=c+c,h=e+e,k=f+f,b=c*j,o=c*h;c*=k;var m=e*h;e*=k;f*=k;j*=g;h*=g;g*=k;this.n11=1-(m+f);this.n12=o-g;this.n13=c+h;this.n21=o+g;this.n22=1-(b+f);this.n23=e-j;this.n31=c-h;this.n32=e+j;this.n33=1-(b+m);return this},scale:function(b){var c=b.x,e=b.y,b=b.z;this.n11*=c;this.n12*=e;this.n13*=b;this.n21*=c;this.n22*=e;this.n23*=b;this.n31*=c;this.n32*=e;this.n33*=b;this.n41*=c;this.n42*=e;this.n43*=b;return this},extractPosition:function(b){this.n14=b.n14;this.n24=b.n24;this.n34=b.n34},
extractRotation:function(b,c){var e=1/c.x,f=1/c.y,g=1/c.z;this.n11=b.n11*e;this.n21=b.n21*e;this.n31=b.n31*e;this.n12=b.n12*f;this.n22=b.n22*f;this.n32=b.n32*f;this.n13=b.n13*g;this.n23=b.n23*g;this.n33=b.n33*g}};
THREE.Matrix4.makeInvert=function(b,c){var e=b.n11,f=b.n12,g=b.n13,j=b.n14,h=b.n21,k=b.n22,o=b.n23,m=b.n24,p=b.n31,u=b.n32,v=b.n33,t=b.n34,w=b.n41,x=b.n42,B=b.n43,A=b.n44;c===void 0&&(c=new THREE.Matrix4);c.n11=o*t*x-m*v*x+m*u*B-k*t*B-o*u*A+k*v*A;c.n12=j*v*x-g*t*x-j*u*B+f*t*B+g*u*A-f*v*A;c.n13=g*m*x-j*o*x+j*k*B-f*m*B-g*k*A+f*o*A;c.n14=j*o*u-g*m*u-j*k*v+f*m*v+g*k*t-f*o*t;c.n21=m*v*w-o*t*w-m*p*B+h*t*B+o*p*A-h*v*A;c.n22=g*t*w-j*v*w+j*p*B-e*t*B-g*p*A+e*v*A;c.n23=j*o*w-g*m*w-j*h*B+e*m*B+g*h*A-e*o*A;c.n24=
g*m*p-j*o*p+j*h*v-e*m*v-g*h*t+e*o*t;c.n31=k*t*w-m*u*w+m*p*x-h*t*x-k*p*A+h*u*A;c.n32=j*u*w-f*t*w-j*p*x+e*t*x+f*p*A-e*u*A;c.n33=g*m*w-j*k*w+j*h*x-e*m*x-f*h*A+e*k*A;c.n34=j*k*p-f*m*p-j*h*u+e*m*u+f*h*t-e*k*t;c.n41=o*u*w-k*v*w-o*p*x+h*v*x+k*p*B-h*u*B;c.n42=f*v*w-g*u*w+g*p*x-e*v*x-f*p*B+e*u*B;c.n43=g*k*w-f*o*w-g*h*x+e*o*x+f*h*B-e*k*B;c.n44=f*o*p-g*k*p+g*h*u-e*o*u-f*h*v+e*k*v;c.multiplyScalar(1/b.determinant());return c};
THREE.Matrix4.makeInvert3x3=function(b){var c=b.m33,e=c.m,f=b.n33*b.n22-b.n32*b.n23,g=-b.n33*b.n21+b.n31*b.n23,j=b.n32*b.n21-b.n31*b.n22,h=-b.n33*b.n12+b.n32*b.n13,k=b.n33*b.n11-b.n31*b.n13,o=-b.n32*b.n11+b.n31*b.n12,m=b.n23*b.n12-b.n22*b.n13,p=-b.n23*b.n11+b.n21*b.n13,u=b.n22*b.n11-b.n21*b.n12,b=b.n11*f+b.n21*h+b.n31*m;b==0&&console.error("THREE.Matrix4.makeInvert3x3: Matrix not invertible.");b=1/b;e[0]=b*f;e[1]=b*g;e[2]=b*j;e[3]=b*h;e[4]=b*k;e[5]=b*o;e[6]=b*m;e[7]=b*p;e[8]=b*u;return c};
THREE.Matrix4.makeFrustum=function(b,c,e,f,g,j){var h;h=new THREE.Matrix4;h.n11=2*g/(c-b);h.n12=0;h.n13=(c+b)/(c-b);h.n14=0;h.n21=0;h.n22=2*g/(f-e);h.n23=(f+e)/(f-e);h.n24=0;h.n31=0;h.n32=0;h.n33=-(j+g)/(j-g);h.n34=-2*j*g/(j-g);h.n41=0;h.n42=0;h.n43=-1;h.n44=0;return h};THREE.Matrix4.makePerspective=function(b,c,e,f){var g,b=e*Math.tan(b*Math.PI/360);g=-b;return THREE.Matrix4.makeFrustum(g*c,b*c,g,b,e,f)};
THREE.Matrix4.makeOrtho=function(b,c,e,f,g,j){var h,k,o,m;h=new THREE.Matrix4;k=c-b;o=e-f;m=j-g;h.n11=2/k;h.n12=0;h.n13=0;h.n14=-((c+b)/k);h.n21=0;h.n22=2/o;h.n23=0;h.n24=-((e+f)/o);h.n31=0;h.n32=0;h.n33=-2/m;h.n34=-((j+g)/m);h.n41=0;h.n42=0;h.n43=0;h.n44=1;return h};THREE.Matrix4.__v1=new THREE.Vector3;THREE.Matrix4.__v2=new THREE.Vector3;THREE.Matrix4.__v3=new THREE.Vector3;
THREE.Object3D=function(){this.parent=void 0;this.children=[];this.up=new THREE.Vector3(0,1,0);this.position=new THREE.Vector3;this.rotation=new THREE.Vector3;this.eulerOrder="XYZ";this.scale=new THREE.Vector3(1,1,1);this.flipSided=this.doubleSided=this.dynamic=!1;this.renderDepth=null;this.rotationAutoUpdate=!0;this.matrix=new THREE.Matrix4;this.matrixWorld=new THREE.Matrix4;this.matrixRotationWorld=new THREE.Matrix4;this.matrixWorldNeedsUpdate=this.matrixAutoUpdate=!0;this.quaternion=new THREE.Quaternion;
this.useQuaternion=!1;this.boundRadius=0;this.boundRadiusScale=1;this.visible=!0;this.receiveShadow=this.castShadow=!1;this._vector=new THREE.Vector3;this.name=""};
THREE.Object3D.prototype={constructor:THREE.Object3D,translate:function(b,c){this.matrix.rotateAxis(c);this.position.addSelf(c.multiplyScalar(b))},translateX:function(b){this.translate(b,this._vector.set(1,0,0))},translateY:function(b){this.translate(b,this._vector.set(0,1,0))},translateZ:function(b){this.translate(b,this._vector.set(0,0,1))},lookAt:function(b){this.matrix.lookAt(b,this.position,this.up);this.rotationAutoUpdate&&this.rotation.setRotationFromMatrix(this.matrix)},addChild:function(b){if(this.children.indexOf(b)===
-1){b.parent!==void 0&&b.parent.removeChild(b);b.parent=this;this.children.push(b);for(var c=this;c.parent!==void 0;)c=c.parent;c!==void 0&&c instanceof THREE.Scene&&c.addChildRecurse(b)}},removeChild:function(b){var c=this.children.indexOf(b);if(c!==-1)b.parent=void 0,this.children.splice(c,1)},getChildByName:function(b,c){var e,f,g;e=0;for(f=this.children.length;e<f;e++){g=this.children[e];if(g.name===b)return g;if(c&&(g=g.getChildByName(b,c),g!==void 0))return g}},updateMatrix:function(){this.matrix.setPosition(this.position);
this.useQuaternion?this.matrix.setRotationFromQuaternion(this.quaternion):this.matrix.setRotationFromEuler(this.rotation,this.eulerOrder);if(this.scale.x!==1||this.scale.y!==1||this.scale.z!==1)this.matrix.scale(this.scale),this.boundRadiusScale=Math.max(this.scale.x,Math.max(this.scale.y,this.scale.z));this.matrixWorldNeedsUpdate=!0},update:function(b,c,e){this.matrixAutoUpdate&&this.updateMatrix();if(this.matrixWorldNeedsUpdate||c)b?this.matrixWorld.multiply(b,this.matrix):this.matrixWorld.copy(this.matrix),
this.matrixRotationWorld.extractRotation(this.matrixWorld,this.scale),this.matrixWorldNeedsUpdate=!1,c=!0;for(var b=0,f=this.children.length;b<f;b++)this.children[b].update(this.matrixWorld,c,e)}};THREE.Quaternion=function(b,c,e,f){this.set(b||0,c||0,e||0,f!==void 0?f:1)};
THREE.Quaternion.prototype={constructor:THREE.Quaternion,set:function(b,c,e,f){this.x=b;this.y=c;this.z=e;this.w=f;return this},copy:function(b){this.x=b.x;this.y=b.y;this.z=b.z;this.w=b.w;return this},setFromEuler:function(b){var c=0.5*Math.PI/360,e=b.x*c,f=b.y*c,g=b.z*c,b=Math.cos(f),f=Math.sin(f),c=Math.cos(-g),g=Math.sin(-g),j=Math.cos(e),e=Math.sin(e),h=b*c,k=f*g;this.w=h*j-k*e;this.x=h*e+k*j;this.y=f*c*j+b*g*e;this.z=b*g*j-f*c*e;return this},setFromAxisAngle:function(b,c){var e=c/2,f=Math.sin(e);
this.x=b.x*f;this.y=b.y*f;this.z=b.z*f;this.w=Math.cos(e);return this},calculateW:function(){this.w=-Math.sqrt(Math.abs(1-this.x*this.x-this.y*this.y-this.z*this.z));return this},inverse:function(){this.x*=-1;this.y*=-1;this.z*=-1;return this},length:function(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)},normalize:function(){var b=Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w);b==0?this.w=this.z=this.y=this.x=0:(b=1/b,this.x*=b,this.y*=b,this.z*=
b,this.w*=b);return this},multiplySelf:function(b){var c=this.x,e=this.y,f=this.z,g=this.w,j=b.x,h=b.y,k=b.z,b=b.w;this.x=c*b+g*j+e*k-f*h;this.y=e*b+g*h+f*j-c*k;this.z=f*b+g*k+c*h-e*j;this.w=g*b-c*j-e*h-f*k;return this},multiply:function(b,c){this.x=b.x*c.w+b.y*c.z-b.z*c.y+b.w*c.x;this.y=-b.x*c.z+b.y*c.w+b.z*c.x+b.w*c.y;this.z=b.x*c.y-b.y*c.x+b.z*c.w+b.w*c.z;this.w=-b.x*c.x-b.y*c.y-b.z*c.z+b.w*c.w;return this},multiplyVector3:function(b,c){c||(c=b);var e=b.x,f=b.y,g=b.z,j=this.x,h=this.y,k=this.z,
o=this.w,m=o*e+h*g-k*f,p=o*f+k*e-j*g,u=o*g+j*f-h*e,e=-j*e-h*f-k*g;c.x=m*o+e*-j+p*-k-u*-h;c.y=p*o+e*-h+u*-j-m*-k;c.z=u*o+e*-k+m*-h-p*-j;return c}};
THREE.Quaternion.slerp=function(b,c,e,f){var g=b.w*c.w+b.x*c.x+b.y*c.y+b.z*c.z;if(Math.abs(g)>=1)return e.w=b.w,e.x=b.x,e.y=b.y,e.z=b.z,e;var j=Math.acos(g),h=Math.sqrt(1-g*g);if(Math.abs(h)<0.001)return e.w=0.5*(b.w+c.w),e.x=0.5*(b.x+c.x),e.y=0.5*(b.y+c.y),e.z=0.5*(b.z+c.z),e;g=Math.sin((1-f)*j)/h;f=Math.sin(f*j)/h;e.w=b.w*g+c.w*f;e.x=b.x*g+c.x*f;e.y=b.y*g+c.y*f;e.z=b.z*g+c.z*f;return e};THREE.Vertex=function(b){this.position=b||new THREE.Vector3};
THREE.Face3=function(b,c,e,f,g,j){this.a=b;this.b=c;this.c=e;this.normal=f instanceof THREE.Vector3?f:new THREE.Vector3;this.vertexNormals=f instanceof Array?f:[];this.color=g instanceof THREE.Color?g:new THREE.Color;this.vertexColors=g instanceof Array?g:[];this.vertexTangents=[];this.materials=j instanceof Array?j:[j];this.centroid=new THREE.Vector3};
THREE.Face4=function(b,c,e,f,g,j,h){this.a=b;this.b=c;this.c=e;this.d=f;this.normal=g instanceof THREE.Vector3?g:new THREE.Vector3;this.vertexNormals=g instanceof Array?g:[];this.color=j instanceof THREE.Color?j:new THREE.Color;this.vertexColors=j instanceof Array?j:[];this.vertexTangents=[];this.materials=h instanceof Array?h:[h];this.centroid=new THREE.Vector3};THREE.UV=function(b,c){this.set(b||0,c||0)};
THREE.UV.prototype={constructor:THREE.UV,set:function(b,c){this.u=b;this.v=c;return this},copy:function(b){this.set(b.u,b.v);return this}};THREE.Geometry=function(){this.id="Geometry"+THREE.GeometryIdCounter++;this.vertices=[];this.colors=[];this.faces=[];this.edges=[];this.faceUvs=[[]];this.faceVertexUvs=[[]];this.morphTargets=[];this.morphColors=[];this.skinWeights=[];this.skinIndices=[];this.boundingSphere=this.boundingBox=null;this.dynamic=this.hasTangents=!1};
THREE.Geometry.prototype={constructor:THREE.Geometry,computeCentroids:function(){var b,c,e;b=0;for(c=this.faces.length;b<c;b++)e=this.faces[b],e.centroid.set(0,0,0),e instanceof THREE.Face3?(e.centroid.addSelf(this.vertices[e.a].position),e.centroid.addSelf(this.vertices[e.b].position),e.centroid.addSelf(this.vertices[e.c].position),e.centroid.divideScalar(3)):e instanceof THREE.Face4&&(e.centroid.addSelf(this.vertices[e.a].position),e.centroid.addSelf(this.vertices[e.b].position),e.centroid.addSelf(this.vertices[e.c].position),
e.centroid.addSelf(this.vertices[e.d].position),e.centroid.divideScalar(4))},computeFaceNormals:function(b){var c,e,f,g,j,h,k=new THREE.Vector3,o=new THREE.Vector3;f=0;for(g=this.faces.length;f<g;f++){j=this.faces[f];if(b&&j.vertexNormals.length){k.set(0,0,0);c=0;for(e=j.vertexNormals.length;c<e;c++)k.addSelf(j.vertexNormals[c]);k.divideScalar(3)}else c=this.vertices[j.a],e=this.vertices[j.b],h=this.vertices[j.c],k.sub(h.position,e.position),o.sub(c.position,e.position),k.crossSelf(o);k.isZero()||
k.normalize();j.normal.copy(k)}},computeVertexNormals:function(){var b,c,e,f;if(this.__tmpVertices==void 0){f=this.__tmpVertices=Array(this.vertices.length);b=0;for(c=this.vertices.length;b<c;b++)f[b]=new THREE.Vector3;b=0;for(c=this.faces.length;b<c;b++)if(e=this.faces[b],e instanceof THREE.Face3)e.vertexNormals=[new THREE.Vector3,new THREE.Vector3,new THREE.Vector3];else if(e instanceof THREE.Face4)e.vertexNormals=[new THREE.Vector3,new THREE.Vector3,new THREE.Vector3,new THREE.Vector3]}else{f=
this.__tmpVertices;b=0;for(c=this.vertices.length;b<c;b++)f[b].set(0,0,0)}b=0;for(c=this.faces.length;b<c;b++)e=this.faces[b],e instanceof THREE.Face3?(f[e.a].addSelf(e.normal),f[e.b].addSelf(e.normal),f[e.c].addSelf(e.normal)):e instanceof THREE.Face4&&(f[e.a].addSelf(e.normal),f[e.b].addSelf(e.normal),f[e.c].addSelf(e.normal),f[e.d].addSelf(e.normal));b=0;for(c=this.vertices.length;b<c;b++)f[b].normalize();b=0;for(c=this.faces.length;b<c;b++)e=this.faces[b],e instanceof THREE.Face3?(e.vertexNormals[0].copy(f[e.a]),
e.vertexNormals[1].copy(f[e.b]),e.vertexNormals[2].copy(f[e.c])):e instanceof THREE.Face4&&(e.vertexNormals[0].copy(f[e.a]),e.vertexNormals[1].copy(f[e.b]),e.vertexNormals[2].copy(f[e.c]),e.vertexNormals[3].copy(f[e.d]))},computeTangents:function(){function b(b,c,e,f,g,j,n){k=b.vertices[c].position;o=b.vertices[e].position;m=b.vertices[f].position;p=h[g];u=h[j];v=h[n];t=o.x-k.x;w=m.x-k.x;x=o.y-k.y;B=m.y-k.y;A=o.z-k.z;H=m.z-k.z;y=u.u-p.u;G=v.u-p.u;I=u.v-p.v;E=v.v-p.v;K=1/(y*E-G*I);X.set((E*t-I*w)*
K,(E*x-I*B)*K,(E*A-I*H)*K);R.set((y*w-G*t)*K,(y*B-G*x)*K,(y*H-G*A)*K);J[c].addSelf(X);J[e].addSelf(X);J[f].addSelf(X);S[c].addSelf(R);S[e].addSelf(R);S[f].addSelf(R)}var c,e,f,g,j,h,k,o,m,p,u,v,t,w,x,B,A,H,y,G,I,E,K,D,J=[],S=[],X=new THREE.Vector3,R=new THREE.Vector3,C=new THREE.Vector3,n=new THREE.Vector3,W=new THREE.Vector3;c=0;for(e=this.vertices.length;c<e;c++)J[c]=new THREE.Vector3,S[c]=new THREE.Vector3;c=0;for(e=this.faces.length;c<e;c++)j=this.faces[c],h=this.faceVertexUvs[0][c],j instanceof
THREE.Face3?b(this,j.a,j.b,j.c,0,1,2):j instanceof THREE.Face4&&(b(this,j.a,j.b,j.c,0,1,2),b(this,j.a,j.b,j.d,0,1,3));var V=["a","b","c","d"];c=0;for(e=this.faces.length;c<e;c++){j=this.faces[c];for(f=0;f<j.vertexNormals.length;f++)W.copy(j.vertexNormals[f]),g=j[V[f]],D=J[g],C.copy(D),C.subSelf(W.multiplyScalar(W.dot(D))).normalize(),n.cross(j.vertexNormals[f],D),g=n.dot(S[g]),g=g<0?-1:1,j.vertexTangents[f]=new THREE.Vector4(C.x,C.y,C.z,g)}this.hasTangents=!0},computeBoundingBox:function(){var b;
if(this.vertices.length>0){this.boundingBox={x:[this.vertices[0].position.x,this.vertices[0].position.x],y:[this.vertices[0].position.y,this.vertices[0].position.y],z:[this.vertices[0].position.z,this.vertices[0].position.z]};for(var c=1,e=this.vertices.length;c<e;c++){b=this.vertices[c];if(b.position.x<this.boundingBox.x[0])this.boundingBox.x[0]=b.position.x;else if(b.position.x>this.boundingBox.x[1])this.boundingBox.x[1]=b.position.x;if(b.position.y<this.boundingBox.y[0])this.boundingBox.y[0]=b.position.y;
else if(b.position.y>this.boundingBox.y[1])this.boundingBox.y[1]=b.position.y;if(b.position.z<this.boundingBox.z[0])this.boundingBox.z[0]=b.position.z;else if(b.position.z>this.boundingBox.z[1])this.boundingBox.z[1]=b.position.z}}},computeBoundingSphere:function(){for(var b=0,c=0,e=this.vertices.length;c<e;c++)b=Math.max(b,this.vertices[c].position.length());this.boundingSphere={radius:b}},computeEdgeFaces:function(){function b(b,c){return Math.min(b,c)+"_"+Math.max(b,c)}function c(b,c,e){b[c]===
void 0?(b[c]={set:{},array:[]},b[c].set[e]=1,b[c].array.push(e)):b[c].set[e]===void 0&&(b[c].set[e]=1,b[c].array.push(e))}var e,f,g,j,h,k={};e=0;for(f=this.faces.length;e<f;e++)h=this.faces[e],h instanceof THREE.Face3?(g=b(h.a,h.b),c(k,g,e),g=b(h.b,h.c),c(k,g,e),g=b(h.a,h.c),c(k,g,e)):h instanceof THREE.Face4&&(g=b(h.b,h.d),c(k,g,e),g=b(h.a,h.b),c(k,g,e),g=b(h.a,h.d),c(k,g,e),g=b(h.b,h.c),c(k,g,e),g=b(h.c,h.d),c(k,g,e));e=0;for(f=this.edges.length;e<f;e++){h=this.edges[e];g=h.vertexIndices[0];j=h.vertexIndices[1];
h.faceIndices=k[b(g,j)].array;for(g=0;g<h.faceIndices.length;g++)j=h.faceIndices[g],h.faces.push(this.faces[j])}}};THREE.GeometryIdCounter=0;
THREE.Spline=function(b){function c(b,c,e,f,h,g,j){b=(e-b)*0.5;f=(f-c)*0.5;return(2*(c-e)+b+f)*j+(-3*(c-e)-2*b-f)*g+b*h+c}this.points=b;var e=[],f={x:0,y:0,z:0},g,j,h,k,o,m,p,u,v;this.initFromArray=function(b){this.points=[];for(var c=0;c<b.length;c++)this.points[c]={x:b[c][0],y:b[c][1],z:b[c][2]}};this.getPoint=function(b){g=(this.points.length-1)*b;j=Math.floor(g);h=g-j;e[0]=j==0?j:j-1;e[1]=j;e[2]=j>this.points.length-2?j:j+1;e[3]=j>this.points.length-3?j:j+2;m=this.points[e[0]];p=this.points[e[1]];
u=this.points[e[2]];v=this.points[e[3]];k=h*h;o=h*k;f.x=c(m.x,p.x,u.x,v.x,h,k,o);f.y=c(m.y,p.y,u.y,v.y,h,k,o);f.z=c(m.z,p.z,u.z,v.z,h,k,o);return f};this.getControlPointsArray=function(){var b,c,e=this.points.length,f=[];for(b=0;b<e;b++)c=this.points[b],f[b]=[c.x,c.y,c.z];return f};this.getLength=function(b){var c,e,f=c=c=0,h=new THREE.Vector3,g=new THREE.Vector3,j=[],k=0;j[0]=0;b||(b=100);e=this.points.length*b;h.copy(this.points[0]);for(b=1;b<e;b++)c=b/e,position=this.getPoint(c),g.copy(position),
k+=g.distanceTo(h),h.copy(position),c*=this.points.length-1,c=Math.floor(c),c!=f&&(j[c]=k,f=c);j[j.length]=k;return{chunks:j,total:k}};this.reparametrizeByArcLength=function(b){var c,e,f,h,g,j,k=[],o=new THREE.Vector3,u=this.getLength();k.push(o.copy(this.points[0]).clone());for(c=1;c<this.points.length;c++){e=u.chunks[c]-u.chunks[c-1];j=Math.ceil(b*e/u.total);h=(c-1)/(this.points.length-1);g=c/(this.points.length-1);for(e=1;e<j-1;e++)f=h+e*(1/j)*(g-h),position=this.getPoint(f),k.push(o.copy(position).clone());
k.push(o.copy(this.points[c]).clone())}this.points=k}};THREE.Edge=function(b,c,e,f){this.vertices=[b,c];this.vertexIndices=[e,f];this.faces=[];this.faceIndices=[]};THREE.Camera=function(b,c,e,f,g){THREE.Object3D.call(this);this.fov=b||50;this.aspect=c||1;this.near=e||0.1;this.far=f||2E3;this.target=g||new THREE.Object3D;this.useTarget=!0;this.matrixWorldInverse=new THREE.Matrix4;this.projectionMatrix=null;this.updateProjectionMatrix()};THREE.Camera.prototype=new THREE.Object3D;
THREE.Camera.prototype.constructor=THREE.Camera;THREE.Camera.prototype.supr=THREE.Object3D.prototype;THREE.Camera.prototype.translate=function(b,c){this.matrix.rotateAxis(c);c.multiplyScalar(b);this.position.addSelf(c);this.target.position.addSelf(c)};
THREE.Camera.prototype.updateProjectionMatrix=function(){if(this.fullWidth){var b=this.fullWidth/this.fullHeight,c=Math.tan(this.fov*Math.PI/360)*this.near,e=-c,f=b*e,b=Math.abs(b*c-f),e=Math.abs(c-e);this.projectionMatrix=THREE.Matrix4.makeFrustum(f+this.x*b/this.fullWidth,f+(this.x+this.width)*b/this.fullWidth,c-(this.y+this.height)*e/this.fullHeight,c-this.y*e/this.fullHeight,this.near,this.far)}else this.projectionMatrix=THREE.Matrix4.makePerspective(this.fov,this.aspect,this.near,this.far)};
THREE.Camera.prototype.setViewOffset=function(b,c,e,f,g,j){this.fullWidth=b;this.fullHeight=c;this.x=e;this.y=f;this.width=g;this.height=j;this.updateProjectionMatrix()};
THREE.Camera.prototype.update=function(b,c,e){if(this.useTarget)this.matrix.lookAt(this.position,this.target.position,this.up),this.matrix.setPosition(this.position),b?this.matrixWorld.multiply(b,this.matrix):this.matrixWorld.copy(this.matrix),THREE.Matrix4.makeInvert(this.matrixWorld,this.matrixWorldInverse),c=!0;else if(this.matrixAutoUpdate&&this.updateMatrix(),c||this.matrixWorldNeedsUpdate)b?this.matrixWorld.multiply(b,this.matrix):this.matrixWorld.copy(this.matrix),this.matrixWorldNeedsUpdate=
!1,c=!0,THREE.Matrix4.makeInvert(this.matrixWorld,this.matrixWorldInverse);for(b=0;b<this.children.length;b++)this.children[b].update(this.matrixWorld,c,e)};THREE.Light=function(b){THREE.Object3D.call(this);this.color=new THREE.Color(b)};THREE.Light.prototype=new THREE.Object3D;THREE.Light.prototype.constructor=THREE.Light;THREE.Light.prototype.supr=THREE.Object3D.prototype;THREE.AmbientLight=function(b){THREE.Light.call(this,b)};THREE.AmbientLight.prototype=new THREE.Light;
THREE.AmbientLight.prototype.constructor=THREE.AmbientLight;THREE.DirectionalLight=function(b,c,e,f){THREE.Light.call(this,b);this.position=new THREE.Vector3(0,1,0);this.intensity=c||1;this.distance=e||0;this.castShadow=f!==void 0?f:!1};THREE.DirectionalLight.prototype=new THREE.Light;THREE.DirectionalLight.prototype.constructor=THREE.DirectionalLight;THREE.PointLight=function(b,c,e){THREE.Light.call(this,b);this.position=new THREE.Vector3;this.intensity=c||1;this.distance=e||0};
THREE.PointLight.prototype=new THREE.Light;THREE.PointLight.prototype.constructor=THREE.PointLight;THREE.SpotLight=function(b,c,e,f){THREE.Light.call(this,b);this.position=new THREE.Vector3(0,1,0);this.target=new THREE.Object3D;this.intensity=c||1;this.distance=e||0;this.castShadow=f!==void 0?f:!1};THREE.SpotLight.prototype=new THREE.Light;THREE.SpotLight.prototype.constructor=THREE.SpotLight;
THREE.Material=function(b){this.id=THREE.MaterialCount++;b=b||{};this.opacity=b.opacity!==void 0?b.opacity:1;this.transparent=b.transparent!==void 0?b.transparent:!1;this.blending=b.blending!==void 0?b.blending:THREE.NormalBlending;this.depthTest=b.depthTest!==void 0?b.depthTest:!0;this.polygonOffset=b.polygonOffset!==void 0?b.polygonOffset:!1;this.polygonOffsetFactor=b.polygonOffsetFactor!==void 0?b.polygonOffsetFactor:0;this.polygonOffsetUnits=b.polygonOffsetUnits!==void 0?b.polygonOffsetUnits:
0;this.alphaTest=b.alphaTest!==void 0?b.alphaTest:0};THREE.MaterialCount=0;THREE.NoShading=0;THREE.FlatShading=1;THREE.SmoothShading=2;THREE.NoColors=0;THREE.FaceColors=1;THREE.VertexColors=2;THREE.NormalBlending=0;THREE.AdditiveBlending=1;THREE.SubtractiveBlending=2;THREE.MultiplyBlending=3;THREE.AdditiveAlphaBlending=4;THREE.CubeReflectionMapping=function(){};THREE.CubeRefractionMapping=function(){};THREE.LatitudeReflectionMapping=function(){};THREE.LatitudeRefractionMapping=function(){};
THREE.SphericalReflectionMapping=function(){};THREE.SphericalRefractionMapping=function(){};THREE.UVMapping=function(){};THREE.LineBasicMaterial=function(b){THREE.Material.call(this,b);b=b||{};this.color=b.color!==void 0?new THREE.Color(b.color):new THREE.Color(16777215);this.linewidth=b.linewidth!==void 0?b.linewidth:1;this.linecap=b.linecap!==void 0?b.linecap:"round";this.linejoin=b.linejoin!==void 0?b.linejoin:"round";this.vertexColors=b.vertexColors?b.vertexColors:!1};
THREE.LineBasicMaterial.prototype=new THREE.Material;THREE.LineBasicMaterial.prototype.constructor=THREE.LineBasicMaterial;
THREE.MeshBasicMaterial=function(b){THREE.Material.call(this,b);b=b||{};this.color=b.color!==void 0?new THREE.Color(b.color):new THREE.Color(16777215);this.map=b.map!==void 0?b.map:null;this.lightMap=b.lightMap!==void 0?b.lightMap:null;this.envMap=b.envMap!==void 0?b.envMap:null;this.combine=b.combine!==void 0?b.combine:THREE.MultiplyOperation;this.reflectivity=b.reflectivity!==void 0?b.reflectivity:1;this.refractionRatio=b.refractionRatio!==void 0?b.refractionRatio:0.98;this.shading=b.shading!==
void 0?b.shading:THREE.SmoothShading;this.wireframe=b.wireframe!==void 0?b.wireframe:!1;this.wireframeLinewidth=b.wireframeLinewidth!==void 0?b.wireframeLinewidth:1;this.wireframeLinecap=b.wireframeLinecap!==void 0?b.wireframeLinecap:"round";this.wireframeLinejoin=b.wireframeLinejoin!==void 0?b.wireframeLinejoin:"round";this.vertexColors=b.vertexColors!==void 0?b.vertexColors:!1;this.skinning=b.skinning!==void 0?b.skinning:!1;this.morphTargets=b.morphTargets!==void 0?b.morphTargets:!1};
THREE.MeshBasicMaterial.prototype=new THREE.Material;THREE.MeshBasicMaterial.prototype.constructor=THREE.MeshBasicMaterial;
THREE.MeshLambertMaterial=function(b){THREE.Material.call(this,b);b=b||{};this.color=b.color!==void 0?new THREE.Color(b.color):new THREE.Color(16777215);this.map=b.map!==void 0?b.map:null;this.lightMap=b.lightMap!==void 0?b.lightMap:null;this.envMap=b.envMap!==void 0?b.envMap:null;this.combine=b.combine!==void 0?b.combine:THREE.MultiplyOperation;this.reflectivity=b.reflectivity!==void 0?b.reflectivity:1;this.refractionRatio=b.refractionRatio!==void 0?b.refractionRatio:0.98;this.shading=b.shading!==
void 0?b.shading:THREE.SmoothShading;this.wireframe=b.wireframe!==void 0?b.wireframe:!1;this.wireframeLinewidth=b.wireframeLinewidth!==void 0?b.wireframeLinewidth:1;this.wireframeLinecap=b.wireframeLinecap!==void 0?b.wireframeLinecap:"round";this.wireframeLinejoin=b.wireframeLinejoin!==void 0?b.wireframeLinejoin:"round";this.vertexColors=b.vertexColors!==void 0?b.vertexColors:!1;this.skinning=b.skinning!==void 0?b.skinning:!1;this.morphTargets=b.morphTargets!==void 0?b.morphTargets:!1};
THREE.MeshLambertMaterial.prototype=new THREE.Material;THREE.MeshLambertMaterial.prototype.constructor=THREE.MeshLambertMaterial;
THREE.MeshPhongMaterial=function(b){THREE.Material.call(this,b);b=b||{};this.color=b.color!==void 0?new THREE.Color(b.color):new THREE.Color(16777215);this.ambient=b.ambient!==void 0?new THREE.Color(b.ambient):new THREE.Color(328965);this.specular=b.specular!==void 0?new THREE.Color(b.specular):new THREE.Color(1118481);this.shininess=b.shininess!==void 0?b.shininess:30;this.map=b.map!==void 0?b.map:null;this.lightMap=b.lightMap!==void 0?b.lightMap:null;this.envMap=b.envMap!==void 0?b.envMap:null;
this.combine=b.combine!==void 0?b.combine:THREE.MultiplyOperation;this.reflectivity=b.reflectivity!==void 0?b.reflectivity:1;this.refractionRatio=b.refractionRatio!==void 0?b.refractionRatio:0.98;this.shading=b.shading!==void 0?b.shading:THREE.SmoothShading;this.wireframe=b.wireframe!==void 0?b.wireframe:!1;this.wireframeLinewidth=b.wireframeLinewidth!==void 0?b.wireframeLinewidth:1;this.wireframeLinecap=b.wireframeLinecap!==void 0?b.wireframeLinecap:"round";this.wireframeLinejoin=b.wireframeLinejoin!==
void 0?b.wireframeLinejoin:"round";this.vertexColors=b.vertexColors!==void 0?b.vertexColors:!1;this.skinning=b.skinning!==void 0?b.skinning:!1;this.morphTargets=b.morphTargets!==void 0?b.morphTargets:!1};THREE.MeshPhongMaterial.prototype=new THREE.Material;THREE.MeshPhongMaterial.prototype.constructor=THREE.MeshPhongMaterial;
THREE.MeshDepthMaterial=function(b){THREE.Material.call(this,b);b=b||{};this.shading=b.shading!==void 0?b.shading:THREE.SmoothShading;this.wireframe=b.wireframe!==void 0?b.wireframe:!1;this.wireframeLinewidth=b.wireframeLinewidth!==void 0?b.wireframeLinewidth:1};THREE.MeshDepthMaterial.prototype=new THREE.Material;THREE.MeshDepthMaterial.prototype.constructor=THREE.MeshDepthMaterial;
THREE.MeshNormalMaterial=function(b){THREE.Material.call(this,b);b=b||{};this.shading=b.shading?b.shading:THREE.FlatShading;this.wireframe=b.wireframe?b.wireframe:!1;this.wireframeLinewidth=b.wireframeLinewidth?b.wireframeLinewidth:1};THREE.MeshNormalMaterial.prototype=new THREE.Material;THREE.MeshNormalMaterial.prototype.constructor=THREE.MeshNormalMaterial;THREE.MeshFaceMaterial=function(){};
THREE.MeshShaderMaterial=function(b){THREE.Material.call(this,b);b=b||{};this.fragmentShader=b.fragmentShader!==void 0?b.fragmentShader:"void main() {}";this.vertexShader=b.vertexShader!==void 0?b.vertexShader:"void main() {}";this.uniforms=b.uniforms!==void 0?b.uniforms:{};this.attributes=b.attributes;this.shading=b.shading!==void 0?b.shading:THREE.SmoothShading;this.wireframe=b.wireframe!==void 0?b.wireframe:!1;this.wireframeLinewidth=b.wireframeLinewidth!==void 0?b.wireframeLinewidth:1;this.fog=
b.fog!==void 0?b.fog:!1;this.lights=b.lights!==void 0?b.lights:!1;this.vertexColors=b.vertexColors!==void 0?b.vertexColors:!1;this.skinning=b.skinning!==void 0?b.skinning:!1;this.morphTargets=b.morphTargets!==void 0?b.morphTargets:!1};THREE.MeshShaderMaterial.prototype=new THREE.Material;THREE.MeshShaderMaterial.prototype.constructor=THREE.MeshShaderMaterial;
THREE.ParticleBasicMaterial=function(b){THREE.Material.call(this,b);b=b||{};this.color=b.color!==void 0?new THREE.Color(b.color):new THREE.Color(16777215);this.map=b.map!==void 0?b.map:null;this.size=b.size!==void 0?b.size:1;this.sizeAttenuation=b.sizeAttenuation!==void 0?b.sizeAttenuation:!0;this.vertexColors=b.vertexColors!==void 0?b.vertexColors:!1};THREE.ParticleBasicMaterial.prototype=new THREE.Material;THREE.ParticleBasicMaterial.prototype.constructor=THREE.ParticleBasicMaterial;
THREE.ParticleCanvasMaterial=function(b){THREE.Material.call(this,b);b=b||{};this.color=b.color!==void 0?new THREE.Color(b.color):new THREE.Color(16777215);this.program=b.program!==void 0?b.program:function(){}};THREE.ParticleCanvasMaterial.prototype=new THREE.Material;THREE.ParticleCanvasMaterial.prototype.constructor=THREE.ParticleCanvasMaterial;THREE.ParticleDOMMaterial=function(b){THREE.Material.call(this);this.domElement=b};
THREE.Texture=function(b,c,e,f,g,j){this.id=THREE.TextureCount++;this.image=b;this.mapping=c!==void 0?c:new THREE.UVMapping;this.wrapS=e!==void 0?e:THREE.ClampToEdgeWrapping;this.wrapT=f!==void 0?f:THREE.ClampToEdgeWrapping;this.magFilter=g!==void 0?g:THREE.LinearFilter;this.minFilter=j!==void 0?j:THREE.LinearMipMapLinearFilter;this.offset=new THREE.Vector2(0,0);this.repeat=new THREE.Vector2(1,1);this.needsUpdate=!1};
THREE.Texture.prototype={constructor:THREE.Texture,clone:function(){var b=new THREE.Texture(this.image,this.mapping,this.wrapS,this.wrapT,this.magFilter,this.minFilter);b.offset.copy(this.offset);b.repeat.copy(this.repeat);return b}};THREE.TextureCount=0;THREE.MultiplyOperation=0;THREE.MixOperation=1;THREE.RepeatWrapping=0;THREE.ClampToEdgeWrapping=1;THREE.MirroredRepeatWrapping=2;THREE.NearestFilter=3;THREE.NearestMipMapNearestFilter=4;THREE.NearestMipMapLinearFilter=5;THREE.LinearFilter=6;
THREE.LinearMipMapNearestFilter=7;THREE.LinearMipMapLinearFilter=8;THREE.ByteType=9;THREE.UnsignedByteType=10;THREE.ShortType=11;THREE.UnsignedShortType=12;THREE.IntType=13;THREE.UnsignedIntType=14;THREE.FloatType=15;THREE.AlphaFormat=16;THREE.RGBFormat=17;THREE.RGBAFormat=18;THREE.LuminanceFormat=19;THREE.LuminanceAlphaFormat=20;THREE.DataTexture=function(b,c,e,f,g,j,h,k,o){THREE.Texture.call(this,null,g,j,h,k,o);this.image={data:b,width:c,height:e};this.format=f!==void 0?f:THREE.RGBAFormat};
THREE.DataTexture.prototype=new THREE.Texture;THREE.DataTexture.prototype.constructor=THREE.DataTexture;THREE.DataTexture.prototype={clone:function(){var b=new THREE.DataTexture(this.data.slice(0),this.mapping,this.wrapS,this.wrapT,this.magFilter,this.minFilter);b.offset.copy(this.offset);b.repeat.copy(this.repeat);return b}};THREE.Particle=function(b){THREE.Object3D.call(this);this.materials=b instanceof Array?b:[b]};THREE.Particle.prototype=new THREE.Object3D;
THREE.Particle.prototype.constructor=THREE.Particle;THREE.ParticleSystem=function(b,c){THREE.Object3D.call(this);this.geometry=b;this.materials=c instanceof Array?c:[c];this.sortParticles=!1};THREE.ParticleSystem.prototype=new THREE.Object3D;THREE.ParticleSystem.prototype.constructor=THREE.ParticleSystem;THREE.Line=function(b,c,e){THREE.Object3D.call(this);this.geometry=b;this.materials=c instanceof Array?c:[c];this.type=e!=void 0?e:THREE.LineStrip};THREE.LineStrip=0;THREE.LinePieces=1;
THREE.Line.prototype=new THREE.Object3D;THREE.Line.prototype.constructor=THREE.Line;
THREE.Mesh=function(b,c){THREE.Object3D.call(this);this.geometry=b;this.materials=c&&c.length?c:[c];this.overdraw=!1;if(this.geometry&&(this.geometry.boundingSphere||this.geometry.computeBoundingSphere(),this.boundRadius=b.boundingSphere.radius,this.geometry.morphTargets.length)){this.morphTargetBase=-1;this.morphTargetForcedOrder=[];this.morphTargetInfluences=[];this.morphTargetDictionary={};for(var e=0;e<this.geometry.morphTargets.length;e++)this.morphTargetInfluences.push(0),this.morphTargetDictionary[this.geometry.morphTargets[e].name]=
e}};THREE.Mesh.prototype=new THREE.Object3D;THREE.Mesh.prototype.constructor=THREE.Mesh;THREE.Mesh.prototype.supr=THREE.Object3D.prototype;THREE.Mesh.prototype.getMorphTargetIndexByName=function(b){if(this.morphTargetDictionary[b]!==void 0)return this.morphTargetDictionary[b];console.log("THREE.Mesh.getMorphTargetIndexByName: morph target "+b+" does not exist. Returning 0.");return 0};
THREE.Bone=function(b){THREE.Object3D.call(this);this.skin=b;this.skinMatrix=new THREE.Matrix4;this.hasNoneBoneChildren=!1};THREE.Bone.prototype=new THREE.Object3D;THREE.Bone.prototype.constructor=THREE.Bone;THREE.Bone.prototype.supr=THREE.Object3D.prototype;
THREE.Bone.prototype.update=function(b,c,e){this.matrixAutoUpdate&&(c|=this.updateMatrix());if(c||this.matrixWorldNeedsUpdate)b?this.skinMatrix.multiply(b,this.matrix):this.skinMatrix.copy(this.matrix),this.matrixWorldNeedsUpdate=!1,c=!0;var f,g=this.children.length;if(this.hasNoneBoneChildren){this.matrixWorld.multiply(this.skin.matrixWorld,this.skinMatrix);for(f=0;f<g;f++)b=this.children[f],b instanceof THREE.Bone?b.update(this.skinMatrix,c,e):b.update(this.matrixWorld,!0,e)}else for(f=0;f<g;f++)this.children[f].update(this.skinMatrix,
c,e)};THREE.Bone.prototype.addChild=function(b){if(this.children.indexOf(b)===-1&&(b.parent!==void 0&&b.parent.removeChild(b),b.parent=this,this.children.push(b),!(b instanceof THREE.Bone)))this.hasNoneBoneChildren=!0};
THREE.SkinnedMesh=function(b,c){THREE.Mesh.call(this,b,c);this.identityMatrix=new THREE.Matrix4;this.bones=[];this.boneMatrices=[];var e,f,g,j,h,k;if(this.geometry.bones!==void 0){for(e=0;e<this.geometry.bones.length;e++)g=this.geometry.bones[e],j=g.pos,h=g.rotq,k=g.scl,f=this.addBone(),f.name=g.name,f.position.set(j[0],j[1],j[2]),f.quaternion.set(h[0],h[1],h[2],h[3]),f.useQuaternion=!0,k!==void 0?f.scale.set(k[0],k[1],k[2]):f.scale.set(1,1,1);for(e=0;e<this.bones.length;e++)g=this.geometry.bones[e],
f=this.bones[e],g.parent===-1?this.addChild(f):this.bones[g.parent].addChild(f);this.boneMatrices=new Float32Array(16*this.bones.length);this.pose()}};THREE.SkinnedMesh.prototype=new THREE.Mesh;THREE.SkinnedMesh.prototype.constructor=THREE.SkinnedMesh;
THREE.SkinnedMesh.prototype.update=function(b,c,e){if(this.visible){this.matrixAutoUpdate&&(c|=this.updateMatrix());if(c||this.matrixWorldNeedsUpdate)b?this.matrixWorld.multiply(b,this.matrix):this.matrixWorld.copy(this.matrix),this.matrixWorldNeedsUpdate=!1,c=!0;var f,g=this.children.length;for(f=0;f<g;f++)b=this.children[f],b instanceof THREE.Bone?b.update(this.identityMatrix,!1,e):b.update(this.matrixWorld,c,e);e=this.bones.length;ba=this.bones;bm=this.boneMatrices;for(c=0;c<e;c++)ba[c].skinMatrix.flattenToArrayOffset(bm,
c*16)}};THREE.SkinnedMesh.prototype.addBone=function(b){b===void 0&&(b=new THREE.Bone(this));this.bones.push(b);return b};
THREE.SkinnedMesh.prototype.pose=function(){this.update(void 0,!0);for(var b,c=[],e=0;e<this.bones.length;e++)b=this.bones[e],c.push(THREE.Matrix4.makeInvert(b.skinMatrix)),b.skinMatrix.flattenToArrayOffset(this.boneMatrices,e*16);if(this.geometry.skinVerticesA===void 0){this.geometry.skinVerticesA=[];this.geometry.skinVerticesB=[];var f;for(b=0;b<this.geometry.skinIndices.length;b++){var e=this.geometry.vertices[b].position,g=this.geometry.skinIndices[b].x,j=this.geometry.skinIndices[b].y;f=new THREE.Vector3(e.x,
e.y,e.z);this.geometry.skinVerticesA.push(c[g].multiplyVector3(f));f=new THREE.Vector3(e.x,e.y,e.z);this.geometry.skinVerticesB.push(c[j].multiplyVector3(f));this.geometry.skinWeights[b].x+this.geometry.skinWeights[b].y!==1&&(e=(1-(this.geometry.skinWeights[b].x+this.geometry.skinWeights[b].y))*0.5,this.geometry.skinWeights[b].x+=e,this.geometry.skinWeights[b].y+=e)}}};THREE.Ribbon=function(b,c){THREE.Object3D.call(this);this.geometry=b;this.materials=c instanceof Array?c:[c]};
THREE.Ribbon.prototype=new THREE.Object3D;THREE.Ribbon.prototype.constructor=THREE.Ribbon;THREE.LOD=function(){THREE.Object3D.call(this);this.LODs=[]};THREE.LOD.prototype=new THREE.Object3D;THREE.LOD.prototype.constructor=THREE.LOD;THREE.LOD.prototype.supr=THREE.Object3D.prototype;THREE.LOD.prototype.add=function(b,c){c===void 0&&(c=0);for(var c=Math.abs(c),e=0;e<this.LODs.length;e++)if(c<this.LODs[e].visibleAtDistance)break;this.LODs.splice(e,0,{visibleAtDistance:c,object3D:b});this.addChild(b)};
THREE.LOD.prototype.update=function(b,c,e){this.matrixAutoUpdate&&(c|=this.updateMatrix());if(c||this.matrixWorldNeedsUpdate)b?this.matrixWorld.multiply(b,this.matrix):this.matrixWorld.copy(this.matrix),this.matrixWorldNeedsUpdate=!1,c=!0;if(this.LODs.length>1){b=e.matrixWorldInverse;b=-(b.n31*this.position.x+b.n32*this.position.y+b.n33*this.position.z+b.n34);this.LODs[0].object3D.visible=!0;for(var f=1;f<this.LODs.length;f++)if(b>=this.LODs[f].visibleAtDistance)this.LODs[f-1].object3D.visible=!1,
this.LODs[f].object3D.visible=!0;else break;for(;f<this.LODs.length;f++)this.LODs[f].object3D.visible=!1}for(b=0;b<this.children.length;b++)this.children[b].update(this.matrixWorld,c,e)};
THREE.Sprite=function(b){THREE.Object3D.call(this);if(b.material!==void 0)this.material=b.material,this.map=void 0,this.blending=material.blending;else if(b.map!==void 0)this.map=b.map instanceof THREE.Texture?b.map:THREE.ImageUtils.loadTexture(b.map),this.material=void 0,this.blending=b.blending!==void 0?b.blending:THREE.NormalBlending;this.useScreenCoordinates=b.useScreenCoordinates!==void 0?b.useScreenCoordinates:!0;this.mergeWith3D=b.mergeWith3D!==void 0?b.mergeWith3D:!this.useScreenCoordinates;
this.affectedByDistance=b.affectedByDistance!==void 0?b.affectedByDistance:!this.useScreenCoordinates;this.scaleByViewport=b.scaleByViewport!==void 0?b.scaleByViewport:!this.affectedByDistance;this.alignment=b.alignment instanceof THREE.Vector2?b.alignment:THREE.SpriteAlignment.center;this.rotation3d=this.rotation;this.rotation=0;this.opacity=1;this.uvOffset=new THREE.Vector2(0,0);this.uvScale=new THREE.Vector2(1,1)};THREE.Sprite.prototype=new THREE.Object3D;THREE.Sprite.prototype.constructor=THREE.Sprite;
THREE.Sprite.prototype.supr=THREE.Object3D.prototype;THREE.Sprite.prototype.updateMatrix=function(){this.matrix.setPosition(this.position);this.rotation3d.set(0,0,this.rotation);this.matrix.setRotationFromEuler(this.rotation3d);if(this.scale.x!==1||this.scale.y!==1)this.matrix.scale(this.scale),this.boundRadiusScale=Math.max(this.scale.x,this.scale.y);this.matrixWorldNeedsUpdate=!0};THREE.SpriteAlignment={};THREE.SpriteAlignment.topLeft=new THREE.Vector2(1,-1);
THREE.SpriteAlignment.topCenter=new THREE.Vector2(0,-1);THREE.SpriteAlignment.topRight=new THREE.Vector2(-1,-1);THREE.SpriteAlignment.centerLeft=new THREE.Vector2(1,0);THREE.SpriteAlignment.center=new THREE.Vector2(0,0);THREE.SpriteAlignment.centerRight=new THREE.Vector2(-1,0);THREE.SpriteAlignment.bottomLeft=new THREE.Vector2(1,1);THREE.SpriteAlignment.bottomCenter=new THREE.Vector2(0,1);THREE.SpriteAlignment.bottomRight=new THREE.Vector2(-1,1);
THREE.Scene=function(){THREE.Object3D.call(this);this.matrixAutoUpdate=!1;this.collisions=this.overrideMaterial=this.fog=null;this.objects=[];this.lights=[];this.__objectsAdded=[];this.__objectsRemoved=[]};THREE.Scene.prototype=new THREE.Object3D;THREE.Scene.prototype.constructor=THREE.Scene;THREE.Scene.prototype.supr=THREE.Object3D.prototype;THREE.Scene.prototype.addChild=function(b){this.supr.addChild.call(this,b);this.addChildRecurse(b)};
THREE.Scene.prototype.addChildRecurse=function(b){if(b instanceof THREE.Light)this.lights.indexOf(b)===-1&&this.lights.push(b);else if(!(b instanceof THREE.Camera||b instanceof THREE.Bone)&&this.objects.indexOf(b)===-1)this.objects.push(b),this.__objectsAdded.push(b);for(var c=0;c<b.children.length;c++)this.addChildRecurse(b.children[c])};THREE.Scene.prototype.removeChild=function(b){this.supr.removeChild.call(this,b);this.removeChildRecurse(b)};
THREE.Scene.prototype.removeChildRecurse=function(b){if(b instanceof THREE.Light){var c=this.lights.indexOf(b);c!==-1&&this.lights.splice(c,1)}else b instanceof THREE.Camera||(c=this.objects.indexOf(b),c!==-1&&(this.objects.splice(c,1),this.__objectsRemoved.push(b)));for(c=0;c<b.children.length;c++)this.removeChildRecurse(b.children[c])};THREE.Scene.prototype.addObject=THREE.Scene.prototype.addChild;THREE.Scene.prototype.removeObject=THREE.Scene.prototype.removeChild;
THREE.Scene.prototype.addLight=THREE.Scene.prototype.addChild;THREE.Scene.prototype.removeLight=THREE.Scene.prototype.removeChild;THREE.Fog=function(b,c,e){this.color=new THREE.Color(b);this.near=c||1;this.far=e||1E3};THREE.FogExp2=function(b,c){this.color=new THREE.Color(b);this.density=c!==void 0?c:2.5E-4};
THREE.Projector=function(){function b(){var b=o[k]=o[k]||new THREE.RenderableVertex;k++;return b}function c(b,c){return c.z-b.z}function e(b,c){var e=0,f=1,h=b.z+b.w,g=c.z+c.w,j=-b.z+b.w,k=-c.z+c.w;return h>=0&&g>=0&&j>=0&&k>=0?!0:h<0&&g<0||j<0&&k<0?!1:(h<0?e=Math.max(e,h/(h-g)):g<0&&(f=Math.min(f,h/(h-g))),j<0?e=Math.max(e,j/(j-k)):k<0&&(f=Math.min(f,j/(j-k))),f<e?!1:(b.lerpSelf(c,e),c.lerpSelf(b,1-f),!0))}var f,g,j=[],h,k,o=[],m,p,u=[],v,t=[],w,x,B=[],A,H,y=[],G=new THREE.Vector4,I=new THREE.Vector4,
E=new THREE.Matrix4,K=new THREE.Matrix4,D=[new THREE.Vector4,new THREE.Vector4,new THREE.Vector4,new THREE.Vector4,new THREE.Vector4,new THREE.Vector4],J=new THREE.Vector4,S=new THREE.Vector4;this.projectVector=function(b,c){E.multiply(c.projectionMatrix,c.matrixWorldInverse);E.multiplyVector3(b);return b};this.unprojectVector=function(b,c){E.multiply(c.matrixWorld,THREE.Matrix4.makeInvert(c.projectionMatrix));E.multiplyVector3(b);return b};this.projectObjects=function(b,e,h){var e=[],k,o,u;g=0;o=
b.objects;b=0;for(k=o.length;b<k;b++){u=o[b];var m;if(!(m=!u.visible))if(m=u instanceof THREE.Mesh){a:{m=void 0;for(var t=u.matrixWorld,p=-u.geometry.boundingSphere.radius*Math.max(u.scale.x,Math.max(u.scale.y,u.scale.z)),v=0;v<6;v++)if(m=D[v].x*t.n14+D[v].y*t.n24+D[v].z*t.n34+D[v].w,m<=p){m=!1;break a}m=!0}m=!m}if(!m)m=j[g]=j[g]||new THREE.RenderableObject,g++,f=m,G.copy(u.position),E.multiplyVector3(G),f.object=u,f.z=G.z,e.push(f)}h&&e.sort(c);return e};this.projectScene=function(f,g,j){var n=[],
G=g.near,V=g.far,fa,L,ea,T,U,da,ha,ia,M,P,aa,Y,Z,ca,ja,la,ka;H=x=v=p=0;g.matrixAutoUpdate&&g.update(void 0,!0);f.update(void 0,!1,g);E.multiply(g.projectionMatrix,g.matrixWorldInverse);D[0].set(E.n41-E.n11,E.n42-E.n12,E.n43-E.n13,E.n44-E.n14);D[1].set(E.n41+E.n11,E.n42+E.n12,E.n43+E.n13,E.n44+E.n14);D[2].set(E.n41+E.n21,E.n42+E.n22,E.n43+E.n23,E.n44+E.n24);D[3].set(E.n41-E.n21,E.n42-E.n22,E.n43-E.n23,E.n44-E.n24);D[4].set(E.n41-E.n31,E.n42-E.n32,E.n43-E.n33,E.n44-E.n34);D[5].set(E.n41+E.n31,E.n42+
E.n32,E.n43+E.n33,E.n44+E.n34);for(fa=0;fa<6;fa++)M=D[fa],M.divideScalar(Math.sqrt(M.x*M.x+M.y*M.y+M.z*M.z));M=this.projectObjects(f,g,!0);f=0;for(fa=M.length;f<fa;f++)if(P=M[f].object,P.visible)if(aa=P.matrixWorld,Y=P.matrixRotationWorld,Z=P.materials,ca=P.overdraw,k=0,P instanceof THREE.Mesh){ja=P.geometry;T=ja.vertices;la=ja.faces;ja=ja.faceVertexUvs;L=0;for(ea=T.length;L<ea;L++)h=b(),h.positionWorld.copy(T[L].position),aa.multiplyVector3(h.positionWorld),h.positionScreen.copy(h.positionWorld),
E.multiplyVector4(h.positionScreen),h.positionScreen.x/=h.positionScreen.w,h.positionScreen.y/=h.positionScreen.w,h.visible=h.positionScreen.z>G&&h.positionScreen.z<V;T=0;for(L=la.length;T<L;T++){ea=la[T];if(ea instanceof THREE.Face3)if(U=o[ea.a],da=o[ea.b],ha=o[ea.c],U.visible&&da.visible&&ha.visible&&(P.doubleSided||P.flipSided!=(ha.positionScreen.x-U.positionScreen.x)*(da.positionScreen.y-U.positionScreen.y)-(ha.positionScreen.y-U.positionScreen.y)*(da.positionScreen.x-U.positionScreen.x)<0))ia=
u[p]=u[p]||new THREE.RenderableFace3,p++,m=ia,m.v1.copy(U),m.v2.copy(da),m.v3.copy(ha);else continue;else if(ea instanceof THREE.Face4)if(U=o[ea.a],da=o[ea.b],ha=o[ea.c],ia=o[ea.d],U.visible&&da.visible&&ha.visible&&ia.visible&&(P.doubleSided||P.flipSided!=((ia.positionScreen.x-U.positionScreen.x)*(da.positionScreen.y-U.positionScreen.y)-(ia.positionScreen.y-U.positionScreen.y)*(da.positionScreen.x-U.positionScreen.x)<0||(da.positionScreen.x-ha.positionScreen.x)*(ia.positionScreen.y-ha.positionScreen.y)-
(da.positionScreen.y-ha.positionScreen.y)*(ia.positionScreen.x-ha.positionScreen.x)<0)))ka=t[v]=t[v]||new THREE.RenderableFace4,v++,m=ka,m.v1.copy(U),m.v2.copy(da),m.v3.copy(ha),m.v4.copy(ia);else continue;m.normalWorld.copy(ea.normal);Y.multiplyVector3(m.normalWorld);m.centroidWorld.copy(ea.centroid);aa.multiplyVector3(m.centroidWorld);m.centroidScreen.copy(m.centroidWorld);E.multiplyVector3(m.centroidScreen);ha=ea.vertexNormals;U=0;for(da=ha.length;U<da;U++)ia=m.vertexNormalsWorld[U],ia.copy(ha[U]),
Y.multiplyVector3(ia);U=0;for(da=ja.length;U<da;U++)if(ka=ja[U][T]){ha=0;for(ia=ka.length;ha<ia;ha++)m.uvs[U][ha]=ka[ha]}m.meshMaterials=Z;m.faceMaterials=ea.materials;m.overdraw=ca;m.z=m.centroidScreen.z;n.push(m)}}else if(P instanceof THREE.Line){K.multiply(E,aa);T=P.geometry.vertices;U=b();U.positionScreen.copy(T[0].position);K.multiplyVector4(U.positionScreen);L=1;for(ea=T.length;L<ea;L++)if(U=b(),U.positionScreen.copy(T[L].position),K.multiplyVector4(U.positionScreen),da=o[k-2],J.copy(U.positionScreen),
S.copy(da.positionScreen),e(J,S))J.multiplyScalar(1/J.w),S.multiplyScalar(1/S.w),aa=B[x]=B[x]||new THREE.RenderableLine,x++,w=aa,w.v1.positionScreen.copy(J),w.v2.positionScreen.copy(S),w.z=Math.max(J.z,S.z),w.materials=P.materials,n.push(w)}else if(P instanceof THREE.Particle&&(I.set(P.matrixWorld.n14,P.matrixWorld.n24,P.matrixWorld.n34,1),E.multiplyVector4(I),I.z/=I.w,I.z>0&&I.z<1))aa=y[H]=y[H]||new THREE.RenderableParticle,H++,A=aa,A.x=I.x/I.w,A.y=I.y/I.w,A.z=I.z,A.rotation=P.rotation.z,A.scale.x=
P.scale.x*Math.abs(A.x-(I.x+g.projectionMatrix.n11)/(I.w+g.projectionMatrix.n14)),A.scale.y=P.scale.y*Math.abs(A.y-(I.y+g.projectionMatrix.n22)/(I.w+g.projectionMatrix.n24)),A.materials=P.materials,n.push(A);j&&n.sort(c);return n}};
THREE.DOMRenderer=function(){THREE.Renderer.call(this);var b=null,c=new THREE.Projector,e,f,g,j;this.domElement=document.createElement("div");this.setSize=function(b,c){e=b;f=c;g=e/2;j=f/2};this.render=function(e,f){var o,m,p,u,v,t,w,x;b=c.projectScene(e,f);o=0;for(m=b.length;o<m;o++)if(v=b[o],v instanceof THREE.RenderableParticle){w=v.x*g+g;x=v.y*j+j;p=0;for(u=v.material.length;p<u;p++)if(t=v.material[p],t instanceof THREE.ParticleDOMMaterial)t=t.domElement,t.style.left=w+"px",t.style.top=x+"px"}}};
THREE.CanvasRenderer=function(b){function c(b){if(B!=b)t.globalAlpha=B=b}function e(b){if(A!=b){switch(b){case THREE.NormalBlending:t.globalCompositeOperation="source-over";break;case THREE.AdditiveBlending:t.globalCompositeOperation="lighter";break;case THREE.SubtractiveBlending:t.globalCompositeOperation="darker"}A=b}}function f(b){if(H!=b)t.strokeStyle=H=b}function g(b){if(y!=b)t.fillStyle=y=b}var j=this,h=null,k=new THREE.Projector,b=b||{},o=b.canvas!==void 0?b.canvas:document.createElement("canvas"),
m,p,u,v,t=o.getContext("2d"),w=new THREE.Color(0),x=0,B=1,A=0,H=null,y=null,G=null,I=null,E=null,K,D,J,S,X=new THREE.RenderableVertex,R=new THREE.RenderableVertex,C,n,W,V,fa,L,ea,T,U,da,ha,ia,M=new THREE.Color(0),P=new THREE.Color(0),aa=new THREE.Color(0),Y=new THREE.Color(0),Z=new THREE.Color(0),ca=[],ja,la,ka,pa,sa,ua,Ia,Ja,Ka,va,ya=new THREE.Rectangle,$=new THREE.Rectangle,ta=new THREE.Rectangle,Ea=!1,oa=new THREE.Color,ma=new THREE.Color,Ga=new THREE.Color,Da=new THREE.Color,N=new THREE.Vector3,
za,ga,Ya,Aa,Ba,Va,b=16;za=document.createElement("canvas");za.width=za.height=2;ga=za.getContext("2d");ga.fillStyle="rgba(0,0,0,1)";ga.fillRect(0,0,2,2);Ya=ga.getImageData(0,0,2,2);Aa=Ya.data;Ba=document.createElement("canvas");Ba.width=Ba.height=b;Va=Ba.getContext("2d");Va.translate(-b/2,-b/2);Va.scale(b,b);b--;this.domElement=o;this.sortElements=this.sortObjects=this.autoClear=!0;this.data={vertices:0,faces:0};this.setSize=function(b,c){m=b;p=c;u=Math.floor(m/2);v=Math.floor(p/2);o.width=m;o.height=
p;ya.set(-u,-v,u,v);$.set(-u,-v,u,v);B=1;A=0;E=I=G=y=H=null};this.setClearColor=function(b,c){w.copy(b);x=c;$.set(-u,-v,u,v)};this.setClearColorHex=function(b,c){w.setHex(b);x=c;$.set(-u,-v,u,v)};this.clear=function(){t.setTransform(1,0,0,-1,u,v);$.isEmpty()||($.minSelf(ya),$.inflate(2),x<1&&t.clearRect(Math.floor($.getX()),Math.floor($.getY()),Math.floor($.getWidth()),Math.floor($.getHeight())),x>0&&(e(THREE.NormalBlending),c(1),g("rgba("+Math.floor(w.r*255)+","+Math.floor(w.g*255)+","+Math.floor(w.b*
255)+","+x+")"),t.fillRect(Math.floor($.getX()),Math.floor($.getY()),Math.floor($.getWidth()),Math.floor($.getHeight()))),$.empty())};this.render=function(b,o){function m(b){var c,e,f,h=b.lights;ma.setRGB(0,0,0);Ga.setRGB(0,0,0);Da.setRGB(0,0,0);b=0;for(c=h.length;b<c;b++)e=h[b],f=e.color,e instanceof THREE.AmbientLight?(ma.r+=f.r,ma.g+=f.g,ma.b+=f.b):e instanceof THREE.DirectionalLight?(Ga.r+=f.r,Ga.g+=f.g,Ga.b+=f.b):e instanceof THREE.PointLight&&(Da.r+=f.r,Da.g+=f.g,Da.b+=f.b)}function p(b,c,e,
f){var h,g,j,k,n=b.lights,b=0;for(h=n.length;b<h;b++)g=n[b],j=g.color,g instanceof THREE.DirectionalLight?(k=e.dot(g.position),k<=0||(k*=g.intensity,f.r+=j.r*k,f.g+=j.g*k,f.b+=j.b*k)):g instanceof THREE.PointLight&&(k=e.dot(N.sub(g.position,c).normalize()),k<=0||(k*=g.distance==0?1:1-Math.min(c.distanceTo(g.position)/g.distance,1),k!=0&&(k*=g.intensity,f.r+=j.r*k,f.g+=j.g*k,f.b+=j.b*k)))}function w(b,h,j){c(j.opacity);e(j.blending);var k,n,o,m,p,ga;if(j instanceof THREE.ParticleBasicMaterial){if(j.map)m=
j.map.image,p=m.width>>1,ga=m.height>>1,j=h.scale.x*u,o=h.scale.y*v,k=j*p,n=o*ga,ta.set(b.x-k,b.y-n,b.x+k,b.y+n),ya.instersects(ta)&&(t.save(),t.translate(b.x,b.y),t.rotate(-h.rotation),t.scale(j,-o),t.translate(-p,-ga),t.drawImage(m,0,0),t.restore())}else j instanceof THREE.ParticleCanvasMaterial&&(k=h.scale.x*u,n=h.scale.y*v,ta.set(b.x-k,b.y-n,b.x+k,b.y+n),ya.instersects(ta)&&(f(j.color.getContextStyle()),g(j.color.getContextStyle()),t.save(),t.translate(b.x,b.y),t.rotate(-h.rotation),t.scale(k,
n),j.program(t),t.restore()))}function x(b,h,g,j){c(j.opacity);e(j.blending);t.beginPath();t.moveTo(b.positionScreen.x,b.positionScreen.y);t.lineTo(h.positionScreen.x,h.positionScreen.y);t.closePath();if(j instanceof THREE.LineBasicMaterial){b=j.linewidth;if(G!=b)t.lineWidth=G=b;b=j.linecap;if(I!=b)t.lineCap=I=b;b=j.linejoin;if(E!=b)t.lineJoin=E=b;f(j.color.getContextStyle());t.stroke();ta.inflate(j.linewidth*2)}}function A(b,f,h,g,k,m,u,t,ga){j.data.vertices+=3;j.data.faces++;c(t.opacity);e(t.blending);
C=b.positionScreen.x;n=b.positionScreen.y;W=f.positionScreen.x;V=f.positionScreen.y;fa=h.positionScreen.x;L=h.positionScreen.y;y(C,n,W,V,fa,L);if(t instanceof THREE.MeshBasicMaterial)if(t.map)t.map.mapping instanceof THREE.UVMapping&&(pa=u.uvs[0],Za(C,n,W,V,fa,L,pa[g].u,pa[g].v,pa[k].u,pa[k].v,pa[m].u,pa[m].v,t.map));else if(t.envMap){if(t.envMap.mapping instanceof THREE.SphericalReflectionMapping)b=o.matrixWorldInverse,N.copy(u.vertexNormalsWorld[0]),sa=(N.x*b.n11+N.y*b.n12+N.z*b.n13)*0.5+0.5,ua=
-(N.x*b.n21+N.y*b.n22+N.z*b.n23)*0.5+0.5,N.copy(u.vertexNormalsWorld[1]),Ia=(N.x*b.n11+N.y*b.n12+N.z*b.n13)*0.5+0.5,Ja=-(N.x*b.n21+N.y*b.n22+N.z*b.n23)*0.5+0.5,N.copy(u.vertexNormalsWorld[2]),Ka=(N.x*b.n11+N.y*b.n12+N.z*b.n13)*0.5+0.5,va=-(N.x*b.n21+N.y*b.n22+N.z*b.n23)*0.5+0.5,Za(C,n,W,V,fa,L,sa,ua,Ia,Ja,Ka,va,t.envMap)}else t.wireframe?La(t.color,t.wireframeLinewidth,t.wireframeLinecap,t.wireframeLinejoin):Ma(t.color);else if(t instanceof THREE.MeshLambertMaterial)t.map&&!t.wireframe&&(t.map.mapping instanceof
THREE.UVMapping&&(pa=u.uvs[0],Za(C,n,W,V,fa,L,pa[g].u,pa[g].v,pa[k].u,pa[k].v,pa[m].u,pa[m].v,t.map)),e(THREE.SubtractiveBlending)),Ea?!t.wireframe&&t.shading==THREE.SmoothShading&&u.vertexNormalsWorld.length==3?(P.r=aa.r=Y.r=ma.r,P.g=aa.g=Y.g=ma.g,P.b=aa.b=Y.b=ma.b,p(ga,u.v1.positionWorld,u.vertexNormalsWorld[0],P),p(ga,u.v2.positionWorld,u.vertexNormalsWorld[1],aa),p(ga,u.v3.positionWorld,u.vertexNormalsWorld[2],Y),Z.r=(aa.r+Y.r)*0.5,Z.g=(aa.g+Y.g)*0.5,Z.b=(aa.b+Y.b)*0.5,ka=Wa(P,aa,Y,Z),Ta(C,n,
W,V,fa,L,0,0,1,0,0,1,ka)):(oa.r=ma.r,oa.g=ma.g,oa.b=ma.b,p(ga,u.centroidWorld,u.normalWorld,oa),M.r=Math.max(0,Math.min(t.color.r*oa.r,1)),M.g=Math.max(0,Math.min(t.color.g*oa.g,1)),M.b=Math.max(0,Math.min(t.color.b*oa.b,1)),t.wireframe?La(M,t.wireframeLinewidth,t.wireframeLinecap,t.wireframeLinejoin):Ma(M)):t.wireframe?La(t.color,t.wireframeLinewidth,t.wireframeLinecap,t.wireframeLinejoin):Ma(t.color);else if(t instanceof THREE.MeshDepthMaterial)ja=o.near,la=o.far,P.r=P.g=P.b=1-Oa(b.positionScreen.z,
ja,la),aa.r=aa.g=aa.b=1-Oa(f.positionScreen.z,ja,la),Y.r=Y.g=Y.b=1-Oa(h.positionScreen.z,ja,la),Z.r=(aa.r+Y.r)*0.5,Z.g=(aa.g+Y.g)*0.5,Z.b=(aa.b+Y.b)*0.5,ka=Wa(P,aa,Y,Z),Ta(C,n,W,V,fa,L,0,0,1,0,0,1,ka);else if(t instanceof THREE.MeshNormalMaterial)M.r=Ua(u.normalWorld.x),M.g=Ua(u.normalWorld.y),M.b=Ua(u.normalWorld.z),t.wireframe?La(M,t.wireframeLinewidth,t.wireframeLinecap,t.wireframeLinejoin):Ma(M)}function B(b,f,h,g,k,u,t,m,ga){j.data.vertices+=4;j.data.faces++;c(m.opacity);e(m.blending);if(m.map||
m.envMap)A(b,f,g,0,1,3,t,m,ga),A(k,h,u,1,2,3,t,m,ga);else if(C=b.positionScreen.x,n=b.positionScreen.y,W=f.positionScreen.x,V=f.positionScreen.y,fa=h.positionScreen.x,L=h.positionScreen.y,ea=g.positionScreen.x,T=g.positionScreen.y,U=k.positionScreen.x,da=k.positionScreen.y,ha=u.positionScreen.x,ia=u.positionScreen.y,m instanceof THREE.MeshBasicMaterial)H(C,n,W,V,fa,L,ea,T),m.wireframe?La(m.color,m.wireframeLinewidth,m.wireframeLinecap,m.wireframeLinejoin):Ma(m.color);else if(m instanceof THREE.MeshLambertMaterial)Ea?
!m.wireframe&&m.shading==THREE.SmoothShading&&t.vertexNormalsWorld.length==4?(P.r=aa.r=Y.r=Z.r=ma.r,P.g=aa.g=Y.g=Z.g=ma.g,P.b=aa.b=Y.b=Z.b=ma.b,p(ga,t.v1.positionWorld,t.vertexNormalsWorld[0],P),p(ga,t.v2.positionWorld,t.vertexNormalsWorld[1],aa),p(ga,t.v4.positionWorld,t.vertexNormalsWorld[3],Y),p(ga,t.v3.positionWorld,t.vertexNormalsWorld[2],Z),ka=Wa(P,aa,Y,Z),y(C,n,W,V,ea,T),Ta(C,n,W,V,ea,T,0,0,1,0,0,1,ka),y(U,da,fa,L,ha,ia),Ta(U,da,fa,L,ha,ia,1,0,1,1,0,1,ka)):(oa.r=ma.r,oa.g=ma.g,oa.b=ma.b,p(ga,
t.centroidWorld,t.normalWorld,oa),M.r=Math.max(0,Math.min(m.color.r*oa.r,1)),M.g=Math.max(0,Math.min(m.color.g*oa.g,1)),M.b=Math.max(0,Math.min(m.color.b*oa.b,1)),H(C,n,W,V,fa,L,ea,T),m.wireframe?La(M,m.wireframeLinewidth,m.wireframeLinecap,m.wireframeLinejoin):Ma(M)):(H(C,n,W,V,fa,L,ea,T),m.wireframe?La(m.color,m.wireframeLinewidth,m.wireframeLinecap,m.wireframeLinejoin):Ma(m.color));else if(m instanceof THREE.MeshNormalMaterial)M.r=Ua(t.normalWorld.x),M.g=Ua(t.normalWorld.y),M.b=Ua(t.normalWorld.z),
H(C,n,W,V,fa,L,ea,T),m.wireframe?La(M,m.wireframeLinewidth,m.wireframeLinecap,m.wireframeLinejoin):Ma(M);else if(m instanceof THREE.MeshDepthMaterial)ja=o.near,la=o.far,P.r=P.g=P.b=1-Oa(b.positionScreen.z,ja,la),aa.r=aa.g=aa.b=1-Oa(f.positionScreen.z,ja,la),Y.r=Y.g=Y.b=1-Oa(g.positionScreen.z,ja,la),Z.r=Z.g=Z.b=1-Oa(h.positionScreen.z,ja,la),ka=Wa(P,aa,Y,Z),y(C,n,W,V,ea,T),Ta(C,n,W,V,ea,T,0,0,1,0,0,1,ka),y(U,da,fa,L,ha,ia),Ta(U,da,fa,L,ha,ia,1,0,1,1,0,1,ka)}function y(b,c,e,f,h,g){t.beginPath();t.moveTo(b,
c);t.lineTo(e,f);t.lineTo(h,g);t.lineTo(b,c);t.closePath()}function H(b,c,e,f,h,g,j,k){t.beginPath();t.moveTo(b,c);t.lineTo(e,f);t.lineTo(h,g);t.lineTo(j,k);t.lineTo(b,c);t.closePath()}function La(b,c,e,h){if(G!=c)t.lineWidth=G=c;if(I!=e)t.lineCap=I=e;if(E!=h)t.lineJoin=E=h;f(b.getContextStyle());t.stroke();ta.inflate(c*2)}function Ma(b){g(b.getContextStyle());t.fill()}function Za(b,c,e,f,h,j,k,n,o,m,u,p,ga){if(ga.image.width!=0){if(ga.needsUpdate==!0||ca[ga.id]==void 0){var v=ga.wrapS==THREE.RepeatWrapping,
Ba=ga.wrapT==THREE.RepeatWrapping;ca[ga.id]=t.createPattern(ga.image,v&&Ba?"repeat":v&&!Ba?"repeat-x":!v&&Ba?"repeat-y":"no-repeat");ga.needsUpdate=!1}g(ca[ga.id]);var v=ga.offset.x/ga.repeat.x,Ba=ga.offset.y/ga.repeat.y,w=(ga.image.width-1)*ga.repeat.x,ga=(ga.image.height-1)*ga.repeat.y,k=(k+v)*w,n=(n+Ba)*ga,o=(o+v)*w,m=(m+Ba)*ga,u=(u+v)*w,p=(p+Ba)*ga;e-=b;f-=c;h-=b;j-=c;o-=k;m-=n;u-=k;p-=n;v=1/(o*p-u*m);ga=(p*e-m*h)*v;m=(p*f-m*j)*v;e=(o*h-u*e)*v;f=(o*j-u*f)*v;b=b-ga*k-e*n;c=c-m*k-f*n;t.save();t.transform(ga,
m,e,f,b,c);t.fill();t.restore()}}function Ta(b,c,e,f,h,g,j,k,n,o,m,u,ga){var p,v;p=ga.width-1;v=ga.height-1;j*=p;k*=v;n*=p;o*=v;m*=p;u*=v;e-=b;f-=c;h-=b;g-=c;n-=j;o-=k;m-=j;u-=k;v=1/(n*u-m*o);p=(u*e-o*h)*v;o=(u*f-o*g)*v;e=(n*h-m*e)*v;f=(n*g-m*f)*v;b=b-p*j-e*k;c=c-o*j-f*k;t.save();t.transform(p,o,e,f,b,c);t.clip();t.drawImage(ga,0,0);t.restore()}function Wa(b,c,e,f){var h=~~(b.r*255),g=~~(b.g*255),b=~~(b.b*255),j=~~(c.r*255),k=~~(c.g*255),c=~~(c.b*255),n=~~(e.r*255),o=~~(e.g*255),e=~~(e.b*255),m=~~(f.r*
255),u=~~(f.g*255),f=~~(f.b*255);Aa[0]=h<0?0:h>255?255:h;Aa[1]=g<0?0:g>255?255:g;Aa[2]=b<0?0:b>255?255:b;Aa[4]=j<0?0:j>255?255:j;Aa[5]=k<0?0:k>255?255:k;Aa[6]=c<0?0:c>255?255:c;Aa[8]=n<0?0:n>255?255:n;Aa[9]=o<0?0:o>255?255:o;Aa[10]=e<0?0:e>255?255:e;Aa[12]=m<0?0:m>255?255:m;Aa[13]=u<0?0:u>255?255:u;Aa[14]=f<0?0:f>255?255:f;ga.putImageData(Ya,0,0);Va.drawImage(za,0,0);return Ba}function Oa(b,c,e){b=(b-c)/(e-c);return b*b*(3-2*b)}function Ua(b){b=(b+1)*0.5;return b<0?0:b>1?1:b}function Na(b,c){var e=
c.x-b.x,f=c.y-b.y,h=e*e+f*f;h!=0&&(h=1/Math.sqrt(h),e*=h,f*=h,c.x+=e,c.y+=f,b.x-=e,b.y-=f)}var Xa,$a,na,Ca,F,z,Q,wa;this.autoClear?this.clear():t.setTransform(1,0,0,-1,u,v);j.data.vertices=0;j.data.faces=0;h=k.projectScene(b,o,this.sortElements);(Ea=b.lights.length>0)&&m(b);Xa=0;for($a=h.length;Xa<$a;Xa++){na=h[Xa];ta.empty();if(na instanceof THREE.RenderableParticle){K=na;K.x*=u;K.y*=v;Ca=0;for(F=na.materials.length;Ca<F;)wa=na.materials[Ca++],wa.opacity!=0&&w(K,na,wa,b)}else if(na instanceof THREE.RenderableLine){if(K=
na.v1,D=na.v2,K.positionScreen.x*=u,K.positionScreen.y*=v,D.positionScreen.x*=u,D.positionScreen.y*=v,ta.addPoint(K.positionScreen.x,K.positionScreen.y),ta.addPoint(D.positionScreen.x,D.positionScreen.y),ya.instersects(ta)){Ca=0;for(F=na.materials.length;Ca<F;)wa=na.materials[Ca++],wa.opacity!=0&&x(K,D,na,wa,b)}}else if(na instanceof THREE.RenderableFace3){if(K=na.v1,D=na.v2,J=na.v3,K.positionScreen.x*=u,K.positionScreen.y*=v,D.positionScreen.x*=u,D.positionScreen.y*=v,J.positionScreen.x*=u,J.positionScreen.y*=
v,na.overdraw&&(Na(K.positionScreen,D.positionScreen),Na(D.positionScreen,J.positionScreen),Na(J.positionScreen,K.positionScreen)),ta.add3Points(K.positionScreen.x,K.positionScreen.y,D.positionScreen.x,D.positionScreen.y,J.positionScreen.x,J.positionScreen.y),ya.instersects(ta)){Ca=0;for(F=na.meshMaterials.length;Ca<F;)if(wa=na.meshMaterials[Ca++],wa instanceof THREE.MeshFaceMaterial){z=0;for(Q=na.faceMaterials.length;z<Q;)(wa=na.faceMaterials[z++])&&wa.opacity!=0&&A(K,D,J,0,1,2,na,wa,b)}else wa.opacity!=
0&&A(K,D,J,0,1,2,na,wa,b)}}else if(na instanceof THREE.RenderableFace4&&(K=na.v1,D=na.v2,J=na.v3,S=na.v4,K.positionScreen.x*=u,K.positionScreen.y*=v,D.positionScreen.x*=u,D.positionScreen.y*=v,J.positionScreen.x*=u,J.positionScreen.y*=v,S.positionScreen.x*=u,S.positionScreen.y*=v,X.positionScreen.copy(D.positionScreen),R.positionScreen.copy(S.positionScreen),na.overdraw&&(Na(K.positionScreen,D.positionScreen),Na(D.positionScreen,S.positionScreen),Na(S.positionScreen,K.positionScreen),Na(J.positionScreen,
X.positionScreen),Na(J.positionScreen,R.positionScreen)),ta.addPoint(K.positionScreen.x,K.positionScreen.y),ta.addPoint(D.positionScreen.x,D.positionScreen.y),ta.addPoint(J.positionScreen.x,J.positionScreen.y),ta.addPoint(S.positionScreen.x,S.positionScreen.y),ya.instersects(ta))){Ca=0;for(F=na.meshMaterials.length;Ca<F;)if(wa=na.meshMaterials[Ca++],wa instanceof THREE.MeshFaceMaterial){z=0;for(Q=na.faceMaterials.length;z<Q;)(wa=na.faceMaterials[z++])&&wa.opacity!=0&&B(K,D,J,S,X,R,na,wa,b)}else wa.opacity!=
0&&B(K,D,J,S,X,R,na,wa,b)}$.addRectangle(ta)}t.setTransform(1,0,0,1,0,0)}};
THREE.SVGRenderer=function(){function b(b,c,e){var f,h,g,j;f=0;for(h=b.lights.length;f<h;f++)g=b.lights[f],g instanceof THREE.DirectionalLight?(j=c.normalWorld.dot(g.position)*g.intensity,j>0&&(e.r+=g.color.r*j,e.g+=g.color.g*j,e.b+=g.color.b*j)):g instanceof THREE.PointLight&&(S.sub(g.position,c.centroidWorld),S.normalize(),j=c.normalWorld.dot(S)*g.intensity,j>0&&(e.r+=g.color.r*j,e.g+=g.color.g*j,e.b+=g.color.b*j))}function c(c,e,h,k,m,u){j.data.vertices+=3;j.data.faces++;C=f(n++);C.setAttribute("d",
"M "+c.positionScreen.x+" "+c.positionScreen.y+" L "+e.positionScreen.x+" "+e.positionScreen.y+" L "+h.positionScreen.x+","+h.positionScreen.y+"z");m instanceof THREE.MeshBasicMaterial?G.copy(m.color):m instanceof THREE.MeshLambertMaterial?y?(I.r=E.r,I.g=E.g,I.b=E.b,b(u,k,I),G.r=Math.max(0,Math.min(m.color.r*I.r,1)),G.g=Math.max(0,Math.min(m.color.g*I.g,1)),G.b=Math.max(0,Math.min(m.color.b*I.b,1))):G.copy(m.color):m instanceof THREE.MeshDepthMaterial?(J=1-m.__2near/(m.__farPlusNear-k.z*m.__farMinusNear),
G.setRGB(J,J,J)):m instanceof THREE.MeshNormalMaterial&&G.setRGB(g(k.normalWorld.x),g(k.normalWorld.y),g(k.normalWorld.z));m.wireframe?C.setAttribute("style","fill: none; stroke: "+G.getContextStyle()+"; stroke-width: "+m.wireframeLinewidth+"; stroke-opacity: "+m.opacity+"; stroke-linecap: "+m.wireframeLinecap+"; stroke-linejoin: "+m.wireframeLinejoin):C.setAttribute("style","fill: "+G.getContextStyle()+"; fill-opacity: "+m.opacity);o.appendChild(C)}function e(c,e,h,k,m,u,t){j.data.vertices+=4;j.data.faces++;
C=f(n++);C.setAttribute("d","M "+c.positionScreen.x+" "+c.positionScreen.y+" L "+e.positionScreen.x+" "+e.positionScreen.y+" L "+h.positionScreen.x+","+h.positionScreen.y+" L "+k.positionScreen.x+","+k.positionScreen.y+"z");u instanceof THREE.MeshBasicMaterial?G.copy(u.color):u instanceof THREE.MeshLambertMaterial?y?(I.r=E.r,I.g=E.g,I.b=E.b,b(t,m,I),G.r=Math.max(0,Math.min(u.color.r*I.r,1)),G.g=Math.max(0,Math.min(u.color.g*I.g,1)),G.b=Math.max(0,Math.min(u.color.b*I.b,1))):G.copy(u.color):u instanceof
THREE.MeshDepthMaterial?(J=1-u.__2near/(u.__farPlusNear-m.z*u.__farMinusNear),G.setRGB(J,J,J)):u instanceof THREE.MeshNormalMaterial&&G.setRGB(g(m.normalWorld.x),g(m.normalWorld.y),g(m.normalWorld.z));u.wireframe?C.setAttribute("style","fill: none; stroke: "+G.getContextStyle()+"; stroke-width: "+u.wireframeLinewidth+"; stroke-opacity: "+u.opacity+"; stroke-linecap: "+u.wireframeLinecap+"; stroke-linejoin: "+u.wireframeLinejoin):C.setAttribute("style","fill: "+G.getContextStyle()+"; fill-opacity: "+
u.opacity);o.appendChild(C)}function f(b){X[b]==null&&(X[b]=document.createElementNS("http://www.w3.org/2000/svg","path"),V==0&&X[b].setAttribute("shape-rendering","crispEdges"));return X[b]}function g(b){b=(b+1)*0.5;return b<0?0:b>1?1:b}var j=this,h=null,k=new THREE.Projector,o=document.createElementNS("http://www.w3.org/2000/svg","svg"),m,p,u,v,t,w,x,B,A=new THREE.Rectangle,H=new THREE.Rectangle,y=!1,G=new THREE.Color(16777215),I=new THREE.Color(16777215),E=new THREE.Color(0),K=new THREE.Color(0),
D=new THREE.Color(0),J,S=new THREE.Vector3,X=[],R=[],C,n,W,V=1;this.domElement=o;this.sortElements=this.sortObjects=this.autoClear=!0;this.data={vertices:0,faces:0};this.setQuality=function(b){switch(b){case "high":V=1;break;case "low":V=0}};this.setSize=function(b,c){m=b;p=c;u=m/2;v=p/2;o.setAttribute("viewBox",-u+" "+-v+" "+m+" "+p);o.setAttribute("width",m);o.setAttribute("height",p);A.set(-u,-v,u,v)};this.clear=function(){for(;o.childNodes.length>0;)o.removeChild(o.childNodes[0])};this.render=
function(b,f){var g,m,p,G,I,J,M,P;this.autoClear&&this.clear();j.data.vertices=0;j.data.faces=0;h=k.projectScene(b,f,this.sortElements);W=n=0;if(y=b.lights.length>0){M=b.lights;E.setRGB(0,0,0);K.setRGB(0,0,0);D.setRGB(0,0,0);g=0;for(m=M.length;g<m;g++)p=M[g],G=p.color,p instanceof THREE.AmbientLight?(E.r+=G.r,E.g+=G.g,E.b+=G.b):p instanceof THREE.DirectionalLight?(K.r+=G.r,K.g+=G.g,K.b+=G.b):p instanceof THREE.PointLight&&(D.r+=G.r,D.g+=G.g,D.b+=G.b)}g=0;for(m=h.length;g<m;g++)if(M=h[g],H.empty(),
M instanceof THREE.RenderableParticle){t=M;t.x*=u;t.y*=-v;p=0;for(G=M.materials.length;p<G;)p++}else if(M instanceof THREE.RenderableLine){if(t=M.v1,w=M.v2,t.positionScreen.x*=u,t.positionScreen.y*=-v,w.positionScreen.x*=u,w.positionScreen.y*=-v,H.addPoint(t.positionScreen.x,t.positionScreen.y),H.addPoint(w.positionScreen.x,w.positionScreen.y),A.instersects(H)){p=0;for(G=M.materials.length;p<G;)if((P=M.materials[p++])&&P.opacity!=0){I=t;J=w;var S=W++;R[S]==null&&(R[S]=document.createElementNS("http://www.w3.org/2000/svg",
"line"),V==0&&R[S].setAttribute("shape-rendering","crispEdges"));C=R[S];C.setAttribute("x1",I.positionScreen.x);C.setAttribute("y1",I.positionScreen.y);C.setAttribute("x2",J.positionScreen.x);C.setAttribute("y2",J.positionScreen.y);P instanceof THREE.LineBasicMaterial&&(C.setAttribute("style","fill: none; stroke: "+P.color.getContextStyle()+"; stroke-width: "+P.linewidth+"; stroke-opacity: "+P.opacity+"; stroke-linecap: "+P.linecap+"; stroke-linejoin: "+P.linejoin),o.appendChild(C))}}}else if(M instanceof
THREE.RenderableFace3){if(t=M.v1,w=M.v2,x=M.v3,t.positionScreen.x*=u,t.positionScreen.y*=-v,w.positionScreen.x*=u,w.positionScreen.y*=-v,x.positionScreen.x*=u,x.positionScreen.y*=-v,H.addPoint(t.positionScreen.x,t.positionScreen.y),H.addPoint(w.positionScreen.x,w.positionScreen.y),H.addPoint(x.positionScreen.x,x.positionScreen.y),A.instersects(H)){p=0;for(G=M.meshMaterials.length;p<G;)if(P=M.meshMaterials[p++],P instanceof THREE.MeshFaceMaterial){I=0;for(J=M.faceMaterials.length;I<J;)(P=M.faceMaterials[I++])&&
P.opacity!=0&&c(t,w,x,M,P,b)}else P&&P.opacity!=0&&c(t,w,x,M,P,b)}}else if(M instanceof THREE.RenderableFace4&&(t=M.v1,w=M.v2,x=M.v3,B=M.v4,t.positionScreen.x*=u,t.positionScreen.y*=-v,w.positionScreen.x*=u,w.positionScreen.y*=-v,x.positionScreen.x*=u,x.positionScreen.y*=-v,B.positionScreen.x*=u,B.positionScreen.y*=-v,H.addPoint(t.positionScreen.x,t.positionScreen.y),H.addPoint(w.positionScreen.x,w.positionScreen.y),H.addPoint(x.positionScreen.x,x.positionScreen.y),H.addPoint(B.positionScreen.x,B.positionScreen.y),
A.instersects(H))){p=0;for(G=M.meshMaterials.length;p<G;)if(P=M.meshMaterials[p++],P instanceof THREE.MeshFaceMaterial){I=0;for(J=M.faceMaterials.length;I<J;)(P=M.faceMaterials[I++])&&P.opacity!=0&&e(t,w,x,B,M,P,b)}else P&&P.opacity!=0&&e(t,w,x,B,M,P,b)}}};
THREE.ShaderChunk={fog_pars_fragment:"#ifdef USE_FOG\nuniform vec3 fogColor;\n#ifdef FOG_EXP2\nuniform float fogDensity;\n#else\nuniform float fogNear;\nuniform float fogFar;\n#endif\n#endif",fog_fragment:"#ifdef USE_FOG\nfloat depth = gl_FragCoord.z / gl_FragCoord.w;\n#ifdef FOG_EXP2\nconst float LOG2 = 1.442695;\nfloat fogFactor = exp2( - fogDensity * fogDensity * depth * depth * LOG2 );\nfogFactor = 1.0 - clamp( fogFactor, 0.0, 1.0 );\n#else\nfloat fogFactor = smoothstep( fogNear, fogFar, depth );\n#endif\ngl_FragColor = mix( gl_FragColor, vec4( fogColor, gl_FragColor.w ), fogFactor );\n#endif",envmap_pars_fragment:"#ifdef USE_ENVMAP\nvarying vec3 vReflect;\nuniform float reflectivity;\nuniform samplerCube envMap;\nuniform int combine;\n#endif",
envmap_fragment:"#ifdef USE_ENVMAP\nvec4 cubeColor = textureCube( envMap, vec3( -vReflect.x, vReflect.yz ) );\nif ( combine == 1 ) {\ngl_FragColor = vec4( mix( gl_FragColor.xyz, cubeColor.xyz, reflectivity ), opacity );\n} else {\ngl_FragColor = gl_FragColor * cubeColor;\n}\n#endif",envmap_pars_vertex:"#ifdef USE_ENVMAP\nvarying vec3 vReflect;\nuniform float refractionRatio;\nuniform bool useRefract;\n#endif",envmap_vertex:"#ifdef USE_ENVMAP\nvec4 mPosition = objectMatrix * vec4( position, 1.0 );\nvec3 nWorld = mat3( objectMatrix[ 0 ].xyz, objectMatrix[ 1 ].xyz, objectMatrix[ 2 ].xyz ) * normal;\nif ( useRefract ) {\nvReflect = refract( normalize( mPosition.xyz - cameraPosition ), normalize( nWorld.xyz ), refractionRatio );\n} else {\nvReflect = reflect( normalize( mPosition.xyz - cameraPosition ), normalize( nWorld.xyz ) );\n}\n#endif",
map_particle_pars_fragment:"#ifdef USE_MAP\nuniform sampler2D map;\n#endif",map_particle_fragment:"#ifdef USE_MAP\ngl_FragColor = gl_FragColor * texture2D( map, gl_PointCoord );\n#endif",map_pars_vertex:"#ifdef USE_MAP\nvarying vec2 vUv;\nuniform vec4 offsetRepeat;\n#endif",map_pars_fragment:"#ifdef USE_MAP\nvarying vec2 vUv;\nuniform sampler2D map;\n#endif",map_vertex:"#ifdef USE_MAP\nvUv = uv * offsetRepeat.zw + offsetRepeat.xy;\n#endif",map_fragment:"#ifdef USE_MAP\ngl_FragColor = gl_FragColor * texture2D( map, vUv );\n#endif",
lightmap_pars_fragment:"#ifdef USE_LIGHTMAP\nvarying vec2 vUv2;\nuniform sampler2D lightMap;\n#endif",lightmap_pars_vertex:"#ifdef USE_LIGHTMAP\nvarying vec2 vUv2;\n#endif",lightmap_fragment:"#ifdef USE_LIGHTMAP\ngl_FragColor = gl_FragColor * texture2D( lightMap, vUv2 );\n#endif",lightmap_vertex:"#ifdef USE_LIGHTMAP\nvUv2 = uv2;\n#endif",lights_pars_vertex:"uniform bool enableLighting;\nuniform vec3 ambientLightColor;\n#if MAX_DIR_LIGHTS > 0\nuniform vec3 directionalLightColor[ MAX_DIR_LIGHTS ];\nuniform vec3 directionalLightDirection[ MAX_DIR_LIGHTS ];\n#endif\n#if MAX_POINT_LIGHTS > 0\nuniform vec3 pointLightColor[ MAX_POINT_LIGHTS ];\nuniform vec3 pointLightPosition[ MAX_POINT_LIGHTS ];\nuniform float pointLightDistance[ MAX_POINT_LIGHTS ];\n#ifdef PHONG\nvarying vec4 vPointLight[ MAX_POINT_LIGHTS ];\n#endif\n#endif",
lights_vertex:"if ( !enableLighting ) {\nvLightWeighting = vec3( 1.0 );\n} else {\nvLightWeighting = ambientLightColor;\n#if MAX_DIR_LIGHTS > 0\nfor( int i = 0; i < MAX_DIR_LIGHTS; i ++ ) {\nvec4 lDirection = viewMatrix * vec4( directionalLightDirection[ i ], 0.0 );\nfloat directionalLightWeighting = max( dot( transformedNormal, normalize( lDirection.xyz ) ), 0.0 );\nvLightWeighting += directionalLightColor[ i ] * directionalLightWeighting;\n}\n#endif\n#if MAX_POINT_LIGHTS > 0\nfor( int i = 0; i < MAX_POINT_LIGHTS; i ++ ) {\nvec4 lPosition = viewMatrix * vec4( pointLightPosition[ i ], 1.0 );\nvec3 lVector = lPosition.xyz - mvPosition.xyz;\nfloat lDistance = 1.0;\nif ( pointLightDistance[ i ] > 0.0 )\nlDistance = 1.0 - min( ( length( lVector ) / pointLightDistance[ i ] ), 1.0 );\nlVector = normalize( lVector );\nfloat pointLightWeighting = max( dot( transformedNormal, lVector ), 0.0 );\nvLightWeighting += pointLightColor[ i ] * pointLightWeighting * lDistance;\n#ifdef PHONG\nvPointLight[ i ] = vec4( lVector, lDistance );\n#endif\n}\n#endif\n}",
lights_pars_fragment:"#if MAX_DIR_LIGHTS > 0\nuniform vec3 directionalLightDirection[ MAX_DIR_LIGHTS ];\n#endif\n#if MAX_POINT_LIGHTS > 0\nvarying vec4 vPointLight[ MAX_POINT_LIGHTS ];\n#endif\nvarying vec3 vViewPosition;\nvarying vec3 vNormal;",lights_fragment:"vec3 normal = normalize( vNormal );\nvec3 viewPosition = normalize( vViewPosition );\nvec4 mColor = vec4( diffuse, opacity );\nvec4 mSpecular = vec4( specular, opacity );\n#if MAX_POINT_LIGHTS > 0\nvec4 pointDiffuse  = vec4( vec3( 0.0 ), 1.0 );\nvec4 pointSpecular = vec4( vec3( 0.0 ), 1.0 );\nfor ( int i = 0; i < MAX_POINT_LIGHTS; i ++ ) {\nvec3 pointVector = normalize( vPointLight[ i ].xyz );\nvec3 pointHalfVector = normalize( vPointLight[ i ].xyz + viewPosition );\nfloat pointDistance = vPointLight[ i ].w;\nfloat pointDotNormalHalf = dot( normal, pointHalfVector );\nfloat pointDiffuseWeight = max( dot( normal, pointVector ), 0.0 );\nfloat pointSpecularWeight = 0.0;\nif ( pointDotNormalHalf >= 0.0 )\npointSpecularWeight = pow( pointDotNormalHalf, shininess );\npointDiffuse  += mColor * pointDiffuseWeight * pointDistance;\npointSpecular += mSpecular * pointSpecularWeight * pointDistance;\n}\n#endif\n#if MAX_DIR_LIGHTS > 0\nvec4 dirDiffuse  = vec4( vec3( 0.0 ), 1.0 );\nvec4 dirSpecular = vec4( vec3( 0.0 ), 1.0 );\nfor( int i = 0; i < MAX_DIR_LIGHTS; i ++ ) {\nvec4 lDirection = viewMatrix * vec4( directionalLightDirection[ i ], 0.0 );\nvec3 dirVector = normalize( lDirection.xyz );\nvec3 dirHalfVector = normalize( lDirection.xyz + viewPosition );\nfloat dirDotNormalHalf = dot( normal, dirHalfVector );\nfloat dirDiffuseWeight = max( dot( normal, dirVector ), 0.0 );\nfloat dirSpecularWeight = 0.0;\nif ( dirDotNormalHalf >= 0.0 )\ndirSpecularWeight = pow( dirDotNormalHalf, shininess );\ndirDiffuse  += mColor * dirDiffuseWeight;\ndirSpecular += mSpecular * dirSpecularWeight;\n}\n#endif\nvec4 totalLight = vec4( ambient, opacity );\n#if MAX_DIR_LIGHTS > 0\ntotalLight += dirDiffuse + dirSpecular;\n#endif\n#if MAX_POINT_LIGHTS > 0\ntotalLight += pointDiffuse + pointSpecular;\n#endif\ngl_FragColor = gl_FragColor * totalLight;",
color_pars_fragment:"#ifdef USE_COLOR\nvarying vec3 vColor;\n#endif",color_fragment:"#ifdef USE_COLOR\ngl_FragColor = gl_FragColor * vec4( vColor, opacity );\n#endif",color_pars_vertex:"#ifdef USE_COLOR\nvarying vec3 vColor;\n#endif",color_vertex:"#ifdef USE_COLOR\nvColor = color;\n#endif",skinning_pars_vertex:"#ifdef USE_SKINNING\nuniform mat4 boneGlobalMatrices[ MAX_BONES ];\n#endif",skinning_vertex:"#ifdef USE_SKINNING\ngl_Position  = ( boneGlobalMatrices[ int( skinIndex.x ) ] * skinVertexA ) * skinWeight.x;\ngl_Position += ( boneGlobalMatrices[ int( skinIndex.y ) ] * skinVertexB ) * skinWeight.y;\ngl_Position  = projectionMatrix * viewMatrix * objectMatrix * gl_Position;\n#endif",
morphtarget_pars_vertex:"#ifdef USE_MORPHTARGETS\nuniform float morphTargetInfluences[ 8 ];\n#endif",morphtarget_vertex:"#ifdef USE_MORPHTARGETS\nvec3 morphed = vec3( 0.0, 0.0, 0.0 );\nmorphed += ( morphTarget0 - position ) * morphTargetInfluences[ 0 ];\nmorphed += ( morphTarget1 - position ) * morphTargetInfluences[ 1 ];\nmorphed += ( morphTarget2 - position ) * morphTargetInfluences[ 2 ];\nmorphed += ( morphTarget3 - position ) * morphTargetInfluences[ 3 ];\nmorphed += ( morphTarget4 - position ) * morphTargetInfluences[ 4 ];\nmorphed += ( morphTarget5 - position ) * morphTargetInfluences[ 5 ];\nmorphed += ( morphTarget6 - position ) * morphTargetInfluences[ 6 ];\nmorphed += ( morphTarget7 - position ) * morphTargetInfluences[ 7 ];\nmorphed += position;\ngl_Position = projectionMatrix * modelViewMatrix * vec4( morphed, 1.0 );\n#endif",
default_vertex:"#ifndef USE_MORPHTARGETS\n#ifndef USE_SKINNING\ngl_Position = projectionMatrix * mvPosition;\n#endif\n#endif",shadowmap_pars_fragment:"#ifdef USE_SHADOWMAP\nuniform sampler2D shadowMap[ MAX_SHADOWS ];\nuniform float shadowDarkness;\nuniform float shadowBias;\nvarying vec4 vShadowCoord[ MAX_SHADOWS ];\nfloat unpackDepth( const in vec4 rgba_depth ) {\nconst vec4 bit_shift = vec4( 1.0 / ( 256.0 * 256.0 * 256.0 ), 1.0 / ( 256.0 * 256.0 ), 1.0 / 256.0, 1.0 );\nfloat depth = dot( rgba_depth, bit_shift );\nreturn depth;\n}\n#endif",
shadowmap_fragment:"#ifdef USE_SHADOWMAP\n#ifdef SHADOWMAP_SOFT\nconst float xPixelOffset = 1.0 / SHADOWMAP_WIDTH;\nconst float yPixelOffset = 1.0 / SHADOWMAP_HEIGHT;\n#endif\nvec4 shadowColor = vec4( 1.0 );\nfor( int i = 0; i < MAX_SHADOWS; i ++ ) {\nvec3 shadowCoord = vShadowCoord[ i ].xyz / vShadowCoord[ i ].w;\nif ( shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0 ) {\n#ifdef SHADOWMAP_SOFT\nfloat shadow = 0.0;\nfor ( float y = -1.25; y <= 1.25; y += 1.25 )\nfor ( float x = -1.25; x <= 1.25; x += 1.25 ) {\nvec4 rgbaDepth = texture2D( shadowMap[ i ], vec2( x * xPixelOffset, y * yPixelOffset ) + shadowCoord.xy );\nfloat fDepth = unpackDepth( rgbaDepth );\nif ( fDepth < ( shadowCoord.z + shadowBias ) )\nshadow += 1.0;\n}\nshadow /= 9.0;\nshadowColor = shadowColor * vec4( vec3( ( 1.0 - shadowDarkness * shadow ) ), 1.0 );\n#else\nvec4 rgbaDepth = texture2D( shadowMap[ i ], shadowCoord.xy );\nfloat fDepth = unpackDepth( rgbaDepth );\nif ( fDepth < ( shadowCoord.z + shadowBias ) )\nshadowColor = shadowColor * vec4( vec3( shadowDarkness ), 1.0 );\n#endif\n}\n}\ngl_FragColor = gl_FragColor * shadowColor;\n#endif",
shadowmap_pars_vertex:"#ifdef USE_SHADOWMAP\nvarying vec4 vShadowCoord[ MAX_SHADOWS ];\nuniform mat4 shadowMatrix[ MAX_SHADOWS ];\n#endif",shadowmap_vertex:"#ifdef USE_SHADOWMAP\nfor( int i = 0; i < MAX_SHADOWS; i ++ ) {\nvShadowCoord[ i ] = shadowMatrix[ i ] * objectMatrix * vec4( position, 1.0 );\n}\n#endif",alphatest_fragment:"#ifdef ALPHATEST\nif ( gl_FragColor.a < ALPHATEST ) discard;\n#endif"};
THREE.UniformsUtils={merge:function(b){var c,e,f,g={};for(c=0;c<b.length;c++)for(e in f=this.clone(b[c]),f)g[e]=f[e];return g},clone:function(b){var c,e,f,g={};for(c in b)for(e in g[c]={},b[c])f=b[c][e],g[c][e]=f instanceof THREE.Color||f instanceof THREE.Vector2||f instanceof THREE.Vector3||f instanceof THREE.Vector4||f instanceof THREE.Matrix4||f instanceof THREE.Texture?f.clone():f instanceof Array?f.slice():f;return g}};
THREE.UniformsLib={common:{diffuse:{type:"c",value:new THREE.Color(15658734)},opacity:{type:"f",value:1},map:{type:"t",value:0,texture:null},offsetRepeat:{type:"v4",value:new THREE.Vector4(0,0,1,1)},lightMap:{type:"t",value:2,texture:null},envMap:{type:"t",value:1,texture:null},useRefract:{type:"i",value:0},reflectivity:{type:"f",value:1},refractionRatio:{type:"f",value:0.98},combine:{type:"i",value:0},morphTargetInfluences:{type:"f",value:0}},fog:{fogDensity:{type:"f",value:2.5E-4},fogNear:{type:"f",
value:1},fogFar:{type:"f",value:2E3},fogColor:{type:"c",value:new THREE.Color(16777215)}},lights:{enableLighting:{type:"i",value:1},ambientLightColor:{type:"fv",value:[]},directionalLightDirection:{type:"fv",value:[]},directionalLightColor:{type:"fv",value:[]},pointLightColor:{type:"fv",value:[]},pointLightPosition:{type:"fv",value:[]},pointLightDistance:{type:"fv1",value:[]}},particle:{psColor:{type:"c",value:new THREE.Color(15658734)},opacity:{type:"f",value:1},size:{type:"f",value:1},scale:{type:"f",
value:1},map:{type:"t",value:0,texture:null},fogDensity:{type:"f",value:2.5E-4},fogNear:{type:"f",value:1},fogFar:{type:"f",value:2E3},fogColor:{type:"c",value:new THREE.Color(16777215)}},shadowmap:{shadowMap:{type:"tv",value:3,texture:[]},shadowMatrix:{type:"m4v",value:[]},shadowBias:{type:"f",value:0.0039},shadowDarkness:{type:"f",value:0.2}}};
THREE.ShaderLib={lensFlareVertexTexture:{vertexShader:"uniform vec3 screenPosition;\nuniform vec2 scale;\nuniform float rotation;\nuniform int renderType;\nuniform sampler2D occlusionMap;\nattribute vec2 position;\nattribute vec2 UV;\nvarying vec2 vUV;\nvarying float vVisibility;\nvoid main() {\nvUV = UV;\nvec2 pos = position;\nif( renderType == 2 ) {\nvec4 visibility = texture2D( occlusionMap, vec2( 0.1, 0.1 ) ) +\ntexture2D( occlusionMap, vec2( 0.5, 0.1 ) ) +\ntexture2D( occlusionMap, vec2( 0.9, 0.1 ) ) +\ntexture2D( occlusionMap, vec2( 0.9, 0.5 ) ) +\ntexture2D( occlusionMap, vec2( 0.9, 0.9 ) ) +\ntexture2D( occlusionMap, vec2( 0.5, 0.9 ) ) +\ntexture2D( occlusionMap, vec2( 0.1, 0.9 ) ) +\ntexture2D( occlusionMap, vec2( 0.1, 0.5 ) ) +\ntexture2D( occlusionMap, vec2( 0.5, 0.5 ) );\nvVisibility = (       visibility.r / 9.0 ) *\n( 1.0 - visibility.g / 9.0 ) *\n(       visibility.b / 9.0 ) *\n( 1.0 - visibility.a / 9.0 );\npos.x = cos( rotation ) * position.x - sin( rotation ) * position.y;\npos.y = sin( rotation ) * position.x + cos( rotation ) * position.y;\n}\ngl_Position = vec4( ( pos * scale + screenPosition.xy ).xy, screenPosition.z, 1.0 );\n}",fragmentShader:"#ifdef GL_ES\nprecision highp float;\n#endif\nuniform sampler2D map;\nuniform float opacity;\nuniform int renderType;\nvarying vec2 vUV;\nvarying float vVisibility;\nvoid main() {\nif( renderType == 0 ) {\ngl_FragColor = vec4( 1.0, 0.0, 1.0, 0.0 );\n} else if( renderType == 1 ) {\ngl_FragColor = texture2D( map, vUV );\n} else {\nvec4 color = texture2D( map, vUV );\ncolor.a *= opacity * vVisibility;\ngl_FragColor = color;\n}\n}"},
lensFlare:{vertexShader:"uniform vec3 screenPosition;\nuniform vec2 scale;\nuniform float rotation;\nuniform int renderType;\nattribute vec2 position;\nattribute vec2 UV;\nvarying vec2 vUV;\nvoid main() {\nvUV = UV;\nvec2 pos = position;\nif( renderType == 2 ) {\npos.x = cos( rotation ) * position.x - sin( rotation ) * position.y;\npos.y = sin( rotation ) * position.x + cos( rotation ) * position.y;\n}\ngl_Position = vec4( ( pos * scale + screenPosition.xy ).xy, screenPosition.z, 1.0 );\n}",fragmentShader:"#ifdef GL_ES\nprecision highp float;\n#endif\nuniform sampler2D map;\nuniform sampler2D occlusionMap;\nuniform float opacity;\nuniform int renderType;\nvarying vec2 vUV;\nvoid main() {\nif( renderType == 0 ) {\ngl_FragColor = vec4( texture2D( map, vUV ).rgb, 0.0 );\n} else if( renderType == 1 ) {\ngl_FragColor = texture2D( map, vUV );\n} else {\nfloat visibility = texture2D( occlusionMap, vec2( 0.5, 0.1 ) ).a +\ntexture2D( occlusionMap, vec2( 0.9, 0.5 ) ).a +\ntexture2D( occlusionMap, vec2( 0.5, 0.9 ) ).a +\ntexture2D( occlusionMap, vec2( 0.1, 0.5 ) ).a;\nvisibility = ( 1.0 - visibility / 4.0 );\nvec4 color = texture2D( map, vUV );\ncolor.a *= opacity * visibility;\ngl_FragColor = color;\n}\n}"},
sprite:{vertexShader:"uniform int useScreenCoordinates;\nuniform int affectedByDistance;\nuniform vec3 screenPosition;\nuniform mat4 modelViewMatrix;\nuniform mat4 projectionMatrix;\nuniform float rotation;\nuniform vec2 scale;\nuniform vec2 alignment;\nuniform vec2 uvOffset;\nuniform vec2 uvScale;\nattribute vec2 position;\nattribute vec2 uv;\nvarying vec2 vUV;\nvoid main() {\nvUV = uvOffset + uv * uvScale;\nvec2 alignedPosition = position + alignment;\nvec2 rotatedPosition;\nrotatedPosition.x = ( cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y ) * scale.x;\nrotatedPosition.y = ( sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y ) * scale.y;\nvec4 finalPosition;\nif( useScreenCoordinates != 0 ) {\nfinalPosition = vec4( screenPosition.xy + rotatedPosition, screenPosition.z, 1.0 );\n} else {\nfinalPosition = projectionMatrix * modelViewMatrix * vec4( 0.0, 0.0, 0.0, 1.0 );\nfinalPosition.xy += rotatedPosition * ( affectedByDistance == 1 ? 1.0 : finalPosition.z );\n}\ngl_Position = finalPosition;\n}",
fragmentShader:"#ifdef GL_ES\nprecision highp float;\n#endif\nuniform sampler2D map;\nuniform float opacity;\nvarying vec2 vUV;\nvoid main() {\nvec4 color = texture2D( map, vUV );\ncolor.a *= opacity;\ngl_FragColor = color;\n}"},shadowPost:{vertexShader:"uniform \tmat4 \tprojectionMatrix;\nattribute \tvec3 \tposition;\nvoid main() {\ngl_Position = projectionMatrix * vec4( position, 1.0 );\n}",fragmentShader:"#ifdef GL_ES\nprecision highp float;\n#endif\nuniform \tfloat \tdarkness;\nvoid main() {\ngl_FragColor = vec4( 0, 0, 0, darkness );\n}"},
shadowVolumeDynamic:{uniforms:{directionalLightDirection:{type:"fv",value:[]}},vertexShader:"uniform \tvec3 \tdirectionalLightDirection;\nvoid main() {\nvec4 pos      = objectMatrix * vec4( position, 1.0 );\nvec3 norm     = mat3( objectMatrix[ 0 ].xyz, objectMatrix[ 1 ].xyz, objectMatrix[ 2 ].xyz ) * normal;\nvec4 extruded = vec4( directionalLightDirection * 5000.0 * step( 0.0, dot( directionalLightDirection, norm ) ), 0.0 );\ngl_Position   = projectionMatrix * viewMatrix * ( pos + extruded );\n}",
fragmentShader:"void main() {\ngl_FragColor = vec4( 1.0 );\n}"},depth:{uniforms:{mNear:{type:"f",value:1},mFar:{type:"f",value:2E3},opacity:{type:"f",value:1}},fragmentShader:"uniform float mNear;\nuniform float mFar;\nuniform float opacity;\nvoid main() {\nfloat depth = gl_FragCoord.z / gl_FragCoord.w;\nfloat color = 1.0 - smoothstep( mNear, mFar, depth );\ngl_FragColor = vec4( vec3( color ), opacity );\n}",vertexShader:"void main() {\ngl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );\n}"},
normal:{uniforms:{opacity:{type:"f",value:1}},fragmentShader:"uniform float opacity;\nvarying vec3 vNormal;\nvoid main() {\ngl_FragColor = vec4( 0.5 * normalize( vNormal ) + 0.5, opacity );\n}",vertexShader:"varying vec3 vNormal;\nvoid main() {\nvec4 mvPosition = modelViewMatrix * vec4( position, 1.0 );\nvNormal = normalize( normalMatrix * normal );\ngl_Position = projectionMatrix * mvPosition;\n}"},basic:{uniforms:THREE.UniformsUtils.merge([THREE.UniformsLib.common,THREE.UniformsLib.fog,THREE.UniformsLib.shadowmap]),
fragmentShader:["uniform vec3 diffuse;\nuniform float opacity;",THREE.ShaderChunk.color_pars_fragment,THREE.ShaderChunk.map_pars_fragment,THREE.ShaderChunk.lightmap_pars_fragment,THREE.ShaderChunk.envmap_pars_fragment,THREE.ShaderChunk.fog_pars_fragment,THREE.ShaderChunk.shadowmap_pars_fragment,"void main() {\ngl_FragColor = vec4( diffuse, opacity );",THREE.ShaderChunk.map_fragment,THREE.ShaderChunk.alphatest_fragment,THREE.ShaderChunk.lightmap_fragment,THREE.ShaderChunk.color_fragment,THREE.ShaderChunk.envmap_fragment,
THREE.ShaderChunk.shadowmap_fragment,THREE.ShaderChunk.fog_fragment,"}"].join("\n"),vertexShader:[THREE.ShaderChunk.map_pars_vertex,THREE.ShaderChunk.lightmap_pars_vertex,THREE.ShaderChunk.envmap_pars_vertex,THREE.ShaderChunk.color_pars_vertex,THREE.ShaderChunk.skinning_pars_vertex,THREE.ShaderChunk.morphtarget_pars_vertex,THREE.ShaderChunk.shadowmap_pars_vertex,"void main() {\nvec4 mvPosition = modelViewMatrix * vec4( position, 1.0 );",THREE.ShaderChunk.map_vertex,THREE.ShaderChunk.lightmap_vertex,
THREE.ShaderChunk.envmap_vertex,THREE.ShaderChunk.color_vertex,THREE.ShaderChunk.skinning_vertex,THREE.ShaderChunk.morphtarget_vertex,THREE.ShaderChunk.default_vertex,THREE.ShaderChunk.shadowmap_vertex,"}"].join("\n")},lambert:{uniforms:THREE.UniformsUtils.merge([THREE.UniformsLib.common,THREE.UniformsLib.fog,THREE.UniformsLib.lights,THREE.UniformsLib.shadowmap]),fragmentShader:["uniform vec3 diffuse;\nuniform float opacity;\nvarying vec3 vLightWeighting;",THREE.ShaderChunk.color_pars_fragment,THREE.ShaderChunk.map_pars_fragment,
THREE.ShaderChunk.lightmap_pars_fragment,THREE.ShaderChunk.envmap_pars_fragment,THREE.ShaderChunk.fog_pars_fragment,THREE.ShaderChunk.shadowmap_pars_fragment,"void main() {\ngl_FragColor = vec4( diffuse, opacity );",THREE.ShaderChunk.map_fragment,THREE.ShaderChunk.alphatest_fragment,"gl_FragColor = gl_FragColor * vec4( vLightWeighting, 1.0 );",THREE.ShaderChunk.lightmap_fragment,THREE.ShaderChunk.color_fragment,THREE.ShaderChunk.envmap_fragment,THREE.ShaderChunk.shadowmap_fragment,THREE.ShaderChunk.fog_fragment,
"}"].join("\n"),vertexShader:["varying vec3 vLightWeighting;",THREE.ShaderChunk.map_pars_vertex,THREE.ShaderChunk.lightmap_pars_vertex,THREE.ShaderChunk.envmap_pars_vertex,THREE.ShaderChunk.lights_pars_vertex,THREE.ShaderChunk.color_pars_vertex,THREE.ShaderChunk.skinning_pars_vertex,THREE.ShaderChunk.morphtarget_pars_vertex,THREE.ShaderChunk.shadowmap_pars_vertex,"void main() {\nvec4 mvPosition = modelViewMatrix * vec4( position, 1.0 );",THREE.ShaderChunk.map_vertex,THREE.ShaderChunk.lightmap_vertex,
THREE.ShaderChunk.envmap_vertex,THREE.ShaderChunk.color_vertex,"vec3 transformedNormal = normalize( normalMatrix * normal );",THREE.ShaderChunk.lights_vertex,THREE.ShaderChunk.skinning_vertex,THREE.ShaderChunk.morphtarget_vertex,THREE.ShaderChunk.default_vertex,THREE.ShaderChunk.shadowmap_vertex,"}"].join("\n")},phong:{uniforms:THREE.UniformsUtils.merge([THREE.UniformsLib.common,THREE.UniformsLib.fog,THREE.UniformsLib.lights,THREE.UniformsLib.shadowmap,{ambient:{type:"c",value:new THREE.Color(328965)},
specular:{type:"c",value:new THREE.Color(1118481)},shininess:{type:"f",value:30}}]),fragmentShader:["uniform vec3 diffuse;\nuniform float opacity;\nuniform vec3 ambient;\nuniform vec3 specular;\nuniform float shininess;\nvarying vec3 vLightWeighting;",THREE.ShaderChunk.color_pars_fragment,THREE.ShaderChunk.map_pars_fragment,THREE.ShaderChunk.lightmap_pars_fragment,THREE.ShaderChunk.envmap_pars_fragment,THREE.ShaderChunk.fog_pars_fragment,THREE.ShaderChunk.lights_pars_fragment,THREE.ShaderChunk.shadowmap_pars_fragment,
"void main() {\ngl_FragColor = vec4( vLightWeighting, 1.0 );",THREE.ShaderChunk.map_fragment,THREE.ShaderChunk.alphatest_fragment,THREE.ShaderChunk.lights_fragment,THREE.ShaderChunk.lightmap_fragment,THREE.ShaderChunk.color_fragment,THREE.ShaderChunk.envmap_fragment,THREE.ShaderChunk.shadowmap_fragment,THREE.ShaderChunk.fog_fragment,"}"].join("\n"),vertexShader:["#define PHONG\nvarying vec3 vLightWeighting;\nvarying vec3 vViewPosition;\nvarying vec3 vNormal;",THREE.ShaderChunk.map_pars_vertex,THREE.ShaderChunk.lightmap_pars_vertex,
THREE.ShaderChunk.envmap_pars_vertex,THREE.ShaderChunk.lights_pars_vertex,THREE.ShaderChunk.color_pars_vertex,THREE.ShaderChunk.skinning_pars_vertex,THREE.ShaderChunk.morphtarget_pars_vertex,THREE.ShaderChunk.shadowmap_pars_vertex,"void main() {\nvec4 mvPosition = modelViewMatrix * vec4( position, 1.0 );",THREE.ShaderChunk.map_vertex,THREE.ShaderChunk.lightmap_vertex,THREE.ShaderChunk.envmap_vertex,THREE.ShaderChunk.color_vertex,"#ifndef USE_ENVMAP\nvec4 mPosition = objectMatrix * vec4( position, 1.0 );\n#endif\nvViewPosition = cameraPosition - mPosition.xyz;\nvec3 transformedNormal = normalize( normalMatrix * normal );\nvNormal = transformedNormal;",
THREE.ShaderChunk.lights_vertex,THREE.ShaderChunk.skinning_vertex,THREE.ShaderChunk.morphtarget_vertex,THREE.ShaderChunk.default_vertex,THREE.ShaderChunk.shadowmap_vertex,"}"].join("\n")},particle_basic:{uniforms:THREE.UniformsUtils.merge([THREE.UniformsLib.particle,THREE.UniformsLib.shadowmap]),fragmentShader:["uniform vec3 psColor;\nuniform float opacity;",THREE.ShaderChunk.color_pars_fragment,THREE.ShaderChunk.map_particle_pars_fragment,THREE.ShaderChunk.fog_pars_fragment,THREE.ShaderChunk.shadowmap_pars_fragment,
"void main() {\ngl_FragColor = vec4( psColor, opacity );",THREE.ShaderChunk.map_particle_fragment,THREE.ShaderChunk.alphatest_fragment,THREE.ShaderChunk.color_fragment,THREE.ShaderChunk.shadowmap_fragment,THREE.ShaderChunk.fog_fragment,"}"].join("\n"),vertexShader:["uniform float size;\nuniform float scale;",THREE.ShaderChunk.color_pars_vertex,THREE.ShaderChunk.shadowmap_pars_vertex,"void main() {",THREE.ShaderChunk.color_vertex,"vec4 mvPosition = modelViewMatrix * vec4( position, 1.0 );\n#ifdef USE_SIZEATTENUATION\ngl_PointSize = size * ( scale / length( mvPosition.xyz ) );\n#else\ngl_PointSize = size;\n#endif\ngl_Position = projectionMatrix * mvPosition;",
THREE.ShaderChunk.shadowmap_vertex,"}"].join("\n")},depthRGBA:{uniforms:{},fragmentShader:"vec4 pack_depth( const in float depth ) {\nconst vec4 bit_shift = vec4( 256.0 * 256.0 * 256.0, 256.0 * 256.0, 256.0, 1.0 );\nconst vec4 bit_mask  = vec4( 0.0, 1.0 / 256.0, 1.0 / 256.0, 1.0 / 256.0 );\nvec4 res = fract( depth * bit_shift );\nres -= res.xxyz * bit_mask;\nreturn res;\n}\nvoid main() {\ngl_FragData[ 0 ] = pack_depth( gl_FragCoord.z );\n}",vertexShader:[THREE.ShaderChunk.morphtarget_pars_vertex,
"void main() {\nvec4 mvPosition = modelViewMatrix * vec4( position, 1.0 );",THREE.ShaderChunk.morphtarget_vertex,THREE.ShaderChunk.default_vertex,"}"].join("\n")}};
THREE.WebGLRenderer=function(b){function c(b,c,e){var f,h,g,j=b.vertices,k=j.length,m=b.colors,o=m.length,u=b.__vertexArray,t=b.__colorArray,p=b.__sortArray,v=b.__dirtyVertices,w=b.__dirtyColors,x=b.__webglCustomAttributes,A,B;if(x)for(A in x)x[A].offset=0;if(e.sortParticles){ja.multiplySelf(e.matrixWorld);for(f=0;f<k;f++)h=j[f].position,pa.copy(h),ja.multiplyVector3(pa),p[f]=[pa.z,f];p.sort(function(b,c){return c[0]-b[0]});for(f=0;f<k;f++)h=j[p[f][1]].position,g=f*3,u[g]=h.x,u[g+1]=h.y,u[g+2]=h.z;
for(f=0;f<o;f++)g=f*3,color=m[p[f][1]],t[g]=color.r,t[g+1]=color.g,t[g+2]=color.b;if(x)for(A in x){f=x[A];m=f.value.length;for(g=0;g<m;g++){index=p[g][1];o=f.offset;if(f.size===1){if(f.boundTo===void 0||f.boundTo==="vertices")f.array[o]=f.value[index]}else{if(f.boundTo===void 0||f.boundTo==="vertices")B=f.value[index];f.size===2?(f.array[o]=B.x,f.array[o+1]=B.y):f.size===3?f.type==="c"?(f.array[o]=B.r,f.array[o+1]=B.g,f.array[o+2]=B.b):(f.array[o]=B.x,f.array[o+1]=B.y,f.array[o+2]=B.z):(f.array[o]=
B.x,f.array[o+1]=B.y,f.array[o+2]=B.z,f.array[o+3]=B.w)}f.offset+=f.size}}}else{if(v)for(f=0;f<k;f++)h=j[f].position,g=f*3,u[g]=h.x,u[g+1]=h.y,u[g+2]=h.z;if(w)for(f=0;f<o;f++)color=m[f],g=f*3,t[g]=color.r,t[g+1]=color.g,t[g+2]=color.b;if(x)for(A in x)if(f=x[A],f.__original.needsUpdate){m=f.value.length;for(g=0;g<m;g++){o=f.offset;if(f.size===1){if(f.boundTo===void 0||f.boundTo==="vertices")f.array[o]=f.value[g]}else{if(f.boundTo===void 0||f.boundTo==="vertices")B=f.value[g];f.size===2?(f.array[o]=
B.x,f.array[o+1]=B.y):f.size===3?f.type==="c"?(f.array[o]=B.r,f.array[o+1]=B.g,f.array[o+2]=B.b):(f.array[o]=B.x,f.array[o+1]=B.y,f.array[o+2]=B.z):(f.array[o]=B.x,f.array[o+1]=B.y,f.array[o+2]=B.z,f.array[o+3]=B.w)}f.offset+=f.size}}}if(v||e.sortParticles)n.bindBuffer(n.ARRAY_BUFFER,b.__webglVertexBuffer),n.bufferData(n.ARRAY_BUFFER,u,c);if(w||e.sortParticles)n.bindBuffer(n.ARRAY_BUFFER,b.__webglColorBuffer),n.bufferData(n.ARRAY_BUFFER,t,c);if(x)for(A in x)if(f=x[A],f.__original.needsUpdate||e.sortParticles)n.bindBuffer(n.ARRAY_BUFFER,
f.buffer),n.bufferData(n.ARRAY_BUFFER,f.array,c)}function e(b,c,e,f,h){f.program||C.initMaterial(f,c,e,h);if(f.morphTargets&&!h.__webglMorphTargetInfluences){h.__webglMorphTargetInfluences=new Float32Array(C.maxMorphTargets);for(var g=0,j=C.maxMorphTargets;g<j;g++)h.__webglMorphTargetInfluences[g]=0}var g=f.program,j=g.uniforms,k=f.uniforms;g!=V&&(n.useProgram(g),V=g);n.uniformMatrix4fv(j.projectionMatrix,!1,la);if(e&&(f instanceof THREE.MeshBasicMaterial||f instanceof THREE.MeshLambertMaterial||
f instanceof THREE.MeshPhongMaterial||f instanceof THREE.LineBasicMaterial||f instanceof THREE.ParticleBasicMaterial||f.fog))if(k.fogColor.value=e.color,e instanceof THREE.Fog)k.fogNear.value=e.near,k.fogFar.value=e.far;else if(e instanceof THREE.FogExp2)k.fogDensity.value=e.density;if(f instanceof THREE.MeshPhongMaterial||f instanceof THREE.MeshLambertMaterial||f.lights){var m,o,u,t=0,p=0,v=0,w,B,x,A=sa,y=A.directional.colors,G=A.directional.positions,H=A.point.colors,I=A.point.positions,ja=A.point.distances,
E=0,J=0,e=o=x=0;for(m=c.length;e<m;e++)if(o=c[e],u=o.color,w=o.position,B=o.intensity,x=o.distance,o instanceof THREE.AmbientLight)t+=u.r,p+=u.g,v+=u.b;else if(o instanceof THREE.DirectionalLight)x=E*3,y[x]=u.r*B,y[x+1]=u.g*B,y[x+2]=u.b*B,G[x]=w.x,G[x+1]=w.y,G[x+2]=w.z,E+=1;else if(o instanceof THREE.SpotLight)x=E*3,y[x]=u.r*B,y[x+1]=u.g*B,y[x+2]=u.b*B,u=1/w.length(),G[x]=w.x*u,G[x+1]=w.y*u,G[x+2]=w.z*u,E+=1;else if(o instanceof THREE.PointLight)o=J*3,H[o]=u.r*B,H[o+1]=u.g*B,H[o+2]=u.b*B,I[o]=w.x,
I[o+1]=w.y,I[o+2]=w.z,ja[J]=x,J+=1;for(e=E*3;e<y.length;e++)y[e]=0;for(e=J*3;e<H.length;e++)H[e]=0;A.point.length=J;A.directional.length=E;A.ambient[0]=t;A.ambient[1]=p;A.ambient[2]=v;c=sa;k.enableLighting.value=c.directional.length+c.point.length;k.ambientLightColor.value=c.ambient;k.directionalLightColor.value=c.directional.colors;k.directionalLightDirection.value=c.directional.positions;k.pointLightColor.value=c.point.colors;k.pointLightPosition.value=c.point.positions;k.pointLightDistance.value=
c.point.distances}if(f instanceof THREE.MeshBasicMaterial||f instanceof THREE.MeshLambertMaterial||f instanceof THREE.MeshPhongMaterial)k.diffuse.value=f.color,k.opacity.value=f.opacity,(k.map.texture=f.map)&&k.offsetRepeat.value.set(f.map.offset.x,f.map.offset.y,f.map.repeat.x,f.map.repeat.y),k.lightMap.texture=f.lightMap,k.envMap.texture=f.envMap,k.reflectivity.value=f.reflectivity,k.refractionRatio.value=f.refractionRatio,k.combine.value=f.combine,k.useRefract.value=f.envMap&&f.envMap.mapping instanceof
THREE.CubeRefractionMapping;if(f instanceof THREE.LineBasicMaterial)k.diffuse.value=f.color,k.opacity.value=f.opacity;else if(f instanceof THREE.ParticleBasicMaterial)k.psColor.value=f.color,k.opacity.value=f.opacity,k.size.value=f.size,k.scale.value=ua.height/2,k.map.texture=f.map;else if(f instanceof THREE.MeshPhongMaterial)k.ambient.value=f.ambient,k.specular.value=f.specular,k.shininess.value=f.shininess;else if(f instanceof THREE.MeshDepthMaterial)k.mNear.value=b.near,k.mFar.value=b.far,k.opacity.value=
f.opacity;else if(f instanceof THREE.MeshNormalMaterial)k.opacity.value=f.opacity;if(h.receiveShadow&&!f._shadowPass&&k.shadowMatrix){for(c=0;c<ta.length;c++)k.shadowMatrix.value[c]=ta[c],k.shadowMap.texture[c]=C.shadowMap[c];k.shadowDarkness.value=C.shadowMapDarkness;k.shadowBias.value=C.shadowMapBias}for(var L in k)if(m=g.uniforms[L])if(e=k[L],t=e.type,c=e.value,t=="i")n.uniform1i(m,c);else if(t=="f")n.uniform1f(m,c);else if(t=="fv1")n.uniform1fv(m,c);else if(t=="fv")n.uniform3fv(m,c);else if(t==
"v2")n.uniform2f(m,c.x,c.y);else if(t=="v3")n.uniform3f(m,c.x,c.y,c.z);else if(t=="v4")n.uniform4f(m,c.x,c.y,c.z,c.w);else if(t=="m4"){if(!e._array)e._array=new Float32Array(16);c.flattenToArray(e._array);n.uniformMatrix4fv(m,!1,e._array)}else if(t=="m4v"){if(!e._array)e._array=new Float32Array(16*c.length);t=0;for(p=c.length;t<p;t++)c[t].flattenToArrayOffset(e._array,t*16);n.uniformMatrix4fv(m,!1,e._array)}else if(t=="c")n.uniform3f(m,c.r,c.g,c.b);else if(t=="t"){if(n.uniform1i(m,c),m=e.texture)if(m.image instanceof
Array&&m.image.length==6){if(e=m,e.image.length==6){if(e.needsUpdate){if(e.__webglInit){n.bindTexture(n.TEXTURE_CUBE_MAP,e.image.__webglTextureCube);for(m=0;m<6;++m)n.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+m,0,0,0,n.RGBA,n.UNSIGNED_BYTE,e.image[m])}else{e.image.__webglTextureCube=n.createTexture();n.bindTexture(n.TEXTURE_CUBE_MAP,e.image.__webglTextureCube);for(m=0;m<6;++m)n.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+m,0,n.RGBA,n.RGBA,n.UNSIGNED_BYTE,e.image[m]);e.__webglInit=!0}K(n.TEXTURE_CUBE_MAP,
e,e.image[0]);n.bindTexture(n.TEXTURE_CUBE_MAP,null);e.needsUpdate=!1}n.activeTexture(n.TEXTURE0+c);n.bindTexture(n.TEXTURE_CUBE_MAP,e.image.__webglTextureCube)}}else D(m,c)}else if(t=="tv"){if(!e._array){e._array=[];t=0;for(p=e.texture.length;t<p;t++)e._array[t]=c+t}n.uniform1iv(m,e._array);t=0;for(p=e.texture.length;t<p;t++)(m=e.texture[t])&&D(m,e._array[t])}n.uniformMatrix4fv(j.modelViewMatrix,!1,h._modelViewMatrixArray);n.uniformMatrix3fv(j.normalMatrix,!1,h._normalMatrixArray);(f instanceof THREE.MeshShaderMaterial||
f instanceof THREE.MeshPhongMaterial||f.envMap)&&j.cameraPosition!==null&&n.uniform3f(j.cameraPosition,b.position.x,b.position.y,b.position.z);(f instanceof THREE.MeshShaderMaterial||f.envMap||f.skinning||h.receiveShadow)&&j.objectMatrix!==null&&n.uniformMatrix4fv(j.objectMatrix,!1,h._objectMatrixArray);(f instanceof THREE.MeshPhongMaterial||f instanceof THREE.MeshLambertMaterial||f instanceof THREE.MeshShaderMaterial||f.skinning)&&j.viewMatrix!==null&&n.uniformMatrix4fv(j.viewMatrix,!1,ka);f.skinning&&
(n.uniformMatrix4fv(j.cameraInverseMatrix,!1,ka),n.uniformMatrix4fv(j.boneGlobalMatrices,!1,h.boneMatrices));return g}function f(b,c,f,h,g,j){if(h.opacity!=0){var k,b=e(b,c,f,h,j).attributes;if(!h.morphTargets&&b.position>=0)n.bindBuffer(n.ARRAY_BUFFER,g.__webglVertexBuffer),n.vertexAttribPointer(b.position,3,n.FLOAT,!1,0,0);else if(j.morphTargetBase){c=h.program.attributes;j.morphTargetBase!==-1?(n.bindBuffer(n.ARRAY_BUFFER,g.__webglMorphTargetsBuffers[j.morphTargetBase]),n.vertexAttribPointer(c.position,
3,n.FLOAT,!1,0,0)):c.position>=0&&(n.bindBuffer(n.ARRAY_BUFFER,g.__webglVertexBuffer),n.vertexAttribPointer(c.position,3,n.FLOAT,!1,0,0));if(j.morphTargetForcedOrder.length)for(var f=0,m=j.morphTargetForcedOrder,o=j.morphTargetInfluences;f<h.numSupportedMorphTargets&&f<m.length;)n.bindBuffer(n.ARRAY_BUFFER,g.__webglMorphTargetsBuffers[m[f]]),n.vertexAttribPointer(c["morphTarget"+f],3,n.FLOAT,!1,0,0),j.__webglMorphTargetInfluences[f]=o[m[f]],f++;else{var m=[],u=-1,t=0,o=j.morphTargetInfluences,p,v=
o.length,f=0;for(j.morphTargetBase!==-1&&(m[j.morphTargetBase]=!0);f<h.numSupportedMorphTargets;){for(p=0;p<v;p++)!m[p]&&o[p]>u&&(t=p,u=o[t]);n.bindBuffer(n.ARRAY_BUFFER,g.__webglMorphTargetsBuffers[t]);n.vertexAttribPointer(c["morphTarget"+f],3,n.FLOAT,!1,0,0);j.__webglMorphTargetInfluences[f]=u;m[t]=1;u=-1;f++}}h.program.uniforms.morphTargetInfluences!==null&&n.uniform1fv(h.program.uniforms.morphTargetInfluences,j.__webglMorphTargetInfluences)}if(g.__webglCustomAttributes)for(k in g.__webglCustomAttributes)b[k]>=
0&&(c=g.__webglCustomAttributes[k],n.bindBuffer(n.ARRAY_BUFFER,c.buffer),n.vertexAttribPointer(b[k],c.size,n.FLOAT,!1,0,0));b.color>=0&&(n.bindBuffer(n.ARRAY_BUFFER,g.__webglColorBuffer),n.vertexAttribPointer(b.color,3,n.FLOAT,!1,0,0));b.normal>=0&&(n.bindBuffer(n.ARRAY_BUFFER,g.__webglNormalBuffer),n.vertexAttribPointer(b.normal,3,n.FLOAT,!1,0,0));b.tangent>=0&&(n.bindBuffer(n.ARRAY_BUFFER,g.__webglTangentBuffer),n.vertexAttribPointer(b.tangent,4,n.FLOAT,!1,0,0));b.uv>=0&&(g.__webglUVBuffer?(n.bindBuffer(n.ARRAY_BUFFER,
g.__webglUVBuffer),n.vertexAttribPointer(b.uv,2,n.FLOAT,!1,0,0),n.enableVertexAttribArray(b.uv)):n.disableVertexAttribArray(b.uv));b.uv2>=0&&(g.__webglUV2Buffer?(n.bindBuffer(n.ARRAY_BUFFER,g.__webglUV2Buffer),n.vertexAttribPointer(b.uv2,2,n.FLOAT,!1,0,0),n.enableVertexAttribArray(b.uv2)):n.disableVertexAttribArray(b.uv2));h.skinning&&b.skinVertexA>=0&&b.skinVertexB>=0&&b.skinIndex>=0&&b.skinWeight>=0&&(n.bindBuffer(n.ARRAY_BUFFER,g.__webglSkinVertexABuffer),n.vertexAttribPointer(b.skinVertexA,4,
n.FLOAT,!1,0,0),n.bindBuffer(n.ARRAY_BUFFER,g.__webglSkinVertexBBuffer),n.vertexAttribPointer(b.skinVertexB,4,n.FLOAT,!1,0,0),n.bindBuffer(n.ARRAY_BUFFER,g.__webglSkinIndicesBuffer),n.vertexAttribPointer(b.skinIndex,4,n.FLOAT,!1,0,0),n.bindBuffer(n.ARRAY_BUFFER,g.__webglSkinWeightsBuffer),n.vertexAttribPointer(b.skinWeight,4,n.FLOAT,!1,0,0));j instanceof THREE.Mesh?(h.wireframe?(n.lineWidth(h.wireframeLinewidth),n.bindBuffer(n.ELEMENT_ARRAY_BUFFER,g.__webglLineBuffer),n.drawElements(n.LINES,g.__webglLineCount,
n.UNSIGNED_SHORT,0)):(n.bindBuffer(n.ELEMENT_ARRAY_BUFFER,g.__webglFaceBuffer),n.drawElements(n.TRIANGLES,g.__webglFaceCount,n.UNSIGNED_SHORT,0)),C.data.vertices+=g.__webglFaceCount,C.data.faces+=g.__webglFaceCount/3,C.data.drawCalls++):j instanceof THREE.Line?(j=j.type==THREE.LineStrip?n.LINE_STRIP:n.LINES,n.lineWidth(h.linewidth),n.drawArrays(j,0,g.__webglLineCount),C.data.drawCalls++):j instanceof THREE.ParticleSystem?(n.drawArrays(n.POINTS,0,g.__webglParticleCount),C.data.drawCalls++):j instanceof
THREE.Ribbon&&(n.drawArrays(n.TRIANGLE_STRIP,0,g.__webglVertexCount),C.data.drawCalls++)}}function g(b,c,e){if(!b.__webglVertexBuffer)b.__webglVertexBuffer=n.createBuffer();if(!b.__webglNormalBuffer)b.__webglNormalBuffer=n.createBuffer();b.hasPos&&(n.bindBuffer(n.ARRAY_BUFFER,b.__webglVertexBuffer),n.bufferData(n.ARRAY_BUFFER,b.positionArray,n.DYNAMIC_DRAW),n.enableVertexAttribArray(c.attributes.position),n.vertexAttribPointer(c.attributes.position,3,n.FLOAT,!1,0,0));if(b.hasNormal){n.bindBuffer(n.ARRAY_BUFFER,
b.__webglNormalBuffer);if(e==THREE.FlatShading){var f,g,h,j,k,m,o,u,t,p,v=b.count*3;for(p=0;p<v;p+=9)e=b.normalArray,f=e[p],g=e[p+1],h=e[p+2],j=e[p+3],m=e[p+4],u=e[p+5],k=e[p+6],o=e[p+7],t=e[p+8],f=(f+j+k)/3,g=(g+m+o)/3,h=(h+u+t)/3,e[p]=f,e[p+1]=g,e[p+2]=h,e[p+3]=f,e[p+4]=g,e[p+5]=h,e[p+6]=f,e[p+7]=g,e[p+8]=h}n.bufferData(n.ARRAY_BUFFER,b.normalArray,n.DYNAMIC_DRAW);n.enableVertexAttribArray(c.attributes.normal);n.vertexAttribPointer(c.attributes.normal,3,n.FLOAT,!1,0,0)}n.drawArrays(n.TRIANGLES,
0,b.count);b.count=0}function j(b){if(ea!=b.doubleSided)b.doubleSided?n.disable(n.CULL_FACE):n.enable(n.CULL_FACE),ea=b.doubleSided;if(T!=b.flipSided)b.flipSided?n.frontFace(n.CW):n.frontFace(n.CCW),T=b.flipSided}function h(b){da!=b&&(b?n.enable(n.DEPTH_TEST):n.disable(n.DEPTH_TEST),da=b)}function k(b,c,e){ha!=b&&(b?n.enable(n.POLYGON_OFFSET_FILL):n.disable(n.POLYGON_OFFSET_FILL),ha=b);if(b&&(ia!=c||M!=e))n.polygonOffset(c,e),ia=c,M=e}function o(b){ca[0].set(b.n41-b.n11,b.n42-b.n12,b.n43-b.n13,b.n44-
b.n14);ca[1].set(b.n41+b.n11,b.n42+b.n12,b.n43+b.n13,b.n44+b.n14);ca[2].set(b.n41+b.n21,b.n42+b.n22,b.n43+b.n23,b.n44+b.n24);ca[3].set(b.n41-b.n21,b.n42-b.n22,b.n43-b.n23,b.n44-b.n24);ca[4].set(b.n41-b.n31,b.n42-b.n32,b.n43-b.n33,b.n44-b.n34);ca[5].set(b.n41+b.n31,b.n42+b.n32,b.n43+b.n33,b.n44+b.n34);for(var c,b=0;b<6;b++)c=ca[b],c.divideScalar(Math.sqrt(c.x*c.x+c.y*c.y+c.z*c.z))}function m(b){for(var c=b.matrixWorld,e=-b.geometry.boundingSphere.radius*Math.max(b.scale.x,Math.max(b.scale.y,b.scale.z)),
f=0;f<6;f++)if(b=ca[f].x*c.n14+ca[f].y*c.n24+ca[f].z*c.n34+ca[f].w,b<=e)return!1;return!0}function p(b,c){b.list[b.count]=c;b.count+=1}function u(b){var c,e,f=b.object,g=b.opaque,h=b.transparent;h.count=0;b=g.count=0;for(c=f.materials.length;b<c;b++)e=f.materials[b],e.transparent?p(h,e):p(g,e)}function v(b){var c,e,f,g,h=b.object,j=b.buffer,k=b.opaque,n=b.transparent;n.count=0;b=k.count=0;for(f=h.materials.length;b<f;b++)if(c=h.materials[b],c instanceof THREE.MeshFaceMaterial){c=0;for(e=j.materials.length;c<
e;c++)(g=j.materials[c])&&(g.transparent?p(n,g):p(k,g))}else(g=c)&&(g.transparent?p(n,g):p(k,g))}function t(b,c){return c.z-b.z}function w(b,c){var k,u,t,p=0,v,w,x,A,y=b.lights;$||($=new THREE.Camera(C.shadowCameraFov,c.aspect,C.shadowCameraNear,C.shadowCameraFar));k=0;for(u=y.length;k<u;k++)if(t=y[k],t instanceof THREE.SpotLight&&t.castShadow){C.shadowMap[p]||(C.shadowMap[p]=new THREE.WebGLRenderTarget(C.shadowMapWidth,C.shadowMapHeight,{minFilter:THREE.LinearFilter,magFilter:THREE.LinearFilter,
format:THREE.RGBAFormat}));ta[p]||(ta[p]=new THREE.Matrix4);v=C.shadowMap[p];w=ta[p];$.position.copy(t.position);$.target.position.copy(t.target.position);$.update(void 0,!0);b.update(void 0,!1,$);w.set(0.5,0,0,0.5,0,0.5,0,0.5,0,0,0.5,0.5,0,0,0,1);w.multiplySelf($.projectionMatrix);w.multiplySelf($.matrixWorldInverse);$.matrixWorldInverse.flattenToArray(ka);$.projectionMatrix.flattenToArray(la);ja.multiply($.projectionMatrix,$.matrixWorldInverse);o(ja);C.initWebGLObjects(b);J(v);n.clearColor(1,1,
1,1);C.clear();n.clearColor(va.r,va.g,va.b,ya);w=b.__webglObjects.length;t=b.__webglObjectsImmediate.length;for(v=0;v<w;v++)x=b.__webglObjects[v],A=x.object,A.visible&&A.castShadow?!(A instanceof THREE.Mesh)||m(A)?(A.matrixWorld.flattenToArray(A._objectMatrixArray),B(A,$,!1),x.render=!0):x.render=!1:x.render=!1;h(!0);E(THREE.NormalBlending);for(v=0;v<w;v++)if(x=b.__webglObjects[v],x.render)A=x.object,buffer=x.buffer,j(A),x=A.customDepthMaterial?A.customDepthMaterial:A.geometry.morphTargets.length?
ma:oa,f($,y,null,x,buffer,A);for(v=0;v<t;v++)x=b.__webglObjectsImmediate[v],A=x.object,A.visible&&A.castShadow&&(A.matrixAutoUpdate&&A.matrixWorld.flattenToArray(A._objectMatrixArray),B(A,$,!1),j(A),program=e($,y,null,oa,A),A.render(function(b){g(b,program,oa.shading)}));p++}}function x(b,c){var e,f,g;e=N.attributes;var h=N.uniforms,j=Z/Y,k,m=[],o=Y*0.5,u=Z*0.5,p=!0;n.useProgram(N.program);V=N.program;da=U=-1;za||(n.enableVertexAttribArray(N.attributes.position),n.enableVertexAttribArray(N.attributes.uv),
za=!0);n.disable(n.CULL_FACE);n.enable(n.BLEND);n.depthMask(!0);n.bindBuffer(n.ARRAY_BUFFER,N.vertexBuffer);n.vertexAttribPointer(e.position,2,n.FLOAT,!1,16,0);n.vertexAttribPointer(e.uv,2,n.FLOAT,!1,16,8);n.bindBuffer(n.ELEMENT_ARRAY_BUFFER,N.elementBuffer);n.uniformMatrix4fv(h.projectionMatrix,!1,la);n.activeTexture(n.TEXTURE0);n.uniform1i(h.map,0);e=0;for(f=b.__webglSprites.length;e<f;e++)g=b.__webglSprites[e],g.useScreenCoordinates?g.z=-g.position.z:(g._modelViewMatrix.multiplyToArray(c.matrixWorldInverse,
g.matrixWorld,g._modelViewMatrixArray),g.z=-g._modelViewMatrix.n34);b.__webglSprites.sort(t);e=0;for(f=b.__webglSprites.length;e<f;e++)g=b.__webglSprites[e],g.material===void 0&&g.map&&g.map.image&&g.map.image.width&&(g.useScreenCoordinates?(n.uniform1i(h.useScreenCoordinates,1),n.uniform3f(h.screenPosition,(g.position.x-o)/o,(u-g.position.y)/u,Math.max(0,Math.min(1,g.position.z)))):(n.uniform1i(h.useScreenCoordinates,0),n.uniform1i(h.affectedByDistance,g.affectedByDistance?1:0),n.uniformMatrix4fv(h.modelViewMatrix,
!1,g._modelViewMatrixArray)),k=g.map.image.width/(g.scaleByViewport?Z:1),m[0]=k*j*g.scale.x,m[1]=k*g.scale.y,n.uniform2f(h.uvScale,g.uvScale.x,g.uvScale.y),n.uniform2f(h.uvOffset,g.uvOffset.x,g.uvOffset.y),n.uniform2f(h.alignment,g.alignment.x,g.alignment.y),n.uniform1f(h.opacity,g.opacity),n.uniform1f(h.rotation,g.rotation),n.uniform2fv(h.scale,m),g.mergeWith3D&&!p?(n.enable(n.DEPTH_TEST),p=!0):!g.mergeWith3D&&p&&(n.disable(n.DEPTH_TEST),p=!1),E(g.blending),D(g.map,0),n.drawElements(n.TRIANGLES,
6,n.UNSIGNED_SHORT,0));n.enable(n.CULL_FACE);n.enable(n.DEPTH_TEST);n.depthMask(L)}function B(b,c,e){b._modelViewMatrix.multiplyToArray(c.matrixWorldInverse,b.matrixWorld,b._modelViewMatrixArray);e&&THREE.Matrix4.makeInvert3x3(b._modelViewMatrix).transposeIntoArray(b._normalMatrixArray)}function A(b){var c,e,f,g;g=b.__materials;b=0;for(e=g.length;b<e;b++)if(f=g[b],f.attributes)for(c in f.attributes)if(f.attributes[c].needsUpdate)return!0;return!1}function H(b){var c,e,f,g;g=b.__materials;b=0;for(e=
g.length;b<e;b++)if(f=g[b],f.attributes)for(c in f.attributes)f.attributes[c].needsUpdate=!1}function y(b,c){var e;for(e=b.length-1;e>=0;e--)b[e].object==c&&b.splice(e,1)}function G(b){function c(b){var g=[];e=0;for(f=b.length;e<f;e++)b[e]==void 0?g.push("undefined"):g.push(b[e].id);return g.join("_")}var e,f,g,h,j,k,n,m,o={},u=b.morphTargets!==void 0?b.morphTargets.length:0;b.geometryGroups={};g=0;for(h=b.faces.length;g<h;g++)j=b.faces[g],k=j.materials,n=c(k),o[n]==void 0&&(o[n]={hash:n,counter:0}),
m=o[n].hash+"_"+o[n].counter,b.geometryGroups[m]==void 0&&(b.geometryGroups[m]={faces:[],materials:k,vertices:0,numMorphTargets:u}),j=j instanceof THREE.Face3?3:4,b.geometryGroups[m].vertices+j>65535&&(o[n].counter+=1,m=o[n].hash+"_"+o[n].counter,b.geometryGroups[m]==void 0&&(b.geometryGroups[m]={faces:[],materials:k,vertices:0,numMorphTargets:u})),b.geometryGroups[m].faces.push(g),b.geometryGroups[m].vertices+=j}function I(b,c,e){b.push({buffer:c,object:e,opaque:{list:[],count:0},transparent:{list:[],
count:0}})}function E(b){if(b!=U){switch(b){case THREE.AdditiveBlending:n.blendEquation(n.FUNC_ADD);n.blendFunc(n.SRC_ALPHA,n.ONE);break;case THREE.SubtractiveBlending:n.blendEquation(n.FUNC_ADD);n.blendFunc(n.ZERO,n.ONE_MINUS_SRC_COLOR);break;case THREE.MultiplyBlending:n.blendEquation(n.FUNC_ADD);n.blendFunc(n.ZERO,n.SRC_COLOR);break;default:n.blendEquationSeparate(n.FUNC_ADD,n.FUNC_ADD),n.blendFuncSeparate(n.SRC_ALPHA,n.ONE_MINUS_SRC_ALPHA,n.ONE,n.ONE_MINUS_SRC_ALPHA)}U=b}}function K(b,c,e){(e.width&
e.width-1)==0&&(e.height&e.height-1)==0?(n.texParameteri(b,n.TEXTURE_WRAP_S,R(c.wrapS)),n.texParameteri(b,n.TEXTURE_WRAP_T,R(c.wrapT)),n.texParameteri(b,n.TEXTURE_MAG_FILTER,R(c.magFilter)),n.texParameteri(b,n.TEXTURE_MIN_FILTER,R(c.minFilter)),n.generateMipmap(b)):(n.texParameteri(b,n.TEXTURE_WRAP_S,n.CLAMP_TO_EDGE),n.texParameteri(b,n.TEXTURE_WRAP_T,n.CLAMP_TO_EDGE),n.texParameteri(b,n.TEXTURE_MAG_FILTER,X(c.magFilter)),n.texParameteri(b,n.TEXTURE_MIN_FILTER,X(c.minFilter)))}function D(b,c){if(b.needsUpdate){if(!b.__webglInit)b.__webglTexture=
n.createTexture(),b.__webglInit=!0;n.bindTexture(n.TEXTURE_2D,b.__webglTexture);b.image.data?n.texImage2D(n.TEXTURE_2D,0,R(b.format),b.image.width,b.image.height,0,R(b.format),n.UNSIGNED_BYTE,b.image.data):n.texImage2D(n.TEXTURE_2D,0,n.RGBA,n.RGBA,n.UNSIGNED_BYTE,b.image);K(n.TEXTURE_2D,b,b.image);n.bindTexture(n.TEXTURE_2D,null);b.needsUpdate=!1}n.activeTexture(n.TEXTURE0+c);n.bindTexture(n.TEXTURE_2D,b.__webglTexture)}function J(b){if(b&&!b.__webglFramebuffer){if(b.depthBuffer===void 0)b.depthBuffer=
!0;if(b.stencilBuffer===void 0)b.stencilBuffer=!0;b.__webglFramebuffer=n.createFramebuffer();b.__webglRenderbuffer=n.createRenderbuffer();b.__webglTexture=n.createTexture();n.bindTexture(n.TEXTURE_2D,b.__webglTexture);n.texParameteri(n.TEXTURE_2D,n.TEXTURE_WRAP_S,R(b.wrapS));n.texParameteri(n.TEXTURE_2D,n.TEXTURE_WRAP_T,R(b.wrapT));n.texParameteri(n.TEXTURE_2D,n.TEXTURE_MAG_FILTER,R(b.magFilter));n.texParameteri(n.TEXTURE_2D,n.TEXTURE_MIN_FILTER,R(b.minFilter));n.texImage2D(n.TEXTURE_2D,0,R(b.format),
b.width,b.height,0,R(b.format),R(b.type),null);n.bindRenderbuffer(n.RENDERBUFFER,b.__webglRenderbuffer);n.bindFramebuffer(n.FRAMEBUFFER,b.__webglFramebuffer);n.framebufferTexture2D(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,b.__webglTexture,0);b.depthBuffer&&!b.stencilBuffer?(n.renderbufferStorage(n.RENDERBUFFER,n.DEPTH_COMPONENT16,b.width,b.height),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.RENDERBUFFER,b.__webglRenderbuffer)):b.depthBuffer&&b.stencilBuffer?(n.renderbufferStorage(n.RENDERBUFFER,
n.DEPTH_STENCIL,b.width,b.height),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.RENDERBUFFER,b.__webglRenderbuffer)):n.renderbufferStorage(n.RENDERBUFFER,n.RGBA4,b.width,b.height);n.bindTexture(n.TEXTURE_2D,null);n.bindRenderbuffer(n.RENDERBUFFER,null);n.bindFramebuffer(n.FRAMEBUFFER,null)}var c,e;b?(c=b.__webglFramebuffer,e=b.width,b=b.height):(c=null,e=Y,b=Z);c!=fa&&(n.bindFramebuffer(n.FRAMEBUFFER,c),n.viewport(P,aa,e,b),fa=c)}function S(b,c){var e;b=="fragment"?e=n.createShader(n.FRAGMENT_SHADER):
b=="vertex"&&(e=n.createShader(n.VERTEX_SHADER));n.shaderSource(e,c);n.compileShader(e);if(!n.getShaderParameter(e,n.COMPILE_STATUS))return console.error(n.getShaderInfoLog(e)),console.error(c),null;return e}function X(b){switch(b){case THREE.NearestFilter:case THREE.NearestMipMapNearestFilter:case THREE.NearestMipMapLinearFilter:return n.NEAREST;default:return n.LINEAR}}function R(b){switch(b){case THREE.RepeatWrapping:return n.REPEAT;case THREE.ClampToEdgeWrapping:return n.CLAMP_TO_EDGE;case THREE.MirroredRepeatWrapping:return n.MIRRORED_REPEAT;
case THREE.NearestFilter:return n.NEAREST;case THREE.NearestMipMapNearestFilter:return n.NEAREST_MIPMAP_NEAREST;case THREE.NearestMipMapLinearFilter:return n.NEAREST_MIPMAP_LINEAR;case THREE.LinearFilter:return n.LINEAR;case THREE.LinearMipMapNearestFilter:return n.LINEAR_MIPMAP_NEAREST;case THREE.LinearMipMapLinearFilter:return n.LINEAR_MIPMAP_LINEAR;case THREE.ByteType:return n.BYTE;case THREE.UnsignedByteType:return n.UNSIGNED_BYTE;case THREE.ShortType:return n.SHORT;case THREE.UnsignedShortType:return n.UNSIGNED_SHORT;
case THREE.IntType:return n.INT;case THREE.UnsignedShortType:return n.UNSIGNED_INT;case THREE.FloatType:return n.FLOAT;case THREE.AlphaFormat:return n.ALPHA;case THREE.RGBFormat:return n.RGB;case THREE.RGBAFormat:return n.RGBA;case THREE.LuminanceFormat:return n.LUMINANCE;case THREE.LuminanceAlphaFormat:return n.LUMINANCE_ALPHA}return 0}var C=this,n,W=[],V=null,fa=null,L=!0,ea=null,T=null,U=null,da=null,ha=null,ia=null,M=null,P=0,aa=0,Y=0,Z=0,ca=[new THREE.Vector4,new THREE.Vector4,new THREE.Vector4,
new THREE.Vector4,new THREE.Vector4,new THREE.Vector4],ja=new THREE.Matrix4,la=new Float32Array(16),ka=new Float32Array(16),pa=new THREE.Vector4,sa={ambient:[0,0,0],directional:{length:0,colors:[],positions:[]},point:{length:0,colors:[],positions:[],distances:[]}},b=b||{},ua=b.canvas!==void 0?b.canvas:document.createElement("canvas"),Ia=b.stencil!==void 0?b.stencil:!0,Ja=b.preserveDrawingBuffer!==void 0?b.preserveDrawingBuffer:!1,Ka=b.antialias!==void 0?b.antialias:!1,va=b.clearColor!==void 0?new THREE.Color(b.clearColor):
new THREE.Color(0),ya=b.clearAlpha!==void 0?b.clearAlpha:0;this.data={vertices:0,faces:0,drawCalls:0};this.maxMorphTargets=8;this.domElement=ua;this.sortObjects=this.autoClear=!0;this.shadowMapBias=0.0039;this.shadowMapDarkness=0.5;this.shadowMapHeight=this.shadowMapWidth=512;this.shadowCameraNear=1;this.shadowCameraFar=5E3;this.shadowCameraFov=50;this.shadowMap=[];this.shadowMapEnabled=!1;this.shadowMapSoft=!0;var $,ta=[],b=THREE.ShaderLib.depthRGBA,Ea=THREE.UniformsUtils.clone(b.uniforms),oa=new THREE.MeshShaderMaterial({fragmentShader:b.fragmentShader,
vertexShader:b.vertexShader,uniforms:Ea}),ma=new THREE.MeshShaderMaterial({fragmentShader:b.fragmentShader,vertexShader:b.vertexShader,uniforms:Ea,morphTargets:!0});oa._shadowPass=!0;ma._shadowPass=!0;try{if(!(n=ua.getContext("experimental-webgl",{antialias:Ka,stencil:Ia,preserveDrawingBuffer:Ja})))throw"Error creating WebGL context.";console.log(navigator.userAgent+" | "+n.getParameter(n.VERSION)+" | "+n.getParameter(n.VENDOR)+" | "+n.getParameter(n.RENDERER)+" | "+n.getParameter(n.SHADING_LANGUAGE_VERSION))}catch(Ga){console.error(Ga)}n.clearColor(0,
0,0,1);n.clearDepth(1);n.enable(n.DEPTH_TEST);n.depthFunc(n.LEQUAL);n.frontFace(n.CCW);n.cullFace(n.BACK);n.enable(n.CULL_FACE);n.enable(n.BLEND);n.blendEquation(n.FUNC_ADD);n.blendFunc(n.SRC_ALPHA,n.ONE_MINUS_SRC_ALPHA);n.clearColor(va.r,va.g,va.b,ya);this.context=n;var Da=n.getParameter(n.MAX_VERTEX_TEXTURE_IMAGE_UNITS)>0,N={};N.vertices=new Float32Array(16);N.faces=new Uint16Array(6);i=0;N.vertices[i++]=-1;N.vertices[i++]=-1;N.vertices[i++]=0;N.vertices[i++]=1;N.vertices[i++]=1;N.vertices[i++]=
-1;N.vertices[i++]=1;N.vertices[i++]=1;N.vertices[i++]=1;N.vertices[i++]=1;N.vertices[i++]=1;N.vertices[i++]=0;N.vertices[i++]=-1;N.vertices[i++]=1;N.vertices[i++]=0;i=N.vertices[i++]=0;N.faces[i++]=0;N.faces[i++]=1;N.faces[i++]=2;N.faces[i++]=0;N.faces[i++]=2;N.faces[i++]=3;N.vertexBuffer=n.createBuffer();N.elementBuffer=n.createBuffer();n.bindBuffer(n.ARRAY_BUFFER,N.vertexBuffer);n.bufferData(n.ARRAY_BUFFER,N.vertices,n.STATIC_DRAW);n.bindBuffer(n.ELEMENT_ARRAY_BUFFER,N.elementBuffer);n.bufferData(n.ELEMENT_ARRAY_BUFFER,
N.faces,n.STATIC_DRAW);N.program=n.createProgram();n.attachShader(N.program,S("fragment",THREE.ShaderLib.sprite.fragmentShader));n.attachShader(N.program,S("vertex",THREE.ShaderLib.sprite.vertexShader));n.linkProgram(N.program);N.attributes={};N.uniforms={};N.attributes.position=n.getAttribLocation(N.program,"position");N.attributes.uv=n.getAttribLocation(N.program,"uv");N.uniforms.uvOffset=n.getUniformLocation(N.program,"uvOffset");N.uniforms.uvScale=n.getUniformLocation(N.program,"uvScale");N.uniforms.rotation=
n.getUniformLocation(N.program,"rotation");N.uniforms.scale=n.getUniformLocation(N.program,"scale");N.uniforms.alignment=n.getUniformLocation(N.program,"alignment");N.uniforms.map=n.getUniformLocation(N.program,"map");N.uniforms.opacity=n.getUniformLocation(N.program,"opacity");N.uniforms.useScreenCoordinates=n.getUniformLocation(N.program,"useScreenCoordinates");N.uniforms.affectedByDistance=n.getUniformLocation(N.program,"affectedByDistance");N.uniforms.screenPosition=n.getUniformLocation(N.program,
"screenPosition");N.uniforms.modelViewMatrix=n.getUniformLocation(N.program,"modelViewMatrix");N.uniforms.projectionMatrix=n.getUniformLocation(N.program,"projectionMatrix");var za=!1;this.setSize=function(b,c){ua.width=b;ua.height=c;this.setViewport(0,0,ua.width,ua.height)};this.setViewport=function(b,c,e,f){P=b;aa=c;Y=e;Z=f;n.viewport(P,aa,Y,Z)};this.setScissor=function(b,c,e,f){n.scissor(b,c,e,f)};this.enableScissorTest=function(b){b?n.enable(n.SCISSOR_TEST):n.disable(n.SCISSOR_TEST)};this.enableDepthBufferWrite=
function(b){L=b;n.depthMask(b)};this.setClearColorHex=function(b,c){va.setHex(b);ya=c;n.clearColor(va.r,va.g,va.b,ya)};this.setClearColor=function(b,c){va.copy(b);ya=c;n.clearColor(va.r,va.g,va.b,ya)};this.clear=function(){n.clear(n.COLOR_BUFFER_BIT|n.DEPTH_BUFFER_BIT|n.STENCIL_BUFFER_BIT)};this.getContext=function(){return n};this.initMaterial=function(b,c,e,f){var g,h,j;b instanceof THREE.MeshDepthMaterial?j="depth":b instanceof THREE.MeshNormalMaterial?j="normal":b instanceof THREE.MeshBasicMaterial?
j="basic":b instanceof THREE.MeshLambertMaterial?j="lambert":b instanceof THREE.MeshPhongMaterial?j="phong":b instanceof THREE.LineBasicMaterial?j="basic":b instanceof THREE.ParticleBasicMaterial&&(j="particle_basic");if(j){var k=THREE.ShaderLib[j];b.uniforms=THREE.UniformsUtils.clone(k.uniforms);b.vertexShader=k.vertexShader;b.fragmentShader=k.fragmentShader}var m,o,u;m=u=k=0;for(o=c.length;m<o;m++)h=c[m],h instanceof THREE.SpotLight&&u++,h instanceof THREE.DirectionalLight&&u++,h instanceof THREE.PointLight&&
k++;k+u<=4?m=u:(m=Math.ceil(4*u/(k+u)),k=4-m);h={directional:m,point:k};k=u=0;for(m=c.length;k<m;k++)o=c[k],o instanceof THREE.SpotLight&&o.castShadow&&u++;var t=50;if(f!==void 0&&f instanceof THREE.SkinnedMesh)t=f.bones.length;var p;a:{m=b.fragmentShader;o=b.vertexShader;var k=b.uniforms,c=b.attributes,e={map:!!b.map,envMap:!!b.envMap,lightMap:!!b.lightMap,vertexColors:b.vertexColors,fog:e,sizeAttenuation:b.sizeAttenuation,skinning:b.skinning,morphTargets:b.morphTargets,maxMorphTargets:this.maxMorphTargets,
maxDirLights:h.directional,maxPointLights:h.point,maxBones:t,shadowMapEnabled:this.shadowMapEnabled&&f.receiveShadow,shadowMapSoft:this.shadowMapSoft,shadowMapWidth:this.shadowMapWidth,shadowMapHeight:this.shadowMapHeight,maxShadows:u,alphaTest:b.alphaTest},v,f=[];j?f.push(j):(f.push(m),f.push(o));for(v in e)f.push(v),f.push(e[v]);j=f.join();v=0;for(f=W.length;v<f;v++)if(W[v].code==j){p=W[v].program;break a}v=n.createProgram();f=[Da?"#define VERTEX_TEXTURES":"","#define MAX_DIR_LIGHTS "+e.maxDirLights,
"#define MAX_POINT_LIGHTS "+e.maxPointLights,"#define MAX_SHADOWS "+e.maxShadows,"#define MAX_BONES "+e.maxBones,e.map?"#define USE_MAP":"",e.envMap?"#define USE_ENVMAP":"",e.lightMap?"#define USE_LIGHTMAP":"",e.vertexColors?"#define USE_COLOR":"",e.skinning?"#define USE_SKINNING":"",e.morphTargets?"#define USE_MORPHTARGETS":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapSoft?"#define SHADOWMAP_SOFT":"",e.sizeAttenuation?"#define USE_SIZEATTENUATION":"","uniform mat4 objectMatrix;\nuniform mat4 modelViewMatrix;\nuniform mat4 projectionMatrix;\nuniform mat4 viewMatrix;\nuniform mat3 normalMatrix;\nuniform vec3 cameraPosition;\nuniform mat4 cameraInverseMatrix;\nattribute vec3 position;\nattribute vec3 normal;\nattribute vec2 uv;\nattribute vec2 uv2;\n#ifdef USE_COLOR\nattribute vec3 color;\n#endif\n#ifdef USE_MORPHTARGETS\nattribute vec3 morphTarget0;\nattribute vec3 morphTarget1;\nattribute vec3 morphTarget2;\nattribute vec3 morphTarget3;\nattribute vec3 morphTarget4;\nattribute vec3 morphTarget5;\nattribute vec3 morphTarget6;\nattribute vec3 morphTarget7;\n#endif\n#ifdef USE_SKINNING\nattribute vec4 skinVertexA;\nattribute vec4 skinVertexB;\nattribute vec4 skinIndex;\nattribute vec4 skinWeight;\n#endif\n"].join("\n");
h=["#ifdef GL_ES\nprecision highp float;\n#endif","#define MAX_DIR_LIGHTS "+e.maxDirLights,"#define MAX_POINT_LIGHTS "+e.maxPointLights,"#define MAX_SHADOWS "+e.maxShadows,e.alphaTest?"#define ALPHATEST "+e.alphaTest:"",e.fog?"#define USE_FOG":"",e.fog instanceof THREE.FogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.envMap?"#define USE_ENVMAP":"",e.lightMap?"#define USE_LIGHTMAP":"",e.vertexColors?"#define USE_COLOR":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapSoft?"#define SHADOWMAP_SOFT":
"",e.shadowMapSoft?"#define SHADOWMAP_WIDTH "+e.shadowMapWidth.toFixed(1):"",e.shadowMapSoft?"#define SHADOWMAP_HEIGHT "+e.shadowMapHeight.toFixed(1):"","uniform mat4 viewMatrix;\nuniform vec3 cameraPosition;\n"].join("\n");n.attachShader(v,S("fragment",h+m));n.attachShader(v,S("vertex",f+o));n.linkProgram(v);n.getProgramParameter(v,n.LINK_STATUS)||console.error("Could not initialise shader\nVALIDATE_STATUS: "+n.getProgramParameter(v,n.VALIDATE_STATUS)+", gl error ["+n.getError()+"]");v.uniforms=
{};v.attributes={};var w,f=["viewMatrix","modelViewMatrix","projectionMatrix","normalMatrix","objectMatrix","cameraPosition","cameraInverseMatrix","boneGlobalMatrices","morphTargetInfluences"];for(w in k)f.push(w);w=f;f=0;for(k=w.length;f<k;f++)m=w[f],v.uniforms[m]=n.getUniformLocation(v,m);f=["position","normal","uv","uv2","tangent","color","skinVertexA","skinVertexB","skinIndex","skinWeight"];for(w=0;w<e.maxMorphTargets;w++)f.push("morphTarget"+w);for(p in c)f.push(p);p=f;w=0;for(c=p.length;w<c;w++)e=
p[w],v.attributes[e]=n.getAttribLocation(v,e);W.push({program:v,code:j});p=v}b.program=p;p=b.program.attributes;p.position>=0&&n.enableVertexAttribArray(p.position);p.color>=0&&n.enableVertexAttribArray(p.color);p.normal>=0&&n.enableVertexAttribArray(p.normal);p.tangent>=0&&n.enableVertexAttribArray(p.tangent);b.skinning&&p.skinVertexA>=0&&p.skinVertexB>=0&&p.skinIndex>=0&&p.skinWeight>=0&&(n.enableVertexAttribArray(p.skinVertexA),n.enableVertexAttribArray(p.skinVertexB),n.enableVertexAttribArray(p.skinIndex),
n.enableVertexAttribArray(p.skinWeight));if(b.attributes)for(g in b.attributes)p[g]!==void 0&&p[g]>=0&&n.enableVertexAttribArray(p[g]);if(b.morphTargets)for(g=b.numSupportedMorphTargets=0;g<this.maxMorphTargets;g++)w="morphTarget"+g,p[w]>=0&&(n.enableVertexAttribArray(p[w]),b.numSupportedMorphTargets++)};this.render=function(b,c,p,A){var y,G,H,I,D,L,K,N,M=b.lights,P=b.fog;this.shadowMapEnabled&&w(b,c);C.data.vertices=0;C.data.faces=0;C.data.drawCalls=0;c.matrixAutoUpdate&&c.update(void 0,!0);b.update(void 0,
!1,c);c.matrixWorldInverse.flattenToArray(ka);c.projectionMatrix.flattenToArray(la);ja.multiply(c.projectionMatrix,c.matrixWorldInverse);o(ja);this.initWebGLObjects(b);J(p);(this.autoClear||A)&&this.clear();D=b.__webglObjects.length;for(A=0;A<D;A++)if(y=b.__webglObjects[A],K=y.object,K.visible)if(!(K instanceof THREE.Mesh)||m(K)){if(K.matrixWorld.flattenToArray(K._objectMatrixArray),B(K,c,!0),v(y),y.render=!0,this.sortObjects)y.object.renderDepth?y.z=y.object.renderDepth:(pa.copy(K.position),ja.multiplyVector3(pa),
y.z=pa.z)}else y.render=!1;else y.render=!1;this.sortObjects&&b.__webglObjects.sort(t);L=b.__webglObjectsImmediate.length;for(A=0;A<L;A++)y=b.__webglObjectsImmediate[A],K=y.object,K.visible&&(K.matrixAutoUpdate&&K.matrixWorld.flattenToArray(K._objectMatrixArray),B(K,c,!0),u(y));if(b.overrideMaterial){h(b.overrideMaterial.depthTest);E(b.overrideMaterial.blending);for(A=0;A<D;A++)if(y=b.__webglObjects[A],y.render)K=y.object,N=y.buffer,j(K),f(c,M,P,b.overrideMaterial,N,K);for(A=0;A<L;A++)y=b.__webglObjectsImmediate[A],
K=y.object,K.visible&&(j(K),G=e(c,M,P,b.overrideMaterial,K),K.render(function(c){g(c,G,b.overrideMaterial.shading)}))}else{E(THREE.NormalBlending);for(A=D-1;A>=0;A--)if(y=b.__webglObjects[A],y.render){K=y.object;N=y.buffer;H=y.opaque;j(K);for(y=0;y<H.count;y++)I=H.list[y],h(I.depthTest),k(I.polygonOffset,I.polygonOffsetFactor,I.polygonOffsetUnits),f(c,M,P,I,N,K)}for(A=0;A<L;A++)if(y=b.__webglObjectsImmediate[A],K=y.object,K.visible){H=y.opaque;j(K);for(y=0;y<H.count;y++)I=H.list[y],h(I.depthTest),
k(I.polygonOffset,I.polygonOffsetFactor,I.polygonOffsetUnits),G=e(c,M,P,I,K),K.render(function(b){g(b,G,I.shading)})}for(A=0;A<D;A++)if(y=b.__webglObjects[A],y.render){K=y.object;N=y.buffer;H=y.transparent;j(K);for(y=0;y<H.count;y++)I=H.list[y],E(I.blending),h(I.depthTest),k(I.polygonOffset,I.polygonOffsetFactor,I.polygonOffsetUnits),f(c,M,P,I,N,K)}for(A=0;A<L;A++)if(y=b.__webglObjectsImmediate[A],K=y.object,K.visible){H=y.transparent;j(K);for(y=0;y<H.count;y++)I=H.list[y],E(I.blending),h(I.depthTest),
k(I.polygonOffset,I.polygonOffsetFactor,I.polygonOffsetUnits),G=e(c,M,P,I,K),K.render(function(b){g(b,G,I.shading)})}}b.__webglSprites.length&&x(b,c);p&&p.minFilter!==THREE.NearestFilter&&p.minFilter!==THREE.LinearFilter&&(n.bindTexture(n.TEXTURE_2D,p.__webglTexture),n.generateMipmap(n.TEXTURE_2D),n.bindTexture(n.TEXTURE_2D,null))};this.initWebGLObjects=function(b){if(!b.__webglObjects)b.__webglObjects=[],b.__webglObjectsImmediate=[],b.__webglSprites=[];for(;b.__objectsAdded.length;){var e=b.__objectsAdded[0],
f=b,g=void 0,h=void 0,j=void 0;if(e._modelViewMatrix==void 0)e._modelViewMatrix=new THREE.Matrix4,e._normalMatrixArray=new Float32Array(9),e._modelViewMatrixArray=new Float32Array(16),e._objectMatrixArray=new Float32Array(16),e.matrixWorld.flattenToArray(e._objectMatrixArray);if(e instanceof THREE.Mesh)for(g in h=e.geometry,h.geometryGroups==void 0&&G(h),h.geometryGroups){j=h.geometryGroups[g];if(!j.__webglVertexBuffer){var k=j;k.__webglVertexBuffer=n.createBuffer();k.__webglNormalBuffer=n.createBuffer();
k.__webglTangentBuffer=n.createBuffer();k.__webglColorBuffer=n.createBuffer();k.__webglUVBuffer=n.createBuffer();k.__webglUV2Buffer=n.createBuffer();k.__webglSkinVertexABuffer=n.createBuffer();k.__webglSkinVertexBBuffer=n.createBuffer();k.__webglSkinIndicesBuffer=n.createBuffer();k.__webglSkinWeightsBuffer=n.createBuffer();k.__webglFaceBuffer=n.createBuffer();k.__webglLineBuffer=n.createBuffer();if(k.numMorphTargets){var m=void 0,o=void 0;k.__webglMorphTargetsBuffers=[];m=0;for(o=k.numMorphTargets;m<
o;m++)k.__webglMorphTargetsBuffers.push(n.createBuffer())}for(var k=j,m=e,u=void 0,p=void 0,t=void 0,v=t=void 0,w=void 0,x=void 0,B=x=o=0,D=t=p=void 0,ja=D=p=u=void 0,t=void 0,v=m.geometry,w=v.faces,D=k.faces,u=0,p=D.length;u<p;u++)t=D[u],t=w[t],t instanceof THREE.Face3?(o+=3,x+=1,B+=3):t instanceof THREE.Face4&&(o+=4,x+=2,B+=4);for(var u=k,p=m,E=D=w=void 0,J=void 0,E=void 0,t=[],w=0,D=p.materials.length;w<D;w++)if(E=p.materials[w],E instanceof THREE.MeshFaceMaterial){E=0;for(l=u.materials.length;E<
l;E++)(J=u.materials[E])&&t.push(J)}else(J=E)&&t.push(J);u=t;k.__materials=u;a:{w=p=void 0;D=u.length;for(p=0;p<D;p++)if(w=u[p],w.map||w.lightMap||w instanceof THREE.MeshShaderMaterial){p=!0;break a}p=!1}a:{D=w=void 0;t=u.length;for(w=0;w<t;w++)if(D=u[w],!(D instanceof THREE.MeshBasicMaterial&&!D.envMap||D instanceof THREE.MeshDepthMaterial)){D=D&&D.shading!=void 0&&D.shading==THREE.SmoothShading?THREE.SmoothShading:THREE.FlatShading;break a}D=!1}a:{t=w=void 0;E=u.length;for(w=0;w<E;w++)if(t=u[w],
t.vertexColors){t=t.vertexColors;break a}t=!1}k.__vertexArray=new Float32Array(o*3);if(D)k.__normalArray=new Float32Array(o*3);if(v.hasTangents)k.__tangentArray=new Float32Array(o*4);if(t)k.__colorArray=new Float32Array(o*3);if(p){if(v.faceUvs.length>0||v.faceVertexUvs.length>0)k.__uvArray=new Float32Array(o*2);if(v.faceUvs.length>1||v.faceVertexUvs.length>1)k.__uv2Array=new Float32Array(o*2)}if(m.geometry.skinWeights.length&&m.geometry.skinIndices.length)k.__skinVertexAArray=new Float32Array(o*4),
k.__skinVertexBArray=new Float32Array(o*4),k.__skinIndexArray=new Float32Array(o*4),k.__skinWeightArray=new Float32Array(o*4);k.__faceArray=new Uint16Array(x*3+(m.geometry.edgeFaces?m.geometry.edgeFaces.length*6:0));k.__lineArray=new Uint16Array(B*2);if(k.numMorphTargets){k.__morphTargetsArrays=[];v=0;for(w=k.numMorphTargets;v<w;v++)k.__morphTargetsArrays.push(new Float32Array(o*3))}k.__needsSmoothNormals=D==THREE.SmoothShading;k.__uvType=p;k.__vertexColorType=t;k.__normalType=D;k.__webglFaceCount=
x*3+(m.geometry.edgeFaces?m.geometry.edgeFaces.length*6:0);k.__webglLineCount=B*2;v=0;for(w=u.length;v<w;v++)if(p=u[v],p.attributes){if(k.__webglCustomAttributes===void 0)k.__webglCustomAttributes={};for(a in p.attributes){t=p.attributes[a];D={};for(ja in t)D[ja]=t[ja];if(!D.__webglInitialized||D.createUniqueBuffers)D.__webglInitialized=!0,x=1,D.type==="v2"?x=2:D.type==="v3"?x=3:D.type==="v4"?x=4:D.type==="c"&&(x=3),D.size=x,D.array=new Float32Array(o*x),D.buffer=n.createBuffer(),D.buffer.belongsToAttribute=
a,t.needsUpdate=!0,D.__original=t;k.__webglCustomAttributes[a]=D}}k.__inittedArrays=!0;h.__dirtyVertices=!0;h.__dirtyMorphTargets=!0;h.__dirtyElements=!0;h.__dirtyUvs=!0;h.__dirtyNormals=!0;h.__dirtyTangents=!0;h.__dirtyColors=!0}I(f.__webglObjects,j,e)}else if(e instanceof THREE.Ribbon){h=e.geometry;if(!h.__webglVertexBuffer)g=h,g.__webglVertexBuffer=n.createBuffer(),g.__webglColorBuffer=n.createBuffer(),g=h,j=g.vertices.length,g.__vertexArray=new Float32Array(j*3),g.__colorArray=new Float32Array(j*
3),g.__webglVertexCount=j,h.__dirtyVertices=!0,h.__dirtyColors=!0;I(f.__webglObjects,h,e)}else if(e instanceof THREE.Line){h=e.geometry;if(!h.__webglVertexBuffer)g=h,g.__webglVertexBuffer=n.createBuffer(),g.__webglColorBuffer=n.createBuffer(),g=h,j=g.vertices.length,g.__vertexArray=new Float32Array(j*3),g.__colorArray=new Float32Array(j*3),g.__webglLineCount=j,h.__dirtyVertices=!0,h.__dirtyColors=!0;I(f.__webglObjects,h,e)}else if(e instanceof THREE.ParticleSystem){h=e.geometry;if(!h.__webglVertexBuffer){g=
h;g.__webglVertexBuffer=n.createBuffer();g.__webglColorBuffer=n.createBuffer();g=h;j=e;k=g.vertices.length;g.__vertexArray=new Float32Array(k*3);g.__colorArray=new Float32Array(k*3);g.__sortArray=[];g.__webglParticleCount=k;g.__materials=j.materials;ja=o=m=void 0;m=0;for(o=j.materials.length;m<o;m++)if(ja=j.materials[m],ja.attributes){if(g.__webglCustomAttributes===void 0)g.__webglCustomAttributes={};for(a in ja.attributes){originalAttribute=ja.attributes[a];attribute={};for(property in originalAttribute)attribute[property]=
originalAttribute[property];if(!attribute.__webglInitialized||attribute.createUniqueBuffers)attribute.__webglInitialized=!0,size=1,attribute.type==="v2"?size=2:attribute.type==="v3"?size=3:attribute.type==="v4"?size=4:attribute.type==="c"&&(size=3),attribute.size=size,attribute.array=new Float32Array(k*size),attribute.buffer=n.createBuffer(),attribute.buffer.belongsToAttribute=a,originalAttribute.needsUpdate=!0,attribute.__original=originalAttribute;g.__webglCustomAttributes[a]=attribute}}h.__dirtyVertices=
!0;h.__dirtyColors=!0}I(f.__webglObjects,h,e)}else THREE.MarchingCubes!==void 0&&e instanceof THREE.MarchingCubes?f.__webglObjectsImmediate.push({object:e,opaque:{list:[],count:0},transparent:{list:[],count:0}}):e instanceof THREE.Sprite&&f.__webglSprites.push(e);b.__objectsAdded.splice(0,1)}for(;b.__objectsRemoved.length;){f=b.__objectsRemoved[0];e=b;if(f instanceof THREE.Mesh||f instanceof THREE.ParticleSystem||f instanceof THREE.Ribbon||f instanceof THREE.Line)y(e.__webglObjects,f);else if(f instanceof
THREE.Sprite){e=e.__webglSprites;h=void 0;for(h=e.length-1;h>=0;h--)e[h]==f&&e.splice(h,1)}else f instanceof THREE.MarchingCubes&&y(e.__webglObjectsImmediate,f);b.__objectsRemoved.splice(0,1)}e=0;for(f=b.__webglObjects.length;e<f;e++)if(g=b.__webglObjects[e].object,m=k=h=j=void 0,g instanceof THREE.Mesh){h=g.geometry;for(j in h.geometryGroups)if(k=h.geometryGroups[j],m=A(k),h.__dirtyVertices||h.__dirtyMorphTargets||h.__dirtyElements||h.__dirtyUvs||h.__dirtyNormals||h.__dirtyColors||h.__dirtyTangents||
m)if(m=k,o=n.DYNAMIC_DRAW,ja=!h.dynamic,m.__inittedArrays){var K=B=x=void 0,C=void 0,la=K=void 0,L=void 0,N=void 0,M=void 0,P=J=E=t=D=w=p=u=v=void 0,F=C=M=C=N=L=void 0,z=void 0,Q=z=F=L=void 0,S=void 0,R=Q=z=F=K=K=la=M=C=Q=z=F=S=Q=z=F=S=Q=z=F=void 0,ka=0,U=0,pa=0,X=0,W=0,ha=0,T=0,aa=0,V=0,O=0,Y=0,Q=F=0,Q=void 0,ia=m.__vertexArray,ea=m.__uvArray,fa=m.__uv2Array,da=m.__normalArray,Z=m.__tangentArray,sa=m.__colorArray,ca=m.__skinVertexAArray,$=m.__skinVertexBArray,qa=m.__skinIndexArray,ra=m.__skinWeightArray,
ta=m.__morphTargetsArrays,ua=m.__webglCustomAttributes,z=void 0,oa=m.__faceArray,ma=m.__lineArray,va=m.__needsSmoothNormals,u=m.__vertexColorType,v=m.__uvType,p=m.__normalType,xa=g.geometry,ya=xa.__dirtyVertices,Ia=xa.__dirtyElements,za=xa.__dirtyUvs,Ja=xa.__dirtyNormals,Ka=xa.__dirtyTangents,Da=xa.__dirtyColors,Ea=xa.__dirtyMorphTargets,Pa=xa.vertices,Ga=m.faces,cb=xa.faces,ab=xa.faceVertexUvs[0],bb=xa.faceVertexUvs[1],Qa=xa.skinVerticesA,Ra=xa.skinVerticesB,Sa=xa.skinIndices,Ha=xa.skinWeights,Fa=
xa.morphTargets;if(ua)for(R in ua)ua[R].offset=0,ua[R].offsetSrc=0;x=0;for(B=Ga.length;x<B;x++)if(K=Ga[x],C=cb[K],ab&&(w=ab[K]),bb&&(D=bb[K]),K=C.vertexNormals,la=C.normal,L=C.vertexColors,N=C.color,M=C.vertexTangents,C instanceof THREE.Face3){if(ya)t=Pa[C.a].position,E=Pa[C.b].position,J=Pa[C.c].position,ia[U]=t.x,ia[U+1]=t.y,ia[U+2]=t.z,ia[U+3]=E.x,ia[U+4]=E.y,ia[U+5]=E.z,ia[U+6]=J.x,ia[U+7]=J.y,ia[U+8]=J.z,U+=9;if(ua)for(R in ua)if(z=ua[R],z.__original.needsUpdate)F=z.offset,Q=z.offsetSrc,z.size===
1?(z.boundTo===void 0||z.boundTo==="vertices"?(z.array[F]=z.value[C.a],z.array[F+1]=z.value[C.b],z.array[F+2]=z.value[C.c]):z.boundTo==="faces"?(Q=z.value[Q],z.array[F]=Q,z.array[F+1]=Q,z.array[F+2]=Q,z.offsetSrc++):z.boundTo==="faceVertices"&&(z.array[F]=z.value[Q],z.array[F+1]=z.value[Q+1],z.array[F+2]=z.value[Q+2],z.offsetSrc+=3),z.offset+=3):(z.boundTo===void 0||z.boundTo==="vertices"?(t=z.value[C.a],E=z.value[C.b],J=z.value[C.c]):z.boundTo==="faces"?(J=E=t=Q=z.value[Q],z.offsetSrc++):z.boundTo===
"faceVertices"&&(t=z.value[Q],E=z.value[Q+1],J=z.value[Q+2],z.offsetSrc+=3),z.size===2?(z.array[F]=t.x,z.array[F+1]=t.y,z.array[F+2]=E.x,z.array[F+3]=E.y,z.array[F+4]=J.x,z.array[F+5]=J.y,z.offset+=6):z.size===3?(z.type==="c"?(z.array[F]=t.r,z.array[F+1]=t.g,z.array[F+2]=t.b,z.array[F+3]=E.r,z.array[F+4]=E.g,z.array[F+5]=E.b,z.array[F+6]=J.r,z.array[F+7]=J.g,z.array[F+8]=J.b):(z.array[F]=t.x,z.array[F+1]=t.y,z.array[F+2]=t.z,z.array[F+3]=E.x,z.array[F+4]=E.y,z.array[F+5]=E.z,z.array[F+6]=J.x,z.array[F+
7]=J.y,z.array[F+8]=J.z),z.offset+=9):(z.array[F]=t.x,z.array[F+1]=t.y,z.array[F+2]=t.z,z.array[F+3]=t.w,z.array[F+4]=E.x,z.array[F+5]=E.y,z.array[F+6]=E.z,z.array[F+7]=E.w,z.array[F+8]=J.x,z.array[F+9]=J.y,z.array[F+10]=J.z,z.array[F+11]=J.w,z.offset+=12));if(Ea){F=0;for(z=Fa.length;F<z;F++)t=Fa[F].vertices[C.a].position,E=Fa[F].vertices[C.b].position,J=Fa[F].vertices[C.c].position,Q=ta[F],Q[Y]=t.x,Q[Y+1]=t.y,Q[Y+2]=t.z,Q[Y+3]=E.x,Q[Y+4]=E.y,Q[Y+5]=E.z,Q[Y+6]=J.x,Q[Y+7]=J.y,Q[Y+8]=J.z;Y+=9}if(Ha.length)F=
Ha[C.a],z=Ha[C.b],Q=Ha[C.c],ra[O]=F.x,ra[O+1]=F.y,ra[O+2]=F.z,ra[O+3]=F.w,ra[O+4]=z.x,ra[O+5]=z.y,ra[O+6]=z.z,ra[O+7]=z.w,ra[O+8]=Q.x,ra[O+9]=Q.y,ra[O+10]=Q.z,ra[O+11]=Q.w,F=Sa[C.a],z=Sa[C.b],Q=Sa[C.c],qa[O]=F.x,qa[O+1]=F.y,qa[O+2]=F.z,qa[O+3]=F.w,qa[O+4]=z.x,qa[O+5]=z.y,qa[O+6]=z.z,qa[O+7]=z.w,qa[O+8]=Q.x,qa[O+9]=Q.y,qa[O+10]=Q.z,qa[O+11]=Q.w,F=Qa[C.a],z=Qa[C.b],Q=Qa[C.c],ca[O]=F.x,ca[O+1]=F.y,ca[O+2]=F.z,ca[O+3]=1,ca[O+4]=z.x,ca[O+5]=z.y,ca[O+6]=z.z,ca[O+7]=1,ca[O+8]=Q.x,ca[O+9]=Q.y,ca[O+10]=Q.z,
ca[O+11]=1,F=Ra[C.a],z=Ra[C.b],Q=Ra[C.c],$[O]=F.x,$[O+1]=F.y,$[O+2]=F.z,$[O+3]=1,$[O+4]=z.x,$[O+5]=z.y,$[O+6]=z.z,$[O+7]=1,$[O+8]=Q.x,$[O+9]=Q.y,$[O+10]=Q.z,$[O+11]=1,O+=12;if(Da&&u)L.length==3&&u==THREE.VertexColors?(C=L[0],F=L[1],z=L[2]):z=F=C=N,sa[V]=C.r,sa[V+1]=C.g,sa[V+2]=C.b,sa[V+3]=F.r,sa[V+4]=F.g,sa[V+5]=F.b,sa[V+6]=z.r,sa[V+7]=z.g,sa[V+8]=z.b,V+=9;if(Ka&&xa.hasTangents)L=M[0],N=M[1],C=M[2],Z[T]=L.x,Z[T+1]=L.y,Z[T+2]=L.z,Z[T+3]=L.w,Z[T+4]=N.x,Z[T+5]=N.y,Z[T+6]=N.z,Z[T+7]=N.w,Z[T+8]=C.x,Z[T+
9]=C.y,Z[T+10]=C.z,Z[T+11]=C.w,T+=12;if(Ja&&p)if(K.length==3&&va)for(M=0;M<3;M++)la=K[M],da[ha]=la.x,da[ha+1]=la.y,da[ha+2]=la.z,ha+=3;else for(M=0;M<3;M++)da[ha]=la.x,da[ha+1]=la.y,da[ha+2]=la.z,ha+=3;if(za&&w!==void 0&&v)for(M=0;M<3;M++)K=w[M],ea[pa]=K.u,ea[pa+1]=K.v,pa+=2;if(za&&D!==void 0&&v)for(M=0;M<3;M++)K=D[M],fa[X]=K.u,fa[X+1]=K.v,X+=2;Ia&&(oa[W]=ka,oa[W+1]=ka+1,oa[W+2]=ka+2,W+=3,ma[aa]=ka,ma[aa+1]=ka+1,ma[aa+2]=ka,ma[aa+3]=ka+2,ma[aa+4]=ka+1,ma[aa+5]=ka+2,aa+=6,ka+=3)}else if(C instanceof
THREE.Face4){if(ya)t=Pa[C.a].position,E=Pa[C.b].position,J=Pa[C.c].position,P=Pa[C.d].position,ia[U]=t.x,ia[U+1]=t.y,ia[U+2]=t.z,ia[U+3]=E.x,ia[U+4]=E.y,ia[U+5]=E.z,ia[U+6]=J.x,ia[U+7]=J.y,ia[U+8]=J.z,ia[U+9]=P.x,ia[U+10]=P.y,ia[U+11]=P.z,U+=12;if(ua)for(R in ua)if(z=ua[R],z.__original.needsUpdate)F=z.offset,Q=z.offsetSrc,z.size===1?(z.boundTo===void 0||z.boundTo==="vertices"?(z.array[F]=z.value[C.a],z.array[F+1]=z.value[C.b],z.array[F+2]=z.value[C.c],z.array[F+3]=z.value[C.d]):z.boundTo==="faces"?
(Q=z.value[Q],z.array[F]=Q,z.array[F+1]=Q,z.array[F+2]=Q,z.array[F+3]=Q,z.offsetSrc++):z.boundTo==="faceVertices"&&(z.array[F]=z.value[Q],z.array[F+1]=z.value[Q+1],z.array[F+2]=z.value[Q+2],z.array[F+3]=z.value[Q+3],z.offsetSrc+=4),z.offset+=4):(z.boundTo===void 0||z.boundTo==="vertices"?(t=z.value[C.a],E=z.value[C.b],J=z.value[C.c],P=z.value[C.d]):z.boundTo==="faces"?(P=J=E=t=Q=z.value[Q],z.offsetSrc++):z.boundTo==="faceVertices"&&(t=z.value[Q],E=z.value[Q+1],J=z.value[Q+2],P=z.value[Q+3],z.offsetSrc+=
4),z.size===2?(z.array[F]=t.x,z.array[F+1]=t.y,z.array[F+2]=E.x,z.array[F+3]=E.y,z.array[F+4]=J.x,z.array[F+5]=J.y,z.array[F+6]=P.x,z.array[F+7]=P.y,z.offset+=8):z.size===3?(z.type==="c"?(z.array[F]=t.r,z.array[F+1]=t.g,z.array[F+2]=t.b,z.array[F+3]=E.r,z.array[F+4]=E.g,z.array[F+5]=E.b,z.array[F+6]=J.r,z.array[F+7]=J.g,z.array[F+8]=J.b,z.array[F+9]=P.r,z.array[F+10]=P.g,z.array[F+11]=P.b):(z.array[F]=t.x,z.array[F+1]=t.y,z.array[F+2]=t.z,z.array[F+3]=E.x,z.array[F+4]=E.y,z.array[F+5]=E.z,z.array[F+
6]=J.x,z.array[F+7]=J.y,z.array[F+8]=J.z,z.array[F+9]=P.x,z.array[F+10]=P.y,z.array[F+11]=P.z),z.offset+=12):(z.array[F]=t.x,z.array[F+1]=t.y,z.array[F+2]=t.z,z.array[F+3]=t.w,z.array[F+4]=E.x,z.array[F+5]=E.y,z.array[F+6]=E.z,z.array[F+7]=E.w,z.array[F+8]=J.x,z.array[F+9]=J.y,z.array[F+10]=J.z,z.array[F+11]=J.w,z.array[F+12]=P.x,z.array[F+13]=P.y,z.array[F+14]=P.z,z.array[F+15]=P.w,z.offset+=16));if(Ea){F=0;for(z=Fa.length;F<z;F++)t=Fa[F].vertices[C.a].position,E=Fa[F].vertices[C.b].position,J=Fa[F].vertices[C.c].position,
P=Fa[F].vertices[C.d].position,Q=ta[F],Q[Y]=t.x,Q[Y+1]=t.y,Q[Y+2]=t.z,Q[Y+3]=E.x,Q[Y+4]=E.y,Q[Y+5]=E.z,Q[Y+6]=J.x,Q[Y+7]=J.y,Q[Y+8]=J.z,Q[Y+9]=P.x,Q[Y+10]=P.y,Q[Y+11]=P.z;Y+=12}if(Ha.length)F=Ha[C.a],z=Ha[C.b],Q=Ha[C.c],S=Ha[C.d],ra[O]=F.x,ra[O+1]=F.y,ra[O+2]=F.z,ra[O+3]=F.w,ra[O+4]=z.x,ra[O+5]=z.y,ra[O+6]=z.z,ra[O+7]=z.w,ra[O+8]=Q.x,ra[O+9]=Q.y,ra[O+10]=Q.z,ra[O+11]=Q.w,ra[O+12]=S.x,ra[O+13]=S.y,ra[O+14]=S.z,ra[O+15]=S.w,F=Sa[C.a],z=Sa[C.b],Q=Sa[C.c],S=Sa[C.d],qa[O]=F.x,qa[O+1]=F.y,qa[O+2]=F.z,qa[O+
3]=F.w,qa[O+4]=z.x,qa[O+5]=z.y,qa[O+6]=z.z,qa[O+7]=z.w,qa[O+8]=Q.x,qa[O+9]=Q.y,qa[O+10]=Q.z,qa[O+11]=Q.w,qa[O+12]=S.x,qa[O+13]=S.y,qa[O+14]=S.z,qa[O+15]=S.w,F=Qa[C.a],z=Qa[C.b],Q=Qa[C.c],S=Qa[C.d],ca[O]=F.x,ca[O+1]=F.y,ca[O+2]=F.z,ca[O+3]=1,ca[O+4]=z.x,ca[O+5]=z.y,ca[O+6]=z.z,ca[O+7]=1,ca[O+8]=Q.x,ca[O+9]=Q.y,ca[O+10]=Q.z,ca[O+11]=1,ca[O+12]=S.x,ca[O+13]=S.y,ca[O+14]=S.z,ca[O+15]=1,F=Ra[C.a],z=Ra[C.b],Q=Ra[C.c],C=Ra[C.d],$[O]=F.x,$[O+1]=F.y,$[O+2]=F.z,$[O+3]=1,$[O+4]=z.x,$[O+5]=z.y,$[O+6]=z.z,$[O+
7]=1,$[O+8]=Q.x,$[O+9]=Q.y,$[O+10]=Q.z,$[O+11]=1,$[O+12]=C.x,$[O+13]=C.y,$[O+14]=C.z,$[O+15]=1,O+=16;if(Da&&u)L.length==4&&u==THREE.VertexColors?(C=L[0],F=L[1],z=L[2],L=L[3]):L=z=F=C=N,sa[V]=C.r,sa[V+1]=C.g,sa[V+2]=C.b,sa[V+3]=F.r,sa[V+4]=F.g,sa[V+5]=F.b,sa[V+6]=z.r,sa[V+7]=z.g,sa[V+8]=z.b,sa[V+9]=L.r,sa[V+10]=L.g,sa[V+11]=L.b,V+=12;if(Ka&&xa.hasTangents)L=M[0],N=M[1],C=M[2],M=M[3],Z[T]=L.x,Z[T+1]=L.y,Z[T+2]=L.z,Z[T+3]=L.w,Z[T+4]=N.x,Z[T+5]=N.y,Z[T+6]=N.z,Z[T+7]=N.w,Z[T+8]=C.x,Z[T+9]=C.y,Z[T+10]=
C.z,Z[T+11]=C.w,Z[T+12]=M.x,Z[T+13]=M.y,Z[T+14]=M.z,Z[T+15]=M.w,T+=16;if(Ja&&p)if(K.length==4&&va)for(M=0;M<4;M++)la=K[M],da[ha]=la.x,da[ha+1]=la.y,da[ha+2]=la.z,ha+=3;else for(M=0;M<4;M++)da[ha]=la.x,da[ha+1]=la.y,da[ha+2]=la.z,ha+=3;if(za&&w!==void 0&&v)for(M=0;M<4;M++)K=w[M],ea[pa]=K.u,ea[pa+1]=K.v,pa+=2;if(za&&D!==void 0&&v)for(M=0;M<4;M++)K=D[M],fa[X]=K.u,fa[X+1]=K.v,X+=2;Ia&&(oa[W]=ka,oa[W+1]=ka+1,oa[W+2]=ka+3,oa[W+3]=ka+1,oa[W+4]=ka+2,oa[W+5]=ka+3,W+=6,ma[aa]=ka,ma[aa+1]=ka+1,ma[aa+2]=ka,ma[aa+
3]=ka+3,ma[aa+4]=ka+1,ma[aa+5]=ka+2,ma[aa+6]=ka+2,ma[aa+7]=ka+3,aa+=8,ka+=4)}ya&&(n.bindBuffer(n.ARRAY_BUFFER,m.__webglVertexBuffer),n.bufferData(n.ARRAY_BUFFER,ia,o));if(ua)for(R in ua)z=ua[R],z.__original.needsUpdate&&(n.bindBuffer(n.ARRAY_BUFFER,z.buffer),n.bufferData(n.ARRAY_BUFFER,z.array,o));if(Ea){F=0;for(z=Fa.length;F<z;F++)n.bindBuffer(n.ARRAY_BUFFER,m.__webglMorphTargetsBuffers[F]),n.bufferData(n.ARRAY_BUFFER,ta[F],o)}Da&&V>0&&(n.bindBuffer(n.ARRAY_BUFFER,m.__webglColorBuffer),n.bufferData(n.ARRAY_BUFFER,
sa,o));Ja&&(n.bindBuffer(n.ARRAY_BUFFER,m.__webglNormalBuffer),n.bufferData(n.ARRAY_BUFFER,da,o));Ka&&xa.hasTangents&&(n.bindBuffer(n.ARRAY_BUFFER,m.__webglTangentBuffer),n.bufferData(n.ARRAY_BUFFER,Z,o));za&&pa>0&&(n.bindBuffer(n.ARRAY_BUFFER,m.__webglUVBuffer),n.bufferData(n.ARRAY_BUFFER,ea,o));za&&X>0&&(n.bindBuffer(n.ARRAY_BUFFER,m.__webglUV2Buffer),n.bufferData(n.ARRAY_BUFFER,fa,o));Ia&&(n.bindBuffer(n.ELEMENT_ARRAY_BUFFER,m.__webglFaceBuffer),n.bufferData(n.ELEMENT_ARRAY_BUFFER,oa,o),n.bindBuffer(n.ELEMENT_ARRAY_BUFFER,
m.__webglLineBuffer),n.bufferData(n.ELEMENT_ARRAY_BUFFER,ma,o));O>0&&(n.bindBuffer(n.ARRAY_BUFFER,m.__webglSkinVertexABuffer),n.bufferData(n.ARRAY_BUFFER,ca,o),n.bindBuffer(n.ARRAY_BUFFER,m.__webglSkinVertexBBuffer),n.bufferData(n.ARRAY_BUFFER,$,o),n.bindBuffer(n.ARRAY_BUFFER,m.__webglSkinIndicesBuffer),n.bufferData(n.ARRAY_BUFFER,qa,o),n.bindBuffer(n.ARRAY_BUFFER,m.__webglSkinWeightsBuffer),n.bufferData(n.ARRAY_BUFFER,ra,o));ja&&(delete m.__inittedArrays,delete m.__colorArray,delete m.__normalArray,
delete m.__tangentArray,delete m.__uvArray,delete m.__uv2Array,delete m.__faceArray,delete m.__vertexArray,delete m.__lineArray,delete m.__skinVertexAArray,delete m.__skinVertexBArray,delete m.__skinIndexArray,delete m.__skinWeightArray)}h.__dirtyVertices=!1;h.__dirtyMorphTargets=!1;h.__dirtyElements=!1;h.__dirtyUvs=!1;h.__dirtyNormals=!1;h.__dirtyTangents=!1;h.__dirtyColors=!1;H(k)}else if(g instanceof THREE.Ribbon){h=g.geometry;if(h.__dirtyVertices||h.__dirtyColors){g=h;j=n.DYNAMIC_DRAW;k=B=x=x=
void 0;v=g.vertices;m=g.colors;u=v.length;o=m.length;p=g.__vertexArray;ja=g.__colorArray;w=g.__dirtyColors;if(g.__dirtyVertices){for(x=0;x<u;x++)B=v[x].position,k=x*3,p[k]=B.x,p[k+1]=B.y,p[k+2]=B.z;n.bindBuffer(n.ARRAY_BUFFER,g.__webglVertexBuffer);n.bufferData(n.ARRAY_BUFFER,p,j)}if(w){for(x=0;x<o;x++)color=m[x],k=x*3,ja[k]=color.r,ja[k+1]=color.g,ja[k+2]=color.b;n.bindBuffer(n.ARRAY_BUFFER,g.__webglColorBuffer);n.bufferData(n.ARRAY_BUFFER,ja,j)}}h.__dirtyVertices=!1;h.__dirtyColors=!1}else if(g instanceof
THREE.Line){h=g.geometry;if(h.__dirtyVertices||h.__dirtyColors){g=h;j=n.DYNAMIC_DRAW;k=B=x=x=void 0;v=g.vertices;m=g.colors;u=v.length;o=m.length;p=g.__vertexArray;ja=g.__colorArray;w=g.__dirtyColors;if(g.__dirtyVertices){for(x=0;x<u;x++)B=v[x].position,k=x*3,p[k]=B.x,p[k+1]=B.y,p[k+2]=B.z;n.bindBuffer(n.ARRAY_BUFFER,g.__webglVertexBuffer);n.bufferData(n.ARRAY_BUFFER,p,j)}if(w){for(x=0;x<o;x++)color=m[x],k=x*3,ja[k]=color.r,ja[k+1]=color.g,ja[k+2]=color.b;n.bindBuffer(n.ARRAY_BUFFER,g.__webglColorBuffer);
n.bufferData(n.ARRAY_BUFFER,ja,j)}}h.__dirtyVertices=!1;h.__dirtyColors=!1}else if(g instanceof THREE.ParticleSystem)h=g.geometry,m=A(h),(h.__dirtyVertices||h.__dirtyColors||g.sortParticles||m)&&c(h,n.DYNAMIC_DRAW,g),h.__dirtyVertices=!1,h.__dirtyColors=!1,H(h)};this.setFaceCulling=function(b,c){b?(!c||c=="ccw"?n.frontFace(n.CCW):n.frontFace(n.CW),b=="back"?n.cullFace(n.BACK):b=="front"?n.cullFace(n.FRONT):n.cullFace(n.FRONT_AND_BACK),n.enable(n.CULL_FACE)):n.disable(n.CULL_FACE)};this.supportsVertexTextures=
function(){return Da}};
THREE.WebGLRenderTarget=function(b,c,e){this.width=b;this.height=c;e=e||{};this.wrapS=e.wrapS!==void 0?e.wrapS:THREE.ClampToEdgeWrapping;this.wrapT=e.wrapT!==void 0?e.wrapT:THREE.ClampToEdgeWrapping;this.magFilter=e.magFilter!==void 0?e.magFilter:THREE.LinearFilter;this.minFilter=e.minFilter!==void 0?e.minFilter:THREE.LinearMipMapLinearFilter;this.offset=new THREE.Vector2(0,0);this.repeat=new THREE.Vector2(1,1);this.format=e.format!==void 0?e.format:THREE.RGBAFormat;this.type=e.type!==void 0?e.type:
THREE.UnsignedByteType;this.depthBuffer=e.depthBuffer!==void 0?e.depthBuffer:!0;this.stencilBuffer=e.stencilBuffer!==void 0?e.stencilBuffer:!0};THREE.RenderableVertex=function(){this.positionWorld=new THREE.Vector3;this.positionScreen=new THREE.Vector4;this.visible=!0};THREE.RenderableVertex.prototype.copy=function(b){this.positionWorld.copy(b.positionWorld);this.positionScreen.copy(b.positionScreen)};
THREE.RenderableFace3=function(){this.v1=new THREE.RenderableVertex;this.v2=new THREE.RenderableVertex;this.v3=new THREE.RenderableVertex;this.centroidWorld=new THREE.Vector3;this.centroidScreen=new THREE.Vector3;this.normalWorld=new THREE.Vector3;this.vertexNormalsWorld=[new THREE.Vector3,new THREE.Vector3,new THREE.Vector3];this.faceMaterials=this.meshMaterials=null;this.overdraw=!1;this.uvs=[[]];this.z=null};
THREE.RenderableFace4=function(){this.v1=new THREE.RenderableVertex;this.v2=new THREE.RenderableVertex;this.v3=new THREE.RenderableVertex;this.v4=new THREE.RenderableVertex;this.centroidWorld=new THREE.Vector3;this.centroidScreen=new THREE.Vector3;this.normalWorld=new THREE.Vector3;this.vertexNormalsWorld=[new THREE.Vector3,new THREE.Vector3,new THREE.Vector3,new THREE.Vector3];this.faceMaterials=this.meshMaterials=null;this.overdraw=!1;this.uvs=[[]];this.z=null};
THREE.RenderableObject=function(){this.z=this.object=null};THREE.RenderableParticle=function(){this.rotation=this.z=this.y=this.x=null;this.scale=new THREE.Vector2;this.materials=null};THREE.RenderableLine=function(){this.z=null;this.v1=new THREE.RenderableVertex;this.v2=new THREE.RenderableVertex;this.materials=null};
THREE.ColorUtils={adjustHSV:function(b,c,e,f){var g=THREE.ColorUtils.__hsv;THREE.ColorUtils.rgbToHsv(b,g);g.h=THREE.ColorUtils.clamp(g.h+c,0,1);g.s=THREE.ColorUtils.clamp(g.s+e,0,1);g.v=THREE.ColorUtils.clamp(g.v+f,0,1);b.setHSV(g.h,g.s,g.v)},rgbToHsv:function(b,c){var e=b.r,f=b.g,g=b.b,j=Math.max(Math.max(e,f),g),h=Math.min(Math.min(e,f),g);if(h==j)h=e=0;else{var k=j-h,h=k/j,e=e==j?(f-g)/k:f==j?2+(g-e)/k:4+(e-f)/k;e/=6;e<0&&(e+=1);e>1&&(e-=1)}c===void 0&&(c={h:0,s:0,v:0});c.h=e;c.s=h;c.v=j;return c},
clamp:function(b,c,e){return b<c?c:b>e?e:b}};THREE.ColorUtils.__hsv={h:0,s:0,v:0};
THREE.GeometryUtils={merge:function(b,c){var e=c instanceof THREE.Mesh,f=b.vertices.length,g=e?c.geometry:c,j=b.vertices,h=g.vertices,k=b.faces,o=g.faces,m=b.faceVertexUvs[0],g=g.faceVertexUvs[0];e&&c.matrixAutoUpdate&&c.updateMatrix();for(var p=0,u=h.length;p<u;p++){var v=new THREE.Vertex(h[p].position.clone());e&&c.matrix.multiplyVector3(v.position);j.push(v)}p=0;for(u=o.length;p<u;p++){var h=o[p],t,w,x=h.vertexNormals,v=h.vertexColors;h instanceof THREE.Face3?t=new THREE.Face3(h.a+f,h.b+f,h.c+
f):h instanceof THREE.Face4&&(t=new THREE.Face4(h.a+f,h.b+f,h.c+f,h.d+f));t.normal.copy(h.normal);e=0;for(j=x.length;e<j;e++)w=x[e],t.vertexNormals.push(w.clone());t.color.copy(h.color);e=0;for(j=v.length;e<j;e++)w=v[e],t.vertexColors.push(w.clone());t.materials=h.materials.slice();t.centroid.copy(h.centroid);k.push(t)}p=0;for(u=g.length;p<u;p++){f=g[p];k=[];e=0;for(j=f.length;e<j;e++)k.push(new THREE.UV(f[e].u,f[e].v));m.push(k)}},clone:function(b){var c=new THREE.Geometry,e,f=b.vertices,g=b.faces,
j=b.faceVertexUvs[0],b=0;for(e=f.length;b<e;b++){var h=new THREE.Vertex(f[b].position.clone());c.vertices.push(h)}b=0;for(e=g.length;b<e;b++){var k=g[b],o,m,p=k.vertexNormals,u=k.vertexColors;k instanceof THREE.Face3?o=new THREE.Face3(k.a,k.b,k.c):k instanceof THREE.Face4&&(o=new THREE.Face4(k.a,k.b,k.c,k.d));o.normal.copy(k.normal);f=0;for(h=p.length;f<h;f++)m=p[f],o.vertexNormals.push(m.clone());o.color.copy(k.color);f=0;for(h=u.length;f<h;f++)m=u[f],o.vertexColors.push(m.clone());o.materials=k.materials.slice();
o.centroid.copy(k.centroid);c.faces.push(o)}b=0;for(e=j.length;b<e;b++){g=j[b];o=[];f=0;for(h=g.length;f<h;f++)o.push(new THREE.UV(g[f].u,g[f].v));c.faceVertexUvs[0].push(o)}return c},randomPointInTriangle:function(b,c,e){var f,g,j,h=new THREE.Vector3,k=THREE.GeometryUtils.__v1;f=THREE.GeometryUtils.random();g=THREE.GeometryUtils.random();f+g>1&&(f=1-f,g=1-g);j=1-f-g;h.copy(b);h.multiplyScalar(f);k.copy(c);k.multiplyScalar(g);h.addSelf(k);k.copy(e);k.multiplyScalar(j);h.addSelf(k);return h},randomPointInFace:function(b,
c,e){var f,g,j;if(b instanceof THREE.Face3)return f=c.vertices[b.a].position,g=c.vertices[b.b].position,j=c.vertices[b.c].position,THREE.GeometryUtils.randomPointInTriangle(f,g,j);else if(b instanceof THREE.Face4){f=c.vertices[b.a].position;g=c.vertices[b.b].position;j=c.vertices[b.c].position;var c=c.vertices[b.d].position,h;e?b._area1&&b._area2?(e=b._area1,h=b._area2):(e=THREE.GeometryUtils.triangleArea(f,g,c),h=THREE.GeometryUtils.triangleArea(g,j,c),b._area1=e,b._area2=h):(e=THREE.GeometryUtils.triangleArea(f,
g,c),h=THREE.GeometryUtils.triangleArea(g,j,c));return THREE.GeometryUtils.random()*(e+h)<e?THREE.GeometryUtils.randomPointInTriangle(f,g,c):THREE.GeometryUtils.randomPointInTriangle(g,j,c)}},randomPointsInGeometry:function(b,c){function e(b){function c(e,f){if(f<e)return e;var g=e+Math.floor((f-e)/2);return m[g]>b?c(e,g-1):m[g]<b?c(g+1,f):g}return c(0,m.length-1)}var f,g,j=b.faces,h=b.vertices,k=j.length,o=0,m=[],p,u,v,t;for(g=0;g<k;g++){f=j[g];if(f instanceof THREE.Face3)p=h[f.a].position,u=h[f.b].position,
v=h[f.c].position,f._area=THREE.GeometryUtils.triangleArea(p,u,v);else if(f instanceof THREE.Face4)p=h[f.a].position,u=h[f.b].position,v=h[f.c].position,t=h[f.d].position,f._area1=THREE.GeometryUtils.triangleArea(p,u,t),f._area2=THREE.GeometryUtils.triangleArea(u,v,t),f._area=f._area1+f._area2;o+=f._area;m[g]=o}f=[];h={};for(g=0;g<c;g++)k=THREE.GeometryUtils.random()*o,k=e(k),f[g]=THREE.GeometryUtils.randomPointInFace(j[k],b,!0),h[k]?h[k]+=1:h[k]=1;return f},triangleArea:function(b,c,e){var f,g=THREE.GeometryUtils.__v1;
g.sub(b,c);f=g.length();g.sub(b,e);b=g.length();g.sub(c,e);e=g.length();c=0.5*(f+b+e);return Math.sqrt(c*(c-f)*(c-b)*(c-e))},random16:function(){return(65280*Math.random()+255*Math.random())/65535}};THREE.GeometryUtils.random=THREE.GeometryUtils.random16;THREE.GeometryUtils.__v1=new THREE.Vector3;
THREE.ImageUtils={loadTexture:function(b,c,e){var f=new Image,g=new THREE.Texture(f,c);f.onload=function(){g.needsUpdate=!0;e&&e(this)};f.crossOrigin="";f.src=b;return g},loadTextureCube:function(b,c,e){var f,g=[],j=new THREE.Texture(g,c),c=g.loadCount=0;for(f=b.length;c<f;++c)g[c]=new Image,g[c].onload=function(){g.loadCount+=1;if(g.loadCount==6)j.needsUpdate=!0;e&&e(this)},g[c].crossOrigin="",g[c].src=b[c];return j}};
THREE.SceneUtils={showHierarchy:function(b,c){THREE.SceneUtils.traverseHierarchy(b,function(b){b.visible=c})},traverseHierarchy:function(b,c){var e,f,g=b.children.length;for(f=0;f<g;f++)e=b.children[f],c(e),THREE.SceneUtils.traverseHierarchy(e,c)}};
if(THREE.WebGLRenderer)THREE.ShaderUtils={lib:{fresnel:{uniforms:{mRefractionRatio:{type:"f",value:1.02},mFresnelBias:{type:"f",value:0.1},mFresnelPower:{type:"f",value:2},mFresnelScale:{type:"f",value:1},tCube:{type:"t",value:1,texture:null}},fragmentShader:"uniform samplerCube tCube;\nvarying vec3 vReflect;\nvarying vec3 vRefract[3];\nvarying float vReflectionFactor;\nvoid main() {\nvec4 reflectedColor = textureCube( tCube, vec3( -vReflect.x, vReflect.yz ) );\nvec4 refractedColor = vec4( 1.0, 1.0, 1.0, 1.0 );\nrefractedColor.r = textureCube( tCube, vec3( -vRefract[0].x, vRefract[0].yz ) ).r;\nrefractedColor.g = textureCube( tCube, vec3( -vRefract[1].x, vRefract[1].yz ) ).g;\nrefractedColor.b = textureCube( tCube, vec3( -vRefract[2].x, vRefract[2].yz ) ).b;\nrefractedColor.a = 1.0;\ngl_FragColor = mix( refractedColor, reflectedColor, clamp( vReflectionFactor, 0.0, 1.0 ) );\n}",vertexShader:"uniform float mRefractionRatio;\nuniform float mFresnelBias;\nuniform float mFresnelScale;\nuniform float mFresnelPower;\nvarying vec3 vReflect;\nvarying vec3 vRefract[3];\nvarying float vReflectionFactor;\nvoid main() {\nvec4 mvPosition = modelViewMatrix * vec4( position, 1.0 );\nvec4 mPosition = objectMatrix * vec4( position, 1.0 );\nvec3 nWorld = normalize ( mat3( objectMatrix[0].xyz, objectMatrix[1].xyz, objectMatrix[2].xyz ) * normal );\nvec3 I = mPosition.xyz - cameraPosition;\nvReflect = reflect( I, nWorld );\nvRefract[0] = refract( normalize( I ), nWorld, mRefractionRatio );\nvRefract[1] = refract( normalize( I ), nWorld, mRefractionRatio * 0.99 );\nvRefract[2] = refract( normalize( I ), nWorld, mRefractionRatio * 0.98 );\nvReflectionFactor = mFresnelBias + mFresnelScale * pow( 1.0 + dot( normalize( I ), nWorld ), mFresnelPower );\ngl_Position = projectionMatrix * mvPosition;\n}"},
normal:{uniforms:THREE.UniformsUtils.merge([THREE.UniformsLib.fog,THREE.UniformsLib.lights,{enableAO:{type:"i",value:0},enableDiffuse:{type:"i",value:0},enableSpecular:{type:"i",value:0},tDiffuse:{type:"t",value:0,texture:null},tNormal:{type:"t",value:2,texture:null},tSpecular:{type:"t",value:3,texture:null},tAO:{type:"t",value:4,texture:null},uNormalScale:{type:"f",value:1},tDisplacement:{type:"t",value:5,texture:null},uDisplacementBias:{type:"f",value:0},uDisplacementScale:{type:"f",value:1},uDiffuseColor:{type:"c",
value:new THREE.Color(15658734)},uSpecularColor:{type:"c",value:new THREE.Color(1118481)},uAmbientColor:{type:"c",value:new THREE.Color(328965)},uShininess:{type:"f",value:30},uOpacity:{type:"f",value:1}}]),fragmentShader:["uniform vec3 uAmbientColor;\nuniform vec3 uDiffuseColor;\nuniform vec3 uSpecularColor;\nuniform float uShininess;\nuniform float uOpacity;\nuniform bool enableDiffuse;\nuniform bool enableSpecular;\nuniform bool enableAO;\nuniform sampler2D tDiffuse;\nuniform sampler2D tNormal;\nuniform sampler2D tSpecular;\nuniform sampler2D tAO;\nuniform float uNormalScale;\nvarying vec3 vTangent;\nvarying vec3 vBinormal;\nvarying vec3 vNormal;\nvarying vec2 vUv;\nuniform vec3 ambientLightColor;\n#if MAX_DIR_LIGHTS > 0\nuniform vec3 directionalLightColor[ MAX_DIR_LIGHTS ];\nuniform vec3 directionalLightDirection[ MAX_DIR_LIGHTS ];\n#endif\n#if MAX_POINT_LIGHTS > 0\nuniform vec3 pointLightColor[ MAX_POINT_LIGHTS ];\nvarying vec4 vPointLight[ MAX_POINT_LIGHTS ];\n#endif\nvarying vec3 vViewPosition;",
THREE.ShaderChunk.fog_pars_fragment,"void main() {\ngl_FragColor = vec4( 1.0 );\nvec4 mColor = vec4( uDiffuseColor, uOpacity );\nvec4 mSpecular = vec4( uSpecularColor, uOpacity );\nvec3 specularTex = vec3( 1.0 );\nvec3 normalTex = texture2D( tNormal, vUv ).xyz * 2.0 - 1.0;\nnormalTex.xy *= uNormalScale;\nnormalTex = normalize( normalTex );\nif( enableDiffuse )\ngl_FragColor = gl_FragColor * texture2D( tDiffuse, vUv );\nif( enableAO )\ngl_FragColor = gl_FragColor * texture2D( tAO, vUv );\nif( enableSpecular )\nspecularTex = texture2D( tSpecular, vUv ).xyz;\nmat3 tsb = mat3( vTangent, vBinormal, vNormal );\nvec3 finalNormal = tsb * normalTex;\nvec3 normal = normalize( finalNormal );\nvec3 viewPosition = normalize( vViewPosition );\n#if MAX_POINT_LIGHTS > 0\nvec4 pointTotal = vec4( vec3( 0.0 ), 1.0 );\nfor ( int i = 0; i < MAX_POINT_LIGHTS; i ++ ) {\nvec3 pointVector = normalize( vPointLight[ i ].xyz );\nvec3 pointHalfVector = normalize( vPointLight[ i ].xyz + viewPosition );\nfloat pointDistance = vPointLight[ i ].w;\nfloat pointDotNormalHalf = dot( normal, pointHalfVector );\nfloat pointDiffuseWeight = max( dot( normal, pointVector ), 0.0 );\nfloat pointSpecularWeight = 0.0;\nif ( pointDotNormalHalf >= 0.0 )\npointSpecularWeight = specularTex.r * pow( pointDotNormalHalf, uShininess );\npointTotal  += pointDistance * vec4( pointLightColor[ i ], 1.0 ) * ( mColor * pointDiffuseWeight + mSpecular * pointSpecularWeight * pointDiffuseWeight );\n}\n#endif\n#if MAX_DIR_LIGHTS > 0\nvec4 dirTotal = vec4( vec3( 0.0 ), 1.0 );\nfor( int i = 0; i < MAX_DIR_LIGHTS; i++ ) {\nvec4 lDirection = viewMatrix * vec4( directionalLightDirection[ i ], 0.0 );\nvec3 dirVector = normalize( lDirection.xyz );\nvec3 dirHalfVector = normalize( lDirection.xyz + viewPosition );\nfloat dirDotNormalHalf = dot( normal, dirHalfVector );\nfloat dirDiffuseWeight = max( dot( normal, dirVector ), 0.0 );\nfloat dirSpecularWeight = 0.0;\nif ( dirDotNormalHalf >= 0.0 )\ndirSpecularWeight = specularTex.r * pow( dirDotNormalHalf, uShininess );\ndirTotal  += vec4( directionalLightColor[ i ], 1.0 ) * ( mColor * dirDiffuseWeight + mSpecular * dirSpecularWeight * dirDiffuseWeight );\n}\n#endif\nvec4 totalLight = vec4( ambientLightColor * uAmbientColor, uOpacity );\n#if MAX_DIR_LIGHTS > 0\ntotalLight += dirTotal;\n#endif\n#if MAX_POINT_LIGHTS > 0\ntotalLight += pointTotal;\n#endif\ngl_FragColor = gl_FragColor * totalLight;",
THREE.ShaderChunk.fog_fragment,"}"].join("\n"),vertexShader:"attribute vec4 tangent;\n#ifdef VERTEX_TEXTURES\nuniform sampler2D tDisplacement;\nuniform float uDisplacementScale;\nuniform float uDisplacementBias;\n#endif\nvarying vec3 vTangent;\nvarying vec3 vBinormal;\nvarying vec3 vNormal;\nvarying vec2 vUv;\n#if MAX_POINT_LIGHTS > 0\nuniform vec3 pointLightPosition[ MAX_POINT_LIGHTS ];\nuniform float pointLightDistance[ MAX_POINT_LIGHTS ];\nvarying vec4 vPointLight[ MAX_POINT_LIGHTS ];\n#endif\nvarying vec3 vViewPosition;\nvoid main() {\nvec4 mPosition = objectMatrix * vec4( position, 1.0 );\nvViewPosition = cameraPosition - mPosition.xyz;\nvec4 mvPosition = modelViewMatrix * vec4( position, 1.0 );\nvNormal = normalize( normalMatrix * normal );\nvTangent = normalize( normalMatrix * tangent.xyz );\nvBinormal = cross( vNormal, vTangent ) * tangent.w;\nvBinormal = normalize( vBinormal );\nvUv = uv;\n#if MAX_POINT_LIGHTS > 0\nfor( int i = 0; i < MAX_POINT_LIGHTS; i++ ) {\nvec4 lPosition = viewMatrix * vec4( pointLightPosition[ i ], 1.0 );\nvec3 lVector = lPosition.xyz - mvPosition.xyz;\nfloat lDistance = 1.0;\nif ( pointLightDistance[ i ] > 0.0 )\nlDistance = 1.0 - min( ( length( lVector ) / pointLightDistance[ i ] ), 1.0 );\nlVector = normalize( lVector );\nvPointLight[ i ] = vec4( lVector, lDistance );\n}\n#endif\n#ifdef VERTEX_TEXTURES\nvec3 dv = texture2D( tDisplacement, uv ).xyz;\nfloat df = uDisplacementScale * dv.x + uDisplacementBias;\nvec4 displacedPosition = vec4( vNormal.xyz * df, 0.0 ) + mvPosition;\ngl_Position = projectionMatrix * displacedPosition;\n#else\ngl_Position = projectionMatrix * mvPosition;\n#endif\n}"},
cube:{uniforms:{tCube:{type:"t",value:1,texture:null}},vertexShader:"varying vec3 vViewPosition;\nvoid main() {\nvec4 mPosition = objectMatrix * vec4( position, 1.0 );\nvViewPosition = cameraPosition - mPosition.xyz;\ngl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );\n}",fragmentShader:"uniform samplerCube tCube;\nvarying vec3 vViewPosition;\nvoid main() {\nvec3 wPos = cameraPosition - vViewPosition;\ngl_FragColor = textureCube( tCube, vec3( - wPos.x, wPos.yz ) );\n}"},convolution:{uniforms:{tDiffuse:{type:"t",
value:0,texture:null},uImageIncrement:{type:"v2",value:new THREE.Vector2(0.001953125,0)},cKernel:{type:"fv1",value:[]}},vertexShader:"varying vec2 vUv;\nuniform vec2 uImageIncrement;\nvoid main(void) {\nvUv = uv - ((KERNEL_SIZE - 1.0) / 2.0) * uImageIncrement;\ngl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );\n}",fragmentShader:"varying vec2 vUv;\nuniform sampler2D tDiffuse;\nuniform vec2 uImageIncrement;\nuniform float cKernel[KERNEL_SIZE];\nvoid main(void) {\nvec2 imageCoord = vUv;\nvec4 sum = vec4( 0.0, 0.0, 0.0, 0.0 );\nfor( int i=0; i<KERNEL_SIZE; ++i ) {\nsum += texture2D( tDiffuse, imageCoord ) * cKernel[i];\nimageCoord += uImageIncrement;\n}\ngl_FragColor = sum;\n}"},
film:{uniforms:{tDiffuse:{type:"t",value:0,texture:null},time:{type:"f",value:0},nIntensity:{type:"f",value:0.5},sIntensity:{type:"f",value:0.05},sCount:{type:"f",value:4096},grayscale:{type:"i",value:1}},vertexShader:"varying vec2 vUv;\nvoid main() {\nvUv = vec2( uv.x, 1.0 - uv.y );\ngl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );\n}",fragmentShader:"varying vec2 vUv;\nuniform sampler2D tDiffuse;\nuniform float time;\nuniform bool grayscale;\nuniform float nIntensity;\nuniform float sIntensity;\nuniform float sCount;\nvoid main() {\nvec4 cTextureScreen = texture2D( tDiffuse, vUv );\nfloat x = vUv.x * vUv.y * time *  1000.0;\nx = mod( x, 13.0 ) * mod( x, 123.0 );\nfloat dx = mod( x, 0.01 );\nvec3 cResult = cTextureScreen.rgb + cTextureScreen.rgb * clamp( 0.1 + dx * 100.0, 0.0, 1.0 );\nvec2 sc = vec2( sin( vUv.y * sCount ), cos( vUv.y * sCount ) );\ncResult += cTextureScreen.rgb * vec3( sc.x, sc.y, sc.x ) * sIntensity;\ncResult = cTextureScreen.rgb + clamp( nIntensity, 0.0,1.0 ) * ( cResult - cTextureScreen.rgb );\nif( grayscale ) {\ncResult = vec3( cResult.r * 0.3 + cResult.g * 0.59 + cResult.b * 0.11 );\n}\ngl_FragColor =  vec4( cResult, cTextureScreen.a );\n}"},
screen:{uniforms:{tDiffuse:{type:"t",value:0,texture:null},opacity:{type:"f",value:1}},vertexShader:"varying vec2 vUv;\nvoid main() {\nvUv = vec2( uv.x, 1.0 - uv.y );\ngl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );\n}",fragmentShader:"varying vec2 vUv;\nuniform sampler2D tDiffuse;\nuniform float opacity;\nvoid main() {\nvec4 texel = texture2D( tDiffuse, vUv );\ngl_FragColor = opacity * texel;\n}"},basic:{uniforms:{},vertexShader:"void main() {\ngl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );\n}",
fragmentShader:"void main() {\ngl_FragColor = vec4( 1.0, 0.0, 0.0, 0.5 );\n}"}},buildKernel:function(b){var c,e,f,g,j=2*Math.ceil(b*3)+1;j>25&&(j=25);g=(j-1)*0.5;e=Array(j);for(c=f=0;c<j;++c)e[c]=Math.exp(-((c-g)*(c-g))/(2*b*b)),f+=e[c];for(c=0;c<j;++c)e[c]/=f;return e}};
THREE.AnimationHandler=function(){var b=[],c={},e={update:function(c){for(var e=0;e<b.length;e++)b[e].update(c)},addToUpdate:function(c){b.indexOf(c)===-1&&b.push(c)},removeFromUpdate:function(c){c=b.indexOf(c);c!==-1&&b.splice(c,1)},add:function(b){c[b.name]!==void 0&&console.log("THREE.AnimationHandler.add: Warning! "+b.name+" already exists in library. Overwriting.");c[b.name]=b;if(b.initialized!==!0){for(var e=0;e<b.hierarchy.length;e++){for(var f=0;f<b.hierarchy[e].keys.length;f++){if(b.hierarchy[e].keys[f].time<
0)b.hierarchy[e].keys[f].time=0;if(b.hierarchy[e].keys[f].rot!==void 0&&!(b.hierarchy[e].keys[f].rot instanceof THREE.Quaternion)){var k=b.hierarchy[e].keys[f].rot;b.hierarchy[e].keys[f].rot=new THREE.Quaternion(k[0],k[1],k[2],k[3])}}if(b.hierarchy[e].keys[0].morphTargets!==void 0){k={};for(f=0;f<b.hierarchy[e].keys.length;f++)for(var o=0;o<b.hierarchy[e].keys[f].morphTargets.length;o++){var m=b.hierarchy[e].keys[f].morphTargets[o];k[m]=-1}b.hierarchy[e].usedMorphTargets=k;for(f=0;f<b.hierarchy[e].keys.length;f++){var p=
{};for(m in k){for(o=0;o<b.hierarchy[e].keys[f].morphTargets.length;o++)if(b.hierarchy[e].keys[f].morphTargets[o]===m){p[m]=b.hierarchy[e].keys[f].morphTargetsInfluences[o];break}o===b.hierarchy[e].keys[f].morphTargets.length&&(p[m]=0)}b.hierarchy[e].keys[f].morphTargetsInfluences=p}}for(f=1;f<b.hierarchy[e].keys.length;f++)b.hierarchy[e].keys[f].time===b.hierarchy[e].keys[f-1].time&&(b.hierarchy[e].keys.splice(f,1),f--);for(f=1;f<b.hierarchy[e].keys.length;f++)b.hierarchy[e].keys[f].index=f}f=parseInt(b.length*
b.fps,10);b.JIT={};b.JIT.hierarchy=[];for(e=0;e<b.hierarchy.length;e++)b.JIT.hierarchy.push(Array(f));b.initialized=!0}},get:function(b){if(typeof b==="string")return c[b]?c[b]:(console.log("THREE.AnimationHandler.get: Couldn't find animation "+b),null)},parse:function(b){var e=[];if(b instanceof THREE.SkinnedMesh)for(var c=0;c<b.bones.length;c++)e.push(b.bones[c]);else f(b,e);return e}},f=function(b,e){e.push(b);for(var c=0;c<b.children.length;c++)f(b.children[c],e)};e.LINEAR=0;e.CATMULLROM=1;e.CATMULLROM_FORWARD=
2;return e}();THREE.Animation=function(b,c,e,f){this.root=b;this.data=THREE.AnimationHandler.get(c);this.hierarchy=THREE.AnimationHandler.parse(b);this.currentTime=0;this.timeScale=1;this.isPlaying=!1;this.loop=this.isPaused=!0;this.interpolationType=e!==void 0?e:THREE.AnimationHandler.LINEAR;this.JITCompile=f!==void 0?f:!0;this.points=[];this.target=new THREE.Vector3};
THREE.Animation.prototype.play=function(b,c){if(!this.isPlaying){this.isPlaying=!0;this.loop=b!==void 0?b:!0;this.currentTime=c!==void 0?c:0;var e,f=this.hierarchy.length,g;for(e=0;e<f;e++){g=this.hierarchy[e];if(this.interpolationType!==THREE.AnimationHandler.CATMULLROM_FORWARD)g.useQuaternion=!0;g.matrixAutoUpdate=!0;if(g.animationCache===void 0)g.animationCache={},g.animationCache.prevKey={pos:0,rot:0,scl:0},g.animationCache.nextKey={pos:0,rot:0,scl:0},g.animationCache.originalMatrix=g instanceof
THREE.Bone?g.skinMatrix:g.matrix;var j=g.animationCache.prevKey;g=g.animationCache.nextKey;j.pos=this.data.hierarchy[e].keys[0];j.rot=this.data.hierarchy[e].keys[0];j.scl=this.data.hierarchy[e].keys[0];g.pos=this.getNextKeyWith("pos",e,1);g.rot=this.getNextKeyWith("rot",e,1);g.scl=this.getNextKeyWith("scl",e,1)}this.update(0)}this.isPaused=!1;THREE.AnimationHandler.addToUpdate(this)};
THREE.Animation.prototype.pause=function(){this.isPaused?THREE.AnimationHandler.addToUpdate(this):THREE.AnimationHandler.removeFromUpdate(this);this.isPaused=!this.isPaused};
THREE.Animation.prototype.stop=function(){this.isPaused=this.isPlaying=!1;THREE.AnimationHandler.removeFromUpdate(this);for(var b=0;b<this.hierarchy.length;b++)if(this.hierarchy[b].animationCache!==void 0)this.hierarchy[b]instanceof THREE.Bone?this.hierarchy[b].skinMatrix=this.hierarchy[b].animationCache.originalMatrix:this.hierarchy[b].matrix=this.hierarchy[b].animationCache.originalMatrix,delete this.hierarchy[b].animationCache};
THREE.Animation.prototype.update=function(b){if(this.isPlaying){var c=["pos","rot","scl"],e,f,g,j,h,k,o,m,p=this.data.JIT.hierarchy,u,v;this.currentTime+=b*this.timeScale;v=this.currentTime;u=this.currentTime%=this.data.length;m=parseInt(Math.min(u*this.data.fps,this.data.length*this.data.fps),10);for(var t=0,w=this.hierarchy.length;t<w;t++)if(b=this.hierarchy[t],o=b.animationCache,this.JITCompile&&p[t][m]!==void 0)b instanceof THREE.Bone?(b.skinMatrix=p[t][m],b.matrixAutoUpdate=!1,b.matrixWorldNeedsUpdate=
!1):(b.matrix=p[t][m],b.matrixAutoUpdate=!1,b.matrixWorldNeedsUpdate=!0);else{if(this.JITCompile)b instanceof THREE.Bone?b.skinMatrix=b.animationCache.originalMatrix:b.matrix=b.animationCache.originalMatrix;for(var x=0;x<3;x++){e=c[x];h=o.prevKey[e];k=o.nextKey[e];if(k.time<=v){if(u<v)if(this.loop){h=this.data.hierarchy[t].keys[0];for(k=this.getNextKeyWith(e,t,1);k.time<u;)h=k,k=this.getNextKeyWith(e,t,k.index+1)}else{this.stop();return}else{do h=k,k=this.getNextKeyWith(e,t,k.index+1);while(k.time<
u)}o.prevKey[e]=h;o.nextKey[e]=k}b.matrixAutoUpdate=!0;b.matrixWorldNeedsUpdate=!0;f=(u-h.time)/(k.time-h.time);g=h[e];j=k[e];if(f<0||f>1)console.log("THREE.Animation.update: Warning! Scale out of bounds:"+f+" on bone "+t),f=f<0?0:1;if(e==="pos")if(e=b.position,this.interpolationType===THREE.AnimationHandler.LINEAR)e.x=g[0]+(j[0]-g[0])*f,e.y=g[1]+(j[1]-g[1])*f,e.z=g[2]+(j[2]-g[2])*f;else{if(this.interpolationType===THREE.AnimationHandler.CATMULLROM||this.interpolationType===THREE.AnimationHandler.CATMULLROM_FORWARD)if(this.points[0]=
this.getPrevKeyWith("pos",t,h.index-1).pos,this.points[1]=g,this.points[2]=j,this.points[3]=this.getNextKeyWith("pos",t,k.index+1).pos,f=f*0.33+0.33,g=this.interpolateCatmullRom(this.points,f),e.x=g[0],e.y=g[1],e.z=g[2],this.interpolationType===THREE.AnimationHandler.CATMULLROM_FORWARD)f=this.interpolateCatmullRom(this.points,f*1.01),this.target.set(f[0],f[1],f[2]),this.target.subSelf(e),this.target.y=0,this.target.normalize(),f=Math.atan2(this.target.x,this.target.z),b.rotation.set(0,f,0)}else if(e===
"rot")THREE.Quaternion.slerp(g,j,b.quaternion,f);else if(e==="scl")e=b.scale,e.x=g[0]+(j[0]-g[0])*f,e.y=g[1]+(j[1]-g[1])*f,e.z=g[2]+(j[2]-g[2])*f}}if(this.JITCompile&&p[0][m]===void 0){this.hierarchy[0].update(void 0,!0);for(t=0;t<this.hierarchy.length;t++)p[t][m]=this.hierarchy[t]instanceof THREE.Bone?this.hierarchy[t].skinMatrix.clone():this.hierarchy[t].matrix.clone()}}};
THREE.Animation.prototype.interpolateCatmullRom=function(b,c){var e=[],f=[],g,j,h,k,o,m;g=(b.length-1)*c;j=Math.floor(g);g-=j;e[0]=j==0?j:j-1;e[1]=j;e[2]=j>b.length-2?j:j+1;e[3]=j>b.length-3?j:j+2;j=b[e[0]];k=b[e[1]];o=b[e[2]];m=b[e[3]];e=g*g;h=g*e;f[0]=this.interpolate(j[0],k[0],o[0],m[0],g,e,h);f[1]=this.interpolate(j[1],k[1],o[1],m[1],g,e,h);f[2]=this.interpolate(j[2],k[2],o[2],m[2],g,e,h);return f};
THREE.Animation.prototype.interpolate=function(b,c,e,f,g,j,h){b=(e-b)*0.5;f=(f-c)*0.5;return(2*(c-e)+b+f)*h+(-3*(c-e)-2*b-f)*j+b*g+c};THREE.Animation.prototype.getNextKeyWith=function(b,c,e){var f=this.data.hierarchy[c].keys;for(this.interpolationType===THREE.AnimationHandler.CATMULLROM||this.interpolationType===THREE.AnimationHandler.CATMULLROM_FORWARD?e=e<f.length-1?e:f.length-1:e%=f.length;e<f.length;e++)if(f[e][b]!==void 0)return f[e];return this.data.hierarchy[c].keys[0]};
THREE.Animation.prototype.getPrevKeyWith=function(b,c,e){for(var f=this.data.hierarchy[c].keys,e=this.interpolationType===THREE.AnimationHandler.CATMULLROM||this.interpolationType===THREE.AnimationHandler.CATMULLROM_FORWARD?e>0?e:0:e>=0?e:e+f.length;e>=0;e--)if(f[e][b]!==void 0)return f[e];return this.data.hierarchy[c].keys[f.length-1]};
THREE.FirstPersonCamera=function(b){function c(b,c){return function(){c.apply(b,arguments)}}THREE.Camera.call(this,b.fov,b.aspect,b.near,b.far,b.target);this.movementSpeed=1;this.lookSpeed=0.005;this.noFly=!1;this.lookVertical=!0;this.autoForward=!1;this.activeLook=!0;this.heightSpeed=!1;this.heightCoef=1;this.heightMin=0;this.constrainVertical=!1;this.verticalMin=0;this.verticalMax=3.14;this.domElement=document;this.lastUpdate=(new Date).getTime();this.tdiff=0;if(b){if(b.movementSpeed!==void 0)this.movementSpeed=
b.movementSpeed;if(b.lookSpeed!==void 0)this.lookSpeed=b.lookSpeed;if(b.noFly!==void 0)this.noFly=b.noFly;if(b.lookVertical!==void 0)this.lookVertical=b.lookVertical;if(b.autoForward!==void 0)this.autoForward=b.autoForward;if(b.activeLook!==void 0)this.activeLook=b.activeLook;if(b.heightSpeed!==void 0)this.heightSpeed=b.heightSpeed;if(b.heightCoef!==void 0)this.heightCoef=b.heightCoef;if(b.heightMin!==void 0)this.heightMin=b.heightMin;if(b.heightMax!==void 0)this.heightMax=b.heightMax;if(b.constrainVertical!==
void 0)this.constrainVertical=b.constrainVertical;if(b.verticalMin!==void 0)this.verticalMin=b.verticalMin;if(b.verticalMax!==void 0)this.verticalMax=b.verticalMax;if(b.domElement!==void 0)this.domElement=b.domElement}this.theta=this.phi=this.lon=this.lat=this.mouseY=this.mouseX=this.autoSpeedFactor=0;this.mouseDragOn=this.freeze=this.moveRight=this.moveLeft=this.moveBackward=this.moveForward=!1;this.windowHalfX=window.innerWidth/2;this.windowHalfY=window.innerHeight/2;this.onMouseDown=function(b){b.preventDefault();
b.stopPropagation();if(this.activeLook)switch(b.button){case 0:this.moveForward=!0;break;case 2:this.moveBackward=!0}this.mouseDragOn=!0};this.onMouseUp=function(b){b.preventDefault();b.stopPropagation();if(this.activeLook)switch(b.button){case 0:this.moveForward=!1;break;case 2:this.moveBackward=!1}this.mouseDragOn=!1};this.onMouseMove=function(b){this.mouseX=b.clientX-this.windowHalfX;this.mouseY=b.clientY-this.windowHalfY};this.onKeyDown=function(b){switch(b.keyCode){case 38:case 87:this.moveForward=
!0;break;case 37:case 65:this.moveLeft=!0;break;case 40:case 83:this.moveBackward=!0;break;case 39:case 68:this.moveRight=!0;break;case 82:this.moveUp=!0;break;case 70:this.moveDown=!0;break;case 81:this.freeze=!this.freeze}};this.onKeyUp=function(b){switch(b.keyCode){case 38:case 87:this.moveForward=!1;break;case 37:case 65:this.moveLeft=!1;break;case 40:case 83:this.moveBackward=!1;break;case 39:case 68:this.moveRight=!1;break;case 82:this.moveUp=!1;break;case 70:this.moveDown=!1}};this.update=
function(){var b=(new Date).getTime();this.tdiff=(b-this.lastUpdate)/1E3;this.lastUpdate=b;if(!this.freeze){this.autoSpeedFactor=this.heightSpeed?this.tdiff*((this.position.y<this.heightMin?this.heightMin:this.position.y>this.heightMax?this.heightMax:this.position.y)-this.heightMin)*this.heightCoef:0;var c=this.tdiff*this.movementSpeed;(this.moveForward||this.autoForward&&!this.moveBackward)&&this.translateZ(-(c+this.autoSpeedFactor));this.moveBackward&&this.translateZ(c);this.moveLeft&&this.translateX(-c);
this.moveRight&&this.translateX(c);this.moveUp&&this.translateY(c);this.moveDown&&this.translateY(-c);c=this.tdiff*this.lookSpeed;this.activeLook||(c=0);this.lon+=this.mouseX*c;this.lookVertical&&(this.lat-=this.mouseY*c);this.lat=Math.max(-85,Math.min(85,this.lat));this.phi=(90-this.lat)*Math.PI/180;this.theta=this.lon*Math.PI/180;var b=this.target.position,g=this.position;b.x=g.x+100*Math.sin(this.phi)*Math.cos(this.theta);b.y=g.y+100*Math.cos(this.phi);b.z=g.z+100*Math.sin(this.phi)*Math.sin(this.theta)}b=
1;this.constrainVertical&&(b=3.14/(this.verticalMax-this.verticalMin));this.lon+=this.mouseX*c;this.lookVertical&&(this.lat-=this.mouseY*c*b);this.lat=Math.max(-85,Math.min(85,this.lat));this.phi=(90-this.lat)*Math.PI/180;this.theta=this.lon*Math.PI/180;if(this.constrainVertical)this.phi=(this.phi-0)*(this.verticalMax-this.verticalMin)/3.14+this.verticalMin;b=this.target.position;g=this.position;b.x=g.x+100*Math.sin(this.phi)*Math.cos(this.theta);b.y=g.y+100*Math.cos(this.phi);b.z=g.z+100*Math.sin(this.phi)*
Math.sin(this.theta);this.supr.update.call(this)};this.domElement.addEventListener("contextmenu",function(b){b.preventDefault()},!1);this.domElement.addEventListener("mousemove",c(this,this.onMouseMove),!1);this.domElement.addEventListener("mousedown",c(this,this.onMouseDown),!1);this.domElement.addEventListener("mouseup",c(this,this.onMouseUp),!1);this.domElement.addEventListener("keydown",c(this,this.onKeyDown),!1);this.domElement.addEventListener("keyup",c(this,this.onKeyUp),!1)};
THREE.FirstPersonCamera.prototype=new THREE.Camera;THREE.FirstPersonCamera.prototype.constructor=THREE.FirstPersonCamera;THREE.FirstPersonCamera.prototype.supr=THREE.Camera.prototype;THREE.FirstPersonCamera.prototype.translate=function(b,c){this.matrix.rotateAxis(c);if(this.noFly)c.y=0;this.position.addSelf(c.multiplyScalar(b));this.target.position.addSelf(c.multiplyScalar(b))};
THREE.PathCamera=function(b){function c(b,c,e,f){var g={name:e,fps:0.6,length:f,hierarchy:[]},h,j=c.getControlPointsArray(),k=c.getLength(),o=j.length,H=0;h=o-1;c={parent:-1,keys:[]};c.keys[0]={time:0,pos:j[0],rot:[0,0,0,1],scl:[1,1,1]};c.keys[h]={time:f,pos:j[h],rot:[0,0,0,1],scl:[1,1,1]};for(h=1;h<o-1;h++)H=f*k.chunks[h]/k.total,c.keys[h]={time:H,pos:j[h]};g.hierarchy[0]=c;THREE.AnimationHandler.add(g);return new THREE.Animation(b,e,THREE.AnimationHandler.CATMULLROM_FORWARD,!1)}function e(b,c){var e,
f,g=new THREE.Geometry;for(e=0;e<b.points.length*c;e++)f=e/(b.points.length*c),f=b.getPoint(f),g.vertices[e]=new THREE.Vertex(new THREE.Vector3(f.x,f.y,f.z));return g}function f(b,c){var f=e(c,10),g=e(c,10),h=new THREE.LineBasicMaterial({color:16711680,linewidth:3});lineObj=new THREE.Line(f,h);particleObj=new THREE.ParticleSystem(g,new THREE.ParticleBasicMaterial({color:16755200,size:3}));lineObj.scale.set(1,1,1);b.addChild(lineObj);particleObj.scale.set(1,1,1);b.addChild(particleObj);g=new THREE.SphereGeometry(1,
16,8);h=new THREE.MeshBasicMaterial({color:65280});for(i=0;i<c.points.length;i++)f=new THREE.Mesh(g,h),f.position.copy(c.points[i]),f.updateMatrix(),b.addChild(f)}THREE.Camera.call(this,b.fov,b.aspect,b.near,b.far,b.target);this.id="PathCamera"+THREE.PathCameraIdCounter++;this.duration=1E4;this.waypoints=[];this.useConstantSpeed=!0;this.resamplingCoef=50;this.debugPath=new THREE.Object3D;this.debugDummy=new THREE.Object3D;this.animationParent=new THREE.Object3D;this.lookSpeed=0.005;this.lookHorizontal=
this.lookVertical=!0;this.verticalAngleMap={srcRange:[0,6.28],dstRange:[0,6.28]};this.horizontalAngleMap={srcRange:[0,6.28],dstRange:[0,6.28]};this.domElement=document;if(b){if(b.duration!==void 0)this.duration=b.duration*1E3;if(b.waypoints!==void 0)this.waypoints=b.waypoints;if(b.useConstantSpeed!==void 0)this.useConstantSpeed=b.useConstantSpeed;if(b.resamplingCoef!==void 0)this.resamplingCoef=b.resamplingCoef;if(b.createDebugPath!==void 0)this.createDebugPath=b.createDebugPath;if(b.createDebugDummy!==
void 0)this.createDebugDummy=b.createDebugDummy;if(b.lookSpeed!==void 0)this.lookSpeed=b.lookSpeed;if(b.lookVertical!==void 0)this.lookVertical=b.lookVertical;if(b.lookHorizontal!==void 0)this.lookHorizontal=b.lookHorizontal;if(b.verticalAngleMap!==void 0)this.verticalAngleMap=b.verticalAngleMap;if(b.horizontalAngleMap!==void 0)this.horizontalAngleMap=b.horizontalAngleMap;if(b.domElement!==void 0)this.domElement=b.domElement}this.theta=this.phi=this.lon=this.lat=this.mouseY=this.mouseX=0;this.windowHalfX=
window.innerWidth/2;this.windowHalfY=window.innerHeight/2;var g=Math.PI*2,j=Math.PI/180;this.update=function(b,c,e){var f,h;this.lookHorizontal&&(this.lon+=this.mouseX*this.lookSpeed);this.lookVertical&&(this.lat-=this.mouseY*this.lookSpeed);this.lon=Math.max(0,Math.min(360,this.lon));this.lat=Math.max(-85,Math.min(85,this.lat));this.phi=(90-this.lat)*j;this.theta=this.lon*j;f=this.phi%g;this.phi=f>=0?f:f+g;f=this.verticalAngleMap.srcRange;h=this.verticalAngleMap.dstRange;var k=h[1]-h[0];this.phi=
TWEEN.Easing.Quadratic.EaseInOut(((this.phi-f[0])*(h[1]-h[0])/(f[1]-f[0])+h[0]-h[0])/k)*k+h[0];f=this.horizontalAngleMap.srcRange;h=this.horizontalAngleMap.dstRange;k=h[1]-h[0];this.theta=TWEEN.Easing.Quadratic.EaseInOut(((this.theta-f[0])*(h[1]-h[0])/(f[1]-f[0])+h[0]-h[0])/k)*k+h[0];f=this.target.position;f.x=100*Math.sin(this.phi)*Math.cos(this.theta);f.y=100*Math.cos(this.phi);f.z=100*Math.sin(this.phi)*Math.sin(this.theta);this.supr.update.call(this,b,c,e)};this.onMouseMove=function(b){this.mouseX=
b.clientX-this.windowHalfX;this.mouseY=b.clientY-this.windowHalfY};this.spline=new THREE.Spline;this.spline.initFromArray(this.waypoints);this.useConstantSpeed&&this.spline.reparametrizeByArcLength(this.resamplingCoef);if(this.createDebugDummy){var b=new THREE.MeshLambertMaterial({color:30719}),h=new THREE.MeshLambertMaterial({color:65280}),k=new THREE.CubeGeometry(10,10,20),o=new THREE.CubeGeometry(2,2,10);this.animationParent=new THREE.Mesh(k,b);b=new THREE.Mesh(o,h);b.position.set(0,10,0);this.animation=
c(this.animationParent,this.spline,this.id,this.duration);this.animationParent.addChild(this);this.animationParent.addChild(this.target);this.animationParent.addChild(b)}else this.animation=c(this.animationParent,this.spline,this.id,this.duration),this.animationParent.addChild(this.target),this.animationParent.addChild(this);this.createDebugPath&&f(this.debugPath,this.spline);this.domElement.addEventListener("mousemove",function(b,c){return function(){c.apply(b,arguments)}}(this,this.onMouseMove),
!1)};THREE.PathCamera.prototype=new THREE.Camera;THREE.PathCamera.prototype.constructor=THREE.PathCamera;THREE.PathCamera.prototype.supr=THREE.Camera.prototype;THREE.PathCameraIdCounter=0;
THREE.FlyCamera=function(b){function c(b,c){return function(){c.apply(b,arguments)}}THREE.Camera.call(this,b.fov,b.aspect,b.near,b.far,b.target);this.tmpQuaternion=new THREE.Quaternion;this.movementSpeed=1;this.rollSpeed=0.005;this.autoForward=this.dragToLook=!1;this.domElement=document;if(b){if(b.movementSpeed!==void 0)this.movementSpeed=b.movementSpeed;if(b.rollSpeed!==void 0)this.rollSpeed=b.rollSpeed;if(b.dragToLook!==void 0)this.dragToLook=b.dragToLook;if(b.autoForward!==void 0)this.autoForward=
b.autoForward;if(b.domElement!==void 0)this.domElement=b.domElement}this.useTarget=!1;this.useQuaternion=!0;this.mouseStatus=0;this.moveState={up:0,down:0,left:0,right:0,forward:0,back:0,pitchUp:0,pitchDown:0,yawLeft:0,yawRight:0,rollLeft:0,rollRight:0};this.moveVector=new THREE.Vector3(0,0,0);this.rotationVector=new THREE.Vector3(0,0,0);this.lastUpdate=-1;this.tdiff=0;this.handleEvent=function(b){if(typeof this[b.type]=="function")this[b.type](b)};this.keydown=function(b){if(!b.altKey){switch(b.keyCode){case 16:this.movementSpeedMultiplier=
0.1;break;case 87:this.moveState.forward=1;break;case 83:this.moveState.back=1;break;case 65:this.moveState.left=1;break;case 68:this.moveState.right=1;break;case 82:this.moveState.up=1;break;case 70:this.moveState.down=1;break;case 38:this.moveState.pitchUp=1;break;case 40:this.moveState.pitchDown=1;break;case 37:this.moveState.yawLeft=1;break;case 39:this.moveState.yawRight=1;break;case 81:this.moveState.rollLeft=1;break;case 69:this.moveState.rollRight=1}this.updateMovementVector();this.updateRotationVector()}};
this.keyup=function(b){switch(b.keyCode){case 16:this.movementSpeedMultiplier=1;break;case 87:this.moveState.forward=0;break;case 83:this.moveState.back=0;break;case 65:this.moveState.left=0;break;case 68:this.moveState.right=0;break;case 82:this.moveState.up=0;break;case 70:this.moveState.down=0;break;case 38:this.moveState.pitchUp=0;break;case 40:this.moveState.pitchDown=0;break;case 37:this.moveState.yawLeft=0;break;case 39:this.moveState.yawRight=0;break;case 81:this.moveState.rollLeft=0;break;
case 69:this.moveState.rollRight=0}this.updateMovementVector();this.updateRotationVector()};this.mousedown=function(b){b.preventDefault();b.stopPropagation();if(this.dragToLook)this.mouseStatus++;else switch(b.button){case 0:this.moveForward=!0;break;case 2:this.moveBackward=!0}};this.mousemove=function(b){if(!this.dragToLook||this.mouseStatus>0){var c=this.getContainerDimensions(),g=c.size[0]/2,j=c.size[1]/2;this.moveState.yawLeft=-(b.clientX-c.offset[0]-g)/g;this.moveState.pitchDown=(b.clientY-
c.offset[1]-j)/j;this.updateRotationVector()}};this.mouseup=function(b){b.preventDefault();b.stopPropagation();if(this.dragToLook)this.mouseStatus--,this.moveState.yawLeft=this.moveState.pitchDown=0;else switch(b.button){case 0:this.moveForward=!1;break;case 2:this.moveBackward=!1}this.updateRotationVector()};this.update=function(){var b=(new Date).getTime();if(this.lastUpdate==-1)this.lastUpdate=b;this.tdiff=(b-this.lastUpdate)/1E3;this.lastUpdate=b;var b=this.tdiff*this.movementSpeed,c=this.tdiff*
this.rollSpeed;this.translateX(this.moveVector.x*b);this.translateY(this.moveVector.y*b);this.translateZ(this.moveVector.z*b);this.tmpQuaternion.set(this.rotationVector.x*c,this.rotationVector.y*c,this.rotationVector.z*c,1).normalize();this.quaternion.multiplySelf(this.tmpQuaternion);this.matrix.setPosition(this.position);this.matrix.setRotationFromQuaternion(this.quaternion);this.matrixWorldNeedsUpdate=!0;this.supr.update.call(this)};this.updateMovementVector=function(){var b=this.moveState.forward||
this.autoForward&&!this.moveState.back?1:0;this.moveVector.x=-this.moveState.left+this.moveState.right;this.moveVector.y=-this.moveState.down+this.moveState.up;this.moveVector.z=-b+this.moveState.back};this.updateRotationVector=function(){this.rotationVector.x=-this.moveState.pitchDown+this.moveState.pitchUp;this.rotationVector.y=-this.moveState.yawRight+this.moveState.yawLeft;this.rotationVector.z=-this.moveState.rollRight+this.moveState.rollLeft};this.getContainerDimensions=function(){return this.domElement!=
document?{size:[this.domElement.offsetWidth,this.domElement.offsetHeight],offset:[this.domElement.offsetLeft,this.domElement.offsetTop]}:{size:[window.innerWidth,window.innerHeight],offset:[0,0]}};this.domElement.addEventListener("mousemove",c(this,this.mousemove),!1);this.domElement.addEventListener("mousedown",c(this,this.mousedown),!1);this.domElement.addEventListener("mouseup",c(this,this.mouseup),!1);window.addEventListener("keydown",c(this,this.keydown),!1);window.addEventListener("keyup",c(this,
this.keyup),!1);this.updateMovementVector();this.updateRotationVector()};THREE.FlyCamera.prototype=new THREE.Camera;THREE.FlyCamera.prototype.constructor=THREE.FlyCamera;THREE.FlyCamera.prototype.supr=THREE.Camera.prototype;
THREE.RollCamera=function(b,c,e,f){THREE.Camera.call(this,b,c,e,f);this.mouseLook=!0;this.autoForward=!1;this.rollSpeed=this.movementSpeed=this.lookSpeed=1;this.constrainVertical=[-0.9,0.9];this.domElement=document;this.matrixAutoUpdate=this.useTarget=!1;this.forward=new THREE.Vector3(0,0,1);this.roll=0;this.lastUpdate=-1;this.delta=0;var g=new THREE.Vector3,j=new THREE.Vector3,h=new THREE.Vector3,k=new THREE.Matrix4,o=!1,m=1,p=0,u=0,v=0,t=0,w=0,x=window.innerWidth/2,B=window.innerHeight/2;this.update=
function(){var b=(new Date).getTime();if(this.lastUpdate==-1)this.lastUpdate=b;this.delta=(b-this.lastUpdate)/1E3;this.lastUpdate=b;this.mouseLook&&(b=this.delta*this.lookSpeed,this.rotateHorizontally(b*t),this.rotateVertically(b*w));b=this.delta*this.movementSpeed;this.translateZ(b*(p>0||this.autoForward&&!(p<0)?1:p));this.translateX(b*u);this.translateY(b*v);o&&(this.roll+=this.rollSpeed*this.delta*m);if(this.forward.y>this.constrainVertical[1])this.forward.y=this.constrainVertical[1],this.forward.normalize();
else if(this.forward.y<this.constrainVertical[0])this.forward.y=this.constrainVertical[0],this.forward.normalize();h.copy(this.forward);j.set(0,1,0);g.cross(j,h).normalize();j.cross(h,g).normalize();this.matrix.n11=g.x;this.matrix.n12=j.x;this.matrix.n13=h.x;this.matrix.n21=g.y;this.matrix.n22=j.y;this.matrix.n23=h.y;this.matrix.n31=g.z;this.matrix.n32=j.z;this.matrix.n33=h.z;k.identity();k.n11=Math.cos(this.roll);k.n12=-Math.sin(this.roll);k.n21=Math.sin(this.roll);k.n22=Math.cos(this.roll);this.matrix.multiplySelf(k);
this.matrixWorldNeedsUpdate=!0;this.matrix.n14=this.position.x;this.matrix.n24=this.position.y;this.matrix.n34=this.position.z;this.supr.update.call(this)};this.translateX=function(b){this.position.x+=this.matrix.n11*b;this.position.y+=this.matrix.n21*b;this.position.z+=this.matrix.n31*b};this.translateY=function(b){this.position.x+=this.matrix.n12*b;this.position.y+=this.matrix.n22*b;this.position.z+=this.matrix.n32*b};this.translateZ=function(b){this.position.x-=this.matrix.n13*b;this.position.y-=
this.matrix.n23*b;this.position.z-=this.matrix.n33*b};this.rotateHorizontally=function(b){g.set(this.matrix.n11,this.matrix.n21,this.matrix.n31);g.multiplyScalar(b);this.forward.subSelf(g);this.forward.normalize()};this.rotateVertically=function(b){j.set(this.matrix.n12,this.matrix.n22,this.matrix.n32);j.multiplyScalar(b);this.forward.addSelf(j);this.forward.normalize()};this.domElement.addEventListener("contextmenu",function(b){b.preventDefault()},!1);this.domElement.addEventListener("mousemove",
function(b){t=(b.clientX-x)/window.innerWidth;w=(b.clientY-B)/window.innerHeight},!1);this.domElement.addEventListener("mousedown",function(b){b.preventDefault();b.stopPropagation();switch(b.button){case 0:p=1;break;case 2:p=-1}},!1);this.domElement.addEventListener("mouseup",function(b){b.preventDefault();b.stopPropagation();switch(b.button){case 0:p=0;break;case 2:p=0}},!1);this.domElement.addEventListener("keydown",function(b){switch(b.keyCode){case 38:case 87:p=1;break;case 37:case 65:u=-1;break;
case 40:case 83:p=-1;break;case 39:case 68:u=1;break;case 81:o=!0;m=1;break;case 69:o=!0;m=-1;break;case 82:v=1;break;case 70:v=-1}},!1);this.domElement.addEventListener("keyup",function(b){switch(b.keyCode){case 38:case 87:p=0;break;case 37:case 65:u=0;break;case 40:case 83:p=0;break;case 39:case 68:u=0;break;case 81:o=!1;break;case 69:o=!1;break;case 82:v=0;break;case 70:v=0}},!1)};THREE.RollCamera.prototype=new THREE.Camera;THREE.RollCamera.prototype.constructor=THREE.RollCamera;
THREE.RollCamera.prototype.supr=THREE.Camera.prototype;
THREE.TrackballCamera=function(b){function c(b,c){return function(){c.apply(b,arguments)}}b=b||{};THREE.Camera.call(this,b.fov,b.aspect,b.near,b.far,b.target);this.domElement=b.domElement||document;this.screen=b.screen||{width:window.innerWidth,height:window.innerHeight,offsetLeft:0,offsetTop:0};this.radius=b.radius||(this.screen.width+this.screen.height)/4;this.rotateSpeed=b.rotateSpeed||1;this.zoomSpeed=b.zoomSpeed||1.2;this.panSpeed=b.panSpeed||0.3;this.noZoom=b.noZoom||!1;this.noPan=b.noPan||
!1;this.staticMoving=b.staticMoving||!1;this.dynamicDampingFactor=b.dynamicDampingFactor||0.2;this.minDistance=b.minDistance||0;this.maxDistance=b.maxDistance||Infinity;this.keys=b.keys||[65,83,68];this.useTarget=!0;var e=!1,f=this.STATE.NONE,g=new THREE.Vector3,j=new THREE.Vector3,h=new THREE.Vector3,k=new THREE.Vector2,o=new THREE.Vector2,m=new THREE.Vector2,p=new THREE.Vector2;this.handleEvent=function(b){if(typeof this[b.type]=="function")this[b.type](b)};this.getMouseOnScreen=function(b,c){return new THREE.Vector2((b-
this.screen.offsetLeft)/this.radius*0.5,(c-this.screen.offsetTop)/this.radius*0.5)};this.getMouseProjectionOnBall=function(b,c){var e=new THREE.Vector3((b-this.screen.width*0.5-this.screen.offsetLeft)/this.radius,(this.screen.height*0.5+this.screen.offsetTop-c)/this.radius,0),f=e.length();f>1?e.normalize():e.z=Math.sqrt(1-f*f);g=this.position.clone().subSelf(this.target.position);f=this.up.clone().setLength(e.y);f.addSelf(this.up.clone().crossSelf(g).setLength(e.x));f.addSelf(g.setLength(e.z));return f};
this.rotateCamera=function(){var b=Math.acos(j.dot(h)/j.length()/h.length());if(b){var c=(new THREE.Vector3).cross(j,h).normalize(),e=new THREE.Quaternion;b*=this.rotateSpeed;e.setFromAxisAngle(c,-b);e.multiplyVector3(g);e.multiplyVector3(this.up);e.multiplyVector3(h);this.staticMoving?j=h:(e.setFromAxisAngle(c,b*(this.dynamicDampingFactor-1)),e.multiplyVector3(j))}};this.zoomCamera=function(){var b=1+(o.y-k.y)*this.zoomSpeed;b!==1&&b>0&&(g.multiplyScalar(b),this.staticMoving?k=o:k.y+=(o.y-k.y)*this.dynamicDampingFactor)};
this.panCamera=function(){var b=p.clone().subSelf(m);if(b.lengthSq()){b.multiplyScalar(g.length()*this.panSpeed);var c=g.clone().crossSelf(this.up).setLength(b.x);c.addSelf(this.up.clone().setLength(b.y));this.position.addSelf(c);this.target.position.addSelf(c);this.staticMoving?m=p:m.addSelf(b.sub(p,m).multiplyScalar(this.dynamicDampingFactor))}};this.checkDistances=function(){if(!this.noZoom||!this.noPan)this.position.lengthSq()>this.maxDistance*this.maxDistance&&this.position.setLength(this.maxDistance),
g.lengthSq()<this.minDistance*this.minDistance&&this.position.add(this.target.position,g.setLength(this.minDistance))};this.update=function(b,c,e){g=this.position.clone().subSelf(this.target.position);this.rotateCamera();this.noZoom||this.zoomCamera();this.noPan||this.panCamera();this.position.add(this.target.position,g);this.checkDistances();this.supr.update.call(this,b,c,e)};this.domElement.addEventListener("contextmenu",function(b){b.preventDefault()},!1);this.domElement.addEventListener("mousemove",
c(this,function(b){e&&(j=h=this.getMouseProjectionOnBall(b.clientX,b.clientY),k=o=this.getMouseOnScreen(b.clientX,b.clientY),m=p=this.getMouseOnScreen(b.clientX,b.clientY),e=!1);f!==this.STATE.NONE&&(f===this.STATE.ROTATE?h=this.getMouseProjectionOnBall(b.clientX,b.clientY):f===this.STATE.ZOOM&&!this.noZoom?o=this.getMouseOnScreen(b.clientX,b.clientY):f===this.STATE.PAN&&!this.noPan&&(p=this.getMouseOnScreen(b.clientX,b.clientY)))}),!1);this.domElement.addEventListener("mousedown",c(this,function(b){b.preventDefault();
b.stopPropagation();if(f===this.STATE.NONE)f=b.button,f===this.STATE.ROTATE?j=h=this.getMouseProjectionOnBall(b.clientX,b.clientY):f===this.STATE.ZOOM&&!this.noZoom?k=o=this.getMouseOnScreen(b.clientX,b.clientY):this.noPan||(m=p=this.getMouseOnScreen(b.clientX,b.clientY))}),!1);this.domElement.addEventListener("mouseup",c(this,function(b){b.preventDefault();b.stopPropagation();f=this.STATE.NONE}),!1);window.addEventListener("keydown",c(this,function(b){if(f===this.STATE.NONE){if(b.keyCode===this.keys[this.STATE.ROTATE])f=
this.STATE.ROTATE;else if(b.keyCode===this.keys[this.STATE.ZOOM]&&!this.noZoom)f=this.STATE.ZOOM;else if(b.keyCode===this.keys[this.STATE.PAN]&&!this.noPan)f=this.STATE.PAN;f!==this.STATE.NONE&&(e=!0)}}),!1);window.addEventListener("keyup",c(this,function(){if(f!==this.STATE.NONE)f=this.STATE.NONE}),!1)};THREE.TrackballCamera.prototype=new THREE.Camera;THREE.TrackballCamera.prototype.constructor=THREE.TrackballCamera;THREE.TrackballCamera.prototype.supr=THREE.Camera.prototype;
THREE.TrackballCamera.prototype.STATE={NONE:-1,ROTATE:0,ZOOM:1,PAN:2};THREE.QuakeCamera=THREE.FirstPersonCamera;THREE.Curve=function(){};THREE.Curve.prototype.getPoint=function(){console.log("Warning, getPoint() not implemented!");return null};THREE.Curve.prototype.getPointAt=function(b){return this.getPoint(this.getUtoTmapping(b))};THREE.Curve.prototype.getPoints=function(b){b||(b=5);var c,e=[];for(c=0;c<=b;c++)e.push(this.getPoint(c/b));return e};
THREE.Curve.prototype.getSpacedPoints=function(b){b||(b=5);var c,e=[];for(c=0;c<=b;c++)e.push(this.getPointAt(c/b));return e};THREE.Curve.prototype.getLength=function(){var b=this.getLengths();return b[b.length-1]};
THREE.Curve.prototype.getLengths=function(b){b||(b=200);if(this.cacheArcLengths&&this.cacheArcLengths.length==b+1)return this.cacheArcLengths;var c=[],e,f=this.getPoint(0),g,j=0;c.push(0);for(g=1;g<=b;g++)e=this.getPoint(g/b),j+=e.distanceTo(f),c.push(j),f=e;return this.cacheArcLengths=c};
THREE.Curve.prototype.getUtoTmapping=function(b,c){var e=this.getLengths(),f=0,g=e.length,j;j=c?c:b*e[g-1];time=Date.now();for(var h=0,k=g-1,o;h<=k;)if(f=Math.floor(h+(k-h)/2),o=e[f]-j,o<0)h=f+1;else if(o>0)k=f-1;else{k=f;break}f=k;if(e[f]==j)return f/(g-1);h=e[f];return e=(f+(j-h)/(e[f+1]-h))/(g-1)};THREE.Curve.prototype.getNormalVector=function(b){b=this.getTangent(b);return new THREE.Vector2(-b.y,b.x)};
THREE.Curve.prototype.getTangent=function(b){var c=b-1.0E-4;b+=1.0E-4;c<0&&(c=0);b>1&&(b=1);var c=this.getPoint(c),b=this.getPoint(b),e=new THREE.Vector2;e.sub(b,c);return e.unit()};THREE.LineCurve=function(b,c){b instanceof THREE.Vector2?(this.v1=b,this.v2=c):THREE.LineCurve.oldConstructor.apply(this,arguments)};THREE.LineCurve.oldConstructor=function(b,c,e,f){this.constructor(new THREE.Vector2(b,c),new THREE.Vector2(e,f))};THREE.LineCurve.prototype=new THREE.Curve;
THREE.LineCurve.prototype.constructor=THREE.LineCurve;THREE.LineCurve.prototype.getPoint=function(b){var c=new THREE.Vector2;c.sub(this.v2,this.v1);c.multiplyScalar(b).addSelf(this.v1);return c};THREE.LineCurve.prototype.getPointAt=function(b){return this.getPoint(b)};THREE.LineCurve.prototype.getTangent=function(){var b=new THREE.Vector2;b.sub(this.v2,this.v1);b.normalize();return b};
THREE.QuadraticBezierCurve=function(b,c,e){if(!(c instanceof THREE.Vector2))var f=Array.prototype.slice.call(arguments),b=new THREE.Vector2(f[0],f[1]),c=new THREE.Vector2(f[2],f[3]),e=new THREE.Vector2(f[4],f[5]);this.v0=b;this.v1=c;this.v2=e};THREE.QuadraticBezierCurve.prototype=new THREE.Curve;THREE.QuadraticBezierCurve.prototype.constructor=THREE.QuadraticBezierCurve;
THREE.QuadraticBezierCurve.prototype.getPoint=function(b){var c;c=THREE.Shape.Utils.b2(b,this.v0.x,this.v1.x,this.v2.x);b=THREE.Shape.Utils.b2(b,this.v0.y,this.v1.y,this.v2.y);return new THREE.Vector2(c,b)};THREE.QuadraticBezierCurve.prototype.getTangent=function(b){var c;c=THREE.Curve.Utils.tangentQuadraticBezier(b,this.v0.x,this.v1.x,this.v2.x);b=THREE.Curve.Utils.tangentQuadraticBezier(b,this.v0.y,this.v1.y,this.v2.y);c=new THREE.Vector2(c,b);c.normalize();return c};
THREE.CubicBezierCurve=function(b,c,e,f){if(!(c instanceof THREE.Vector2))var g=Array.prototype.slice.call(arguments),b=new THREE.Vector2(g[0],g[1]),c=new THREE.Vector2(g[2],g[3]),e=new THREE.Vector2(g[4],g[5]),f=new THREE.Vector2(g[6],g[7]);this.v0=b;this.v1=c;this.v2=e;this.v3=f};THREE.CubicBezierCurve.prototype=new THREE.Curve;THREE.CubicBezierCurve.prototype.constructor=THREE.CubicBezierCurve;
THREE.CubicBezierCurve.prototype.getPoint=function(b){var c;c=THREE.Shape.Utils.b3(b,this.v0.x,this.v1.x,this.v2.x,this.v3.x);b=THREE.Shape.Utils.b3(b,this.v0.y,this.v1.y,this.v2.y,this.v3.y);return new THREE.Vector2(c,b)};THREE.CubicBezierCurve.prototype.getTangent=function(b){var c;c=THREE.Curve.Utils.tangentCubicBezier(b,this.v0.x,this.v1.x,this.v2.x,this.v3.x);b=THREE.Curve.Utils.tangentCubicBezier(b,this.v0.y,this.v1.y,this.v2.y,this.v3.y);c=new THREE.Vector2(c,b);c.normalize();return c};
THREE.SplineCurve=function(b){this.points=b};THREE.SplineCurve.prototype=new THREE.Curve;THREE.SplineCurve.prototype.constructor=THREE.SplineCurve;
THREE.SplineCurve.prototype.getPoint=function(b){var c=new THREE.Vector2,e=[],f=this.points,g;g=(f.length-1)*b;b=Math.floor(g);g-=b;e[0]=b==0?b:b-1;e[1]=b;e[2]=b>f.length-2?b:b+1;e[3]=b>f.length-3?b:b+2;c.x=THREE.Curve.Utils.interpolate(f[e[0]].x,f[e[1]].x,f[e[2]].x,f[e[3]].x,g);c.y=THREE.Curve.Utils.interpolate(f[e[0]].y,f[e[1]].y,f[e[2]].y,f[e[3]].y,g);return c};THREE.ArcCurve=function(b,c,e,f,g,j){this.aX=b;this.aY=c;this.aRadius=e;this.aStartAngle=f;this.aEndAngle=g;this.aClockwise=j};
THREE.ArcCurve.prototype=new THREE.Curve;THREE.ArcCurve.prototype.constructor=THREE.ArcCurve;THREE.ArcCurve.prototype.getPoint=function(b){var c=this.aEndAngle-this.aStartAngle;this.aClockwise||(b=1-b);b=this.aStartAngle+b*c;return new THREE.Vector2(this.aX+this.aRadius*Math.cos(b),this.aY+this.aRadius*Math.sin(b))};
THREE.Curve.Utils={tangentQuadraticBezier:function(b,c,e,f){return 2*(1-b)*(e-c)+2*b*(f-e)},tangentCubicBezier:function(b,c,e,f,g){return-3*c*(1-b)*(1-b)+3*e*(1-b)*(1-b)-6*b*e*(1-b)+6*b*f*(1-b)-3*b*b*f+3*b*b*g},tangentSpline:function(b){return 6*b*b-6*b+(3*b*b-4*b+1)+(-6*b*b+6*b)+(3*b*b-2*b)},interpolate:function(b,c,e,f,g){var b=(e-b)*0.5,f=(f-c)*0.5,j=g*g;return(2*c-2*e+b+f)*g*j+(-3*c+3*e-2*b-f)*j+b*g+c}};
THREE.Curve.create=function(b,c){b.prototype=new THREE.Curve;b.prototype.constructor=b;b.prototype.getPoint=c;return b};THREE.LineCurve3=THREE.Curve.create(function(b,c){this.v1=b;this.v2=c},function(b){var c=new THREE.Vector3;c.sub(v2,v1);c.multiplyScalar(b);c.addSelf(this.v1);return c});
THREE.QuadraticBezierCurve3=THREE.Curve.create(function(b,c,e){this.v0=b;this.v1=c;this.v2=e},function(b){var c,e;c=THREE.Shape.Utils.b2(b,this.v0.x,this.v1.x,this.v2.x);e=THREE.Shape.Utils.b2(b,this.v0.y,this.v1.y,this.v2.y);b=THREE.Shape.Utils.b2(b,this.v0.z,this.v1.z,this.v2.z);return new THREE.Vector3(c,e,b)});THREE.CurvePath=function(){this.curves=[];this.bends=[]};THREE.CurvePath.prototype=new THREE.Curve;THREE.CurvePath.prototype.constructor=THREE.CurvePath;THREE.CurvePath.prototype.add=function(b){this.curves.push(b)};
THREE.CurvePath.prototype.checkConnection=function(){};THREE.CurvePath.prototype.closePath=function(){};THREE.CurvePath.prototype.getPoint=function(b){for(var c=b*this.getLength(),e=this.getCurveLengths(),b=0;b<e.length;){if(e[b]>=c)return c=e[b]-c,b=this.curves[b],c=1-c/b.getLength(),b.getPointAt(c);b++}return null};THREE.CurvePath.prototype.getLength=function(){var b=this.getCurveLengths();return b[b.length-1]};
THREE.CurvePath.prototype.getCurveLengths=function(){if(this.cacheLengths&&this.cacheLengths.length==this.curves.length)return this.cacheLengths;var b=[],c=0,e,f=this.curves.length;for(e=0;e<f;e++)c+=this.curves[e].getLength(),b.push(c);return this.cacheLengths=b};
THREE.CurvePath.prototype.getBoundingBox=function(){var b=this.getPoints(),c,e,f,g;c=e=Number.NEGATIVE_INFINITY;f=g=Number.POSITIVE_INFINITY;var j,h,k,o;o=new THREE.Vector2;h=0;for(k=b.length;h<k;h++){j=b[h];if(j.x>c)c=j.x;else if(j.x<f)f=j.x;if(j.y>e)e=j.y;else if(j.y<e)g=j.y;o.addSelf(j.x,j.y)}return{minX:f,minY:g,maxX:c,maxY:e,centroid:o.divideScalar(k)}};THREE.CurvePath.prototype.createPointsGeometry=function(b){return this.createGeometry(this.getPoints(b,!0))};
THREE.CurvePath.prototype.createSpacedPointsGeometry=function(b){return this.createGeometry(this.getSpacedPoints(b,!0))};THREE.CurvePath.prototype.createGeometry=function(b){for(var c=new THREE.Geometry,e=0;e<b.length;e++)c.vertices.push(new THREE.Vertex(new THREE.Vector3(b[e].x,b[e].y,0)));return c};THREE.CurvePath.prototype.addWrapPath=function(b){this.bends.push(b)};
THREE.CurvePath.prototype.getTransformedPoints=function(b,c){var e=this.getPoints(b),f,g;if(!c)c=this.bends;f=0;for(g=c.length;f<g;f++)e=this.getWrapPoints(e,c[f]);return e};THREE.CurvePath.prototype.getTransformedSpacedPoints=function(b,c){var e=this.getSpacedPoints(b),f,g;if(!c)c=this.bends;f=0;for(g=c.length;f<g;f++)e=this.getWrapPoints(e,c[f]);return e};
THREE.CurvePath.prototype.getWrapPoints=function(b,c){var e=this.getBoundingBox(),f,g,j,h,k,o;f=0;for(g=b.length;f<g;f++)j=b[f],h=j.x,k=j.y,o=h/e.maxX,o=c.getUtoTmapping(o,h),h=c.getPoint(o),k=c.getNormalVector(o).multiplyScalar(k),j.x=h.x+k.x,j.y=h.y+k.y;return b};THREE.Path=function(b){THREE.CurvePath.call(this);this.actions=[];b&&this.fromPoints(b)};THREE.Path.prototype=new THREE.CurvePath;THREE.Path.prototype.constructor=THREE.Path;
THREE.PathActions={MOVE_TO:"moveTo",LINE_TO:"lineTo",QUADRATIC_CURVE_TO:"quadraticCurveTo",BEZIER_CURVE_TO:"bezierCurveTo",CSPLINE_THRU:"splineThru",ARC:"arc"};THREE.Path.prototype.fromPoints=function(b){this.moveTo(b[0].x,b[0].y);var c,e=b.length;for(c=1;c<e;c++)this.lineTo(b[c].x,b[c].y)};THREE.Path.prototype.moveTo=function(){var b=Array.prototype.slice.call(arguments);this.actions.push({action:THREE.PathActions.MOVE_TO,args:b})};
THREE.Path.prototype.lineTo=function(b,c){var e=Array.prototype.slice.call(arguments),f=this.actions[this.actions.length-1].args;this.curves.push(new THREE.LineCurve(new THREE.Vector2(f[f.length-2],f[f.length-1]),new THREE.Vector2(b,c)));this.actions.push({action:THREE.PathActions.LINE_TO,args:e})};
THREE.Path.prototype.quadraticCurveTo=function(b,c,e,f){var g=Array.prototype.slice.call(arguments),j=this.actions[this.actions.length-1].args;this.curves.push(new THREE.QuadraticBezierCurve(new THREE.Vector2(j[j.length-2],j[j.length-1]),new THREE.Vector2(b,c),new THREE.Vector2(e,f)));this.actions.push({action:THREE.PathActions.QUADRATIC_CURVE_TO,args:g})};
THREE.Path.prototype.bezierCurveTo=function(b,c,e,f,g,j){var h=Array.prototype.slice.call(arguments),k=this.actions[this.actions.length-1].args;this.curves.push(new THREE.CubicBezierCurve(new THREE.Vector2(k[k.length-2],k[k.length-1]),new THREE.Vector2(b,c),new THREE.Vector2(e,f),new THREE.Vector2(g,j)));this.actions.push({action:THREE.PathActions.BEZIER_CURVE_TO,args:h})};
THREE.Path.prototype.splineThru=function(b){var c=Array.prototype.slice.call(arguments),e=this.actions[this.actions.length-1].args,e=[new THREE.Vector2(e[e.length-2],e[e.length-1])],e=e.concat(b);this.curves.push(new THREE.SplineCurve(e));this.actions.push({action:THREE.PathActions.CSPLINE_THRU,args:c})};THREE.Path.prototype.arc=function(b,c,e,f,g,j){var h=Array.prototype.slice.call(arguments);this.curves.push(new THREE.ArcCurve(b,c,e,f,g,j));this.actions.push({action:THREE.PathActions.ARC,args:h})};
THREE.Path.prototype.getSpacedPoints=function(b){b||(b=40);for(var c=[],e=0;e<b;e++)c.push(this.getPoint(e/b));return c};
THREE.Path.prototype.getPoints=function(b,c){var b=b||12,e=[],f,g,j,h,k,o,m,p,u,v,t,w,x;f=0;for(g=this.actions.length;f<g;f++)switch(j=this.actions[f],h=j.action,j=j.args,h){case THREE.PathActions.LINE_TO:e.push(new THREE.Vector2(j[0],j[1]));break;case THREE.PathActions.QUADRATIC_CURVE_TO:k=j[2];o=j[3];u=j[0];v=j[1];e.length>0?(h=e[e.length-1],t=h.x,w=h.y):(h=this.actions[f-1].args,t=h[h.length-2],w=h[h.length-1]);for(h=1;h<=b;h++)x=h/b,j=THREE.Shape.Utils.b2(x,t,u,k),x=THREE.Shape.Utils.b2(x,w,v,
o),e.push(new THREE.Vector2(j,x));break;case THREE.PathActions.BEZIER_CURVE_TO:k=j[4];o=j[5];u=j[0];v=j[1];m=j[2];p=j[3];e.length>0?(h=e[e.length-1],t=h.x,w=h.y):(h=this.actions[f-1].args,t=h[h.length-2],w=h[h.length-1]);for(h=1;h<=b;h++)x=h/b,j=THREE.Shape.Utils.b3(x,t,u,m,k),x=THREE.Shape.Utils.b3(x,w,v,p,o),e.push(new THREE.Vector2(j,x));break;case THREE.PathActions.CSPLINE_THRU:h=this.actions[f-1].args;h=[new THREE.Vector2(h[h.length-2],h[h.length-1])];x=b*j[0].length;h=h.concat(j[0]);j=new THREE.SplineCurve(h);
for(h=1;h<=x;h++)e.push(j.getPointAt(h/x));break;case THREE.PathActions.ARC:h=this.actions[f-1].args;k=j[0];o=j[1];m=j[2];u=j[3];x=j[4];v=!!j[5];p=h[h.length-2];t=h[h.length-1];h.length==0&&(p=t=0);w=x-u;var B=b*2;for(h=1;h<=B;h++)x=h/B,v||(x=1-x),x=u+x*w,j=p+k+m*Math.cos(x),x=t+o+m*Math.sin(x),e.push(new THREE.Vector2(j,x))}c&&e.push(e[0]);return e};THREE.Path.prototype.transform=function(b,c){this.getBoundingBox();return this.getWrapPoints(this.getPoints(c),b)};
THREE.Path.prototype.nltransform=function(b,c,e,f,g,j){var h=this.getPoints(),k,o,m,p,u;k=0;for(o=h.length;k<o;k++)m=h[k],p=m.x,u=m.y,m.x=b*p+c*u+e,m.y=f*u+g*p+j;return h};
THREE.Path.prototype.debug=function(b){var c=this.getBoundingBox();b||(b=document.createElement("canvas"),b.setAttribute("width",c.maxX+100),b.setAttribute("height",c.maxY+100),document.body.appendChild(b));c=b.getContext("2d");c.fillStyle="white";c.fillRect(0,0,b.width,b.height);c.strokeStyle="black";c.beginPath();var e,f,g,b=0;for(e=this.actions.length;b<e;b++)f=this.actions[b],g=f.args,f=f.action,f!=THREE.PathActions.CSPLINE_THRU&&c[f].apply(c,g);c.stroke();c.closePath();c.strokeStyle="red";f=
this.getPoints();b=0;for(e=f.length;b<e;b++)g=f[b],c.beginPath(),c.arc(g.x,g.y,1.5,0,Math.PI*2,!1),c.stroke(),c.closePath()};
THREE.Path.prototype.toShapes=function(){var b,c,e,f,g=[],j=new THREE.Path;b=0;for(c=this.actions.length;b<c;b++)e=this.actions[b],f=e.args,e=e.action,e==THREE.PathActions.MOVE_TO&&j.actions.length!=0&&(g.push(j),j=new THREE.Path),j[e].apply(j,f);j.actions.length!=0&&g.push(j);if(g.length==0)return[];var h,j=[];if(THREE.Shape.Utils.isClockWise(g[0].getPoints())){b=0;for(c=g.length;b<c;b++)f=g[b],THREE.Shape.Utils.isClockWise(f.getPoints())?(h&&j.push(h),h=new THREE.Shape,h.actions=f.actions,h.curves=
f.curves):h.holes.push(f);j.push(h)}else{h=new THREE.Shape;b=0;for(c=g.length;b<c;b++)f=g[b],THREE.Shape.Utils.isClockWise(f.getPoints())?(h.actions=f.actions,h.curves=f.curves,j.push(h),h=new THREE.Shape):h.holes.push(f)}return j};THREE.Shape=function(){THREE.Path.apply(this,arguments);this.holes=[]};THREE.Shape.prototype=new THREE.Path;THREE.Shape.prototype.constructor=THREE.Path;THREE.Shape.prototype.extrude=function(b){return new THREE.ExtrudeGeometry(this,b)};
THREE.Shape.prototype.getPointsHoles=function(b){var c,e=this.holes.length,f=[];for(c=0;c<e;c++)f[c]=this.holes[c].getTransformedPoints(b,this.bends);return f};THREE.Shape.prototype.getSpacedPointsHoles=function(b){var c,e=this.holes.length,f=[];for(c=0;c<e;c++)f[c]=this.holes[c].getTransformedSpacedPoints(b,this.bends);return f};THREE.Shape.prototype.extractAllPoints=function(b){return{shape:this.getTransformedPoints(b),holes:this.getPointsHoles(b)}};
THREE.Shape.prototype.extractAllSpacedPoints=function(b){return{shape:this.getTransformedSpacedPoints(b),holes:this.getSpacedPointsHoles(b)}};
THREE.Shape.Utils={removeHoles:function(b,c){var e=b.concat(),f=e.concat(),g,j,h,k,o,m,p,u,v,t,w=[];for(o=0;o<c.length;o++){m=c[o];f=f.concat(m);j=Number.POSITIVE_INFINITY;for(g=0;g<m.length;g++){v=m[g];t=[];for(u=0;u<e.length;u++)p=e[u],p=v.distanceToSquared(p),t.push(p),p<j&&(j=p,h=g,k=u)}g=k-1>=0?k-1:e.length-1;j=h-1>=0?h-1:m.length-1;var x=[m[h],e[k],e[g]];u=THREE.FontUtils.Triangulate.area(x);var B=[m[h],m[j],e[k]];v=THREE.FontUtils.Triangulate.area(B);t=k;p=h;k+=1;h+=-1;k<0&&(k+=e.length);k%=
e.length;h<0&&(h+=m.length);h%=m.length;g=k-1>=0?k-1:e.length-1;j=h-1>=0?h-1:m.length-1;x=[m[h],e[k],e[g]];x=THREE.FontUtils.Triangulate.area(x);B=[m[h],m[j],e[k]];B=THREE.FontUtils.Triangulate.area(B);u+v>x+B&&(k=t,h=p,k<0&&(k+=e.length),k%=e.length,h<0&&(h+=m.length),h%=m.length,g=k-1>=0?k-1:e.length-1,j=h-1>=0?h-1:m.length-1);u=e.slice(0,k);v=e.slice(k);t=m.slice(h);p=m.slice(0,h);j=[m[h],m[j],e[k]];w.push([m[h],e[k],e[g]]);w.push(j);e=u.concat(t).concat(p).concat(v)}return{shape:e,isolatedPts:w,
allpoints:f}},triangulateShape:function(b,c){var e=THREE.Shape.Utils.removeHoles(b,c),f=e.allpoints,g=e.isolatedPts,e=THREE.FontUtils.Triangulate(e.shape,!1),j,h,k,o,m={};j=0;for(h=f.length;j<h;j++)o=f[j].x+":"+f[j].y,m[o]!==void 0&&console.log("Duplicate point",o),m[o]=j;j=0;for(h=e.length;j<h;j++){k=e[j];for(f=0;f<3;f++)o=k[f].x+":"+k[f].y,o=m[o],o!==void 0&&(k[f]=o)}j=0;for(h=g.length;j<h;j++){k=g[j];for(f=0;f<3;f++)o=k[f].x+":"+k[f].y,o=m[o],o!==void 0&&(k[f]=o)}return e.concat(g)},isClockWise:function(b){return THREE.FontUtils.Triangulate.area(b)<
0},b2p0:function(b,c){var e=1-b;return e*e*c},b2p1:function(b,c){return 2*(1-b)*b*c},b2p2:function(b,c){return b*b*c},b2:function(b,c,e,f){return this.b2p0(b,c)+this.b2p1(b,e)+this.b2p2(b,f)},b3p0:function(b,c){var e=1-b;return e*e*e*c},b3p1:function(b,c){var e=1-b;return 3*e*e*b*c},b3p2:function(b,c){return 3*(1-b)*b*b*c},b3p3:function(b,c){return b*b*b*c},b3:function(b,c,e,f,g){return this.b3p0(b,c)+this.b3p1(b,e)+this.b3p2(b,f)+this.b3p3(b,g)}};
THREE.TextPath=function(b,c){THREE.Path.call(this);this.parameters=c||{};this.set(b)};THREE.TextPath.prototype.set=function(b,c){this.text=b;var c=c||this.parameters,e=c.curveSegments!==void 0?c.curveSegments:4,f=c.font!==void 0?c.font:"helvetiker",g=c.weight!==void 0?c.weight:"normal",j=c.style!==void 0?c.style:"normal";THREE.FontUtils.size=c.size!==void 0?c.size:100;THREE.FontUtils.divisions=e;THREE.FontUtils.face=f;THREE.FontUtils.weight=g;THREE.FontUtils.style=j};
THREE.TextPath.prototype.toShapes=function(){for(var b=THREE.FontUtils.drawText(this.text).paths,c=[],e=0,f=b.length;e<f;e++)c=c.concat(b[e].toShapes());return c};
THREE.CubeGeometry=function(b,c,e,f,g,j,h,k,o){function m(b,c,e,h,k,m,o,t){var u,v,w=f||1,x=g||1,R=k/2,C=m/2,n=p.vertices.length;if(b=="x"&&c=="y"||b=="y"&&c=="x")u="z";else if(b=="x"&&c=="z"||b=="z"&&c=="x")u="y",x=j||1;else if(b=="z"&&c=="y"||b=="y"&&c=="z")u="x",w=j||1;var W=w+1,V=x+1;k/=w;var fa=m/x;for(v=0;v<V;v++)for(m=0;m<W;m++){var L=new THREE.Vector3;L[b]=(m*k-R)*e;L[c]=(v*fa-C)*h;L[u]=o;p.vertices.push(new THREE.Vertex(L))}for(v=0;v<x;v++)for(m=0;m<w;m++)p.faces.push(new THREE.Face4(m+W*
v+n,m+W*(v+1)+n,m+1+W*(v+1)+n,m+1+W*v+n,null,null,t)),p.faceVertexUvs[0].push([new THREE.UV(m/w,v/x),new THREE.UV(m/w,(v+1)/x),new THREE.UV((m+1)/w,(v+1)/x),new THREE.UV((m+1)/w,v/x)])}THREE.Geometry.call(this);var p=this,u=b/2,v=c/2,t=e/2,k=k?-1:1;if(h!==void 0)if(h instanceof Array)this.materials=h;else{this.materials=[];for(var w=0;w<6;w++)this.materials.push([h])}else this.materials=[];this.sides={px:!0,nx:!0,py:!0,ny:!0,pz:!0,nz:!0};if(o!=void 0)for(var x in o)this.sides[x]!=void 0&&(this.sides[x]=
o[x]);this.sides.px&&m("z","y",1*k,-1,e,c,-u,this.materials[0]);this.sides.nx&&m("z","y",-1*k,-1,e,c,u,this.materials[1]);this.sides.py&&m("x","z",1*k,1,b,e,v,this.materials[2]);this.sides.ny&&m("x","z",1*k,-1,b,e,-v,this.materials[3]);this.sides.pz&&m("x","y",1*k,-1,b,c,t,this.materials[4]);this.sides.nz&&m("x","y",-1*k,-1,b,c,-t,this.materials[5]);(function(){for(var b=[],c=[],e=0,f=p.vertices.length;e<f;e++){for(var g=p.vertices[e],h=!1,j=0,k=b.length;j<k;j++){var m=b[j];if(g.position.x==m.position.x&&
g.position.y==m.position.y&&g.position.z==m.position.z){c[e]=j;h=!0;break}}if(!h)c[e]=b.length,b.push(new THREE.Vertex(g.position.clone()))}e=0;for(f=p.faces.length;e<f;e++)g=p.faces[e],g.a=c[g.a],g.b=c[g.b],g.c=c[g.c],g.d=c[g.d];p.vertices=b})();this.computeCentroids();this.computeFaceNormals()};THREE.CubeGeometry.prototype=new THREE.Geometry;THREE.CubeGeometry.prototype.constructor=THREE.CubeGeometry;
THREE.CylinderGeometry=function(b,c,e,f,g,j){function h(b,c,e){k.vertices.push(new THREE.Vertex(new THREE.Vector3(b,c,e)))}THREE.Geometry.call(this);var k=this,o,m=Math.PI*2,p=f/2;for(o=0;o<b;o++)h(Math.sin(m*o/b)*c,Math.cos(m*o/b)*c,-p);for(o=0;o<b;o++)h(Math.sin(m*o/b)*e,Math.cos(m*o/b)*e,p);for(o=0;o<b;o++)k.faces.push(new THREE.Face4(o,o+b,b+(o+1)%b,(o+1)%b));if(e>0){h(0,0,-p-(j||0));for(o=b;o<b+b/2;o++)k.faces.push(new THREE.Face4(2*b,(2*o-2*b)%b,(2*o-2*b+1)%b,(2*o-2*b+2)%b))}if(c>0){h(0,0,p+
(g||0));for(o=b+b/2;o<2*b;o++)k.faces.push(new THREE.Face4(2*b+1,(2*o-2*b+2)%b+b,(2*o-2*b+1)%b+b,(2*o-2*b)%b+b))}o=0;for(b=this.faces.length;o<b;o++){var c=[],e=this.faces[o],g=this.vertices[e.a],j=this.vertices[e.b],p=this.vertices[e.c],u=this.vertices[e.d];c.push(new THREE.UV(0.5+Math.atan2(g.position.x,g.position.y)/m,0.5+g.position.z/f));c.push(new THREE.UV(0.5+Math.atan2(j.position.x,j.position.y)/m,0.5+j.position.z/f));c.push(new THREE.UV(0.5+Math.atan2(p.position.x,p.position.y)/m,0.5+p.position.z/
f));e instanceof THREE.Face4&&c.push(new THREE.UV(0.5+Math.atan2(u.position.x,u.position.y)/m,0.5+u.position.z/f));this.faceVertexUvs[0].push(c)}this.computeCentroids();this.computeFaceNormals()};THREE.CylinderGeometry.prototype=new THREE.Geometry;THREE.CylinderGeometry.prototype.constructor=THREE.CylinderGeometry;THREE.ExtrudeGeometry=function(b,c){if(typeof b!="undefined"){THREE.Geometry.call(this);var b=b instanceof Array?b:[b],e,f=b.length,g;for(e=0;e<f;e++)g=b[e],this.addShape(g,c)}};
THREE.ExtrudeGeometry.prototype=new THREE.Geometry;THREE.ExtrudeGeometry.prototype.constructor=THREE.ExtrudeGeometry;
THREE.ExtrudeGeometry.prototype.addShape=function(b,c){function e(b,c,e){c||console.log("die");return c.clone().multiplyScalar(e).addSelf(b)}function f(b,c,e){var f=THREE.ExtrudeGeometry.__v1,g=THREE.ExtrudeGeometry.__v2,h=THREE.ExtrudeGeometry.__v3,j=THREE.ExtrudeGeometry.__v4,k=THREE.ExtrudeGeometry.__v5,m=THREE.ExtrudeGeometry.__v6;f.set(b.x-c.x,b.y-c.y);g.set(b.x-e.x,b.y-e.y);f=f.normalize();g=g.normalize();h.set(-f.y,f.x);j.set(g.y,-g.x);k.copy(b).addSelf(h);m.copy(b).addSelf(j);if(k.equals(m))return j.clone();
k.copy(c).addSelf(h);m.copy(e).addSelf(j);h=f.dot(j);j=m.subSelf(k).dot(j);h==0&&(console.log("Either infinite or no solutions!"),j==0?console.log("Its finite solutions."):console.log("Too bad, no solutions."));j/=h;if(j<0)return c=Math.atan2(c.y-b.y,c.x-b.x),b=Math.atan2(e.y-b.y,e.x-b.x),c>b&&(b+=Math.PI*2),anglec=(c+b)/2,new THREE.Vector2(-Math.cos(anglec),-Math.sin(anglec));return f.multiplyScalar(j).addSelf(k).subSelf(b).clone()}function g(b){for(D=b.length;--D>=0;){T=D;U=D-1;U<0&&(U=b.length-
1);for(var c=0,c=0;c<t+p*2;c++){var e=n*c,f=n*(c+1),g=da+T+e,e=da+U+e,h=da+U+f,f=da+T+f;g+=K;e+=K;h+=K;f+=K;E.faces.push(new THREE.Face4(g,e,h,f))}}}function j(b,c,e){E.vertices.push(new THREE.Vertex(new THREE.Vector3(b,c,e)))}function h(b,c,e){b+=K;c+=K;e+=K;E.faces.push(new THREE.Face3(b,c,e))}var k=c.amount!==void 0?c.amount:100,o=c.bevelThickness!==void 0?c.bevelThickness:6,m=c.bevelSize!==void 0?c.bevelSize:o-2,p=c.bevelSegments!==void 0?c.bevelSegments:3,u=c.bevelEnabled!==void 0?c.bevelEnabled:
!0,v=c.curveSegments!==void 0?c.curveSegments:12,t=c.steps!==void 0?c.steps:1,w=c.bendPath,x=c.extrudePath,B,A=!1,H=c.useSpacedPoints!==void 0?c.useSpacedPoints:!1;if(x)B=x.getPoints(v),t=B.length,A=!0,u=!1;u||(m=o=p=0);var y,G,I,E=this,K=this.vertices.length;w&&b.addWrapPath(w);v=H?b.extractAllSpacedPoints(v):b.extractAllPoints(v);w=v.shape;v=v.holes;if(x=!THREE.Shape.Utils.isClockWise(w)){w=w.reverse();G=0;for(I=v.length;G<I;G++)y=v[G],THREE.Shape.Utils.isClockWise(y)&&(v[G]=y.reverse());x=!1}x=
THREE.Shape.Utils.triangulateShape(w,v);H=w;G=0;for(I=v.length;G<I;G++)y=v[G],w=w.concat(y);var D,J,S,X,R,C,n=w.length,W=x.length,V=[];D=0;J=H.length;T=J-1;for(U=D+1;D<J;D++,T++,U++)T==J&&(T=0),U==J&&(U=0),V[D]=f(H[D],H[T],H[U]);var fa=[],L,ea=V.concat();G=0;for(I=v.length;G<I;G++){y=v[G];L=[];D=0;J=y.length;T=J-1;for(U=D+1;D<J;D++,T++,U++)T==J&&(T=0),U==J&&(U=0),L[D]=f(y[D],y[T],y[U]);fa.push(L);ea=ea.concat(L)}for(S=0;S<p;S++){X=S/p;R=o*(1-X);X=m*Math.sin(X*Math.PI/2);D=0;for(J=H.length;D<J;D++)C=
e(H[D],V[D],X),j(C.x,C.y,-R);G=0;for(I=v.length;G<I;G++){y=v[G];L=fa[G];D=0;for(J=y.length;D<J;D++)C=e(y[D],L[D],X),j(C.x,C.y,-R)}}X=m;for(D=0;D<n;D++)C=u?e(w[D],ea[D],X):w[D],A?j(C.x,C.y+B[0].y,B[0].x):j(C.x,C.y,0);for(S=1;S<=t;S++)for(D=0;D<n;D++)C=u?e(w[D],ea[D],X):w[D],A?j(C.x,C.y+B[S-1].y,B[S-1].x):j(C.x,C.y,k/t*S);for(S=p-1;S>=0;S--){X=S/p;R=o*(1-X);X=m*Math.sin(X*Math.PI/2);D=0;for(J=H.length;D<J;D++)C=e(H[D],V[D],X),j(C.x,C.y,k+R);G=0;for(I=v.length;G<I;G++){y=v[G];L=fa[G];D=0;for(J=y.length;D<
J;D++)C=e(y[D],L[D],X),A?j(C.x,C.y+B[t-1].y,B[t-1].x+R):j(C.x,C.y,k+R)}}if(u){o=n*0;for(D=0;D<W;D++)k=x[D],h(k[2]+o,k[1]+o,k[0]+o);o=n*(t+p*2);for(D=0;D<W;D++)k=x[D],h(k[0]+o,k[1]+o,k[2]+o)}else{for(D=0;D<W;D++)k=x[D],h(k[2],k[1],k[0]);for(D=0;D<W;D++)k=x[D],h(k[0]+n*t,k[1]+n*t,k[2]+n*t)}var T,U,da=0;g(H);da+=H.length;G=0;for(I=v.length;G<I;G++)y=v[G],g(y),da+=y.length;this.computeCentroids();this.computeFaceNormals()};THREE.ExtrudeGeometry.__v1=new THREE.Vector2;THREE.ExtrudeGeometry.__v2=new THREE.Vector2;
THREE.ExtrudeGeometry.__v3=new THREE.Vector2;THREE.ExtrudeGeometry.__v4=new THREE.Vector2;THREE.ExtrudeGeometry.__v5=new THREE.Vector2;THREE.ExtrudeGeometry.__v6=new THREE.Vector2;
THREE.IcosahedronGeometry=function(b){function c(b,c,e){var f=Math.sqrt(b*b+c*c+e*e);return g.vertices.push(new THREE.Vertex(new THREE.Vector3(b/f,c/f,e/f)))-1}function e(b,c,e,f){f.faces.push(new THREE.Face3(b,c,e))}function f(b,e){var f=g.vertices[b].position,h=g.vertices[e].position;return c((f.x+h.x)/2,(f.y+h.y)/2,(f.z+h.z)/2)}var g=this,j=new THREE.Geometry;this.subdivisions=b||0;THREE.Geometry.call(this);b=(1+Math.sqrt(5))/2;c(-1,b,0);c(1,b,0);c(-1,-b,0);c(1,-b,0);c(0,-1,b);c(0,1,b);c(0,-1,
-b);c(0,1,-b);c(b,0,-1);c(b,0,1);c(-b,0,-1);c(-b,0,1);e(0,11,5,j);e(0,5,1,j);e(0,1,7,j);e(0,7,10,j);e(0,10,11,j);e(1,5,9,j);e(5,11,4,j);e(11,10,2,j);e(10,7,6,j);e(7,1,8,j);e(3,9,4,j);e(3,4,2,j);e(3,2,6,j);e(3,6,8,j);e(3,8,9,j);e(4,9,5,j);e(2,4,11,j);e(6,2,10,j);e(8,6,7,j);e(9,8,1,j);for(var h=0;h<this.subdivisions;h++){var b=new THREE.Geometry,k;for(k in j.faces){var o=f(j.faces[k].a,j.faces[k].b),m=f(j.faces[k].b,j.faces[k].c),p=f(j.faces[k].c,j.faces[k].a);e(j.faces[k].a,o,p,b);e(j.faces[k].b,m,
o,b);e(j.faces[k].c,p,m,b);e(o,m,p,b)}j.faces=b.faces}g.faces=j.faces;this.computeCentroids();this.computeFaceNormals();this.computeVertexNormals()};THREE.IcosahedronGeometry.prototype=new THREE.Geometry;THREE.IcosahedronGeometry.prototype.constructor=THREE.IcosahedronGeometry;
THREE.LatheGeometry=function(b,c,e){THREE.Geometry.call(this);this.steps=c||12;this.angle=e||2*Math.PI;for(var c=this.angle/this.steps,e=[],f=[],g=[],j=[],h=(new THREE.Matrix4).setRotationZ(c),k=0;k<b.length;k++)this.vertices.push(new THREE.Vertex(b[k])),e[k]=b[k].clone(),f[k]=this.vertices.length-1;for(var o=0;o<=this.angle+0.001;o+=c){for(k=0;k<e.length;k++)o<this.angle?(e[k]=h.multiplyVector3(e[k].clone()),this.vertices.push(new THREE.Vertex(e[k])),g[k]=this.vertices.length-1):g=j;o==0&&(j=f);
for(k=0;k<f.length-1;k++)this.faces.push(new THREE.Face4(g[k],g[k+1],f[k+1],f[k])),this.faceVertexUvs[0].push([new THREE.UV(1-o/this.angle,k/b.length),new THREE.UV(1-o/this.angle,(k+1)/b.length),new THREE.UV(1-(o-c)/this.angle,(k+1)/b.length),new THREE.UV(1-(o-c)/this.angle,k/b.length)]);f=g;g=[]}this.computeCentroids();this.computeFaceNormals();this.computeVertexNormals()};THREE.LatheGeometry.prototype=new THREE.Geometry;THREE.LatheGeometry.prototype.constructor=THREE.LatheGeometry;
THREE.PlaneGeometry=function(b,c,e,f){THREE.Geometry.call(this);var g,j=b/2,h=c/2,e=e||1,f=f||1,k=e+1,o=f+1;b/=e;var m=c/f;for(g=0;g<o;g++)for(c=0;c<k;c++)this.vertices.push(new THREE.Vertex(new THREE.Vector3(c*b-j,-(g*m-h),0)));for(g=0;g<f;g++)for(c=0;c<e;c++)this.faces.push(new THREE.Face4(c+k*g,c+k*(g+1),c+1+k*(g+1),c+1+k*g)),this.faceVertexUvs[0].push([new THREE.UV(c/e,g/f),new THREE.UV(c/e,(g+1)/f),new THREE.UV((c+1)/e,(g+1)/f),new THREE.UV((c+1)/e,g/f)]);this.computeCentroids();this.computeFaceNormals()};
THREE.PlaneGeometry.prototype=new THREE.Geometry;THREE.PlaneGeometry.prototype.constructor=THREE.PlaneGeometry;
THREE.SphereGeometry=function(b,c,e){THREE.Geometry.call(this);for(var b=b||50,f,g=Math.PI,j=Math.max(3,c||8),h=Math.max(2,e||6),c=[],e=0;e<h+1;e++){f=e/h;var k=b*Math.cos(f*g),o=b*Math.sin(f*g),m=[],p=0;for(f=0;f<j;f++){var u=2*f/j,v=o*Math.sin(u*g),u=o*Math.cos(u*g);(e==0||e==h)&&f>0||(p=this.vertices.push(new THREE.Vertex(new THREE.Vector3(u,k,v)))-1);m.push(p)}c.push(m)}for(var t,w,x,g=c.length,e=0;e<g;e++)if(j=c[e].length,e>0)for(f=0;f<j;f++){m=f==j-1;h=c[e][m?0:f+1];k=c[e][m?j-1:f];o=c[e-1][m?
j-1:f];m=c[e-1][m?0:f+1];v=e/(g-1);t=(e-1)/(g-1);w=(f+1)/j;var u=f/j,p=new THREE.UV(1-w,v),v=new THREE.UV(1-u,v),u=new THREE.UV(1-u,t),B=new THREE.UV(1-w,t);e<c.length-1&&(t=this.vertices[h].position.clone(),w=this.vertices[k].position.clone(),x=this.vertices[o].position.clone(),t.normalize(),w.normalize(),x.normalize(),this.faces.push(new THREE.Face3(h,k,o,[new THREE.Vector3(t.x,t.y,t.z),new THREE.Vector3(w.x,w.y,w.z),new THREE.Vector3(x.x,x.y,x.z)])),this.faceVertexUvs[0].push([p,v,u]));e>1&&(t=
this.vertices[h].position.clone(),w=this.vertices[o].position.clone(),x=this.vertices[m].position.clone(),t.normalize(),w.normalize(),x.normalize(),this.faces.push(new THREE.Face3(h,o,m,[new THREE.Vector3(t.x,t.y,t.z),new THREE.Vector3(w.x,w.y,w.z),new THREE.Vector3(x.x,x.y,x.z)])),this.faceVertexUvs[0].push([p,u,B]))}this.computeCentroids();this.computeFaceNormals();this.computeVertexNormals();this.boundingSphere={radius:b}};THREE.SphereGeometry.prototype=new THREE.Geometry;
THREE.SphereGeometry.prototype.constructor=THREE.SphereGeometry;
THREE.TextGeometry=function(b,c){var e=(new THREE.TextPath(b,c)).toShapes();c.amount=c.height!==void 0?c.height:50;if(c.bevelThickness===void 0)c.bevelThickness=10;if(c.bevelSize===void 0)c.bevelSize=8;if(c.bevelEnabled===void 0)c.bevelEnabled=!1;if(c.bend){var f=e[e.length-1].getBoundingBox().maxX;c.bendPath=new THREE.QuadraticBezierCurve(new THREE.Vector2(0,0),new THREE.Vector2(f/2,120),new THREE.Vector2(f,0))}THREE.ExtrudeGeometry.call(this,e,c)};THREE.TextGeometry.prototype=new THREE.ExtrudeGeometry;
THREE.TextGeometry.prototype.constructor=THREE.TextGeometry;
THREE.FontUtils={faces:{},face:"helvetiker",weight:"normal",style:"normal",size:150,divisions:10,getFace:function(){return this.faces[this.face][this.weight][this.style]},getTextShapes:function(b,c){return(new TextPath(b,c)).toShapes()},loadFace:function(b){var c=b.familyName.toLowerCase();this.faces[c]=this.faces[c]||{};this.faces[c][b.cssFontWeight]=this.faces[c][b.cssFontWeight]||{};this.faces[c][b.cssFontWeight][b.cssFontStyle]=b;return this.faces[c][b.cssFontWeight][b.cssFontStyle]=b},drawText:function(b){for(var c=
this.getFace(),e=this.size/c.resolution,f=0,g=String(b).split(""),j=g.length,h=[],b=0;b<j;b++){var k=new THREE.Path,k=this.extractGlyphPoints(g[b],c,e,f,k);f+=k.offset;h.push(k.path)}return{paths:h,offset:f/2}},extractGlyphPoints:function(b,c,e,f,g){var j=[],h,k,o,m,p,u,v,t,w,x,B=c.glyphs[b]||c.glyphs[ctxt.options.fallbackCharacter];if(B){if(B.o){c=B._cachedOutline||(B._cachedOutline=B.o.split(" "));o=c.length;for(b=0;b<o;)switch(k=c[b++],k){case "m":k=c[b++]*e+f;m=c[b++]*e;j.push(new THREE.Vector2(k,
m));g.moveTo(k,m);break;case "l":k=c[b++]*e+f;m=c[b++]*e;j.push(new THREE.Vector2(k,m));g.lineTo(k,m);break;case "q":k=c[b++]*e+f;m=c[b++]*e;v=c[b++]*e+f;t=c[b++]*e;g.quadraticCurveTo(v,t,k,m);if(h=j[j.length-1]){p=h.x;u=h.y;h=1;for(divisions=this.divisions;h<=divisions;h++){var A=h/divisions,H=THREE.Shape.Utils.b2(A,p,v,k),A=THREE.Shape.Utils.b2(A,u,t,m);j.push(new THREE.Vector2(H,A))}}break;case "b":if(k=c[b++]*e+f,m=c[b++]*e,v=c[b++]*e+f,t=c[b++]*-e,w=c[b++]*e+f,x=c[b++]*-e,g.bezierCurveTo(k,m,
v,t,w,x),h=j[j.length-1]){p=h.x;u=h.y;h=1;for(divisions=this.divisions;h<=divisions;h++)A=h/divisions,H=THREE.Shape.Utils.b3(A,p,v,w,k),A=THREE.Shape.Utils.b3(A,u,t,x,m),j.push(new THREE.Vector2(H,A))}}}return{offset:B.ha*e,points:j,path:g}}}};
(function(b){var c=function(b){for(var c=b.length,g=0,j=c-1,h=0;h<c;j=h++)g+=b[j].x*b[h].y-b[h].x*b[j].y;return g*0.5};b.Triangulate=function(b,f){var g=b.length;if(g<3)return null;var j=[],h=[],k=[],o,m,p;if(c(b)>0)for(m=0;m<g;m++)h[m]=m;else for(m=0;m<g;m++)h[m]=g-1-m;var u=2*g;for(m=g-1;g>2;){if(u--<=0){console.log("Warning, unable to triangulate polygon!");if(f)return k;return j}o=m;g<=o&&(o=0);m=o+1;g<=m&&(m=0);p=m+1;g<=p&&(p=0);var v;a:{v=b;var t=o,w=m,x=p,B=g,A=h,H=void 0,y=void 0,G=void 0,
I=void 0,E=void 0,K=void 0,D=void 0,J=void 0,S=void 0,y=v[A[t]].x,G=v[A[t]].y,I=v[A[w]].x,E=v[A[w]].y,K=v[A[x]].x,D=v[A[x]].y;if(1.0E-10>(I-y)*(D-G)-(E-G)*(K-y))v=!1;else{for(H=0;H<B;H++)if(!(H==t||H==w||H==x)){var J=v[A[H]].x,S=v[A[H]].y,X=void 0,R=void 0,C=void 0,n=void 0,W=void 0,V=void 0,fa=void 0,L=void 0,ea=void 0,T=void 0,U=void 0,da=void 0,X=C=W=void 0,X=K-I,R=D-E,C=y-K,n=G-D,W=I-y,V=E-G,fa=J-y,L=S-G,ea=J-I,T=S-E,U=J-K,da=S-D,X=X*T-R*ea,W=W*L-V*fa,C=C*da-n*U;if(X>=0&&C>=0&&W>=0){v=!1;break a}}v=
!0}}if(v){j.push([b[h[o]],b[h[m]],b[h[p]]]);k.push([h[o],h[m],h[p]]);o=m;for(p=m+1;p<g;o++,p++)h[o]=h[p];g--;u=2*g}}if(f)return k;return j};b.Triangulate.area=c;return b})(THREE.FontUtils);window._typeface_js={faces:THREE.FontUtils.faces,loadFace:THREE.FontUtils.loadFace};
THREE.TorusGeometry=function(b,c,e,f){THREE.Geometry.call(this);this.radius=b||100;this.tube=c||40;this.segmentsR=e||8;this.segmentsT=f||6;b=[];for(c=0;c<=this.segmentsR;++c)for(e=0;e<=this.segmentsT;++e){var f=e/this.segmentsT*2*Math.PI,g=c/this.segmentsR*2*Math.PI;this.vertices.push(new THREE.Vertex(new THREE.Vector3((this.radius+this.tube*Math.cos(g))*Math.cos(f),(this.radius+this.tube*Math.cos(g))*Math.sin(f),this.tube*Math.sin(g))));b.push([e/this.segmentsT,1-c/this.segmentsR])}for(c=1;c<=this.segmentsR;++c)for(e=
1;e<=this.segmentsT;++e){var f=(this.segmentsT+1)*c+e,g=(this.segmentsT+1)*c+e-1,j=(this.segmentsT+1)*(c-1)+e-1,h=(this.segmentsT+1)*(c-1)+e;this.faces.push(new THREE.Face4(f,g,j,h));this.faceVertexUvs[0].push([new THREE.UV(b[f][0],b[f][1]),new THREE.UV(b[g][0],b[g][1]),new THREE.UV(b[j][0],b[j][1]),new THREE.UV(b[h][0],b[h][1])])}this.computeCentroids();this.computeFaceNormals();this.computeVertexNormals()};THREE.TorusGeometry.prototype=new THREE.Geometry;
THREE.TorusGeometry.prototype.constructor=THREE.TorusGeometry;
THREE.TorusKnotGeometry=function(b,c,e,f,g,j,h){function k(b,c,e,f,g,h){c=e/f*b;e=Math.cos(c);return new THREE.Vector3(g*(2+e)*0.5*Math.cos(b),g*(2+e)*Math.sin(b)*0.5,h*g*Math.sin(c)*0.5)}THREE.Geometry.call(this);this.radius=b||200;this.tube=c||40;this.segmentsR=e||64;this.segmentsT=f||8;this.p=g||2;this.q=j||3;this.heightScale=h||1;this.grid=Array(this.segmentsR);e=new THREE.Vector3;f=new THREE.Vector3;j=new THREE.Vector3;for(b=0;b<this.segmentsR;++b){this.grid[b]=Array(this.segmentsT);for(c=0;c<
this.segmentsT;++c){var o=b/this.segmentsR*2*this.p*Math.PI,h=c/this.segmentsT*2*Math.PI,g=k(o,h,this.q,this.p,this.radius,this.heightScale),o=k(o+0.01,h,this.q,this.p,this.radius,this.heightScale);e.x=o.x-g.x;e.y=o.y-g.y;e.z=o.z-g.z;f.x=o.x+g.x;f.y=o.y+g.y;f.z=o.z+g.z;j.cross(e,f);f.cross(j,e);j.normalize();f.normalize();o=-this.tube*Math.cos(h);h=this.tube*Math.sin(h);g.x+=o*f.x+h*j.x;g.y+=o*f.y+h*j.y;g.z+=o*f.z+h*j.z;this.grid[b][c]=this.vertices.push(new THREE.Vertex(new THREE.Vector3(g.x,g.y,
g.z)))-1}}for(b=0;b<this.segmentsR;++b)for(c=0;c<this.segmentsT;++c){var f=(b+1)%this.segmentsR,j=(c+1)%this.segmentsT,g=this.grid[b][c],e=this.grid[f][c],f=this.grid[f][j],j=this.grid[b][j],h=new THREE.UV(b/this.segmentsR,c/this.segmentsT),o=new THREE.UV((b+1)/this.segmentsR,c/this.segmentsT),m=new THREE.UV((b+1)/this.segmentsR,(c+1)/this.segmentsT),p=new THREE.UV(b/this.segmentsR,(c+1)/this.segmentsT);this.faces.push(new THREE.Face4(g,e,f,j));this.faceVertexUvs[0].push([h,o,m,p])}this.computeCentroids();
this.computeFaceNormals();this.computeVertexNormals()};THREE.TorusKnotGeometry.prototype=new THREE.Geometry;THREE.TorusKnotGeometry.prototype.constructor=THREE.TorusKnotGeometry;THREE.Loader=function(b){this.statusDomElement=(this.showStatus=b)?THREE.Loader.prototype.addStatusElement():null;this.onLoadStart=function(){};this.onLoadProgress=function(){};this.onLoadComplete=function(){}};
THREE.Loader.prototype={addStatusElement:function(){var b=document.createElement("div");b.style.position="absolute";b.style.right="0px";b.style.top="0px";b.style.fontSize="0.8em";b.style.textAlign="left";b.style.background="rgba(0,0,0,0.25)";b.style.color="#fff";b.style.width="120px";b.style.padding="0.5em 0.5em 0.5em 0.5em";b.style.zIndex=1E3;b.innerHTML="Loading ...";return b},updateProgress:function(b){var c="Loaded ";c+=b.total?(100*b.loaded/b.total).toFixed(0)+"%":(b.loaded/1E3).toFixed(2)+" KB";
this.statusDomElement.innerHTML=c},extractUrlbase:function(b){b=b.split("/");b.pop();return b.join("/")},init_materials:function(b,c,e){b.materials=[];for(var f=0;f<c.length;++f)b.materials[f]=[THREE.Loader.prototype.createMaterial(c[f],e)]},hasNormals:function(b){var c,e,f=b.materials.length;for(e=0;e<f;e++)if(c=b.materials[e][0],c instanceof THREE.MeshShaderMaterial)return!0;return!1},createMaterial:function(b,c){function e(b){b=Math.log(b)/Math.LN2;return Math.floor(b)==b}function f(b,c){var f=
new Image;f.onload=function(){if(!e(this.width)||!e(this.height)){var c=Math.pow(2,Math.round(Math.log(this.width)/Math.LN2)),f=Math.pow(2,Math.round(Math.log(this.height)/Math.LN2));b.image.width=c;b.image.height=f;b.image.getContext("2d").drawImage(this,0,0,c,f)}else b.image=this;b.needsUpdate=!0};f.src=c}function g(b,e,g,h,j,k){var m=document.createElement("canvas");b[e]=new THREE.Texture(m);b[e].sourceFile=g;if(h){b[e].repeat.set(h[0],h[1]);if(h[0]!=1)b[e].wrapS=THREE.RepeatWrapping;if(h[1]!=
1)b[e].wrapT=THREE.RepeatWrapping}j&&b[e].offset.set(j[0],j[1]);if(k){h={repeat:THREE.RepeatWrapping,mirror:THREE.MirroredRepeatWrapping};if(h[k[0]]!==void 0)b[e].wrapS=h[k[0]];if(h[k[1]]!==void 0)b[e].wrapT=h[k[1]]}f(b[e],c+"/"+g)}function j(b){return(b[0]*255<<16)+(b[1]*255<<8)+b[2]*255}var h,k,o;k="MeshLambertMaterial";h={color:15658734,opacity:1,map:null,lightMap:null,normalMap:null,wireframe:b.wireframe};b.shading&&(b.shading=="Phong"?k="MeshPhongMaterial":b.shading=="Basic"&&(k="MeshBasicMaterial"));
if(b.blending)if(b.blending=="Additive")h.blending=THREE.AdditiveBlending;else if(b.blending=="Subtractive")h.blending=THREE.SubtractiveBlending;else if(b.blending=="Multiply")h.blending=THREE.MultiplyBlending;if(b.transparent!==void 0||b.opacity<1)h.transparent=b.transparent;if(b.depthTest!==void 0)h.depthTest=b.depthTest;if(b.vertexColors!==void 0)if(b.vertexColors=="face")h.vertexColors=THREE.FaceColors;else if(b.vertexColors)h.vertexColors=THREE.VertexColors;if(b.colorDiffuse)h.color=j(b.colorDiffuse);
else if(b.DbgColor)h.color=b.DbgColor;if(b.colorSpecular)h.specular=j(b.colorSpecular);if(b.colorAmbient)h.ambient=j(b.colorAmbient);if(b.transparency)h.opacity=b.transparency;if(b.specularCoef)h.shininess=b.specularCoef;b.mapDiffuse&&c&&g(h,"map",b.mapDiffuse,b.mapDiffuseRepeat,b.mapDiffuseOffset,b.mapDiffuseWrap);b.mapLight&&c&&g(h,"lightMap",b.mapLight,b.mapLightRepeat,b.mapLightOffset,b.mapLightWrap);b.mapNormal&&c&&g(h,"normalMap",b.mapNormal,b.mapNormalRepeat,b.mapNormalOffset,b.mapNormalWrap);
b.mapSpecular&&c&&g(h,"specularMap",b.mapSpecular,b.mapSpecularRepeat,b.mapSpecularOffset,b.mapSpecularWrap);if(b.mapNormal){var m=THREE.ShaderUtils.lib.normal,p=THREE.UniformsUtils.clone(m.uniforms),u=h.color;k=h.specular;o=h.ambient;var v=h.shininess;p.tNormal.texture=h.normalMap;if(b.mapNormalFactor)p.uNormalScale.value=b.mapNormalFactor;if(h.map)p.tDiffuse.texture=h.map,p.enableDiffuse.value=!0;if(h.specularMap)p.tSpecular.texture=h.specularMap,p.enableSpecular.value=!0;if(h.lightMap)p.tAO.texture=
h.lightMap,p.enableAO.value=!0;p.uDiffuseColor.value.setHex(u);p.uSpecularColor.value.setHex(k);p.uAmbientColor.value.setHex(o);p.uShininess.value=v;if(h.opacity)p.uOpacity.value=h.opacity;h=new THREE.MeshShaderMaterial({fragmentShader:m.fragmentShader,vertexShader:m.vertexShader,uniforms:p,lights:!0,fog:!0})}else h=new THREE[k](h);return h},constructor:THREE.Loader};THREE.JSONLoader=function(b){THREE.Loader.call(this,b)};THREE.JSONLoader.prototype=new THREE.Loader;
THREE.JSONLoader.prototype.constructor=THREE.JSONLoader;THREE.JSONLoader.prototype.supr=THREE.Loader.prototype;THREE.JSONLoader.prototype.load=function(b){var c=this,e=b.model,f=b.callback,g=b.texture_path?b.texture_path:this.extractUrlbase(e),b=new Worker(e);b.onmessage=function(b){c.createModel(b.data,f,g);c.onLoadComplete()};this.onLoadStart();b.postMessage((new Date).getTime())};
THREE.JSONLoader.prototype.createModel=function(b,c,e){var f=new THREE.Geometry,g=b.scale!==void 0?1/b.scale:1;this.init_materials(f,b.materials,e);(function(c){if(b.version===void 0||b.version!=2)console.error("Deprecated file format.");else{var e,g,o,m,p,u,v,t,w,x,B,A,H,y,G=b.faces;u=b.vertices;var I=b.normals,E=b.colors,K=0;for(e=0;e<b.uvs.length;e++)b.uvs[e].length&&K++;for(e=0;e<K;e++)f.faceUvs[e]=[],f.faceVertexUvs[e]=[];m=0;for(p=u.length;m<p;)v=new THREE.Vertex,v.position.x=u[m++]*c,v.position.y=
u[m++]*c,v.position.z=u[m++]*c,f.vertices.push(v);m=0;for(p=G.length;m<p;){c=G[m++];u=c&1;o=c&2;e=c&4;g=c&8;t=c&16;v=c&32;x=c&64;c&=128;u?(B=new THREE.Face4,B.a=G[m++],B.b=G[m++],B.c=G[m++],B.d=G[m++],u=4):(B=new THREE.Face3,B.a=G[m++],B.b=G[m++],B.c=G[m++],u=3);if(o)o=G[m++],B.materials=f.materials[o];o=f.faces.length;if(e)for(e=0;e<K;e++)A=b.uvs[e],w=G[m++],y=A[w*2],w=A[w*2+1],f.faceUvs[e][o]=new THREE.UV(y,w);if(g)for(e=0;e<K;e++){A=b.uvs[e];H=[];for(g=0;g<u;g++)w=G[m++],y=A[w*2],w=A[w*2+1],H[g]=
new THREE.UV(y,w);f.faceVertexUvs[e][o]=H}if(t)t=G[m++]*3,g=new THREE.Vector3,g.x=I[t++],g.y=I[t++],g.z=I[t],B.normal=g;if(v)for(e=0;e<u;e++)t=G[m++]*3,g=new THREE.Vector3,g.x=I[t++],g.y=I[t++],g.z=I[t],B.vertexNormals.push(g);if(x)v=G[m++],v=new THREE.Color(E[v]),B.color=v;if(c)for(e=0;e<u;e++)v=G[m++],v=new THREE.Color(E[v]),B.vertexColors.push(v);f.faces.push(B)}}})(g);(function(){var c,e,g,o;if(b.skinWeights){c=0;for(e=b.skinWeights.length;c<e;c+=2)g=b.skinWeights[c],o=b.skinWeights[c+1],f.skinWeights.push(new THREE.Vector4(g,
o,0,0))}if(b.skinIndices){c=0;for(e=b.skinIndices.length;c<e;c+=2)g=b.skinIndices[c],o=b.skinIndices[c+1],f.skinIndices.push(new THREE.Vector4(g,o,0,0))}f.bones=b.bones;f.animation=b.animation})();(function(c){if(b.morphTargets!==void 0){var e,g,o,m,p,u,v,t,w;e=0;for(g=b.morphTargets.length;e<g;e++){f.morphTargets[e]={};f.morphTargets[e].name=b.morphTargets[e].name;f.morphTargets[e].vertices=[];t=f.morphTargets[e].vertices;w=b.morphTargets[e].vertices;o=0;for(m=w.length;o<m;o+=3)p=w[o]*c,u=w[o+1]*
c,v=w[o+2]*c,t.push(new THREE.Vertex(new THREE.Vector3(p,u,v)))}}if(b.morphColors!==void 0){e=0;for(g=b.morphColors.length;e<g;e++){f.morphColors[e]={};f.morphColors[e].name=b.morphColors[e].name;f.morphColors[e].colors=[];m=f.morphColors[e].colors;p=b.morphColors[e].colors;c=0;for(o=p.length;c<o;c+=3)u=new THREE.Color(16755200),u.setRGB(p[c],p[c+1],p[c+2]),m.push(u)}}})(g);(function(){if(b.edges!==void 0){var c,e,g;for(c=0;c<b.edges.length;c+=2)e=b.edges[c],g=b.edges[c+1],f.edges.push(new THREE.Edge(f.vertices[e],
f.vertices[g],e,g))}})();f.computeCentroids();f.computeFaceNormals();this.hasNormals(f)&&f.computeTangents();c(f)};THREE.BinaryLoader=function(b){THREE.Loader.call(this,b)};THREE.BinaryLoader.prototype=new THREE.Loader;THREE.BinaryLoader.prototype.constructor=THREE.BinaryLoader;THREE.BinaryLoader.prototype.supr=THREE.Loader.prototype;
THREE.BinaryLoader.prototype={load:function(b){var c=b.model,e=b.callback,f=b.texture_path?b.texture_path:THREE.Loader.prototype.extractUrlbase(c),g=b.bin_path?b.bin_path:THREE.Loader.prototype.extractUrlbase(c),b=(new Date).getTime(),c=new Worker(c),j=this.showProgress?THREE.Loader.prototype.updateProgress:null;c.onmessage=function(b){THREE.BinaryLoader.prototype.loadAjaxBuffers(b.data.buffers,b.data.materials,e,g,f,j)};c.onerror=function(b){alert("worker.onerror: "+b.message+"\n"+b.data);b.preventDefault()};
c.postMessage(b)},loadAjaxBuffers:function(b,c,e,f,g,j){var h=new XMLHttpRequest,k=f+"/"+b,o=0;h.onreadystatechange=function(){h.readyState==4?h.status==200||h.status==0?THREE.BinaryLoader.prototype.createBinModel(h.responseText,e,g,c):alert("Couldn't load ["+k+"] ["+h.status+"]"):h.readyState==3?j&&(o==0&&(o=h.getResponseHeader("Content-Length")),j({total:o,loaded:h.responseText.length})):h.readyState==2&&(o=h.getResponseHeader("Content-Length"))};h.open("GET",k,!0);h.overrideMimeType("text/plain; charset=x-user-defined");
h.setRequestHeader("Content-Type","text/plain");h.send(null)},createBinModel:function(b,c,e,f){var g=function(c){function e(b,c){var f=p(b,c),g=p(b,c+1),h=p(b,c+2),j=p(b,c+3),k=(j<<1&255|h>>7)-127;f|=(h&127)<<16|g<<8;if(f==0&&k==-127)return 0;return(1-2*(j>>7))*(1+f*Math.pow(2,-23))*Math.pow(2,k)}function g(b,c){var e=p(b,c),f=p(b,c+1),h=p(b,c+2);return(p(b,c+3)<<24)+(h<<16)+(f<<8)+e}function o(b,c){var e=p(b,c);return(p(b,c+1)<<8)+e}function m(b,c){var e=p(b,c);return e>127?e-256:e}function p(b,
c){return b.charCodeAt(c)&255}function u(c){var e,f,h;e=g(b,c);f=g(b,c+E);h=g(b,c+K);c=o(b,c+D);THREE.BinaryLoader.prototype.f3(A,e,f,h,c)}function v(c){var e,f,h,j,m,n;e=g(b,c);f=g(b,c+E);h=g(b,c+K);j=o(b,c+D);m=g(b,c+J);n=g(b,c+S);c=g(b,c+X);THREE.BinaryLoader.prototype.f3n(A,G,e,f,h,j,m,n,c)}function t(c){var e,f,h,j;e=g(b,c);f=g(b,c+R);h=g(b,c+C);j=g(b,c+n);c=o(b,c+W);THREE.BinaryLoader.prototype.f4(A,e,f,h,j,c)}function w(c){var e,f,h,j,m,p,t,u;e=g(b,c);f=g(b,c+R);h=g(b,c+C);j=g(b,c+n);m=o(b,
c+W);p=g(b,c+V);t=g(b,c+fa);u=g(b,c+L);c=g(b,c+ea);THREE.BinaryLoader.prototype.f4n(A,G,e,f,h,j,m,p,t,u,c)}function x(c){var e,f;e=g(b,c);f=g(b,c+T);c=g(b,c+U);THREE.BinaryLoader.prototype.uv3(A.faceVertexUvs[0],I[e*2],I[e*2+1],I[f*2],I[f*2+1],I[c*2],I[c*2+1])}function B(c){var e,f,h;e=g(b,c);f=g(b,c+da);h=g(b,c+ha);c=g(b,c+ia);THREE.BinaryLoader.prototype.uv4(A.faceVertexUvs[0],I[e*2],I[e*2+1],I[f*2],I[f*2+1],I[h*2],I[h*2+1],I[c*2],I[c*2+1])}var A=this,H=0,y,G=[],I=[],E,K,D,J,S,X,R,C,n,W,V,fa,L,
ea,T,U,da,ha,ia,M,P,aa,Y,Z,ca;THREE.Geometry.call(this);THREE.Loader.prototype.init_materials(A,f,c);y={signature:b.substr(H,8),header_bytes:p(b,H+8),vertex_coordinate_bytes:p(b,H+9),normal_coordinate_bytes:p(b,H+10),uv_coordinate_bytes:p(b,H+11),vertex_index_bytes:p(b,H+12),normal_index_bytes:p(b,H+13),uv_index_bytes:p(b,H+14),material_index_bytes:p(b,H+15),nvertices:g(b,H+16),nnormals:g(b,H+16+4),nuvs:g(b,H+16+8),ntri_flat:g(b,H+16+12),ntri_smooth:g(b,H+16+16),ntri_flat_uv:g(b,H+16+20),ntri_smooth_uv:g(b,
H+16+24),nquad_flat:g(b,H+16+28),nquad_smooth:g(b,H+16+32),nquad_flat_uv:g(b,H+16+36),nquad_smooth_uv:g(b,H+16+40)};H+=y.header_bytes;E=y.vertex_index_bytes;K=y.vertex_index_bytes*2;D=y.vertex_index_bytes*3;J=y.vertex_index_bytes*3+y.material_index_bytes;S=y.vertex_index_bytes*3+y.material_index_bytes+y.normal_index_bytes;X=y.vertex_index_bytes*3+y.material_index_bytes+y.normal_index_bytes*2;R=y.vertex_index_bytes;C=y.vertex_index_bytes*2;n=y.vertex_index_bytes*3;W=y.vertex_index_bytes*4;V=y.vertex_index_bytes*
4+y.material_index_bytes;fa=y.vertex_index_bytes*4+y.material_index_bytes+y.normal_index_bytes;L=y.vertex_index_bytes*4+y.material_index_bytes+y.normal_index_bytes*2;ea=y.vertex_index_bytes*4+y.material_index_bytes+y.normal_index_bytes*3;T=y.uv_index_bytes;U=y.uv_index_bytes*2;da=y.uv_index_bytes;ha=y.uv_index_bytes*2;ia=y.uv_index_bytes*3;c=y.vertex_index_bytes*3+y.material_index_bytes;ca=y.vertex_index_bytes*4+y.material_index_bytes;M=y.ntri_flat*c;P=y.ntri_smooth*(c+y.normal_index_bytes*3);aa=
y.ntri_flat_uv*(c+y.uv_index_bytes*3);Y=y.ntri_smooth_uv*(c+y.normal_index_bytes*3+y.uv_index_bytes*3);Z=y.nquad_flat*ca;c=y.nquad_smooth*(ca+y.normal_index_bytes*4);ca=y.nquad_flat_uv*(ca+y.uv_index_bytes*4);H+=function(c){for(var f,g,j,k=y.vertex_coordinate_bytes*3,m=c+y.nvertices*k;c<m;c+=k)f=e(b,c),g=e(b,c+y.vertex_coordinate_bytes),j=e(b,c+y.vertex_coordinate_bytes*2),THREE.BinaryLoader.prototype.v(A,f,g,j);return y.nvertices*k}(H);H+=function(c){for(var e,f,g,h=y.normal_coordinate_bytes*3,j=
c+y.nnormals*h;c<j;c+=h)e=m(b,c),f=m(b,c+y.normal_coordinate_bytes),g=m(b,c+y.normal_coordinate_bytes*2),G.push(e/127,f/127,g/127);return y.nnormals*h}(H);H+=function(c){for(var f,g,j=y.uv_coordinate_bytes*2,k=c+y.nuvs*j;c<k;c+=j)f=e(b,c),g=e(b,c+y.uv_coordinate_bytes),I.push(f,g);return y.nuvs*j}(H);M=H+M;P=M+P;aa=P+aa;Y=aa+Y;Z=Y+Z;c=Z+c;ca=c+ca;(function(b){var c,e=y.vertex_index_bytes*3+y.material_index_bytes,f=e+y.uv_index_bytes*3,g=b+y.ntri_flat_uv*f;for(c=b;c<g;c+=f)u(c),x(c+e);return g-b})(P);
(function(b){var c,e=y.vertex_index_bytes*3+y.material_index_bytes+y.normal_index_bytes*3,f=e+y.uv_index_bytes*3,g=b+y.ntri_smooth_uv*f;for(c=b;c<g;c+=f)v(c),x(c+e);return g-b})(aa);(function(b){var c,e=y.vertex_index_bytes*4+y.material_index_bytes,f=e+y.uv_index_bytes*4,g=b+y.nquad_flat_uv*f;for(c=b;c<g;c+=f)t(c),B(c+e);return g-b})(c);(function(b){var c,e=y.vertex_index_bytes*4+y.material_index_bytes+y.normal_index_bytes*4,f=e+y.uv_index_bytes*4,g=b+y.nquad_smooth_uv*f;for(c=b;c<g;c+=f)w(c),B(c+
e);return g-b})(ca);(function(b){var c,e=y.vertex_index_bytes*3+y.material_index_bytes,f=b+y.ntri_flat*e;for(c=b;c<f;c+=e)u(c);return f-b})(H);(function(b){var c,e=y.vertex_index_bytes*3+y.material_index_bytes+y.normal_index_bytes*3,f=b+y.ntri_smooth*e;for(c=b;c<f;c+=e)v(c);return f-b})(M);(function(b){var c,e=y.vertex_index_bytes*4+y.material_index_bytes,f=b+y.nquad_flat*e;for(c=b;c<f;c+=e)t(c);return f-b})(Y);(function(b){var c,e=y.vertex_index_bytes*4+y.material_index_bytes+y.normal_index_bytes*
4,f=b+y.nquad_smooth*e;for(c=b;c<f;c+=e)w(c);return f-b})(Z);this.computeCentroids();this.computeFaceNormals();THREE.Loader.prototype.hasNormals(this)&&this.computeTangents()};g.prototype=new THREE.Geometry;g.prototype.constructor=g;c(new g(e))},v:function(b,c,e,f){b.vertices.push(new THREE.Vertex(new THREE.Vector3(c,e,f)))},f3:function(b,c,e,f,g){b.faces.push(new THREE.Face3(c,e,f,null,null,b.materials[g]))},f4:function(b,c,e,f,g,j){b.faces.push(new THREE.Face4(c,e,f,g,null,null,b.materials[j]))},
f3n:function(b,c,e,f,g,j,h,k,o){var j=b.materials[j],m=c[k*3],p=c[k*3+1],k=c[k*3+2],u=c[o*3],v=c[o*3+1],o=c[o*3+2];b.faces.push(new THREE.Face3(e,f,g,[new THREE.Vector3(c[h*3],c[h*3+1],c[h*3+2]),new THREE.Vector3(m,p,k),new THREE.Vector3(u,v,o)],null,j))},f4n:function(b,c,e,f,g,j,h,k,o,m,p){var h=b.materials[h],u=c[o*3],v=c[o*3+1],o=c[o*3+2],t=c[m*3],w=c[m*3+1],m=c[m*3+2],x=c[p*3],B=c[p*3+1],p=c[p*3+2];b.faces.push(new THREE.Face4(e,f,g,j,[new THREE.Vector3(c[k*3],c[k*3+1],c[k*3+2]),new THREE.Vector3(u,
v,o),new THREE.Vector3(t,w,m),new THREE.Vector3(x,B,p)],null,h))},uv3:function(b,c,e,f,g,j,h){var k=[];k.push(new THREE.UV(c,e));k.push(new THREE.UV(f,g));k.push(new THREE.UV(j,h));b.push(k)},uv4:function(b,c,e,f,g,j,h,k,o){var m=[];m.push(new THREE.UV(c,e));m.push(new THREE.UV(f,g));m.push(new THREE.UV(j,h));m.push(new THREE.UV(k,o));b.push(m)},constructor:THREE.BinaryLoader};
THREE.SceneLoader=function(){this.onLoadStart=function(){};this.onLoadProgress=function(){};this.onLoadComplete=function(){};this.callbackSync=function(){};this.callbackProgress=function(){}};
THREE.SceneLoader.prototype={load:function(b,c){var e=this,f=new Worker(b);f.postMessage(0);var g=THREE.Loader.prototype.extractUrlbase(b);f.onmessage=function(b){function f(b,c){return c=="relativeToHTML"?b:g+"/"+b}function k(){for(t in R.objects)if(!L.objects[t])if(H=R.objects[t],H.geometry!==void 0){if(E=L.geometries[H.geometry]){var b=!1;S=[];for(T=0;T<H.materials.length;T++)S[T]=L.materials[H.materials[T]],b=S[T]instanceof THREE.MeshShaderMaterial;b&&E.computeTangents();y=H.position;r=H.rotation;
q=H.quaternion;s=H.scale;q=0;S.length==0&&(S[0]=new THREE.MeshFaceMaterial);S.length>1&&(S=[new THREE.MeshFaceMaterial]);object=new THREE.Mesh(E,S);object.name=t;object.position.set(y[0],y[1],y[2]);q?(object.quaternion.set(q[0],q[1],q[2],q[3]),object.useQuaternion=!0):object.rotation.set(r[0],r[1],r[2]);object.scale.set(s[0],s[1],s[2]);object.visible=H.visible;L.scene.addObject(object);L.objects[t]=object;H.meshCollider&&(b=THREE.CollisionUtils.MeshColliderWBox(object),L.scene.collisions.colliders.push(b));
if(H.castsShadow)b=new THREE.ShadowVolume(E),L.scene.addChild(b),b.position=object.position,b.rotation=object.rotation,b.scale=object.scale;H.trigger&&H.trigger.toLowerCase()!="none"&&(b={type:H.trigger,object:H},L.triggers[object.name]=b)}}else y=H.position,r=H.rotation,q=H.quaternion,s=H.scale,q=0,object=new THREE.Object3D,object.name=t,object.position.set(y[0],y[1],y[2]),q?(object.quaternion.set(q[0],q[1],q[2],q[3]),object.useQuaternion=!0):object.rotation.set(r[0],r[1],r[2]),object.scale.set(s[0],
s[1],s[2]),object.visible=H.visible!==void 0?H.visible:!1,L.scene.addObject(object),L.objects[t]=object,L.empties[t]=object,H.trigger&&H.trigger.toLowerCase()!="none"&&(b={type:H.trigger,object:H},L.triggers[object.name]=b)}function o(b){return function(c){L.geometries[b]=c;k();n-=1;e.onLoadComplete();p()}}function m(b){return function(c){L.geometries[b]=c}}function p(){e.callbackProgress({totalModels:V,totalTextures:fa,loadedModels:V-n,loadedTextures:fa-W},L);e.onLoadProgress();n==0&&W==0&&c(L)}
var u,v,t,w,x,B,A,H,y,G,I,E,K,D,J,S,X,R,C,n,W,V,fa,L;R=b.data;J=new THREE.BinaryLoader;C=new THREE.JSONLoader;W=n=0;L={scene:new THREE.Scene,geometries:{},materials:{},textures:{},objects:{},cameras:{},lights:{},fogs:{},triggers:{},empties:{}};b=!1;for(t in R.objects)if(H=R.objects[t],H.meshCollider){b=!0;break}if(b)L.scene.collisions=new THREE.CollisionSystem;if(R.transform){b=R.transform.position;G=R.transform.rotation;var ea=R.transform.scale;b&&L.scene.position.set(b[0],b[1],b[2]);G&&L.scene.rotation.set(G[0],
G[1],G[2]);ea&&L.scene.scale.set(ea[0],ea[1],ea[2]);(b||G||ea)&&L.scene.updateMatrix()}b=function(){W-=1;p();e.onLoadComplete()};for(x in R.cameras){G=R.cameras[x];if(G.type=="perspective")K=new THREE.Camera(G.fov,G.aspect,G.near,G.far);else if(G.type=="ortho")K=new THREE.Camera,K.projectionMatrix=THREE.Matrix4.makeOrtho(G.left,G.right,G.top,G.bottom,G.near,G.far);y=G.position;G=G.target;K.position.set(y[0],y[1],y[2]);K.target.position.set(G[0],G[1],G[2]);L.cameras[x]=K}for(w in R.lights)x=R.lights[w],
K=x.color!==void 0?x.color:16777215,G=x.intensity!==void 0?x.intensity:1,x.type=="directional"?(y=x.direction,X=new THREE.DirectionalLight(K,G),X.position.set(y[0],y[1],y[2]),X.position.normalize()):x.type=="point"?(y=x.position,d=x.distance,X=new THREE.PointLight(K,G,d),X.position.set(y[0],y[1],y[2])):x.type=="ambient"&&(X=new THREE.AmbientLight(K)),L.scene.addLight(X),L.lights[w]=X;for(B in R.fogs)w=R.fogs[B],w.type=="linear"?D=new THREE.Fog(0,w.near,w.far):w.type=="exp2"&&(D=new THREE.FogExp2(0,
w.density)),G=w.color,D.color.setRGB(G[0],G[1],G[2]),L.fogs[B]=D;if(L.cameras&&R.defaults.camera)L.currentCamera=L.cameras[R.defaults.camera];if(L.fogs&&R.defaults.fog)L.scene.fog=L.fogs[R.defaults.fog];G=R.defaults.bgcolor;L.bgColor=new THREE.Color;L.bgColor.setRGB(G[0],G[1],G[2]);L.bgColorAlpha=R.defaults.bgalpha;for(u in R.geometries)if(B=R.geometries[u],B.type=="bin_mesh"||B.type=="ascii_mesh")n+=1,e.onLoadStart();V=n;for(u in R.geometries)B=R.geometries[u],B.type=="cube"?(E=new THREE.CubeGeometry(B.width,
B.height,B.depth,B.segmentsWidth,B.segmentsHeight,B.segmentsDepth,null,B.flipped,B.sides),L.geometries[u]=E):B.type=="plane"?(E=new THREE.PlaneGeometry(B.width,B.height,B.segmentsWidth,B.segmentsHeight),L.geometries[u]=E):B.type=="sphere"?(E=new THREE.SphereGeometry(B.radius,B.segmentsWidth,B.segmentsHeight),L.geometries[u]=E):B.type=="cylinder"?(E=new THREE.CylinderGeometry(B.numSegs,B.topRad,B.botRad,B.height,B.topOffset,B.botOffset),L.geometries[u]=E):B.type=="torus"?(E=new THREE.TorusGeometry(B.radius,
B.tube,B.segmentsR,B.segmentsT),L.geometries[u]=E):B.type=="icosahedron"?(E=new THREE.IcosahedronGeometry(B.subdivisions),L.geometries[u]=E):B.type=="bin_mesh"?J.load({model:f(B.url,R.urlBaseType),callback:o(u)}):B.type=="ascii_mesh"?C.load({model:f(B.url,R.urlBaseType),callback:o(u)}):B.type=="embedded_mesh"&&(B=R.embeds[B.id])&&C.createModel(B,m(u),"");for(A in R.textures)if(u=R.textures[A],u.url instanceof Array){W+=u.url.length;for(J=0;J<u.url.length;J++)e.onLoadStart()}else W+=1,e.onLoadStart();
fa=W;for(A in R.textures){u=R.textures[A];if(u.mapping!=void 0&&THREE[u.mapping]!=void 0)u.mapping=new THREE[u.mapping];if(u.url instanceof Array){J=[];for(var T=0;T<u.url.length;T++)J[T]=f(u.url[T],R.urlBaseType);J=THREE.ImageUtils.loadTextureCube(J,u.mapping,b)}else{J=THREE.ImageUtils.loadTexture(f(u.url,R.urlBaseType),u.mapping,b);if(THREE[u.minFilter]!=void 0)J.minFilter=THREE[u.minFilter];if(THREE[u.magFilter]!=void 0)J.magFilter=THREE[u.magFilter];if(u.repeat){J.repeat.set(u.repeat[0],u.repeat[1]);
if(u.repeat[0]!=1)J.wrapS=THREE.RepeatWrapping;if(u.repeat[1]!=1)J.wrapT=THREE.RepeatWrapping}u.offset&&J.offset.set(u.offset[0],u.offset[1]);if(u.wrap){C={repeat:THREE.RepeatWrapping,mirror:THREE.MirroredRepeatWrapping};if(C[u.wrap[0]]!==void 0)J.wrapS=C[u.wrap[0]];if(C[u.wrap[1]]!==void 0)J.wrapT=C[u.wrap[1]]}}L.textures[A]=J}for(v in R.materials){A=R.materials[v];for(I in A.parameters)if(I=="envMap"||I=="map"||I=="lightMap")A.parameters[I]=L.textures[A.parameters[I]];else if(I=="shading")A.parameters[I]=
A.parameters[I]=="flat"?THREE.FlatShading:THREE.SmoothShading;else if(I=="blending")A.parameters[I]=THREE[A.parameters[I]]?THREE[A.parameters[I]]:THREE.NormalBlending;else if(I=="combine")A.parameters[I]=A.parameters[I]=="MixOperation"?THREE.MixOperation:THREE.MultiplyOperation;else if(I=="vertexColors")if(A.parameters[I]=="face")A.parameters[I]=THREE.FaceColors;else if(A.parameters[I])A.parameters[I]=THREE.VertexColors;if(A.parameters.opacity!==void 0&&A.parameters.opacity<1)A.parameters.transparent=
!0;if(A.parameters.normalMap){u=THREE.ShaderUtils.lib.normal;b=THREE.UniformsUtils.clone(u.uniforms);J=A.parameters.color;C=A.parameters.specular;B=A.parameters.ambient;D=A.parameters.shininess;b.tNormal.texture=L.textures[A.parameters.normalMap];if(A.parameters.normalMapFactor)b.uNormalScale.value=A.parameters.normalMapFactor;if(A.parameters.map)b.tDiffuse.texture=A.parameters.map,b.enableDiffuse.value=!0;if(A.parameters.lightMap)b.tAO.texture=A.parameters.lightMap,b.enableAO.value=!0;if(A.parameters.specularMap)b.tSpecular.texture=
L.textures[A.parameters.specularMap],b.enableSpecular.value=!0;b.uDiffuseColor.value.setHex(J);b.uSpecularColor.value.setHex(C);b.uAmbientColor.value.setHex(B);b.uShininess.value=D;if(A.parameters.opacity)b.uOpacity.value=A.parameters.opacity;A=new THREE.MeshShaderMaterial({fragmentShader:u.fragmentShader,vertexShader:u.vertexShader,uniforms:b,lights:!0,fog:!0})}else A=new THREE[A.type](A.parameters);L.materials[v]=A}k();e.callbackSync(L)}},constructor:THREE.SceneLoader};THREE.UTF8Loader=function(){};
THREE.UTF8Loader.prototype=new THREE.UTF8Loader;THREE.UTF8Loader.prototype.constructor=THREE.UTF8Loader;
THREE.UTF8Loader.prototype={load:function(b){var c=new XMLHttpRequest,e=b.model,f=b.callback,g=b.scale!==void 0?b.scale:1,j=b.offsetX!==void 0?b.offsetX:0,h=b.offsetY!==void 0?b.offsetY:0,k=b.offsetZ!==void 0?b.offsetZ:0;c.onreadystatechange=function(){c.readyState==4?c.status==200||c.status==0?THREE.UTF8Loader.prototype.createModel(c.responseText,f,g,j,h,k):alert("Couldn't load ["+e+"] ["+c.status+"]"):c.readyState!=3&&c.readyState==2&&c.getResponseHeader("Content-Length")};c.open("GET",e,!0);c.send(null)},
decompressMesh:function(b){var c=b.charCodeAt(0);c>=57344&&(c-=2048);c++;for(var e=new Float32Array(8*c),f=1,g=0;g<8;g++){for(var j=0,h=0;h<c;++h){var k=b.charCodeAt(h+f);j+=k>>1^-(k&1);e[8*h+g]=j}f+=c}c=b.length-f;j=new Uint16Array(c);for(g=h=0;g<c;g++)k=b.charCodeAt(g+f),j[g]=h-k,k==0&&h++;return[e,j]},createModel:function(b,c,e,f,g,j){var h=function(){var c=this;c.materials=[];THREE.Geometry.call(this);var h=THREE.UTF8Loader.prototype.decompressMesh(b),m=[],p=[];(function(b,h,m){for(var o,p,B,
A=b.length;m<A;m+=h)o=b[m],p=b[m+1],B=b[m+2],o=o/16383*e,p=p/16383*e,B=B/16383*e,o+=f,p+=g,B+=j,THREE.UTF8Loader.prototype.v(c,o,p,B)})(h[0],8,0);(function(b,c,e){for(var f,g,h=b.length;e<h;e+=c)f=b[e],g=b[e+1],f/=1023,g/=1023,p.push(f,g)})(h[0],8,3);(function(b,c,e){for(var f,g,h,j=b.length;e<j;e+=c)f=b[e],g=b[e+1],h=b[e+2],f=(f-512)/511,g=(g-512)/511,h=(h-512)/511,m.push(f,g,h)})(h[0],8,5);(function(b){var e,f,g,h,j,o,H,y=b.length;for(e=0;e<y;e+=3)f=b[e],g=b[e+1],h=b[e+2],THREE.UTF8Loader.prototype.f3n(c,
m,f,g,h,0,f,g,h),j=p[f*2],f=p[f*2+1],o=p[g*2],g=p[g*2+1],H=p[h*2],h=p[h*2+1],THREE.UTF8Loader.prototype.uv3(c.faceVertexUvs[0],j,f,o,g,H,h)})(h[1]);this.computeCentroids();this.computeFaceNormals()};h.prototype=new THREE.Geometry;h.prototype.constructor=h;c(new h)},v:function(b,c,e,f){b.vertices.push(new THREE.Vertex(new THREE.Vector3(c,e,f)))},f3n:function(b,c,e,f,g,j,h,k,o){var j=b.materials[j],m=c[k*3],p=c[k*3+1],k=c[k*3+2],u=c[o*3],v=c[o*3+1],o=c[o*3+2],h=new THREE.Vector3(c[h*3],c[h*3+1],c[h*
3+2]),k=new THREE.Vector3(m,p,k),o=new THREE.Vector3(u,v,o);b.faces.push(new THREE.Face3(e,f,g,[h,k,o],null,j))},uv3:function(b,c,e,f,g,j,h){var k=[];k.push(new THREE.UV(c,e));k.push(new THREE.UV(f,g));k.push(new THREE.UV(j,h));b.push(k)},constructor:THREE.UTF8Loader};
THREE.MarchingCubes=function(b,c){THREE.Object3D.call(this);this.materials=c instanceof Array?c:[c];this.init=function(b){this.isolation=80;this.size=b;this.size2=this.size*this.size;this.size3=this.size2*this.size;this.halfsize=this.size/2;this.delta=2/this.size;this.yd=this.size;this.zd=this.size2;this.field=new Float32Array(this.size3);this.normal_cache=new Float32Array(this.size3*3);this.vlist=new Float32Array(36);this.nlist=new Float32Array(36);this.firstDraw=!0;this.maxCount=4096;this.count=
0;this.hasNormal=this.hasPos=!1;this.positionArray=new Float32Array(this.maxCount*3);this.normalArray=new Float32Array(this.maxCount*3)};this.lerp=function(b,c,g){return b+(c-b)*g};this.VIntX=function(b,c,g,j,h,k,o,m,p,u){h=(h-p)/(u-p);p=this.normal_cache;c[j]=k+h*this.delta;c[j+1]=o;c[j+2]=m;g[j]=this.lerp(p[b],p[b+3],h);g[j+1]=this.lerp(p[b+1],p[b+4],h);g[j+2]=this.lerp(p[b+2],p[b+5],h)};this.VIntY=function(b,c,g,j,h,k,o,m,p,u){h=(h-p)/(u-p);p=this.normal_cache;c[j]=k;c[j+1]=o+h*this.delta;c[j+
2]=m;c=b+this.yd*3;g[j]=this.lerp(p[b],p[c],h);g[j+1]=this.lerp(p[b+1],p[c+1],h);g[j+2]=this.lerp(p[b+2],p[c+2],h)};this.VIntZ=function(b,c,g,j,h,k,o,m,p,u){h=(h-p)/(u-p);p=this.normal_cache;c[j]=k;c[j+1]=o;c[j+2]=m+h*this.delta;c=b+this.zd*3;g[j]=this.lerp(p[b],p[c],h);g[j+1]=this.lerp(p[b+1],p[c+1],h);g[j+2]=this.lerp(p[b+2],p[c+2],h)};this.compNorm=function(b){var c=b*3;this.normal_cache[c]==0&&(this.normal_cache[c]=this.field[b-1]-this.field[b+1],this.normal_cache[c+1]=this.field[b-this.yd]-this.field[b+
this.yd],this.normal_cache[c+2]=this.field[b-this.zd]-this.field[b+this.zd])};this.polygonize=function(b,c,g,j,h,k){var o=j+1,m=j+this.yd,p=j+this.zd,u=o+this.yd,v=o+this.zd,t=j+this.yd+this.zd,w=o+this.yd+this.zd,x=0,B=this.field[j],A=this.field[o],H=this.field[m],y=this.field[u],G=this.field[p],I=this.field[v],E=this.field[t],K=this.field[w];B<h&&(x|=1);A<h&&(x|=2);H<h&&(x|=8);y<h&&(x|=4);G<h&&(x|=16);I<h&&(x|=32);E<h&&(x|=128);K<h&&(x|=64);var D=THREE.edgeTable[x];if(D==0)return 0;var J=this.delta,
S=b+J,X=c+J,J=g+J;D&1&&(this.compNorm(j),this.compNorm(o),this.VIntX(j*3,this.vlist,this.nlist,0,h,b,c,g,B,A));D&2&&(this.compNorm(o),this.compNorm(u),this.VIntY(o*3,this.vlist,this.nlist,3,h,S,c,g,A,y));D&4&&(this.compNorm(m),this.compNorm(u),this.VIntX(m*3,this.vlist,this.nlist,6,h,b,X,g,H,y));D&8&&(this.compNorm(j),this.compNorm(m),this.VIntY(j*3,this.vlist,this.nlist,9,h,b,c,g,B,H));D&16&&(this.compNorm(p),this.compNorm(v),this.VIntX(p*3,this.vlist,this.nlist,12,h,b,c,J,G,I));D&32&&(this.compNorm(v),
this.compNorm(w),this.VIntY(v*3,this.vlist,this.nlist,15,h,S,c,J,I,K));D&64&&(this.compNorm(t),this.compNorm(w),this.VIntX(t*3,this.vlist,this.nlist,18,h,b,X,J,E,K));D&128&&(this.compNorm(p),this.compNorm(t),this.VIntY(p*3,this.vlist,this.nlist,21,h,b,c,J,G,E));D&256&&(this.compNorm(j),this.compNorm(p),this.VIntZ(j*3,this.vlist,this.nlist,24,h,b,c,g,B,G));D&512&&(this.compNorm(o),this.compNorm(v),this.VIntZ(o*3,this.vlist,this.nlist,27,h,S,c,g,A,I));D&1024&&(this.compNorm(u),this.compNorm(w),this.VIntZ(u*
3,this.vlist,this.nlist,30,h,S,X,g,y,K));D&2048&&(this.compNorm(m),this.compNorm(t),this.VIntZ(m*3,this.vlist,this.nlist,33,h,b,X,g,H,E));x<<=4;for(h=j=0;THREE.triTable[x+h]!=-1;)b=x+h,c=b+1,g=b+2,this.posnormtriv(this.vlist,this.nlist,3*THREE.triTable[b],3*THREE.triTable[c],3*THREE.triTable[g],k),h+=3,j++;return j};this.posnormtriv=function(b,c,g,j,h,k){var o=this.count*3;this.positionArray[o]=b[g];this.positionArray[o+1]=b[g+1];this.positionArray[o+2]=b[g+2];this.positionArray[o+3]=b[j];this.positionArray[o+
4]=b[j+1];this.positionArray[o+5]=b[j+2];this.positionArray[o+6]=b[h];this.positionArray[o+7]=b[h+1];this.positionArray[o+8]=b[h+2];this.normalArray[o]=c[g];this.normalArray[o+1]=c[g+1];this.normalArray[o+2]=c[g+2];this.normalArray[o+3]=c[j];this.normalArray[o+4]=c[j+1];this.normalArray[o+5]=c[j+2];this.normalArray[o+6]=c[h];this.normalArray[o+7]=c[h+1];this.normalArray[o+8]=c[h+2];this.hasNormal=this.hasPos=!0;this.count+=3;this.count>=this.maxCount-3&&k(this)};this.begin=function(){this.count=0;
this.hasNormal=this.hasPos=!1};this.end=function(b){if(this.count!=0){for(var c=this.count*3;c<this.positionArray.length;c++)this.positionArray[c]=0;b(this)}};this.addBall=function(b,c,g,j,h){var k=this.size*Math.sqrt(j/h),o=g*this.size,m=c*this.size,p=b*this.size,u=Math.floor(o-k);u<1&&(u=1);o=Math.floor(o+k);o>this.size-1&&(o=this.size-1);var v=Math.floor(m-k);v<1&&(v=1);m=Math.floor(m+k);m>this.size-1&&(m=this.size-1);var t=Math.floor(p-k);t<1&&(t=1);k=Math.floor(p+k);k>this.size-1&&(k=this.size-
1);for(var w,x,B,A,H,y;u<o;u++){p=this.size2*u;x=u/this.size-g;H=x*x;for(x=v;x<m;x++){B=p+this.size*x;w=x/this.size-c;y=w*w;for(w=t;w<k;w++)A=w/this.size-b,A=j/(1.0E-6+A*A+y+H)-h,A>0&&(this.field[B+w]+=A)}}};this.addPlaneX=function(b,c){var g,j,h,k,o,m=this.size,p=this.yd,u=this.zd,v=this.field,t=m*Math.sqrt(b/c);t>m&&(t=m);for(g=0;g<t;g++)if(j=g/m,j*=j,k=b/(1.0E-4+j)-c,k>0)for(j=0;j<m;j++){o=g+j*p;for(h=0;h<m;h++)v[u*h+o]+=k}};this.addPlaneY=function(b,c){var g,j,h,k,o,m,p=this.size,u=this.yd,v=
this.zd,t=this.field,w=p*Math.sqrt(b/c);w>p&&(w=p);for(j=0;j<w;j++)if(g=j/p,g*=g,k=b/(1.0E-4+g)-c,k>0){o=j*u;for(g=0;g<p;g++){m=o+g;for(h=0;h<p;h++)t[v*h+m]+=k}}};this.addPlaneZ=function(b,c){var g,j,h,k,o,m;size=this.size;yd=this.yd;zd=this.zd;field=this.field;dist=size*Math.sqrt(b/c);dist>size&&(dist=size);for(h=0;h<dist;h++)if(g=h/size,g*=g,k=b/(1.0E-4+g)-c,k>0){o=zd*h;for(j=0;j<size;j++){m=o+j*yd;for(g=0;g<size;g++)field[m+g]+=k}}};this.reset=function(){var b;for(b=0;b<this.size3;b++)this.normal_cache[b*
3]=0,this.field[b]=0};this.render=function(b){this.begin();var c,g,j,h,k,o,m,p,u,v=this.size-2;for(h=1;h<v;h++){u=this.size2*h;m=(h-this.halfsize)/this.halfsize;for(j=1;j<v;j++){p=u+this.size*j;o=(j-this.halfsize)/this.halfsize;for(g=1;g<v;g++)k=(g-this.halfsize)/this.halfsize,c=p+g,this.polygonize(k,o,m,c,this.isolation,b)}}this.end(b)};this.generateGeometry=function(){var b=0,c=new THREE.Geometry,g=[];this.render(function(j){var h,k,o,m,p,u,v,t;for(h=0;h<j.count;h++)v=h*3,p=v+1,t=v+2,k=j.positionArray[v],
o=j.positionArray[p],m=j.positionArray[t],u=new THREE.Vector3(k,o,m),k=j.normalArray[v],o=j.normalArray[p],m=j.normalArray[t],v=new THREE.Vector3(k,o,m),v.normalize(),p=new THREE.Vertex(u),c.vertices.push(p),g.push(v);nfaces=j.count/3;for(h=0;h<nfaces;h++)v=(b+h)*3,p=v+1,t=v+2,u=g[v],k=g[p],o=g[t],v=new THREE.Face3(v,p,t,[u,k,o]),c.faces.push(v);b+=nfaces;j.count=0});return c};this.init(b)};THREE.MarchingCubes.prototype=new THREE.Object3D;THREE.MarchingCubes.prototype.constructor=THREE.MarchingCubes;
THREE.edgeTable=new Int32Array([0,265,515,778,1030,1295,1541,1804,2060,2309,2575,2822,3082,3331,3593,3840,400,153,915,666,1430,1183,1941,1692,2460,2197,2975,2710,3482,3219,3993,3728,560,825,51,314,1590,1855,1077,1340,2620,2869,2111,2358,3642,3891,3129,3376,928,681,419,170,1958,1711,1445,1196,2988,2725,2479,2214,4010,3747,3497,3232,1120,1385,1635,1898,102,367,613,876,3180,3429,3695,3942,2154,2403,2665,2912,1520,1273,2035,1786,502,255,1013,764,3580,3317,4095,3830,2554,2291,3065,2800,1616,1881,1107,
1370,598,863,85,348,3676,3925,3167,3414,2650,2899,2137,2384,1984,1737,1475,1226,966,719,453,204,4044,3781,3535,3270,3018,2755,2505,2240,2240,2505,2755,3018,3270,3535,3781,4044,204,453,719,966,1226,1475,1737,1984,2384,2137,2899,2650,3414,3167,3925,3676,348,85,863,598,1370,1107,1881,1616,2800,3065,2291,2554,3830,4095,3317,3580,764,1013,255,502,1786,2035,1273,1520,2912,2665,2403,2154,3942,3695,3429,3180,876,613,367,102,1898,1635,1385,1120,3232,3497,3747,4010,2214,2479,2725,2988,1196,1445,1711,1958,170,
419,681,928,3376,3129,3891,3642,2358,2111,2869,2620,1340,1077,1855,1590,314,51,825,560,3728,3993,3219,3482,2710,2975,2197,2460,1692,1941,1183,1430,666,915,153,400,3840,3593,3331,3082,2822,2575,2309,2060,1804,1541,1295,1030,778,515,265,0]);
THREE.triTable=new Int32Array([-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,0,8,3,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,0,1,9,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,1,8,3,9,8,1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,1,2,10,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,0,8,3,1,2,10,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,9,2,10,0,2,9,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,2,8,3,2,10,8,10,9,8,-1,-1,-1,-1,-1,-1,-1,3,11,2,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,0,11,2,8,11,0,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,1,9,0,2,3,11,-1,-1,-1,-1,-1,
-1,-1,-1,-1,-1,1,11,2,1,9,11,9,8,11,-1,-1,-1,-1,-1,-1,-1,3,10,1,11,10,3,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,0,10,1,0,8,10,8,11,10,-1,-1,-1,-1,-1,-1,-1,3,9,0,3,11,9,11,10,9,-1,-1,-1,-1,-1,-1,-1,9,8,10,10,8,11,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,4,7,8,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,4,3,0,7,3,4,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,0,1,9,8,4,7,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,4,1,9,4,7,1,7,3,1,-1,-1,-1,-1,-1,-1,-1,1,2,10,8,4,7,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,3,4,7,3,0,4,1,2,10,-1,-1,-1,-1,-1,-1,-1,9,2,10,9,0,2,8,4,7,
-1,-1,-1,-1,-1,-1,-1,2,10,9,2,9,7,2,7,3,7,9,4,-1,-1,-1,-1,8,4,7,3,11,2,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,11,4,7,11,2,4,2,0,4,-1,-1,-1,-1,-1,-1,-1,9,0,1,8,4,7,2,3,11,-1,-1,-1,-1,-1,-1,-1,4,7,11,9,4,11,9,11,2,9,2,1,-1,-1,-1,-1,3,10,1,3,11,10,7,8,4,-1,-1,-1,-1,-1,-1,-1,1,11,10,1,4,11,1,0,4,7,11,4,-1,-1,-1,-1,4,7,8,9,0,11,9,11,10,11,0,3,-1,-1,-1,-1,4,7,11,4,11,9,9,11,10,-1,-1,-1,-1,-1,-1,-1,9,5,4,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,9,5,4,0,8,3,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,0,5,4,1,5,0,-1,-1,-1,-1,-1,-1,
-1,-1,-1,-1,8,5,4,8,3,5,3,1,5,-1,-1,-1,-1,-1,-1,-1,1,2,10,9,5,4,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,3,0,8,1,2,10,4,9,5,-1,-1,-1,-1,-1,-1,-1,5,2,10,5,4,2,4,0,2,-1,-1,-1,-1,-1,-1,-1,2,10,5,3,2,5,3,5,4,3,4,8,-1,-1,-1,-1,9,5,4,2,3,11,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,0,11,2,0,8,11,4,9,5,-1,-1,-1,-1,-1,-1,-1,0,5,4,0,1,5,2,3,11,-1,-1,-1,-1,-1,-1,-1,2,1,5,2,5,8,2,8,11,4,8,5,-1,-1,-1,-1,10,3,11,10,1,3,9,5,4,-1,-1,-1,-1,-1,-1,-1,4,9,5,0,8,1,8,10,1,8,11,10,-1,-1,-1,-1,5,4,0,5,0,11,5,11,10,11,0,3,-1,-1,-1,-1,5,4,8,5,
8,10,10,8,11,-1,-1,-1,-1,-1,-1,-1,9,7,8,5,7,9,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,9,3,0,9,5,3,5,7,3,-1,-1,-1,-1,-1,-1,-1,0,7,8,0,1,7,1,5,7,-1,-1,-1,-1,-1,-1,-1,1,5,3,3,5,7,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,9,7,8,9,5,7,10,1,2,-1,-1,-1,-1,-1,-1,-1,10,1,2,9,5,0,5,3,0,5,7,3,-1,-1,-1,-1,8,0,2,8,2,5,8,5,7,10,5,2,-1,-1,-1,-1,2,10,5,2,5,3,3,5,7,-1,-1,-1,-1,-1,-1,-1,7,9,5,7,8,9,3,11,2,-1,-1,-1,-1,-1,-1,-1,9,5,7,9,7,2,9,2,0,2,7,11,-1,-1,-1,-1,2,3,11,0,1,8,1,7,8,1,5,7,-1,-1,-1,-1,11,2,1,11,1,7,7,1,5,-1,-1,-1,-1,-1,-1,
-1,9,5,8,8,5,7,10,1,3,10,3,11,-1,-1,-1,-1,5,7,0,5,0,9,7,11,0,1,0,10,11,10,0,-1,11,10,0,11,0,3,10,5,0,8,0,7,5,7,0,-1,11,10,5,7,11,5,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,10,6,5,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,0,8,3,5,10,6,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,9,0,1,5,10,6,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,1,8,3,1,9,8,5,10,6,-1,-1,-1,-1,-1,-1,-1,1,6,5,2,6,1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,1,6,5,1,2,6,3,0,8,-1,-1,-1,-1,-1,-1,-1,9,6,5,9,0,6,0,2,6,-1,-1,-1,-1,-1,-1,-1,5,9,8,5,8,2,5,2,6,3,2,8,-1,-1,-1,-1,2,3,11,10,6,
5,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,11,0,8,11,2,0,10,6,5,-1,-1,-1,-1,-1,-1,-1,0,1,9,2,3,11,5,10,6,-1,-1,-1,-1,-1,-1,-1,5,10,6,1,9,2,9,11,2,9,8,11,-1,-1,-1,-1,6,3,11,6,5,3,5,1,3,-1,-1,-1,-1,-1,-1,-1,0,8,11,0,11,5,0,5,1,5,11,6,-1,-1,-1,-1,3,11,6,0,3,6,0,6,5,0,5,9,-1,-1,-1,-1,6,5,9,6,9,11,11,9,8,-1,-1,-1,-1,-1,-1,-1,5,10,6,4,7,8,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,4,3,0,4,7,3,6,5,10,-1,-1,-1,-1,-1,-1,-1,1,9,0,5,10,6,8,4,7,-1,-1,-1,-1,-1,-1,-1,10,6,5,1,9,7,1,7,3,7,9,4,-1,-1,-1,-1,6,1,2,6,5,1,4,7,8,-1,-1,-1,-1,
-1,-1,-1,1,2,5,5,2,6,3,0,4,3,4,7,-1,-1,-1,-1,8,4,7,9,0,5,0,6,5,0,2,6,-1,-1,-1,-1,7,3,9,7,9,4,3,2,9,5,9,6,2,6,9,-1,3,11,2,7,8,4,10,6,5,-1,-1,-1,-1,-1,-1,-1,5,10,6,4,7,2,4,2,0,2,7,11,-1,-1,-1,-1,0,1,9,4,7,8,2,3,11,5,10,6,-1,-1,-1,-1,9,2,1,9,11,2,9,4,11,7,11,4,5,10,6,-1,8,4,7,3,11,5,3,5,1,5,11,6,-1,-1,-1,-1,5,1,11,5,11,6,1,0,11,7,11,4,0,4,11,-1,0,5,9,0,6,5,0,3,6,11,6,3,8,4,7,-1,6,5,9,6,9,11,4,7,9,7,11,9,-1,-1,-1,-1,10,4,9,6,4,10,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,4,10,6,4,9,10,0,8,3,-1,-1,-1,-1,-1,-1,-1,
10,0,1,10,6,0,6,4,0,-1,-1,-1,-1,-1,-1,-1,8,3,1,8,1,6,8,6,4,6,1,10,-1,-1,-1,-1,1,4,9,1,2,4,2,6,4,-1,-1,-1,-1,-1,-1,-1,3,0,8,1,2,9,2,4,9,2,6,4,-1,-1,-1,-1,0,2,4,4,2,6,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,8,3,2,8,2,4,4,2,6,-1,-1,-1,-1,-1,-1,-1,10,4,9,10,6,4,11,2,3,-1,-1,-1,-1,-1,-1,-1,0,8,2,2,8,11,4,9,10,4,10,6,-1,-1,-1,-1,3,11,2,0,1,6,0,6,4,6,1,10,-1,-1,-1,-1,6,4,1,6,1,10,4,8,1,2,1,11,8,11,1,-1,9,6,4,9,3,6,9,1,3,11,6,3,-1,-1,-1,-1,8,11,1,8,1,0,11,6,1,9,1,4,6,4,1,-1,3,11,6,3,6,0,0,6,4,-1,-1,-1,-1,-1,-1,-1,
6,4,8,11,6,8,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,7,10,6,7,8,10,8,9,10,-1,-1,-1,-1,-1,-1,-1,0,7,3,0,10,7,0,9,10,6,7,10,-1,-1,-1,-1,10,6,7,1,10,7,1,7,8,1,8,0,-1,-1,-1,-1,10,6,7,10,7,1,1,7,3,-1,-1,-1,-1,-1,-1,-1,1,2,6,1,6,8,1,8,9,8,6,7,-1,-1,-1,-1,2,6,9,2,9,1,6,7,9,0,9,3,7,3,9,-1,7,8,0,7,0,6,6,0,2,-1,-1,-1,-1,-1,-1,-1,7,3,2,6,7,2,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,2,3,11,10,6,8,10,8,9,8,6,7,-1,-1,-1,-1,2,0,7,2,7,11,0,9,7,6,7,10,9,10,7,-1,1,8,0,1,7,8,1,10,7,6,7,10,2,3,11,-1,11,2,1,11,1,7,10,6,1,6,7,1,-1,-1,-1,-1,
8,9,6,8,6,7,9,1,6,11,6,3,1,3,6,-1,0,9,1,11,6,7,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,7,8,0,7,0,6,3,11,0,11,6,0,-1,-1,-1,-1,7,11,6,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,7,6,11,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,3,0,8,11,7,6,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,0,1,9,11,7,6,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,8,1,9,8,3,1,11,7,6,-1,-1,-1,-1,-1,-1,-1,10,1,2,6,11,7,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,1,2,10,3,0,8,6,11,7,-1,-1,-1,-1,-1,-1,-1,2,9,0,2,10,9,6,11,7,-1,-1,-1,-1,-1,-1,-1,6,11,7,2,10,3,10,8,3,10,9,8,-1,-1,-1,-1,7,
2,3,6,2,7,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,7,0,8,7,6,0,6,2,0,-1,-1,-1,-1,-1,-1,-1,2,7,6,2,3,7,0,1,9,-1,-1,-1,-1,-1,-1,-1,1,6,2,1,8,6,1,9,8,8,7,6,-1,-1,-1,-1,10,7,6,10,1,7,1,3,7,-1,-1,-1,-1,-1,-1,-1,10,7,6,1,7,10,1,8,7,1,0,8,-1,-1,-1,-1,0,3,7,0,7,10,0,10,9,6,10,7,-1,-1,-1,-1,7,6,10,7,10,8,8,10,9,-1,-1,-1,-1,-1,-1,-1,6,8,4,11,8,6,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,3,6,11,3,0,6,0,4,6,-1,-1,-1,-1,-1,-1,-1,8,6,11,8,4,6,9,0,1,-1,-1,-1,-1,-1,-1,-1,9,4,6,9,6,3,9,3,1,11,3,6,-1,-1,-1,-1,6,8,4,6,11,8,2,10,1,-1,-1,-1,
-1,-1,-1,-1,1,2,10,3,0,11,0,6,11,0,4,6,-1,-1,-1,-1,4,11,8,4,6,11,0,2,9,2,10,9,-1,-1,-1,-1,10,9,3,10,3,2,9,4,3,11,3,6,4,6,3,-1,8,2,3,8,4,2,4,6,2,-1,-1,-1,-1,-1,-1,-1,0,4,2,4,6,2,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,1,9,0,2,3,4,2,4,6,4,3,8,-1,-1,-1,-1,1,9,4,1,4,2,2,4,6,-1,-1,-1,-1,-1,-1,-1,8,1,3,8,6,1,8,4,6,6,10,1,-1,-1,-1,-1,10,1,0,10,0,6,6,0,4,-1,-1,-1,-1,-1,-1,-1,4,6,3,4,3,8,6,10,3,0,3,9,10,9,3,-1,10,9,4,6,10,4,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,4,9,5,7,6,11,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,0,8,3,4,9,5,11,7,6,
-1,-1,-1,-1,-1,-1,-1,5,0,1,5,4,0,7,6,11,-1,-1,-1,-1,-1,-1,-1,11,7,6,8,3,4,3,5,4,3,1,5,-1,-1,-1,-1,9,5,4,10,1,2,7,6,11,-1,-1,-1,-1,-1,-1,-1,6,11,7,1,2,10,0,8,3,4,9,5,-1,-1,-1,-1,7,6,11,5,4,10,4,2,10,4,0,2,-1,-1,-1,-1,3,4,8,3,5,4,3,2,5,10,5,2,11,7,6,-1,7,2,3,7,6,2,5,4,9,-1,-1,-1,-1,-1,-1,-1,9,5,4,0,8,6,0,6,2,6,8,7,-1,-1,-1,-1,3,6,2,3,7,6,1,5,0,5,4,0,-1,-1,-1,-1,6,2,8,6,8,7,2,1,8,4,8,5,1,5,8,-1,9,5,4,10,1,6,1,7,6,1,3,7,-1,-1,-1,-1,1,6,10,1,7,6,1,0,7,8,7,0,9,5,4,-1,4,0,10,4,10,5,0,3,10,6,10,7,3,7,10,
-1,7,6,10,7,10,8,5,4,10,4,8,10,-1,-1,-1,-1,6,9,5,6,11,9,11,8,9,-1,-1,-1,-1,-1,-1,-1,3,6,11,0,6,3,0,5,6,0,9,5,-1,-1,-1,-1,0,11,8,0,5,11,0,1,5,5,6,11,-1,-1,-1,-1,6,11,3,6,3,5,5,3,1,-1,-1,-1,-1,-1,-1,-1,1,2,10,9,5,11,9,11,8,11,5,6,-1,-1,-1,-1,0,11,3,0,6,11,0,9,6,5,6,9,1,2,10,-1,11,8,5,11,5,6,8,0,5,10,5,2,0,2,5,-1,6,11,3,6,3,5,2,10,3,10,5,3,-1,-1,-1,-1,5,8,9,5,2,8,5,6,2,3,8,2,-1,-1,-1,-1,9,5,6,9,6,0,0,6,2,-1,-1,-1,-1,-1,-1,-1,1,5,8,1,8,0,5,6,8,3,8,2,6,2,8,-1,1,5,6,2,1,6,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
1,3,6,1,6,10,3,8,6,5,6,9,8,9,6,-1,10,1,0,10,0,6,9,5,0,5,6,0,-1,-1,-1,-1,0,3,8,5,6,10,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,10,5,6,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,11,5,10,7,5,11,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,11,5,10,11,7,5,8,3,0,-1,-1,-1,-1,-1,-1,-1,5,11,7,5,10,11,1,9,0,-1,-1,-1,-1,-1,-1,-1,10,7,5,10,11,7,9,8,1,8,3,1,-1,-1,-1,-1,11,1,2,11,7,1,7,5,1,-1,-1,-1,-1,-1,-1,-1,0,8,3,1,2,7,1,7,5,7,2,11,-1,-1,-1,-1,9,7,5,9,2,7,9,0,2,2,11,7,-1,-1,-1,-1,7,5,2,7,2,11,5,9,2,3,2,8,9,8,2,-1,2,5,10,2,3,5,3,7,5,-1,-1,
-1,-1,-1,-1,-1,8,2,0,8,5,2,8,7,5,10,2,5,-1,-1,-1,-1,9,0,1,5,10,3,5,3,7,3,10,2,-1,-1,-1,-1,9,8,2,9,2,1,8,7,2,10,2,5,7,5,2,-1,1,3,5,3,7,5,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,0,8,7,0,7,1,1,7,5,-1,-1,-1,-1,-1,-1,-1,9,0,3,9,3,5,5,3,7,-1,-1,-1,-1,-1,-1,-1,9,8,7,5,9,7,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,5,8,4,5,10,8,10,11,8,-1,-1,-1,-1,-1,-1,-1,5,0,4,5,11,0,5,10,11,11,3,0,-1,-1,-1,-1,0,1,9,8,4,10,8,10,11,10,4,5,-1,-1,-1,-1,10,11,4,10,4,5,11,3,4,9,4,1,3,1,4,-1,2,5,1,2,8,5,2,11,8,4,5,8,-1,-1,-1,-1,0,4,11,0,11,3,4,5,11,
2,11,1,5,1,11,-1,0,2,5,0,5,9,2,11,5,4,5,8,11,8,5,-1,9,4,5,2,11,3,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,2,5,10,3,5,2,3,4,5,3,8,4,-1,-1,-1,-1,5,10,2,5,2,4,4,2,0,-1,-1,-1,-1,-1,-1,-1,3,10,2,3,5,10,3,8,5,4,5,8,0,1,9,-1,5,10,2,5,2,4,1,9,2,9,4,2,-1,-1,-1,-1,8,4,5,8,5,3,3,5,1,-1,-1,-1,-1,-1,-1,-1,0,4,5,1,0,5,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,8,4,5,8,5,3,9,0,5,0,3,5,-1,-1,-1,-1,9,4,5,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,4,11,7,4,9,11,9,10,11,-1,-1,-1,-1,-1,-1,-1,0,8,3,4,9,7,9,11,7,9,10,11,-1,-1,-1,-1,1,10,11,1,11,
4,1,4,0,7,4,11,-1,-1,-1,-1,3,1,4,3,4,8,1,10,4,7,4,11,10,11,4,-1,4,11,7,9,11,4,9,2,11,9,1,2,-1,-1,-1,-1,9,7,4,9,11,7,9,1,11,2,11,1,0,8,3,-1,11,7,4,11,4,2,2,4,0,-1,-1,-1,-1,-1,-1,-1,11,7,4,11,4,2,8,3,4,3,2,4,-1,-1,-1,-1,2,9,10,2,7,9,2,3,7,7,4,9,-1,-1,-1,-1,9,10,7,9,7,4,10,2,7,8,7,0,2,0,7,-1,3,7,10,3,10,2,7,4,10,1,10,0,4,0,10,-1,1,10,2,8,7,4,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,4,9,1,4,1,7,7,1,3,-1,-1,-1,-1,-1,-1,-1,4,9,1,4,1,7,0,8,1,8,7,1,-1,-1,-1,-1,4,0,3,7,4,3,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,4,8,7,-1,-1,-1,
-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,9,10,8,10,11,8,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,3,0,9,3,9,11,11,9,10,-1,-1,-1,-1,-1,-1,-1,0,1,10,0,10,8,8,10,11,-1,-1,-1,-1,-1,-1,-1,3,1,10,11,3,10,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,1,2,11,1,11,9,9,11,8,-1,-1,-1,-1,-1,-1,-1,3,0,9,3,9,11,1,2,9,2,11,9,-1,-1,-1,-1,0,2,11,8,0,11,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,3,2,11,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,2,3,8,2,8,10,10,8,9,-1,-1,-1,-1,-1,-1,-1,9,10,2,0,9,2,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,2,3,8,2,8,10,0,1,8,1,10,8,-1,-1,-1,-1,1,10,
2,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,1,3,8,9,1,8,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,0,9,1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,0,3,8,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1]);
THREE.Trident=function(b){function c(c){return new THREE.Mesh(new THREE.CylinderGeometry(30,0.1,b.length/20,b.length/5),new THREE.MeshBasicMaterial({color:c}))}function e(b,c){var e=new THREE.Geometry;e.vertices=[new THREE.Vertex,new THREE.Vertex(b)];return new THREE.Line(e,new THREE.LineBasicMaterial({color:c}))}THREE.Object3D.call(this);var f=Math.PI/2,g,b=b||THREE.Trident.defaultParams;if(b!==THREE.Trident.defaultParams)for(g in THREE.Trident.defaultParams)b.hasOwnProperty(g)||(b[g]=THREE.Trident.defaultParams[g]);
this.scale=new THREE.Vector3(b.scale,b.scale,b.scale);this.addChild(e(new THREE.Vector3(b.length,0,0),b.xAxisColor));this.addChild(e(new THREE.Vector3(0,b.length,0),b.yAxisColor));this.addChild(e(new THREE.Vector3(0,0,b.length),b.zAxisColor));if(b.showArrows)g=c(b.xAxisColor),g.rotation.y=-f,g.position.x=b.length,this.addChild(g),g=c(b.yAxisColor),g.rotation.x=f,g.position.y=b.length,this.addChild(g),g=c(b.zAxisColor),g.rotation.y=Math.PI,g.position.z=b.length,this.addChild(g)};
THREE.Trident.prototype=new THREE.Object3D;THREE.Trident.prototype.constructor=THREE.Trident;THREE.Trident.defaultParams={xAxisColor:16711680,yAxisColor:65280,zAxisColor:255,showArrows:!0,length:100,scale:1};THREE.PlaneCollider=function(b,c){this.point=b;this.normal=c};THREE.SphereCollider=function(b,c){this.center=b;this.radius=c;this.radiusSq=c*c};THREE.BoxCollider=function(b,c){this.min=b;this.max=c;this.dynamic=!0;this.normal=new THREE.Vector3};
THREE.MeshCollider=function(b,c){this.mesh=b;this.box=c;this.numFaces=this.mesh.geometry.faces.length;this.normal=new THREE.Vector3};THREE.CollisionSystem=function(){this.collisionNormal=new THREE.Vector3;this.colliders=[];this.hits=[]};THREE.Collisions=new THREE.CollisionSystem;THREE.CollisionSystem.prototype.merge=function(b){this.colliders=this.colliders.concat(b.colliders);this.hits=this.hits.concat(b.hits)};
THREE.CollisionSystem.prototype.rayCastAll=function(b){b.direction.normalize();this.hits.length=0;var c,e,f,g,j=0;c=0;for(e=this.colliders.length;c<e;c++)if(g=this.colliders[c],f=this.rayCast(b,g),f<Number.MAX_VALUE)g.distance=f,f>j?this.hits.push(g):this.hits.unshift(g),j=f;return this.hits};
THREE.CollisionSystem.prototype.rayCastNearest=function(b){var c=this.rayCastAll(b);if(c.length==0)return null;for(var e=0;c[e]instanceof THREE.MeshCollider;){var f=this.rayMesh(b,c[e]);if(f.dist<Number.MAX_VALUE){c[e].distance=f.dist;c[e].faceIndex=f.faceIndex;break}e++}if(e>c.length)return null;return c[e]};
THREE.CollisionSystem.prototype.rayCast=function(b,c){if(c instanceof THREE.PlaneCollider)return this.rayPlane(b,c);else if(c instanceof THREE.SphereCollider)return this.raySphere(b,c);else if(c instanceof THREE.BoxCollider)return this.rayBox(b,c);else if(c instanceof THREE.MeshCollider&&c.box)return this.rayBox(b,c.box)};
THREE.CollisionSystem.prototype.rayMesh=function(b,c){for(var e=this.makeRayLocal(b,c.mesh),f=Number.MAX_VALUE,g,j=0;j<c.numFaces;j++){var h=c.mesh.geometry.faces[j],k=c.mesh.geometry.vertices[h.a].position,o=c.mesh.geometry.vertices[h.b].position,m=c.mesh.geometry.vertices[h.c].position,p=h instanceof THREE.Face4?c.mesh.geometry.vertices[h.d].position:null;h instanceof THREE.Face3?(h=this.rayTriangle(e,k,o,m,f,this.collisionNormal,c.mesh),h<f&&(f=h,g=j,c.normal.copy(this.collisionNormal),c.normal.normalize())):
h instanceof THREE.Face4&&(h=this.rayTriangle(e,k,o,p,f,this.collisionNormal,c.mesh),h<f&&(f=h,g=j,c.normal.copy(this.collisionNormal),c.normal.normalize()),h=this.rayTriangle(e,o,m,p,f,this.collisionNormal,c.mesh),h<f&&(f=h,g=j,c.normal.copy(this.collisionNormal),c.normal.normalize()))}return{dist:f,faceIndex:g}};
THREE.CollisionSystem.prototype.rayTriangle=function(b,c,e,f,g,j,h){var k=THREE.CollisionSystem.__v1,o=THREE.CollisionSystem.__v2;j.set(0,0,0);k.sub(e,c);o.sub(f,e);j.cross(k,o);k=j.dot(b.direction);if(!(k<0))if(h.doubleSided||h.flipSided)j.multiplyScalar(-1),k*=-1;else return Number.MAX_VALUE;h=j.dot(c)-j.dot(b.origin);if(!(h<=0))return Number.MAX_VALUE;if(!(h>=k*g))return Number.MAX_VALUE;h/=k;k=THREE.CollisionSystem.__v3;k.copy(b.direction);k.multiplyScalar(h);k.addSelf(b.origin);Math.abs(j.x)>
Math.abs(j.y)?Math.abs(j.x)>Math.abs(j.z)?(b=k.y-c.y,j=e.y-c.y,g=f.y-c.y,k=k.z-c.z,e=e.z-c.z,f=f.z-c.z):(b=k.x-c.x,j=e.x-c.x,g=f.x-c.x,k=k.y-c.y,e=e.y-c.y,f=f.y-c.y):Math.abs(j.y)>Math.abs(j.z)?(b=k.x-c.x,j=e.x-c.x,g=f.x-c.x,k=k.z-c.z,e=e.z-c.z,f=f.z-c.z):(b=k.x-c.x,j=e.x-c.x,g=f.x-c.x,k=k.y-c.y,e=e.y-c.y,f=f.y-c.y);c=j*f-e*g;if(c==0)return Number.MAX_VALUE;c=1/c;f=(b*f-k*g)*c;if(!(f>=0))return Number.MAX_VALUE;c*=j*k-e*b;if(!(c>=0))return Number.MAX_VALUE;if(!(1-f-c>=0))return Number.MAX_VALUE;return h};
THREE.CollisionSystem.prototype.makeRayLocal=function(b,c){var e=THREE.CollisionSystem.__m;THREE.Matrix4.makeInvert(c.matrixWorld,e);var f=THREE.CollisionSystem.__r;f.origin.copy(b.origin);f.direction.copy(b.direction);e.multiplyVector3(f.origin);e.rotateAxis(f.direction);f.direction.normalize();return f};
THREE.CollisionSystem.prototype.rayBox=function(b,c){var e;c.dynamic&&c.mesh&&c.mesh.matrixWorld?e=this.makeRayLocal(b,c.mesh):(e=THREE.CollisionSystem.__r,e.origin.copy(b.origin),e.direction.copy(b.direction));var f=0,g=0,j=0,h=0,k=0,o=0,m=!0;e.origin.x<c.min.x?(f=c.min.x-e.origin.x,f/=e.direction.x,m=!1,h=-1):e.origin.x>c.max.x&&(f=c.max.x-e.origin.x,f/=e.direction.x,m=!1,h=1);e.origin.y<c.min.y?(g=c.min.y-e.origin.y,g/=e.direction.y,m=!1,k=-1):e.origin.y>c.max.y&&(g=c.max.y-e.origin.y,g/=e.direction.y,
m=!1,k=1);e.origin.z<c.min.z?(j=c.min.z-e.origin.z,j/=e.direction.z,m=!1,o=-1):e.origin.z>c.max.z&&(j=c.max.z-e.origin.z,j/=e.direction.z,m=!1,o=1);if(m)return-1;m=0;g>f&&(m=1,f=g);j>f&&(m=2,f=j);switch(m){case 0:k=e.origin.y+e.direction.y*f;if(k<c.min.y||k>c.max.y)return Number.MAX_VALUE;e=e.origin.z+e.direction.z*f;if(e<c.min.z||e>c.max.z)return Number.MAX_VALUE;c.normal.set(h,0,0);break;case 1:h=e.origin.x+e.direction.x*f;if(h<c.min.x||h>c.max.x)return Number.MAX_VALUE;e=e.origin.z+e.direction.z*
f;if(e<c.min.z||e>c.max.z)return Number.MAX_VALUE;c.normal.set(0,k,0);break;case 2:h=e.origin.x+e.direction.x*f;if(h<c.min.x||h>c.max.x)return Number.MAX_VALUE;k=e.origin.y+e.direction.y*f;if(k<c.min.y||k>c.max.y)return Number.MAX_VALUE;c.normal.set(0,0,o)}return f};THREE.CollisionSystem.prototype.rayPlane=function(b,c){var e=b.direction.dot(c.normal),f=c.point.dot(c.normal);if(e<0)e=(f-b.origin.dot(c.normal))/e;else return Number.MAX_VALUE;return e>0?e:Number.MAX_VALUE};
THREE.CollisionSystem.prototype.raySphere=function(b,c){var e=c.center.clone().subSelf(b.origin);if(e.lengthSq<c.radiusSq)return-1;var f=e.dot(b.direction.clone());if(f<=0)return Number.MAX_VALUE;e=c.radiusSq-(e.lengthSq()-f*f);if(e>=0)return Math.abs(f)-Math.sqrt(e);return Number.MAX_VALUE};THREE.CollisionSystem.__v1=new THREE.Vector3;THREE.CollisionSystem.__v2=new THREE.Vector3;THREE.CollisionSystem.__v3=new THREE.Vector3;THREE.CollisionSystem.__nr=new THREE.Vector3;THREE.CollisionSystem.__m=new THREE.Matrix4;
THREE.CollisionSystem.__r=new THREE.Ray;THREE.CollisionUtils={};THREE.CollisionUtils.MeshOBB=function(b){b.geometry.computeBoundingBox();var c=b.geometry.boundingBox,e=new THREE.Vector3(c.x[0],c.y[0],c.z[0]),c=new THREE.Vector3(c.x[1],c.y[1],c.z[1]),e=new THREE.BoxCollider(e,c);e.mesh=b;return e};THREE.CollisionUtils.MeshAABB=function(b){var c=THREE.CollisionUtils.MeshOBB(b);c.min.addSelf(b.position);c.max.addSelf(b.position);c.dynamic=!1;return c};
THREE.CollisionUtils.MeshColliderWBox=function(b){return new THREE.MeshCollider(b,THREE.CollisionUtils.MeshOBB(b))};
if(THREE.WebGLRenderer)THREE.AnaglyphWebGLRenderer=function(b){THREE.WebGLRenderer.call(this,b);var c=this,e=this.setSize,f=this.render,g=new THREE.Camera,j=new THREE.Camera,h=new THREE.Matrix4,k=new THREE.Matrix4,o,m,p;g.useTarget=j.useTarget=!1;g.matrixAutoUpdate=j.matrixAutoUpdate=!1;var b={minFilter:THREE.LinearFilter,magFilter:THREE.NearestFilter,format:THREE.RGBAFormat},u=new THREE.WebGLRenderTarget(512,512,b),v=new THREE.WebGLRenderTarget(512,512,b),t=new THREE.Camera(53,1,1,1E4);t.position.z=
2;_material=new THREE.MeshShaderMaterial({uniforms:{mapLeft:{type:"t",value:0,texture:u},mapRight:{type:"t",value:1,texture:v}},vertexShader:"varying vec2 vUv;\nvoid main() {\nvUv = vec2( uv.x, 1.0 - uv.y );\ngl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );\n}",fragmentShader:"uniform sampler2D mapLeft;\nuniform sampler2D mapRight;\nvarying vec2 vUv;\nvoid main() {\nvec4 colorL, colorR;\nvec2 uv = vUv;\ncolorL = texture2D( mapLeft, uv );\ncolorR = texture2D( mapRight, uv );\ngl_FragColor = vec4( colorL.g * 0.7 + colorL.b * 0.3, colorR.g, colorR.b, colorL.a + colorR.a ) * 1.1;\n}"});
var w=new THREE.Scene;w.addObject(new THREE.Mesh(new THREE.PlaneGeometry(2,2),_material));this.setSize=function(b,f){e.call(c,b,f);u.width=b;u.height=f;v.width=b;v.height=f};this.render=function(b,e){e.update(null,!0);if(o!==e.aspect||m!==e.near||p!==e.fov){o=e.aspect;m=e.near;p=e.fov;var A=e.projectionMatrix.clone(),H=125/30*0.5,y=H*m/125,G=m*Math.tan(p*Math.PI/360),I;h.n14=H;k.n14=-H;H=-G*o+y;I=G*o+y;A.n11=2*m/(I-H);A.n13=(I+H)/(I-H);g.projectionMatrix=A.clone();H=-G*o-y;I=G*o-y;A.n11=2*m/(I-H);
A.n13=(I+H)/(I-H);j.projectionMatrix=A.clone()}g.matrix=e.matrixWorld.clone().multiplySelf(k);g.update(null,!0);g.position.copy(e.position);g.near=m;g.far=e.far;f.call(c,b,g,u,!0);j.matrix=e.matrixWorld.clone().multiplySelf(h);j.update(null,!0);j.position.copy(e.position);j.near=m;j.far=e.far;f.call(c,b,j,v,!0);f.call(c,w,t)}};
if(THREE.WebGLRenderer)THREE.CrosseyedWebGLRenderer=function(b){THREE.WebGLRenderer.call(this,b);this.autoClear=!1;var c=this,e=this.setSize,f=this.render,g,j,h=new THREE.Camera,k=new THREE.Camera;c.separation=10;if(b&&b.separation!==void 0)c.separation=b.separation;(new THREE.Camera(53,window.innerWidth/2/window.innerHeight,1,1E4)).position.z=-10;this.setSize=function(b,f){e.call(c,b,f);g=b/2;j=f};this.render=function(b,e){this.clear();h.fov=e.fov;h.aspect=0.5*e.aspect;h.near=e.near;h.far=e.far;
h.updateProjectionMatrix();h.position.copy(e.position);h.target.position.copy(e.target.position);h.translateX(c.separation);k.projectionMatrix=h.projectionMatrix;k.position.copy(e.position);k.target.position.copy(e.target.position);k.translateX(-c.separation);this.setViewport(0,0,g,j);f.call(c,b,h);this.setViewport(g,0,g,j);f.call(c,b,k,!1)}};
/**
 * @author mr.doob / http://mrdoob.com/
 * based on http://papervision3d.googlecode.com/svn/trunk/as3/trunk/src/org/papervision3d/objects/primitives/Cube.as
 */

THREE.CustomCubeGeometry = function ( width, height, depth, segmentsWidth, segmentsHeight, segmentsDepth, materials, flipped, sides ) {

  THREE.Geometry.call( this );

  var scope = this,
  width_half = width / 2,
  height_half = height / 2,
  depth_half = depth / 2,
  flip = flipped ? - 1 : 1;

  if ( materials !== undefined ) {

    if ( materials instanceof Array ) {

      this.materials = materials;

    } else {

      this.materials = [];

      for ( var i = 0; i < 6; i ++ ) {

        this.materials.push( [ materials ] );

      }

    }

  } else {

    this.materials = [];

  }

  this.sides = { px: true, nx: true, py: true, ny: true, pz: true, nz: true };

  if( sides != undefined ) {

    for( var s in sides ) {

      if ( this.sides[ s ] != undefined ) {

        this.sides[ s ] = sides[ s ];

      }

    }

  }
  
  // re-ordered uvs
  this.sides.px && buildPlane( 'y', 'z',   1 * flip, - 1, depth, height, width_half, this.materials[ 0 ] ); // px
  this.sides.nx && buildPlane( 'y', 'z', - 1 * flip, - 1, depth, height, - width_half, this.materials[ 1 ] );   // nx
  this.sides.py && buildPlane( 'x', 'z',  - 1 * flip, - 1, width, depth, height_half, this.materials[ 2 ] );   // py
  this.sides.ny && buildPlane( 'x', 'z',  1 * flip, - 1, width, depth, - height_half, this.materials[ 3 ] ); // ny
  this.sides.pz && buildPlane( 'x', 'y',   1 * flip, - 1, width, height, depth_half, this.materials[ 4 ] );   // pz
  this.sides.nz && buildPlane( 'x', 'y', - 1 * flip, - 1, width, height, - depth_half, this.materials[ 5 ] ); // nz

  mergeVertices();

  function buildPlane( u, v, udir, vdir, width, height, depth, material ) {

    var w, ix, iy,
    gridX = segmentsWidth || 1,
    gridY = segmentsHeight || 1,
    width_half = width / 2,
    height_half = height / 2,
    offset = scope.vertices.length;

    if ( ( u == 'x' && v == 'y' ) || ( u == 'y' && v == 'x' ) ) {

      w = 'z';

    } else if ( ( u == 'x' && v == 'z' ) || ( u == 'z' && v == 'x' ) ) {

      w = 'y';
      gridY = segmentsDepth || 1;

    } else if ( ( u == 'z' && v == 'y' ) || ( u == 'y' && v == 'z' ) ) {

      w = 'x';
      gridX = segmentsDepth || 1;

    }

    var gridX1 = gridX + 1,
    gridY1 = gridY + 1,
    segment_width = width / gridX,
    segment_height = height / gridY;

    for( iy = 0; iy < gridY1; iy++ ) {

      for( ix = 0; ix < gridX1; ix++ ) {

        var vector = new THREE.Vector3();
        vector[ u ] = ( ix * segment_width - width_half ) * udir;
        vector[ v ] = ( iy * segment_height - height_half ) * vdir;
        vector[ w ] = depth;

        scope.vertices.push( new THREE.Vertex( vector ) );

      }

    }

    for( iy = 0; iy < gridY; iy++ ) {

      for( ix = 0; ix < gridX; ix++ ) {

        var a = ix + gridX1 * iy;
        var b = ix + gridX1 * ( iy + 1 );
        var c = ( ix + 1 ) + gridX1 * ( iy + 1 );
        var d = ( ix + 1 ) + gridX1 * iy;

        scope.faces.push( new THREE.Face4( a + offset, b + offset, c + offset, d + offset, null, null, material ) );
        scope.faceVertexUvs[ 0 ].push( [
              new THREE.UV( ix / gridX, iy / gridY ),
              new THREE.UV( ix / gridX, ( iy + 1 ) / gridY ),
              new THREE.UV( ( ix + 1 ) / gridX, ( iy + 1 ) / gridY ),
              new THREE.UV( ( ix + 1 ) / gridX, iy / gridY )
            ] );

      }

    }

  }

  function mergeVertices() {

    var unique = [], changes = [];

    for ( var i = 0, il = scope.vertices.length; i < il; i ++ ) {

      var v = scope.vertices[ i ],
      duplicate = false;

      for ( var j = 0, jl = unique.length; j < jl; j ++ ) {

        var vu = unique[ j ];

        if( v.position.x == vu.position.x && v.position.y == vu.position.y && v.position.z == vu.position.z ) {

          changes[ i ] = j;
          duplicate = true;
          break;

        }

      }

      if ( ! duplicate ) {

        changes[ i ] = unique.length;
        unique.push( new THREE.Vertex( v.position.clone() ) );

      }

    }

    for ( i = 0, il = scope.faces.length; i < il; i ++ ) {

      var face = scope.faces[ i ];

      face.a = changes[ face.a ];
      face.b = changes[ face.b ];
      face.c = changes[ face.c ];
      face.d = changes[ face.d ];

    }

    scope.vertices = unique;

  }

  this.computeCentroids();
  this.computeFaceNormals();

};

THREE.CustomCubeGeometry.prototype = new THREE.Geometry();
THREE.CustomCubeGeometry.prototype.constructor = THREE.CustomCubeGeometry;
/**
 * Provides requestAnimationFrame in a cross browser way.
 * http://paulirish.com/2011/requestanimationframe-for-smart-animating/
 */

if ( !window.requestAnimationFrame ) {

	window.requestAnimationFrame = ( function() {

		return window.webkitRequestAnimationFrame ||
		window.mozRequestAnimationFrame ||
		window.oRequestAnimationFrame ||
		window.msRequestAnimationFrame ||
		function( /* function FrameRequestCallback */ callback, /* DOMElement Element */ element ) {

			window.setTimeout( callback, 1000 / 60 );

		};

	} )();

}


/** 
    example:

    (function animloop(){
      render();
      requestAnimFrame(animloop, element);
    })();
    
*/    // stats.js r6 - http://github.com/mrdoob/stats.js
var Stats=function(){function s(a,g,d){var f,c,e;for(c=0;c<30;c++)for(f=0;f<73;f++)e=(f+c*74)*4,a[e]=a[e+4],a[e+1]=a[e+5],a[e+2]=a[e+6];for(c=0;c<30;c++)e=(73+c*74)*4,c<g?(a[e]=b[d].bg.r,a[e+1]=b[d].bg.g,a[e+2]=b[d].bg.b):(a[e]=b[d].fg.r,a[e+1]=b[d].fg.g,a[e+2]=b[d].fg.b)}var r=0,t=2,g,u=0,j=(new Date).getTime(),F=j,v=j,l=0,w=1E3,x=0,k,d,a,m,y,n=0,z=1E3,A=0,f,c,o,B,p=0,C=1E3,D=0,h,i,q,E,b={fps:{bg:{r:16,g:16,b:48},fg:{r:0,g:255,b:255}},ms:{bg:{r:16,g:48,b:16},fg:{r:0,g:255,b:0}},mb:{bg:{r:48,g:16,
b:26},fg:{r:255,g:0,b:128}}};g=document.createElement("div");g.style.cursor="pointer";g.style.width="80px";g.style.opacity="0.9";g.style.zIndex="10001";g.addEventListener("click",function(){r++;r==t&&(r=0);k.style.display="none";f.style.display="none";h.style.display="none";switch(r){case 0:k.style.display="block";break;case 1:f.style.display="block";break;case 2:h.style.display="block"}},!1);k=document.createElement("div");k.style.backgroundColor="rgb("+Math.floor(b.fps.bg.r/2)+","+Math.floor(b.fps.bg.g/
2)+","+Math.floor(b.fps.bg.b/2)+")";k.style.padding="2px 0px 3px 0px";g.appendChild(k);d=document.createElement("div");d.style.fontFamily="Helvetica, Arial, sans-serif";d.style.textAlign="left";d.style.fontSize="9px";d.style.color="rgb("+b.fps.fg.r+","+b.fps.fg.g+","+b.fps.fg.b+")";d.style.margin="0px 0px 1px 3px";d.innerHTML='<span style="font-weight:bold">FPS</span>';k.appendChild(d);a=document.createElement("canvas");a.width=74;a.height=30;a.style.display="block";a.style.marginLeft="3px";k.appendChild(a);
m=a.getContext("2d");m.fillStyle="rgb("+b.fps.bg.r+","+b.fps.bg.g+","+b.fps.bg.b+")";m.fillRect(0,0,a.width,a.height);y=m.getImageData(0,0,a.width,a.height);f=document.createElement("div");f.style.backgroundColor="rgb("+Math.floor(b.ms.bg.r/2)+","+Math.floor(b.ms.bg.g/2)+","+Math.floor(b.ms.bg.b/2)+")";f.style.padding="2px 0px 3px 0px";f.style.display="none";g.appendChild(f);c=document.createElement("div");c.style.fontFamily="Helvetica, Arial, sans-serif";c.style.textAlign="left";c.style.fontSize=
"9px";c.style.color="rgb("+b.ms.fg.r+","+b.ms.fg.g+","+b.ms.fg.b+")";c.style.margin="0px 0px 1px 3px";c.innerHTML='<span style="font-weight:bold">MS</span>';f.appendChild(c);a=document.createElement("canvas");a.width=74;a.height=30;a.style.display="block";a.style.marginLeft="3px";f.appendChild(a);o=a.getContext("2d");o.fillStyle="rgb("+b.ms.bg.r+","+b.ms.bg.g+","+b.ms.bg.b+")";o.fillRect(0,0,a.width,a.height);B=o.getImageData(0,0,a.width,a.height);try{performance&&performance.memory&&performance.memory.totalJSHeapSize&&
(t=3)}catch(G){}h=document.createElement("div");h.style.backgroundColor="rgb("+Math.floor(b.mb.bg.r/2)+","+Math.floor(b.mb.bg.g/2)+","+Math.floor(b.mb.bg.b/2)+")";h.style.padding="2px 0px 3px 0px";h.style.display="none";g.appendChild(h);i=document.createElement("div");i.style.fontFamily="Helvetica, Arial, sans-serif";i.style.textAlign="left";i.style.fontSize="9px";i.style.color="rgb("+b.mb.fg.r+","+b.mb.fg.g+","+b.mb.fg.b+")";i.style.margin="0px 0px 1px 3px";i.innerHTML='<span style="font-weight:bold">MB</span>';
h.appendChild(i);a=document.createElement("canvas");a.width=74;a.height=30;a.style.display="block";a.style.marginLeft="3px";h.appendChild(a);q=a.getContext("2d");q.fillStyle="#301010";q.fillRect(0,0,a.width,a.height);E=q.getImageData(0,0,a.width,a.height);return{domElement:g,update:function(){u++;j=(new Date).getTime();n=j-F;z=Math.min(z,n);A=Math.max(A,n);s(B.data,Math.min(30,30-n/200*30),"ms");c.innerHTML='<span style="font-weight:bold">'+n+" MS</span> ("+z+"-"+A+")";o.putImageData(B,0,0);F=j;if(j>
v+1E3){l=Math.round(u*1E3/(j-v));w=Math.min(w,l);x=Math.max(x,l);s(y.data,Math.min(30,30-l/100*30),"fps");d.innerHTML='<span style="font-weight:bold">'+l+" FPS</span> ("+w+"-"+x+")";m.putImageData(y,0,0);if(t==3)p=performance.memory.usedJSHeapSize*9.54E-7,C=Math.min(C,p),D=Math.max(D,p),s(E.data,Math.min(30,30-p/2),"mb"),i.innerHTML='<span style="font-weight:bold">'+Math.round(p)+" MB</span> ("+Math.round(C)+"-"+Math.round(D)+")",q.putImageData(E,0,0);v=j;u=0}}}};

/*! jQuery v1.7.1 jquery.com | jquery.org/license */
(function(a,b){function cy(a){return f.isWindow(a)?a:a.nodeType===9?a.defaultView||a.parentWindow:!1}function cv(a){if(!ck[a]){var b=c.body,d=f("<"+a+">").appendTo(b),e=d.css("display");d.remove();if(e==="none"||e===""){cl||(cl=c.createElement("iframe"),cl.frameBorder=cl.width=cl.height=0),b.appendChild(cl);if(!cm||!cl.createElement)cm=(cl.contentWindow||cl.contentDocument).document,cm.write((c.compatMode==="CSS1Compat"?"<!doctype html>":"")+"<html><body>"),cm.close();d=cm.createElement(a),cm.body.appendChild(d),e=f.css(d,"display"),b.removeChild(cl)}ck[a]=e}return ck[a]}function cu(a,b){var c={};f.each(cq.concat.apply([],cq.slice(0,b)),function(){c[this]=a});return c}function ct(){cr=b}function cs(){setTimeout(ct,0);return cr=f.now()}function cj(){try{return new a.ActiveXObject("Microsoft.XMLHTTP")}catch(b){}}function ci(){try{return new a.XMLHttpRequest}catch(b){}}function cc(a,c){a.dataFilter&&(c=a.dataFilter(c,a.dataType));var d=a.dataTypes,e={},g,h,i=d.length,j,k=d[0],l,m,n,o,p;for(g=1;g<i;g++){if(g===1)for(h in a.converters)typeof h=="string"&&(e[h.toLowerCase()]=a.converters[h]);l=k,k=d[g];if(k==="*")k=l;else if(l!=="*"&&l!==k){m=l+" "+k,n=e[m]||e["* "+k];if(!n){p=b;for(o in e){j=o.split(" ");if(j[0]===l||j[0]==="*"){p=e[j[1]+" "+k];if(p){o=e[o],o===!0?n=p:p===!0&&(n=o);break}}}}!n&&!p&&f.error("No conversion from "+m.replace(" "," to ")),n!==!0&&(c=n?n(c):p(o(c)))}}return c}function cb(a,c,d){var e=a.contents,f=a.dataTypes,g=a.responseFields,h,i,j,k;for(i in g)i in d&&(c[g[i]]=d[i]);while(f[0]==="*")f.shift(),h===b&&(h=a.mimeType||c.getResponseHeader("content-type"));if(h)for(i in e)if(e[i]&&e[i].test(h)){f.unshift(i);break}if(f[0]in d)j=f[0];else{for(i in d){if(!f[0]||a.converters[i+" "+f[0]]){j=i;break}k||(k=i)}j=j||k}if(j){j!==f[0]&&f.unshift(j);return d[j]}}function ca(a,b,c,d){if(f.isArray(b))f.each(b,function(b,e){c||bE.test(a)?d(a,e):ca(a+"["+(typeof e=="object"||f.isArray(e)?b:"")+"]",e,c,d)});else if(!c&&b!=null&&typeof b=="object")for(var e in b)ca(a+"["+e+"]",b[e],c,d);else d(a,b)}function b_(a,c){var d,e,g=f.ajaxSettings.flatOptions||{};for(d in c)c[d]!==b&&((g[d]?a:e||(e={}))[d]=c[d]);e&&f.extend(!0,a,e)}function b$(a,c,d,e,f,g){f=f||c.dataTypes[0],g=g||{},g[f]=!0;var h=a[f],i=0,j=h?h.length:0,k=a===bT,l;for(;i<j&&(k||!l);i++)l=h[i](c,d,e),typeof l=="string"&&(!k||g[l]?l=b:(c.dataTypes.unshift(l),l=b$(a,c,d,e,l,g)));(k||!l)&&!g["*"]&&(l=b$(a,c,d,e,"*",g));return l}function bZ(a){return function(b,c){typeof b!="string"&&(c=b,b="*");if(f.isFunction(c)){var d=b.toLowerCase().split(bP),e=0,g=d.length,h,i,j;for(;e<g;e++)h=d[e],j=/^\+/.test(h),j&&(h=h.substr(1)||"*"),i=a[h]=a[h]||[],i[j?"unshift":"push"](c)}}}function bC(a,b,c){var d=b==="width"?a.offsetWidth:a.offsetHeight,e=b==="width"?bx:by,g=0,h=e.length;if(d>0){if(c!=="border")for(;g<h;g++)c||(d-=parseFloat(f.css(a,"padding"+e[g]))||0),c==="margin"?d+=parseFloat(f.css(a,c+e[g]))||0:d-=parseFloat(f.css(a,"border"+e[g]+"Width"))||0;return d+"px"}d=bz(a,b,b);if(d<0||d==null)d=a.style[b]||0;d=parseFloat(d)||0;if(c)for(;g<h;g++)d+=parseFloat(f.css(a,"padding"+e[g]))||0,c!=="padding"&&(d+=parseFloat(f.css(a,"border"+e[g]+"Width"))||0),c==="margin"&&(d+=parseFloat(f.css(a,c+e[g]))||0);return d+"px"}function bp(a,b){b.src?f.ajax({url:b.src,async:!1,dataType:"script"}):f.globalEval((b.text||b.textContent||b.innerHTML||"").replace(bf,"/*$0*/")),b.parentNode&&b.parentNode.removeChild(b)}function bo(a){var b=c.createElement("div");bh.appendChild(b),b.innerHTML=a.outerHTML;return b.firstChild}function bn(a){var b=(a.nodeName||"").toLowerCase();b==="input"?bm(a):b!=="script"&&typeof a.getElementsByTagName!="undefined"&&f.grep(a.getElementsByTagName("input"),bm)}function bm(a){if(a.type==="checkbox"||a.type==="radio")a.defaultChecked=a.checked}function bl(a){return typeof a.getElementsByTagName!="undefined"?a.getElementsByTagName("*"):typeof a.querySelectorAll!="undefined"?a.querySelectorAll("*"):[]}function bk(a,b){var c;if(b.nodeType===1){b.clearAttributes&&b.clearAttributes(),b.mergeAttributes&&b.mergeAttributes(a),c=b.nodeName.toLowerCase();if(c==="object")b.outerHTML=a.outerHTML;else if(c!=="input"||a.type!=="checkbox"&&a.type!=="radio"){if(c==="option")b.selected=a.defaultSelected;else if(c==="input"||c==="textarea")b.defaultValue=a.defaultValue}else a.checked&&(b.defaultChecked=b.checked=a.checked),b.value!==a.value&&(b.value=a.value);b.removeAttribute(f.expando)}}function bj(a,b){if(b.nodeType===1&&!!f.hasData(a)){var c,d,e,g=f._data(a),h=f._data(b,g),i=g.events;if(i){delete h.handle,h.events={};for(c in i)for(d=0,e=i[c].length;d<e;d++)f.event.add(b,c+(i[c][d].namespace?".":"")+i[c][d].namespace,i[c][d],i[c][d].data)}h.data&&(h.data=f.extend({},h.data))}}function bi(a,b){return f.nodeName(a,"table")?a.getElementsByTagName("tbody")[0]||a.appendChild(a.ownerDocument.createElement("tbody")):a}function U(a){var b=V.split("|"),c=a.createDocumentFragment();if(c.createElement)while(b.length)c.createElement(b.pop());return c}function T(a,b,c){b=b||0;if(f.isFunction(b))return f.grep(a,function(a,d){var e=!!b.call(a,d,a);return e===c});if(b.nodeType)return f.grep(a,function(a,d){return a===b===c});if(typeof b=="string"){var d=f.grep(a,function(a){return a.nodeType===1});if(O.test(b))return f.filter(b,d,!c);b=f.filter(b,d)}return f.grep(a,function(a,d){return f.inArray(a,b)>=0===c})}function S(a){return!a||!a.parentNode||a.parentNode.nodeType===11}function K(){return!0}function J(){return!1}function n(a,b,c){var d=b+"defer",e=b+"queue",g=b+"mark",h=f._data(a,d);h&&(c==="queue"||!f._data(a,e))&&(c==="mark"||!f._data(a,g))&&setTimeout(function(){!f._data(a,e)&&!f._data(a,g)&&(f.removeData(a,d,!0),h.fire())},0)}function m(a){for(var b in a){if(b==="data"&&f.isEmptyObject(a[b]))continue;if(b!=="toJSON")return!1}return!0}function l(a,c,d){if(d===b&&a.nodeType===1){var e="data-"+c.replace(k,"-$1").toLowerCase();d=a.getAttribute(e);if(typeof d=="string"){try{d=d==="true"?!0:d==="false"?!1:d==="null"?null:f.isNumeric(d)?parseFloat(d):j.test(d)?f.parseJSON(d):d}catch(g){}f.data(a,c,d)}else d=b}return d}function h(a){var b=g[a]={},c,d;a=a.split(/\s+/);for(c=0,d=a.length;c<d;c++)b[a[c]]=!0;return b}var c=a.document,d=a.navigator,e=a.location,f=function(){function J(){if(!e.isReady){try{c.documentElement.doScroll("left")}catch(a){setTimeout(J,1);return}e.ready()}}var e=function(a,b){return new e.fn.init(a,b,h)},f=a.jQuery,g=a.$,h,i=/^(?:[^#<]*(<[\w\W]+>)[^>]*$|#([\w\-]*)$)/,j=/\S/,k=/^\s+/,l=/\s+$/,m=/^<(\w+)\s*\/?>(?:<\/\1>)?$/,n=/^[\],:{}\s]*$/,o=/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g,p=/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g,q=/(?:^|:|,)(?:\s*\[)+/g,r=/(webkit)[ \/]([\w.]+)/,s=/(opera)(?:.*version)?[ \/]([\w.]+)/,t=/(msie) ([\w.]+)/,u=/(mozilla)(?:.*? rv:([\w.]+))?/,v=/-([a-z]|[0-9])/ig,w=/^-ms-/,x=function(a,b){return(b+"").toUpperCase()},y=d.userAgent,z,A,B,C=Object.prototype.toString,D=Object.prototype.hasOwnProperty,E=Array.prototype.push,F=Array.prototype.slice,G=String.prototype.trim,H=Array.prototype.indexOf,I={};e.fn=e.prototype={constructor:e,init:function(a,d,f){var g,h,j,k;if(!a)return this;if(a.nodeType){this.context=this[0]=a,this.length=1;return this}if(a==="body"&&!d&&c.body){this.context=c,this[0]=c.body,this.selector=a,this.length=1;return this}if(typeof a=="string"){a.charAt(0)!=="<"||a.charAt(a.length-1)!==">"||a.length<3?g=i.exec(a):g=[null,a,null];if(g&&(g[1]||!d)){if(g[1]){d=d instanceof e?d[0]:d,k=d?d.ownerDocument||d:c,j=m.exec(a),j?e.isPlainObject(d)?(a=[c.createElement(j[1])],e.fn.attr.call(a,d,!0)):a=[k.createElement(j[1])]:(j=e.buildFragment([g[1]],[k]),a=(j.cacheable?e.clone(j.fragment):j.fragment).childNodes);return e.merge(this,a)}h=c.getElementById(g[2]);if(h&&h.parentNode){if(h.id!==g[2])return f.find(a);this.length=1,this[0]=h}this.context=c,this.selector=a;return this}return!d||d.jquery?(d||f).find(a):this.constructor(d).find(a)}if(e.isFunction(a))return f.ready(a);a.selector!==b&&(this.selector=a.selector,this.context=a.context);return e.makeArray(a,this)},selector:"",jquery:"1.7.1",length:0,size:function(){return this.length},toArray:function(){return F.call(this,0)},get:function(a){return a==null?this.toArray():a<0?this[this.length+a]:this[a]},pushStack:function(a,b,c){var d=this.constructor();e.isArray(a)?E.apply(d,a):e.merge(d,a),d.prevObject=this,d.context=this.context,b==="find"?d.selector=this.selector+(this.selector?" ":"")+c:b&&(d.selector=this.selector+"."+b+"("+c+")");return d},each:function(a,b){return e.each(this,a,b)},ready:function(a){e.bindReady(),A.add(a);return this},eq:function(a){a=+a;return a===-1?this.slice(a):this.slice(a,a+1)},first:function(){return this.eq(0)},last:function(){return this.eq(-1)},slice:function(){return this.pushStack(F.apply(this,arguments),"slice",F.call(arguments).join(","))},map:function(a){return this.pushStack(e.map(this,function(b,c){return a.call(b,c,b)}))},end:function(){return this.prevObject||this.constructor(null)},push:E,sort:[].sort,splice:[].splice},e.fn.init.prototype=e.fn,e.extend=e.fn.extend=function(){var a,c,d,f,g,h,i=arguments[0]||{},j=1,k=arguments.length,l=!1;typeof i=="boolean"&&(l=i,i=arguments[1]||{},j=2),typeof i!="object"&&!e.isFunction(i)&&(i={}),k===j&&(i=this,--j);for(;j<k;j++)if((a=arguments[j])!=null)for(c in a){d=i[c],f=a[c];if(i===f)continue;l&&f&&(e.isPlainObject(f)||(g=e.isArray(f)))?(g?(g=!1,h=d&&e.isArray(d)?d:[]):h=d&&e.isPlainObject(d)?d:{},i[c]=e.extend(l,h,f)):f!==b&&(i[c]=f)}return i},e.extend({noConflict:function(b){a.$===e&&(a.$=g),b&&a.jQuery===e&&(a.jQuery=f);return e},isReady:!1,readyWait:1,holdReady:function(a){a?e.readyWait++:e.ready(!0)},ready:function(a){if(a===!0&&!--e.readyWait||a!==!0&&!e.isReady){if(!c.body)return setTimeout(e.ready,1);e.isReady=!0;if(a!==!0&&--e.readyWait>0)return;A.fireWith(c,[e]),e.fn.trigger&&e(c).trigger("ready").off("ready")}},bindReady:function(){if(!A){A=e.Callbacks("once memory");if(c.readyState==="complete")return setTimeout(e.ready,1);if(c.addEventListener)c.addEventListener("DOMContentLoaded",B,!1),a.addEventListener("load",e.ready,!1);else if(c.attachEvent){c.attachEvent("onreadystatechange",B),a.attachEvent("onload",e.ready);var b=!1;try{b=a.frameElement==null}catch(d){}c.documentElement.doScroll&&b&&J()}}},isFunction:function(a){return e.type(a)==="function"},isArray:Array.isArray||function(a){return e.type(a)==="array"},isWindow:function(a){return a&&typeof a=="object"&&"setInterval"in a},isNumeric:function(a){return!isNaN(parseFloat(a))&&isFinite(a)},type:function(a){return a==null?String(a):I[C.call(a)]||"object"},isPlainObject:function(a){if(!a||e.type(a)!=="object"||a.nodeType||e.isWindow(a))return!1;try{if(a.constructor&&!D.call(a,"constructor")&&!D.call(a.constructor.prototype,"isPrototypeOf"))return!1}catch(c){return!1}var d;for(d in a);return d===b||D.call(a,d)},isEmptyObject:function(a){for(var b in a)return!1;return!0},error:function(a){throw new Error(a)},parseJSON:function(b){if(typeof b!="string"||!b)return null;b=e.trim(b);if(a.JSON&&a.JSON.parse)return a.JSON.parse(b);if(n.test(b.replace(o,"@").replace(p,"]").replace(q,"")))return(new Function("return "+b))();e.error("Invalid JSON: "+b)},parseXML:function(c){var d,f;try{a.DOMParser?(f=new DOMParser,d=f.parseFromString(c,"text/xml")):(d=new ActiveXObject("Microsoft.XMLDOM"),d.async="false",d.loadXML(c))}catch(g){d=b}(!d||!d.documentElement||d.getElementsByTagName("parsererror").length)&&e.error("Invalid XML: "+c);return d},noop:function(){},globalEval:function(b){b&&j.test(b)&&(a.execScript||function(b){a.eval.call(a,b)})(b)},camelCase:function(a){return a.replace(w,"ms-").replace(v,x)},nodeName:function(a,b){return a.nodeName&&a.nodeName.toUpperCase()===b.toUpperCase()},each:function(a,c,d){var f,g=0,h=a.length,i=h===b||e.isFunction(a);if(d){if(i){for(f in a)if(c.apply(a[f],d)===!1)break}else for(;g<h;)if(c.apply(a[g++],d)===!1)break}else if(i){for(f in a)if(c.call(a[f],f,a[f])===!1)break}else for(;g<h;)if(c.call(a[g],g,a[g++])===!1)break;return a},trim:G?function(a){return a==null?"":G.call(a)}:function(a){return a==null?"":(a+"").replace(k,"").replace(l,"")},makeArray:function(a,b){var c=b||[];if(a!=null){var d=e.type(a);a.length==null||d==="string"||d==="function"||d==="regexp"||e.isWindow(a)?E.call(c,a):e.merge(c,a)}return c},inArray:function(a,b,c){var d;if(b){if(H)return H.call(b,a,c);d=b.length,c=c?c<0?Math.max(0,d+c):c:0;for(;c<d;c++)if(c in b&&b[c]===a)return c}return-1},merge:function(a,c){var d=a.length,e=0;if(typeof c.length=="number")for(var f=c.length;e<f;e++)a[d++]=c[e];else while(c[e]!==b)a[d++]=c[e++];a.length=d;return a},grep:function(a,b,c){var d=[],e;c=!!c;for(var f=0,g=a.length;f<g;f++)e=!!b(a[f],f),c!==e&&d.push(a[f]);return d},map:function(a,c,d){var f,g,h=[],i=0,j=a.length,k=a instanceof e||j!==b&&typeof j=="number"&&(j>0&&a[0]&&a[j-1]||j===0||e.isArray(a));if(k)for(;i<j;i++)f=c(a[i],i,d),f!=null&&(h[h.length]=f);else for(g in a)f=c(a[g],g,d),f!=null&&(h[h.length]=f);return h.concat.apply([],h)},guid:1,proxy:function(a,c){if(typeof c=="string"){var d=a[c];c=a,a=d}if(!e.isFunction(a))return b;var f=F.call(arguments,2),g=function(){return a.apply(c,f.concat(F.call(arguments)))};g.guid=a.guid=a.guid||g.guid||e.guid++;return g},access:function(a,c,d,f,g,h){var i=a.length;if(typeof c=="object"){for(var j in c)e.access(a,j,c[j],f,g,d);return a}if(d!==b){f=!h&&f&&e.isFunction(d);for(var k=0;k<i;k++)g(a[k],c,f?d.call(a[k],k,g(a[k],c)):d,h);return a}return i?g(a[0],c):b},now:function(){return(new Date).getTime()},uaMatch:function(a){a=a.toLowerCase();var b=r.exec(a)||s.exec(a)||t.exec(a)||a.indexOf("compatible")<0&&u.exec(a)||[];return{browser:b[1]||"",version:b[2]||"0"}},sub:function(){function a(b,c){return new a.fn.init(b,c)}e.extend(!0,a,this),a.superclass=this,a.fn=a.prototype=this(),a.fn.constructor=a,a.sub=this.sub,a.fn.init=function(d,f){f&&f instanceof e&&!(f instanceof a)&&(f=a(f));return e.fn.init.call(this,d,f,b)},a.fn.init.prototype=a.fn;var b=a(c);return a},browser:{}}),e.each("Boolean Number String Function Array Date RegExp Object".split(" "),function(a,b){I["[object "+b+"]"]=b.toLowerCase()}),z=e.uaMatch(y),z.browser&&(e.browser[z.browser]=!0,e.browser.version=z.version),e.browser.webkit&&(e.browser.safari=!0),j.test(" ")&&(k=/^[\s\xA0]+/,l=/[\s\xA0]+$/),h=e(c),c.addEventListener?B=function(){c.removeEventListener("DOMContentLoaded",B,!1),e.ready()}:c.attachEvent&&(B=function(){c.readyState==="complete"&&(c.detachEvent("onreadystatechange",B),e.ready())});return e}(),g={};f.Callbacks=function(a){a=a?g[a]||h(a):{};var c=[],d=[],e,i,j,k,l,m=function(b){var d,e,g,h,i;for(d=0,e=b.length;d<e;d++)g=b[d],h=f.type(g),h==="array"?m(g):h==="function"&&(!a.unique||!o.has(g))&&c.push(g)},n=function(b,f){f=f||[],e=!a.memory||[b,f],i=!0,l=j||0,j=0,k=c.length;for(;c&&l<k;l++)if(c[l].apply(b,f)===!1&&a.stopOnFalse){e=!0;break}i=!1,c&&(a.once?e===!0?o.disable():c=[]:d&&d.length&&(e=d.shift(),o.fireWith(e[0],e[1])))},o={add:function(){if(c){var a=c.length;m(arguments),i?k=c.length:e&&e!==!0&&(j=a,n(e[0],e[1]))}return this},remove:function(){if(c){var b=arguments,d=0,e=b.length;for(;d<e;d++)for(var f=0;f<c.length;f++)if(b[d]===c[f]){i&&f<=k&&(k--,f<=l&&l--),c.splice(f--,1);if(a.unique)break}}return this},has:function(a){if(c){var b=0,d=c.length;for(;b<d;b++)if(a===c[b])return!0}return!1},empty:function(){c=[];return this},disable:function(){c=d=e=b;return this},disabled:function(){return!c},lock:function(){d=b,(!e||e===!0)&&o.disable();return this},locked:function(){return!d},fireWith:function(b,c){d&&(i?a.once||d.push([b,c]):(!a.once||!e)&&n(b,c));return this},fire:function(){o.fireWith(this,arguments);return this},fired:function(){return!!e}};return o};var i=[].slice;f.extend({Deferred:function(a){var b=f.Callbacks("once memory"),c=f.Callbacks("once memory"),d=f.Callbacks("memory"),e="pending",g={resolve:b,reject:c,notify:d},h={done:b.add,fail:c.add,progress:d.add,state:function(){return e},isResolved:b.fired,isRejected:c.fired,then:function(a,b,c){i.done(a).fail(b).progress(c);return this},always:function(){i.done.apply(i,arguments).fail.apply(i,arguments);return this},pipe:function(a,b,c){return f.Deferred(function(d){f.each({done:[a,"resolve"],fail:[b,"reject"],progress:[c,"notify"]},function(a,b){var c=b[0],e=b[1],g;f.isFunction(c)?i[a](function(){g=c.apply(this,arguments),g&&f.isFunction(g.promise)?g.promise().then(d.resolve,d.reject,d.notify):d[e+"With"](this===i?d:this,[g])}):i[a](d[e])})}).promise()},promise:function(a){if(a==null)a=h;else for(var b in h)a[b]=h[b];return a}},i=h.promise({}),j;for(j in g)i[j]=g[j].fire,i[j+"With"]=g[j].fireWith;i.done(function(){e="resolved"},c.disable,d.lock).fail(function(){e="rejected"},b.disable,d.lock),a&&a.call(i,i);return i},when:function(a){function m(a){return function(b){e[a]=arguments.length>1?i.call(arguments,0):b,j.notifyWith(k,e)}}function l(a){return function(c){b[a]=arguments.length>1?i.call(arguments,0):c,--g||j.resolveWith(j,b)}}var b=i.call(arguments,0),c=0,d=b.length,e=Array(d),g=d,h=d,j=d<=1&&a&&f.isFunction(a.promise)?a:f.Deferred(),k=j.promise();if(d>1){for(;c<d;c++)b[c]&&b[c].promise&&f.isFunction(b[c].promise)?b[c].promise().then(l(c),j.reject,m(c)):--g;g||j.resolveWith(j,b)}else j!==a&&j.resolveWith(j,d?[a]:[]);return k}}),f.support=function(){var b,d,e,g,h,i,j,k,l,m,n,o,p,q=c.createElement("div"),r=c.documentElement;q.setAttribute("className","t"),q.innerHTML="   <link/><table></table><a href='/a' style='top:1px;float:left;opacity:.55;'>a</a><input type='checkbox'/>",d=q.getElementsByTagName("*"),e=q.getElementsByTagName("a")[0];if(!d||!d.length||!e)return{};g=c.createElement("select"),h=g.appendChild(c.createElement("option")),i=q.getElementsByTagName("input")[0],b={leadingWhitespace:q.firstChild.nodeType===3,tbody:!q.getElementsByTagName("tbody").length,htmlSerialize:!!q.getElementsByTagName("link").length,style:/top/.test(e.getAttribute("style")),hrefNormalized:e.getAttribute("href")==="/a",opacity:/^0.55/.test(e.style.opacity),cssFloat:!!e.style.cssFloat,checkOn:i.value==="on",optSelected:h.selected,getSetAttribute:q.className!=="t",enctype:!!c.createElement("form").enctype,html5Clone:c.createElement("nav").cloneNode(!0).outerHTML!=="<:nav></:nav>",submitBubbles:!0,changeBubbles:!0,focusinBubbles:!1,deleteExpando:!0,noCloneEvent:!0,inlineBlockNeedsLayout:!1,shrinkWrapBlocks:!1,reliableMarginRight:!0},i.checked=!0,b.noCloneChecked=i.cloneNode(!0).checked,g.disabled=!0,b.optDisabled=!h.disabled;try{delete q.test}catch(s){b.deleteExpando=!1}!q.addEventListener&&q.attachEvent&&q.fireEvent&&(q.attachEvent("onclick",function(){b.noCloneEvent=!1}),q.cloneNode(!0).fireEvent("onclick")),i=c.createElement("input"),i.value="t",i.setAttribute("type","radio"),b.radioValue=i.value==="t",i.setAttribute("checked","checked"),q.appendChild(i),k=c.createDocumentFragment(),k.appendChild(q.lastChild),b.checkClone=k.cloneNode(!0).cloneNode(!0).lastChild.checked,b.appendChecked=i.checked,k.removeChild(i),k.appendChild(q),q.innerHTML="",a.getComputedStyle&&(j=c.createElement("div"),j.style.width="0",j.style.marginRight="0",q.style.width="2px",q.appendChild(j),b.reliableMarginRight=(parseInt((a.getComputedStyle(j,null)||{marginRight:0}).marginRight,10)||0)===0);if(q.attachEvent)for(o in{submit:1,change:1,focusin:1})n="on"+o,p=n in q,p||(q.setAttribute(n,"return;"),p=typeof q[n]=="function"),b[o+"Bubbles"]=p;k.removeChild(q),k=g=h=j=q=i=null,f(function(){var a,d,e,g,h,i,j,k,m,n,o,r=c.getElementsByTagName("body")[0];!r||(j=1,k="position:absolute;top:0;left:0;width:1px;height:1px;margin:0;",m="visibility:hidden;border:0;",n="style='"+k+"border:5px solid #000;padding:0;'",o="<div "+n+"><div></div></div>"+"<table "+n+" cellpadding='0' cellspacing='0'>"+"<tr><td></td></tr></table>",a=c.createElement("div"),a.style.cssText=m+"width:0;height:0;position:static;top:0;margin-top:"+j+"px",r.insertBefore(a,r.firstChild),q=c.createElement("div"),a.appendChild(q),q.innerHTML="<table><tr><td style='padding:0;border:0;display:none'></td><td>t</td></tr></table>",l=q.getElementsByTagName("td"),p=l[0].offsetHeight===0,l[0].style.display="",l[1].style.display="none",b.reliableHiddenOffsets=p&&l[0].offsetHeight===0,q.innerHTML="",q.style.width=q.style.paddingLeft="1px",f.boxModel=b.boxModel=q.offsetWidth===2,typeof q.style.zoom!="undefined"&&(q.style.display="inline",q.style.zoom=1,b.inlineBlockNeedsLayout=q.offsetWidth===2,q.style.display="",q.innerHTML="<div style='width:4px;'></div>",b.shrinkWrapBlocks=q.offsetWidth!==2),q.style.cssText=k+m,q.innerHTML=o,d=q.firstChild,e=d.firstChild,h=d.nextSibling.firstChild.firstChild,i={doesNotAddBorder:e.offsetTop!==5,doesAddBorderForTableAndCells:h.offsetTop===5},e.style.position="fixed",e.style.top="20px",i.fixedPosition=e.offsetTop===20||e.offsetTop===15,e.style.position=e.style.top="",d.style.overflow="hidden",d.style.position="relative",i.subtractsBorderForOverflowNotVisible=e.offsetTop===-5,i.doesNotIncludeMarginInBodyOffset=r.offsetTop!==j,r.removeChild(a),q=a=null,f.extend(b,i))});return b}();var j=/^(?:\{.*\}|\[.*\])$/,k=/([A-Z])/g;f.extend({cache:{},uuid:0,expando:"jQuery"+(f.fn.jquery+Math.random()).replace(/\D/g,""),noData:{embed:!0,object:"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000",applet:!0},hasData:function(a){a=a.nodeType?f.cache[a[f.expando]]:a[f.expando];return!!a&&!m(a)},data:function(a,c,d,e){if(!!f.acceptData(a)){var g,h,i,j=f.expando,k=typeof c=="string",l=a.nodeType,m=l?f.cache:a,n=l?a[j]:a[j]&&j,o=c==="events";if((!n||!m[n]||!o&&!e&&!m[n].data)&&k&&d===b)return;n||(l?a[j]=n=++f.uuid:n=j),m[n]||(m[n]={},l||(m[n].toJSON=f.noop));if(typeof c=="object"||typeof c=="function")e?m[n]=f.extend(m[n],c):m[n].data=f.extend(m[n].data,c);g=h=m[n],e||(h.data||(h.data={}),h=h.data),d!==b&&(h[f.camelCase(c)]=d);if(o&&!h[c])return g.events;k?(i=h[c],i==null&&(i=h[f.camelCase(c)])):i=h;return i}},removeData:function(a,b,c){if(!!f.acceptData(a)){var d,e,g,h=f.expando,i=a.nodeType,j=i?f.cache:a,k=i?a[h]:h;if(!j[k])return;if(b){d=c?j[k]:j[k].data;if(d){f.isArray(b)||(b in d?b=[b]:(b=f.camelCase(b),b in d?b=[b]:b=b.split(" ")));for(e=0,g=b.length;e<g;e++)delete d[b[e]];if(!(c?m:f.isEmptyObject)(d))return}}if(!c){delete j[k].data;if(!m(j[k]))return}f.support.deleteExpando||!j.setInterval?delete j[k]:j[k]=null,i&&(f.support.deleteExpando?delete a[h]:a.removeAttribute?a.removeAttribute(h):a[h]=null)}},_data:function(a,b,c){return f.data(a,b,c,!0)},acceptData:function(a){if(a.nodeName){var b=f.noData[a.nodeName.toLowerCase()];if(b)return b!==!0&&a.getAttribute("classid")===b}return!0}}),f.fn.extend({data:function(a,c){var d,e,g,h=null;if(typeof a=="undefined"){if(this.length){h=f.data(this[0]);if(this[0].nodeType===1&&!f._data(this[0],"parsedAttrs")){e=this[0].attributes;for(var i=0,j=e.length;i<j;i++)g=e[i].name,g.indexOf("data-")===0&&(g=f.camelCase(g.substring(5)),l(this[0],g,h[g]));f._data(this[0],"parsedAttrs",!0)}}return h}if(typeof a=="object")return this.each(function(){f.data(this,a)});d=a.split("."),d[1]=d[1]?"."+d[1]:"";if(c===b){h=this.triggerHandler("getData"+d[1]+"!",[d[0]]),h===b&&this.length&&(h=f.data(this[0],a),h=l(this[0],a,h));return h===b&&d[1]?this.data(d[0]):h}return this.each(function(){var b=f(this),e=[d[0],c];b.triggerHandler("setData"+d[1]+"!",e),f.data(this,a,c),b.triggerHandler("changeData"+d[1]+"!",e)})},removeData:function(a){return this.each(function(){f.removeData(this,a)})}}),f.extend({_mark:function(a,b){a&&(b=(b||"fx")+"mark",f._data(a,b,(f._data(a,b)||0)+1))},_unmark:function(a,b,c){a!==!0&&(c=b,b=a,a=!1);if(b){c=c||"fx";var d=c+"mark",e=a?0:(f._data(b,d)||1)-1;e?f._data(b,d,e):(f.removeData(b,d,!0),n(b,c,"mark"))}},queue:function(a,b,c){var d;if(a){b=(b||"fx")+"queue",d=f._data(a,b),c&&(!d||f.isArray(c)?d=f._data(a,b,f.makeArray(c)):d.push(c));return d||[]}},dequeue:function(a,b){b=b||"fx";var c=f.queue(a,b),d=c.shift(),e={};d==="inprogress"&&(d=c.shift()),d&&(b==="fx"&&c.unshift("inprogress"),f._data(a,b+".run",e),d.call(a,function(){f.dequeue(a,b)},e)),c.length||(f.removeData(a,b+"queue "+b+".run",!0),n(a,b,"queue"))}}),f.fn.extend({queue:function(a,c){typeof a!="string"&&(c=a,a="fx");if(c===b)return f.queue(this[0],a);return this.each(function(){var b=f.queue(this,a,c);a==="fx"&&b[0]!=="inprogress"&&f.dequeue(this,a)})},dequeue:function(a){return this.each(function(){f.dequeue(this,a)})},delay:function(a,b){a=f.fx?f.fx.speeds[a]||a:a,b=b||"fx";return this.queue(b,function(b,c){var d=setTimeout(b,a);c.stop=function(){clearTimeout(d)}})},clearQueue:function(a){return this.queue(a||"fx",[])},promise:function(a,c){function m(){--h||d.resolveWith(e,[e])}typeof a!="string"&&(c=a,a=b),a=a||"fx";var d=f.Deferred(),e=this,g=e.length,h=1,i=a+"defer",j=a+"queue",k=a+"mark",l;while(g--)if(l=f.data(e[g],i,b,!0)||(f.data(e[g],j,b,!0)||f.data(e[g],k,b,!0))&&f.data(e[g],i,f.Callbacks("once memory"),!0))h++,l.add(m);m();return d.promise()}});var o=/[\n\t\r]/g,p=/\s+/,q=/\r/g,r=/^(?:button|input)$/i,s=/^(?:button|input|object|select|textarea)$/i,t=/^a(?:rea)?$/i,u=/^(?:autofocus|autoplay|async|checked|controls|defer|disabled|hidden|loop|multiple|open|readonly|required|scoped|selected)$/i,v=f.support.getSetAttribute,w,x,y;f.fn.extend({attr:function(a,b){return f.access(this,a,b,!0,f.attr)},removeAttr:function(a){return this.each(function(){f.removeAttr(this,a)})},prop:function(a,b){return f.access(this,a,b,!0,f.prop)},removeProp:function(a){a=f.propFix[a]||a;return this.each(function(){try{this[a]=b,delete this[a]}catch(c){}})},addClass:function(a){var b,c,d,e,g,h,i;if(f.isFunction(a))return this.each(function(b){f(this).addClass(a.call(this,b,this.className))});if(a&&typeof a=="string"){b=a.split(p);for(c=0,d=this.length;c<d;c++){e=this[c];if(e.nodeType===1)if(!e.className&&b.length===1)e.className=a;else{g=" "+e.className+" ";for(h=0,i=b.length;h<i;h++)~g.indexOf(" "+b[h]+" ")||(g+=b[h]+" ");e.className=f.trim(g)}}}return this},removeClass:function(a){var c,d,e,g,h,i,j;if(f.isFunction(a))return this.each(function(b){f(this).removeClass(a.call(this,b,this.className))});if(a&&typeof a=="string"||a===b){c=(a||"").split(p);for(d=0,e=this.length;d<e;d++){g=this[d];if(g.nodeType===1&&g.className)if(a){h=(" "+g.className+" ").replace(o," ");for(i=0,j=c.length;i<j;i++)h=h.replace(" "+c[i]+" "," ");g.className=f.trim(h)}else g.className=""}}return this},toggleClass:function(a,b){var c=typeof a,d=typeof b=="boolean";if(f.isFunction(a))return this.each(function(c){f(this).toggleClass(a.call(this,c,this.className,b),b)});return this.each(function(){if(c==="string"){var e,g=0,h=f(this),i=b,j=a.split(p);while(e=j[g++])i=d?i:!h.hasClass(e),h[i?"addClass":"removeClass"](e)}else if(c==="undefined"||c==="boolean")this.className&&f._data(this,"__className__",this.className),this.className=this.className||a===!1?"":f._data(this,"__className__")||""})},hasClass:function(a){var b=" "+a+" ",c=0,d=this.length;for(;c<d;c++)if(this[c].nodeType===1&&(" "+this[c].className+" ").replace(o," ").indexOf(b)>-1)return!0;return!1},val:function(a){var c,d,e,g=this[0];{if(!!arguments.length){e=f.isFunction(a);return this.each(function(d){var g=f(this),h;if(this.nodeType===1){e?h=a.call(this,d,g.val()):h=a,h==null?h="":typeof h=="number"?h+="":f.isArray(h)&&(h=f.map(h,function(a){return a==null?"":a+""})),c=f.valHooks[this.nodeName.toLowerCase()]||f.valHooks[this.type];if(!c||!("set"in c)||c.set(this,h,"value")===b)this.value=h}})}if(g){c=f.valHooks[g.nodeName.toLowerCase()]||f.valHooks[g.type];if(c&&"get"in c&&(d=c.get(g,"value"))!==b)return d;d=g.value;return typeof d=="string"?d.replace(q,""):d==null?"":d}}}}),f.extend({valHooks:{option:{get:function(a){var b=a.attributes.value;return!b||b.specified?a.value:a.text}},select:{get:function(a){var b,c,d,e,g=a.selectedIndex,h=[],i=a.options,j=a.type==="select-one";if(g<0)return null;c=j?g:0,d=j?g+1:i.length;for(;c<d;c++){e=i[c];if(e.selected&&(f.support.optDisabled?!e.disabled:e.getAttribute("disabled")===null)&&(!e.parentNode.disabled||!f.nodeName(e.parentNode,"optgroup"))){b=f(e).val();if(j)return b;h.push(b)}}if(j&&!h.length&&i.length)return f(i[g]).val();return h},set:function(a,b){var c=f.makeArray(b);f(a).find("option").each(function(){this.selected=f.inArray(f(this).val(),c)>=0}),c.length||(a.selectedIndex=-1);return c}}},attrFn:{val:!0,css:!0,html:!0,text:!0,data:!0,width:!0,height:!0,offset:!0},attr:function(a,c,d,e){var g,h,i,j=a.nodeType;if(!!a&&j!==3&&j!==8&&j!==2){if(e&&c in f.attrFn)return f(a)[c](d);if(typeof a.getAttribute=="undefined")return f.prop(a,c,d);i=j!==1||!f.isXMLDoc(a),i&&(c=c.toLowerCase(),h=f.attrHooks[c]||(u.test(c)?x:w));if(d!==b){if(d===null){f.removeAttr(a,c);return}if(h&&"set"in h&&i&&(g=h.set(a,d,c))!==b)return g;a.setAttribute(c,""+d);return d}if(h&&"get"in h&&i&&(g=h.get(a,c))!==null)return g;g=a.getAttribute(c);return g===null?b:g}},removeAttr:function(a,b){var c,d,e,g,h=0;if(b&&a.nodeType===1){d=b.toLowerCase().split(p),g=d.length;for(;h<g;h++)e=d[h],e&&(c=f.propFix[e]||e,f.attr(a,e,""),a.removeAttribute(v?e:c),u.test(e)&&c in a&&(a[c]=!1))}},attrHooks:{type:{set:function(a,b){if(r.test(a.nodeName)&&a.parentNode)f.error("type property can't be changed");else if(!f.support.radioValue&&b==="radio"&&f.nodeName(a,"input")){var c=a.value;a.setAttribute("type",b),c&&(a.value=c);return b}}},value:{get:function(a,b){if(w&&f.nodeName(a,"button"))return w.get(a,b);return b in a?a.value:null},set:function(a,b,c){if(w&&f.nodeName(a,"button"))return w.set(a,b,c);a.value=b}}},propFix:{tabindex:"tabIndex",readonly:"readOnly","for":"htmlFor","class":"className",maxlength:"maxLength",cellspacing:"cellSpacing",cellpadding:"cellPadding",rowspan:"rowSpan",colspan:"colSpan",usemap:"useMap",frameborder:"frameBorder",contenteditable:"contentEditable"},prop:function(a,c,d){var e,g,h,i=a.nodeType;if(!!a&&i!==3&&i!==8&&i!==2){h=i!==1||!f.isXMLDoc(a),h&&(c=f.propFix[c]||c,g=f.propHooks[c]);return d!==b?g&&"set"in g&&(e=g.set(a,d,c))!==b?e:a[c]=d:g&&"get"in g&&(e=g.get(a,c))!==null?e:a[c]}},propHooks:{tabIndex:{get:function(a){var c=a.getAttributeNode("tabindex");return c&&c.specified?parseInt(c.value,10):s.test(a.nodeName)||t.test(a.nodeName)&&a.href?0:b}}}}),f.attrHooks.tabindex=f.propHooks.tabIndex,x={get:function(a,c){var d,e=f.prop(a,c);return e===!0||typeof e!="boolean"&&(d=a.getAttributeNode(c))&&d.nodeValue!==!1?c.toLowerCase():b},set:function(a,b,c){var d;b===!1?f.removeAttr(a,c):(d=f.propFix[c]||c,d in a&&(a[d]=!0),a.setAttribute(c,c.toLowerCase()));return c}},v||(y={name:!0,id:!0},w=f.valHooks.button={get:function(a,c){var d;d=a.getAttributeNode(c);return d&&(y[c]?d.nodeValue!=="":d.specified)?d.nodeValue:b},set:function(a,b,d){var e=a.getAttributeNode(d);e||(e=c.createAttribute(d),a.setAttributeNode(e));return e.nodeValue=b+""}},f.attrHooks.tabindex.set=w.set,f.each(["width","height"],function(a,b){f.attrHooks[b]=f.extend(f.attrHooks[b],{set:function(a,c){if(c===""){a.setAttribute(b,"auto");return c}}})}),f.attrHooks.contenteditable={get:w.get,set:function(a,b,c){b===""&&(b="false"),w.set(a,b,c)}}),f.support.hrefNormalized||f.each(["href","src","width","height"],function(a,c){f.attrHooks[c]=f.extend(f.attrHooks[c],{get:function(a){var d=a.getAttribute(c,2);return d===null?b:d}})}),f.support.style||(f.attrHooks.style={get:function(a){return a.style.cssText.toLowerCase()||b},set:function(a,b){return a.style.cssText=""+b}}),f.support.optSelected||(f.propHooks.selected=f.extend(f.propHooks.selected,{get:function(a){var b=a.parentNode;b&&(b.selectedIndex,b.parentNode&&b.parentNode.selectedIndex);return null}})),f.support.enctype||(f.propFix.enctype="encoding"),f.support.checkOn||f.each(["radio","checkbox"],function(){f.valHooks[this]={get:function(a){return a.getAttribute("value")===null?"on":a.value}}}),f.each(["radio","checkbox"],function(){f.valHooks[this]=f.extend(f.valHooks[this],{set:function(a,b){if(f.isArray(b))return a.checked=f.inArray(f(a).val(),b)>=0}})});var z=/^(?:textarea|input|select)$/i,A=/^([^\.]*)?(?:\.(.+))?$/,B=/\bhover(\.\S+)?\b/,C=/^key/,D=/^(?:mouse|contextmenu)|click/,E=/^(?:focusinfocus|focusoutblur)$/,F=/^(\w*)(?:#([\w\-]+))?(?:\.([\w\-]+))?$/,G=function(a){var b=F.exec(a);b&&(b[1]=(b[1]||"").toLowerCase(),b[3]=b[3]&&new RegExp("(?:^|\\s)"+b[3]+"(?:\\s|$)"));return b},H=function(a,b){var c=a.attributes||{};return(!b[1]||a.nodeName.toLowerCase()===b[1])&&(!b[2]||(c.id||{}).value===b[2])&&(!b[3]||b[3].test((c["class"]||{}).value))},I=function(a){return f.event.special.hover?a:a.replace(B,"mouseenter$1 mouseleave$1")};
f.event={add:function(a,c,d,e,g){var h,i,j,k,l,m,n,o,p,q,r,s;if(!(a.nodeType===3||a.nodeType===8||!c||!d||!(h=f._data(a)))){d.handler&&(p=d,d=p.handler),d.guid||(d.guid=f.guid++),j=h.events,j||(h.events=j={}),i=h.handle,i||(h.handle=i=function(a){return typeof f!="undefined"&&(!a||f.event.triggered!==a.type)?f.event.dispatch.apply(i.elem,arguments):b},i.elem=a),c=f.trim(I(c)).split(" ");for(k=0;k<c.length;k++){l=A.exec(c[k])||[],m=l[1],n=(l[2]||"").split(".").sort(),s=f.event.special[m]||{},m=(g?s.delegateType:s.bindType)||m,s=f.event.special[m]||{},o=f.extend({type:m,origType:l[1],data:e,handler:d,guid:d.guid,selector:g,quick:G(g),namespace:n.join(".")},p),r=j[m];if(!r){r=j[m]=[],r.delegateCount=0;if(!s.setup||s.setup.call(a,e,n,i)===!1)a.addEventListener?a.addEventListener(m,i,!1):a.attachEvent&&a.attachEvent("on"+m,i)}s.add&&(s.add.call(a,o),o.handler.guid||(o.handler.guid=d.guid)),g?r.splice(r.delegateCount++,0,o):r.push(o),f.event.global[m]=!0}a=null}},global:{},remove:function(a,b,c,d,e){var g=f.hasData(a)&&f._data(a),h,i,j,k,l,m,n,o,p,q,r,s;if(!!g&&!!(o=g.events)){b=f.trim(I(b||"")).split(" ");for(h=0;h<b.length;h++){i=A.exec(b[h])||[],j=k=i[1],l=i[2];if(!j){for(j in o)f.event.remove(a,j+b[h],c,d,!0);continue}p=f.event.special[j]||{},j=(d?p.delegateType:p.bindType)||j,r=o[j]||[],m=r.length,l=l?new RegExp("(^|\\.)"+l.split(".").sort().join("\\.(?:.*\\.)?")+"(\\.|$)"):null;for(n=0;n<r.length;n++)s=r[n],(e||k===s.origType)&&(!c||c.guid===s.guid)&&(!l||l.test(s.namespace))&&(!d||d===s.selector||d==="**"&&s.selector)&&(r.splice(n--,1),s.selector&&r.delegateCount--,p.remove&&p.remove.call(a,s));r.length===0&&m!==r.length&&((!p.teardown||p.teardown.call(a,l)===!1)&&f.removeEvent(a,j,g.handle),delete o[j])}f.isEmptyObject(o)&&(q=g.handle,q&&(q.elem=null),f.removeData(a,["events","handle"],!0))}},customEvent:{getData:!0,setData:!0,changeData:!0},trigger:function(c,d,e,g){if(!e||e.nodeType!==3&&e.nodeType!==8){var h=c.type||c,i=[],j,k,l,m,n,o,p,q,r,s;if(E.test(h+f.event.triggered))return;h.indexOf("!")>=0&&(h=h.slice(0,-1),k=!0),h.indexOf(".")>=0&&(i=h.split("."),h=i.shift(),i.sort());if((!e||f.event.customEvent[h])&&!f.event.global[h])return;c=typeof c=="object"?c[f.expando]?c:new f.Event(h,c):new f.Event(h),c.type=h,c.isTrigger=!0,c.exclusive=k,c.namespace=i.join("."),c.namespace_re=c.namespace?new RegExp("(^|\\.)"+i.join("\\.(?:.*\\.)?")+"(\\.|$)"):null,o=h.indexOf(":")<0?"on"+h:"";if(!e){j=f.cache;for(l in j)j[l].events&&j[l].events[h]&&f.event.trigger(c,d,j[l].handle.elem,!0);return}c.result=b,c.target||(c.target=e),d=d!=null?f.makeArray(d):[],d.unshift(c),p=f.event.special[h]||{};if(p.trigger&&p.trigger.apply(e,d)===!1)return;r=[[e,p.bindType||h]];if(!g&&!p.noBubble&&!f.isWindow(e)){s=p.delegateType||h,m=E.test(s+h)?e:e.parentNode,n=null;for(;m;m=m.parentNode)r.push([m,s]),n=m;n&&n===e.ownerDocument&&r.push([n.defaultView||n.parentWindow||a,s])}for(l=0;l<r.length&&!c.isPropagationStopped();l++)m=r[l][0],c.type=r[l][1],q=(f._data(m,"events")||{})[c.type]&&f._data(m,"handle"),q&&q.apply(m,d),q=o&&m[o],q&&f.acceptData(m)&&q.apply(m,d)===!1&&c.preventDefault();c.type=h,!g&&!c.isDefaultPrevented()&&(!p._default||p._default.apply(e.ownerDocument,d)===!1)&&(h!=="click"||!f.nodeName(e,"a"))&&f.acceptData(e)&&o&&e[h]&&(h!=="focus"&&h!=="blur"||c.target.offsetWidth!==0)&&!f.isWindow(e)&&(n=e[o],n&&(e[o]=null),f.event.triggered=h,e[h](),f.event.triggered=b,n&&(e[o]=n));return c.result}},dispatch:function(c){c=f.event.fix(c||a.event);var d=(f._data(this,"events")||{})[c.type]||[],e=d.delegateCount,g=[].slice.call(arguments,0),h=!c.exclusive&&!c.namespace,i=[],j,k,l,m,n,o,p,q,r,s,t;g[0]=c,c.delegateTarget=this;if(e&&!c.target.disabled&&(!c.button||c.type!=="click")){m=f(this),m.context=this.ownerDocument||this;for(l=c.target;l!=this;l=l.parentNode||this){o={},q=[],m[0]=l;for(j=0;j<e;j++)r=d[j],s=r.selector,o[s]===b&&(o[s]=r.quick?H(l,r.quick):m.is(s)),o[s]&&q.push(r);q.length&&i.push({elem:l,matches:q})}}d.length>e&&i.push({elem:this,matches:d.slice(e)});for(j=0;j<i.length&&!c.isPropagationStopped();j++){p=i[j],c.currentTarget=p.elem;for(k=0;k<p.matches.length&&!c.isImmediatePropagationStopped();k++){r=p.matches[k];if(h||!c.namespace&&!r.namespace||c.namespace_re&&c.namespace_re.test(r.namespace))c.data=r.data,c.handleObj=r,n=((f.event.special[r.origType]||{}).handle||r.handler).apply(p.elem,g),n!==b&&(c.result=n,n===!1&&(c.preventDefault(),c.stopPropagation()))}}return c.result},props:"attrChange attrName relatedNode srcElement altKey bubbles cancelable ctrlKey currentTarget eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),fixHooks:{},keyHooks:{props:"char charCode key keyCode".split(" "),filter:function(a,b){a.which==null&&(a.which=b.charCode!=null?b.charCode:b.keyCode);return a}},mouseHooks:{props:"button buttons clientX clientY fromElement offsetX offsetY pageX pageY screenX screenY toElement".split(" "),filter:function(a,d){var e,f,g,h=d.button,i=d.fromElement;a.pageX==null&&d.clientX!=null&&(e=a.target.ownerDocument||c,f=e.documentElement,g=e.body,a.pageX=d.clientX+(f&&f.scrollLeft||g&&g.scrollLeft||0)-(f&&f.clientLeft||g&&g.clientLeft||0),a.pageY=d.clientY+(f&&f.scrollTop||g&&g.scrollTop||0)-(f&&f.clientTop||g&&g.clientTop||0)),!a.relatedTarget&&i&&(a.relatedTarget=i===a.target?d.toElement:i),!a.which&&h!==b&&(a.which=h&1?1:h&2?3:h&4?2:0);return a}},fix:function(a){if(a[f.expando])return a;var d,e,g=a,h=f.event.fixHooks[a.type]||{},i=h.props?this.props.concat(h.props):this.props;a=f.Event(g);for(d=i.length;d;)e=i[--d],a[e]=g[e];a.target||(a.target=g.srcElement||c),a.target.nodeType===3&&(a.target=a.target.parentNode),a.metaKey===b&&(a.metaKey=a.ctrlKey);return h.filter?h.filter(a,g):a},special:{ready:{setup:f.bindReady},load:{noBubble:!0},focus:{delegateType:"focusin"},blur:{delegateType:"focusout"},beforeunload:{setup:function(a,b,c){f.isWindow(this)&&(this.onbeforeunload=c)},teardown:function(a,b){this.onbeforeunload===b&&(this.onbeforeunload=null)}}},simulate:function(a,b,c,d){var e=f.extend(new f.Event,c,{type:a,isSimulated:!0,originalEvent:{}});d?f.event.trigger(e,null,b):f.event.dispatch.call(b,e),e.isDefaultPrevented()&&c.preventDefault()}},f.event.handle=f.event.dispatch,f.removeEvent=c.removeEventListener?function(a,b,c){a.removeEventListener&&a.removeEventListener(b,c,!1)}:function(a,b,c){a.detachEvent&&a.detachEvent("on"+b,c)},f.Event=function(a,b){if(!(this instanceof f.Event))return new f.Event(a,b);a&&a.type?(this.originalEvent=a,this.type=a.type,this.isDefaultPrevented=a.defaultPrevented||a.returnValue===!1||a.getPreventDefault&&a.getPreventDefault()?K:J):this.type=a,b&&f.extend(this,b),this.timeStamp=a&&a.timeStamp||f.now(),this[f.expando]=!0},f.Event.prototype={preventDefault:function(){this.isDefaultPrevented=K;var a=this.originalEvent;!a||(a.preventDefault?a.preventDefault():a.returnValue=!1)},stopPropagation:function(){this.isPropagationStopped=K;var a=this.originalEvent;!a||(a.stopPropagation&&a.stopPropagation(),a.cancelBubble=!0)},stopImmediatePropagation:function(){this.isImmediatePropagationStopped=K,this.stopPropagation()},isDefaultPrevented:J,isPropagationStopped:J,isImmediatePropagationStopped:J},f.each({mouseenter:"mouseover",mouseleave:"mouseout"},function(a,b){f.event.special[a]={delegateType:b,bindType:b,handle:function(a){var c=this,d=a.relatedTarget,e=a.handleObj,g=e.selector,h;if(!d||d!==c&&!f.contains(c,d))a.type=e.origType,h=e.handler.apply(this,arguments),a.type=b;return h}}}),f.support.submitBubbles||(f.event.special.submit={setup:function(){if(f.nodeName(this,"form"))return!1;f.event.add(this,"click._submit keypress._submit",function(a){var c=a.target,d=f.nodeName(c,"input")||f.nodeName(c,"button")?c.form:b;d&&!d._submit_attached&&(f.event.add(d,"submit._submit",function(a){this.parentNode&&!a.isTrigger&&f.event.simulate("submit",this.parentNode,a,!0)}),d._submit_attached=!0)})},teardown:function(){if(f.nodeName(this,"form"))return!1;f.event.remove(this,"._submit")}}),f.support.changeBubbles||(f.event.special.change={setup:function(){if(z.test(this.nodeName)){if(this.type==="checkbox"||this.type==="radio")f.event.add(this,"propertychange._change",function(a){a.originalEvent.propertyName==="checked"&&(this._just_changed=!0)}),f.event.add(this,"click._change",function(a){this._just_changed&&!a.isTrigger&&(this._just_changed=!1,f.event.simulate("change",this,a,!0))});return!1}f.event.add(this,"beforeactivate._change",function(a){var b=a.target;z.test(b.nodeName)&&!b._change_attached&&(f.event.add(b,"change._change",function(a){this.parentNode&&!a.isSimulated&&!a.isTrigger&&f.event.simulate("change",this.parentNode,a,!0)}),b._change_attached=!0)})},handle:function(a){var b=a.target;if(this!==b||a.isSimulated||a.isTrigger||b.type!=="radio"&&b.type!=="checkbox")return a.handleObj.handler.apply(this,arguments)},teardown:function(){f.event.remove(this,"._change");return z.test(this.nodeName)}}),f.support.focusinBubbles||f.each({focus:"focusin",blur:"focusout"},function(a,b){var d=0,e=function(a){f.event.simulate(b,a.target,f.event.fix(a),!0)};f.event.special[b]={setup:function(){d++===0&&c.addEventListener(a,e,!0)},teardown:function(){--d===0&&c.removeEventListener(a,e,!0)}}}),f.fn.extend({on:function(a,c,d,e,g){var h,i;if(typeof a=="object"){typeof c!="string"&&(d=c,c=b);for(i in a)this.on(i,c,d,a[i],g);return this}d==null&&e==null?(e=c,d=c=b):e==null&&(typeof c=="string"?(e=d,d=b):(e=d,d=c,c=b));if(e===!1)e=J;else if(!e)return this;g===1&&(h=e,e=function(a){f().off(a);return h.apply(this,arguments)},e.guid=h.guid||(h.guid=f.guid++));return this.each(function(){f.event.add(this,a,e,d,c)})},one:function(a,b,c,d){return this.on.call(this,a,b,c,d,1)},off:function(a,c,d){if(a&&a.preventDefault&&a.handleObj){var e=a.handleObj;f(a.delegateTarget).off(e.namespace?e.type+"."+e.namespace:e.type,e.selector,e.handler);return this}if(typeof a=="object"){for(var g in a)this.off(g,c,a[g]);return this}if(c===!1||typeof c=="function")d=c,c=b;d===!1&&(d=J);return this.each(function(){f.event.remove(this,a,d,c)})},bind:function(a,b,c){return this.on(a,null,b,c)},unbind:function(a,b){return this.off(a,null,b)},live:function(a,b,c){f(this.context).on(a,this.selector,b,c);return this},die:function(a,b){f(this.context).off(a,this.selector||"**",b);return this},delegate:function(a,b,c,d){return this.on(b,a,c,d)},undelegate:function(a,b,c){return arguments.length==1?this.off(a,"**"):this.off(b,a,c)},trigger:function(a,b){return this.each(function(){f.event.trigger(a,b,this)})},triggerHandler:function(a,b){if(this[0])return f.event.trigger(a,b,this[0],!0)},toggle:function(a){var b=arguments,c=a.guid||f.guid++,d=0,e=function(c){var e=(f._data(this,"lastToggle"+a.guid)||0)%d;f._data(this,"lastToggle"+a.guid,e+1),c.preventDefault();return b[e].apply(this,arguments)||!1};e.guid=c;while(d<b.length)b[d++].guid=c;return this.click(e)},hover:function(a,b){return this.mouseenter(a).mouseleave(b||a)}}),f.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu".split(" "),function(a,b){f.fn[b]=function(a,c){c==null&&(c=a,a=null);return arguments.length>0?this.on(b,null,a,c):this.trigger(b)},f.attrFn&&(f.attrFn[b]=!0),C.test(b)&&(f.event.fixHooks[b]=f.event.keyHooks),D.test(b)&&(f.event.fixHooks[b]=f.event.mouseHooks)}),function(){function x(a,b,c,e,f,g){for(var h=0,i=e.length;h<i;h++){var j=e[h];if(j){var k=!1;j=j[a];while(j){if(j[d]===c){k=e[j.sizset];break}if(j.nodeType===1){g||(j[d]=c,j.sizset=h);if(typeof b!="string"){if(j===b){k=!0;break}}else if(m.filter(b,[j]).length>0){k=j;break}}j=j[a]}e[h]=k}}}function w(a,b,c,e,f,g){for(var h=0,i=e.length;h<i;h++){var j=e[h];if(j){var k=!1;j=j[a];while(j){if(j[d]===c){k=e[j.sizset];break}j.nodeType===1&&!g&&(j[d]=c,j.sizset=h);if(j.nodeName.toLowerCase()===b){k=j;break}j=j[a]}e[h]=k}}}var a=/((?:\((?:\([^()]+\)|[^()]+)+\)|\[(?:\[[^\[\]]*\]|['"][^'"]*['"]|[^\[\]'"]+)+\]|\\.|[^ >+~,(\[\\]+)+|[>+~])(\s*,\s*)?((?:.|\r|\n)*)/g,d="sizcache"+(Math.random()+"").replace(".",""),e=0,g=Object.prototype.toString,h=!1,i=!0,j=/\\/g,k=/\r\n/g,l=/\W/;[0,0].sort(function(){i=!1;return 0});var m=function(b,d,e,f){e=e||[],d=d||c;var h=d;if(d.nodeType!==1&&d.nodeType!==9)return[];if(!b||typeof b!="string")return e;var i,j,k,l,n,q,r,t,u=!0,v=m.isXML(d),w=[],x=b;do{a.exec(""),i=a.exec(x);if(i){x=i[3],w.push(i[1]);if(i[2]){l=i[3];break}}}while(i);if(w.length>1&&p.exec(b))if(w.length===2&&o.relative[w[0]])j=y(w[0]+w[1],d,f);else{j=o.relative[w[0]]?[d]:m(w.shift(),d);while(w.length)b=w.shift(),o.relative[b]&&(b+=w.shift()),j=y(b,j,f)}else{!f&&w.length>1&&d.nodeType===9&&!v&&o.match.ID.test(w[0])&&!o.match.ID.test(w[w.length-1])&&(n=m.find(w.shift(),d,v),d=n.expr?m.filter(n.expr,n.set)[0]:n.set[0]);if(d){n=f?{expr:w.pop(),set:s(f)}:m.find(w.pop(),w.length===1&&(w[0]==="~"||w[0]==="+")&&d.parentNode?d.parentNode:d,v),j=n.expr?m.filter(n.expr,n.set):n.set,w.length>0?k=s(j):u=!1;while(w.length)q=w.pop(),r=q,o.relative[q]?r=w.pop():q="",r==null&&(r=d),o.relative[q](k,r,v)}else k=w=[]}k||(k=j),k||m.error(q||b);if(g.call(k)==="[object Array]")if(!u)e.push.apply(e,k);else if(d&&d.nodeType===1)for(t=0;k[t]!=null;t++)k[t]&&(k[t]===!0||k[t].nodeType===1&&m.contains(d,k[t]))&&e.push(j[t]);else for(t=0;k[t]!=null;t++)k[t]&&k[t].nodeType===1&&e.push(j[t]);else s(k,e);l&&(m(l,h,e,f),m.uniqueSort(e));return e};m.uniqueSort=function(a){if(u){h=i,a.sort(u);if(h)for(var b=1;b<a.length;b++)a[b]===a[b-1]&&a.splice(b--,1)}return a},m.matches=function(a,b){return m(a,null,null,b)},m.matchesSelector=function(a,b){return m(b,null,null,[a]).length>0},m.find=function(a,b,c){var d,e,f,g,h,i;if(!a)return[];for(e=0,f=o.order.length;e<f;e++){h=o.order[e];if(g=o.leftMatch[h].exec(a)){i=g[1],g.splice(1,1);if(i.substr(i.length-1)!=="\\"){g[1]=(g[1]||"").replace(j,""),d=o.find[h](g,b,c);if(d!=null){a=a.replace(o.match[h],"");break}}}}d||(d=typeof b.getElementsByTagName!="undefined"?b.getElementsByTagName("*"):[]);return{set:d,expr:a}},m.filter=function(a,c,d,e){var f,g,h,i,j,k,l,n,p,q=a,r=[],s=c,t=c&&c[0]&&m.isXML(c[0]);while(a&&c.length){for(h in o.filter)if((f=o.leftMatch[h].exec(a))!=null&&f[2]){k=o.filter[h],l=f[1],g=!1,f.splice(1,1);if(l.substr(l.length-1)==="\\")continue;s===r&&(r=[]);if(o.preFilter[h]){f=o.preFilter[h](f,s,d,r,e,t);if(!f)g=i=!0;else if(f===!0)continue}if(f)for(n=0;(j=s[n])!=null;n++)j&&(i=k(j,f,n,s),p=e^i,d&&i!=null?p?g=!0:s[n]=!1:p&&(r.push(j),g=!0));if(i!==b){d||(s=r),a=a.replace(o.match[h],"");if(!g)return[];break}}if(a===q)if(g==null)m.error(a);else break;q=a}return s},m.error=function(a){throw new Error("Syntax error, unrecognized expression: "+a)};var n=m.getText=function(a){var b,c,d=a.nodeType,e="";if(d){if(d===1||d===9){if(typeof a.textContent=="string")return a.textContent;if(typeof a.innerText=="string")return a.innerText.replace(k,"");for(a=a.firstChild;a;a=a.nextSibling)e+=n(a)}else if(d===3||d===4)return a.nodeValue}else for(b=0;c=a[b];b++)c.nodeType!==8&&(e+=n(c));return e},o=m.selectors={order:["ID","NAME","TAG"],match:{ID:/#((?:[\w\u00c0-\uFFFF\-]|\\.)+)/,CLASS:/\.((?:[\w\u00c0-\uFFFF\-]|\\.)+)/,NAME:/\[name=['"]*((?:[\w\u00c0-\uFFFF\-]|\\.)+)['"]*\]/,ATTR:/\[\s*((?:[\w\u00c0-\uFFFF\-]|\\.)+)\s*(?:(\S?=)\s*(?:(['"])(.*?)\3|(#?(?:[\w\u00c0-\uFFFF\-]|\\.)*)|)|)\s*\]/,TAG:/^((?:[\w\u00c0-\uFFFF\*\-]|\\.)+)/,CHILD:/:(only|nth|last|first)-child(?:\(\s*(even|odd|(?:[+\-]?\d+|(?:[+\-]?\d*)?n\s*(?:[+\-]\s*\d+)?))\s*\))?/,POS:/:(nth|eq|gt|lt|first|last|even|odd)(?:\((\d*)\))?(?=[^\-]|$)/,PSEUDO:/:((?:[\w\u00c0-\uFFFF\-]|\\.)+)(?:\((['"]?)((?:\([^\)]+\)|[^\(\)]*)+)\2\))?/},leftMatch:{},attrMap:{"class":"className","for":"htmlFor"},attrHandle:{href:function(a){return a.getAttribute("href")},type:function(a){return a.getAttribute("type")}},relative:{"+":function(a,b){var c=typeof b=="string",d=c&&!l.test(b),e=c&&!d;d&&(b=b.toLowerCase());for(var f=0,g=a.length,h;f<g;f++)if(h=a[f]){while((h=h.previousSibling)&&h.nodeType!==1);a[f]=e||h&&h.nodeName.toLowerCase()===b?h||!1:h===b}e&&m.filter(b,a,!0)},">":function(a,b){var c,d=typeof b=="string",e=0,f=a.length;if(d&&!l.test(b)){b=b.toLowerCase();for(;e<f;e++){c=a[e];if(c){var g=c.parentNode;a[e]=g.nodeName.toLowerCase()===b?g:!1}}}else{for(;e<f;e++)c=a[e],c&&(a[e]=d?c.parentNode:c.parentNode===b);d&&m.filter(b,a,!0)}},"":function(a,b,c){var d,f=e++,g=x;typeof b=="string"&&!l.test(b)&&(b=b.toLowerCase(),d=b,g=w),g("parentNode",b,f,a,d,c)},"~":function(a,b,c){var d,f=e++,g=x;typeof b=="string"&&!l.test(b)&&(b=b.toLowerCase(),d=b,g=w),g("previousSibling",b,f,a,d,c)}},find:{ID:function(a,b,c){if(typeof b.getElementById!="undefined"&&!c){var d=b.getElementById(a[1]);return d&&d.parentNode?[d]:[]}},NAME:function(a,b){if(typeof b.getElementsByName!="undefined"){var c=[],d=b.getElementsByName(a[1]);for(var e=0,f=d.length;e<f;e++)d[e].getAttribute("name")===a[1]&&c.push(d[e]);return c.length===0?null:c}},TAG:function(a,b){if(typeof b.getElementsByTagName!="undefined")return b.getElementsByTagName(a[1])}},preFilter:{CLASS:function(a,b,c,d,e,f){a=" "+a[1].replace(j,"")+" ";if(f)return a;for(var g=0,h;(h=b[g])!=null;g++)h&&(e^(h.className&&(" "+h.className+" ").replace(/[\t\n\r]/g," ").indexOf(a)>=0)?c||d.push(h):c&&(b[g]=!1));return!1},ID:function(a){return a[1].replace(j,"")},TAG:function(a,b){return a[1].replace(j,"").toLowerCase()},CHILD:function(a){if(a[1]==="nth"){a[2]||m.error(a[0]),a[2]=a[2].replace(/^\+|\s*/g,"");var b=/(-?)(\d*)(?:n([+\-]?\d*))?/.exec(a[2]==="even"&&"2n"||a[2]==="odd"&&"2n+1"||!/\D/.test(a[2])&&"0n+"+a[2]||a[2]);a[2]=b[1]+(b[2]||1)-0,a[3]=b[3]-0}else a[2]&&m.error(a[0]);a[0]=e++;return a},ATTR:function(a,b,c,d,e,f){var g=a[1]=a[1].replace(j,"");!f&&o.attrMap[g]&&(a[1]=o.attrMap[g]),a[4]=(a[4]||a[5]||"").replace(j,""),a[2]==="~="&&(a[4]=" "+a[4]+" ");return a},PSEUDO:function(b,c,d,e,f){if(b[1]==="not")if((a.exec(b[3])||"").length>1||/^\w/.test(b[3]))b[3]=m(b[3],null,null,c);else{var g=m.filter(b[3],c,d,!0^f);d||e.push.apply(e,g);return!1}else if(o.match.POS.test(b[0])||o.match.CHILD.test(b[0]))return!0;return b},POS:function(a){a.unshift(!0);return a}},filters:{enabled:function(a){return a.disabled===!1&&a.type!=="hidden"},disabled:function(a){return a.disabled===!0},checked:function(a){return a.checked===!0},selected:function(a){a.parentNode&&a.parentNode.selectedIndex;return a.selected===!0},parent:function(a){return!!a.firstChild},empty:function(a){return!a.firstChild},has:function(a,b,c){return!!m(c[3],a).length},header:function(a){return/h\d/i.test(a.nodeName)},text:function(a){var b=a.getAttribute("type"),c=a.type;return a.nodeName.toLowerCase()==="input"&&"text"===c&&(b===c||b===null)},radio:function(a){return a.nodeName.toLowerCase()==="input"&&"radio"===a.type},checkbox:function(a){return a.nodeName.toLowerCase()==="input"&&"checkbox"===a.type},file:function(a){return a.nodeName.toLowerCase()==="input"&&"file"===a.type},password:function(a){return a.nodeName.toLowerCase()==="input"&&"password"===a.type},submit:function(a){var b=a.nodeName.toLowerCase();return(b==="input"||b==="button")&&"submit"===a.type},image:function(a){return a.nodeName.toLowerCase()==="input"&&"image"===a.type},reset:function(a){var b=a.nodeName.toLowerCase();return(b==="input"||b==="button")&&"reset"===a.type},button:function(a){var b=a.nodeName.toLowerCase();return b==="input"&&"button"===a.type||b==="button"},input:function(a){return/input|select|textarea|button/i.test(a.nodeName)},focus:function(a){return a===a.ownerDocument.activeElement}},setFilters:{first:function(a,b){return b===0},last:function(a,b,c,d){return b===d.length-1},even:function(a,b){return b%2===0},odd:function(a,b){return b%2===1},lt:function(a,b,c){return b<c[3]-0},gt:function(a,b,c){return b>c[3]-0},nth:function(a,b,c){return c[3]-0===b},eq:function(a,b,c){return c[3]-0===b}},filter:{PSEUDO:function(a,b,c,d){var e=b[1],f=o.filters[e];if(f)return f(a,c,b,d);if(e==="contains")return(a.textContent||a.innerText||n([a])||"").indexOf(b[3])>=0;if(e==="not"){var g=b[3];for(var h=0,i=g.length;h<i;h++)if(g[h]===a)return!1;return!0}m.error(e)},CHILD:function(a,b){var c,e,f,g,h,i,j,k=b[1],l=a;switch(k){case"only":case"first":while(l=l.previousSibling)if(l.nodeType===1)return!1;if(k==="first")return!0;l=a;case"last":while(l=l.nextSibling)if(l.nodeType===1)return!1;return!0;case"nth":c=b[2],e=b[3];if(c===1&&e===0)return!0;f=b[0],g=a.parentNode;if(g&&(g[d]!==f||!a.nodeIndex)){i=0;for(l=g.firstChild;l;l=l.nextSibling)l.nodeType===1&&(l.nodeIndex=++i);g[d]=f}j=a.nodeIndex-e;return c===0?j===0:j%c===0&&j/c>=0}},ID:function(a,b){return a.nodeType===1&&a.getAttribute("id")===b},TAG:function(a,b){return b==="*"&&a.nodeType===1||!!a.nodeName&&a.nodeName.toLowerCase()===b},CLASS:function(a,b){return(" "+(a.className||a.getAttribute("class"))+" ").indexOf(b)>-1},ATTR:function(a,b){var c=b[1],d=m.attr?m.attr(a,c):o.attrHandle[c]?o.attrHandle[c](a):a[c]!=null?a[c]:a.getAttribute(c),e=d+"",f=b[2],g=b[4];return d==null?f==="!=":!f&&m.attr?d!=null:f==="="?e===g:f==="*="?e.indexOf(g)>=0:f==="~="?(" "+e+" ").indexOf(g)>=0:g?f==="!="?e!==g:f==="^="?e.indexOf(g)===0:f==="$="?e.substr(e.length-g.length)===g:f==="|="?e===g||e.substr(0,g.length+1)===g+"-":!1:e&&d!==!1},POS:function(a,b,c,d){var e=b[2],f=o.setFilters[e];if(f)return f(a,c,b,d)}}},p=o.match.POS,q=function(a,b){return"\\"+(b-0+1)};for(var r in o.match)o.match[r]=new RegExp(o.match[r].source+/(?![^\[]*\])(?![^\(]*\))/.source),o.leftMatch[r]=new RegExp(/(^(?:.|\r|\n)*?)/.source+o.match[r].source.replace(/\\(\d+)/g,q));var s=function(a,b){a=Array.prototype.slice.call(a,0);if(b){b.push.apply(b,a);return b}return a};try{Array.prototype.slice.call(c.documentElement.childNodes,0)[0].nodeType}catch(t){s=function(a,b){var c=0,d=b||[];if(g.call(a)==="[object Array]")Array.prototype.push.apply(d,a);else if(typeof a.length=="number")for(var e=a.length;c<e;c++)d.push(a[c]);else for(;a[c];c++)d.push(a[c]);return d}}var u,v;c.documentElement.compareDocumentPosition?u=function(a,b){if(a===b){h=!0;return 0}if(!a.compareDocumentPosition||!b.compareDocumentPosition)return a.compareDocumentPosition?-1:1;return a.compareDocumentPosition(b)&4?-1:1}:(u=function(a,b){if(a===b){h=!0;return 0}if(a.sourceIndex&&b.sourceIndex)return a.sourceIndex-b.sourceIndex;var c,d,e=[],f=[],g=a.parentNode,i=b.parentNode,j=g;if(g===i)return v(a,b);if(!g)return-1;if(!i)return 1;while(j)e.unshift(j),j=j.parentNode;j=i;while(j)f.unshift(j),j=j.parentNode;c=e.length,d=f.length;for(var k=0;k<c&&k<d;k++)if(e[k]!==f[k])return v(e[k],f[k]);return k===c?v(a,f[k],-1):v(e[k],b,1)},v=function(a,b,c){if(a===b)return c;var d=a.nextSibling;while(d){if(d===b)return-1;d=d.nextSibling}return 1}),function(){var a=c.createElement("div"),d="script"+(new Date).getTime(),e=c.documentElement;a.innerHTML="<a name='"+d+"'/>",e.insertBefore(a,e.firstChild),c.getElementById(d)&&(o.find.ID=function(a,c,d){if(typeof c.getElementById!="undefined"&&!d){var e=c.getElementById(a[1]);return e?e.id===a[1]||typeof e.getAttributeNode!="undefined"&&e.getAttributeNode("id").nodeValue===a[1]?[e]:b:[]}},o.filter.ID=function(a,b){var c=typeof a.getAttributeNode!="undefined"&&a.getAttributeNode("id");return a.nodeType===1&&c&&c.nodeValue===b}),e.removeChild(a),e=a=null}(),function(){var a=c.createElement("div");a.appendChild(c.createComment("")),a.getElementsByTagName("*").length>0&&(o.find.TAG=function(a,b){var c=b.getElementsByTagName(a[1]);if(a[1]==="*"){var d=[];for(var e=0;c[e];e++)c[e].nodeType===1&&d.push(c[e]);c=d}return c}),a.innerHTML="<a href='#'></a>",a.firstChild&&typeof a.firstChild.getAttribute!="undefined"&&a.firstChild.getAttribute("href")!=="#"&&(o.attrHandle.href=function(a){return a.getAttribute("href",2)}),a=null}(),c.querySelectorAll&&function(){var a=m,b=c.createElement("div"),d="__sizzle__";b.innerHTML="<p class='TEST'></p>";if(!b.querySelectorAll||b.querySelectorAll(".TEST").length!==0){m=function(b,e,f,g){e=e||c;if(!g&&!m.isXML(e)){var h=/^(\w+$)|^\.([\w\-]+$)|^#([\w\-]+$)/.exec(b);if(h&&(e.nodeType===1||e.nodeType===9)){if(h[1])return s(e.getElementsByTagName(b),f);if(h[2]&&o.find.CLASS&&e.getElementsByClassName)return s(e.getElementsByClassName(h[2]),f)}if(e.nodeType===9){if(b==="body"&&e.body)return s([e.body],f);if(h&&h[3]){var i=e.getElementById(h[3]);if(!i||!i.parentNode)return s([],f);if(i.id===h[3])return s([i],f)}try{return s(e.querySelectorAll(b),f)}catch(j){}}else if(e.nodeType===1&&e.nodeName.toLowerCase()!=="object"){var k=e,l=e.getAttribute("id"),n=l||d,p=e.parentNode,q=/^\s*[+~]/.test(b);l?n=n.replace(/'/g,"\\$&"):e.setAttribute("id",n),q&&p&&(e=e.parentNode);try{if(!q||p)return s(e.querySelectorAll("[id='"+n+"'] "+b),f)}catch(r){}finally{l||k.removeAttribute("id")}}}return a(b,e,f,g)};for(var e in a)m[e]=a[e];b=null}}(),function(){var a=c.documentElement,b=a.matchesSelector||a.mozMatchesSelector||a.webkitMatchesSelector||a.msMatchesSelector;if(b){var d=!b.call(c.createElement("div"),"div"),e=!1;try{b.call(c.documentElement,"[test!='']:sizzle")}catch(f){e=!0}m.matchesSelector=function(a,c){c=c.replace(/\=\s*([^'"\]]*)\s*\]/g,"='$1']");if(!m.isXML(a))try{if(e||!o.match.PSEUDO.test(c)&&!/!=/.test(c)){var f=b.call(a,c);if(f||!d||a.document&&a.document.nodeType!==11)return f}}catch(g){}return m(c,null,null,[a]).length>0}}}(),function(){var a=c.createElement("div");a.innerHTML="<div class='test e'></div><div class='test'></div>";if(!!a.getElementsByClassName&&a.getElementsByClassName("e").length!==0){a.lastChild.className="e";if(a.getElementsByClassName("e").length===1)return;o.order.splice(1,0,"CLASS"),o.find.CLASS=function(a,b,c){if(typeof b.getElementsByClassName!="undefined"&&!c)return b.getElementsByClassName(a[1])},a=null}}(),c.documentElement.contains?m.contains=function(a,b){return a!==b&&(a.contains?a.contains(b):!0)}:c.documentElement.compareDocumentPosition?m.contains=function(a,b){return!!(a.compareDocumentPosition(b)&16)}:m.contains=function(){return!1},m.isXML=function(a){var b=(a?a.ownerDocument||a:0).documentElement;return b?b.nodeName!=="HTML":!1};var y=function(a,b,c){var d,e=[],f="",g=b.nodeType?[b]:b;while(d=o.match.PSEUDO.exec(a))f+=d[0],a=a.replace(o.match.PSEUDO,"");a=o.relative[a]?a+"*":a;for(var h=0,i=g.length;h<i;h++)m(a,g[h],e,c);return m.filter(f,e)};m.attr=f.attr,m.selectors.attrMap={},f.find=m,f.expr=m.selectors,f.expr[":"]=f.expr.filters,f.unique=m.uniqueSort,f.text=m.getText,f.isXMLDoc=m.isXML,f.contains=m.contains}();var L=/Until$/,M=/^(?:parents|prevUntil|prevAll)/,N=/,/,O=/^.[^:#\[\.,]*$/,P=Array.prototype.slice,Q=f.expr.match.POS,R={children:!0,contents:!0,next:!0,prev:!0};f.fn.extend({find:function(a){var b=this,c,d;if(typeof a!="string")return f(a).filter(function(){for(c=0,d=b.length;c<d;c++)if(f.contains(b[c],this))return!0});var e=this.pushStack("","find",a),g,h,i;for(c=0,d=this.length;c<d;c++){g=e.length,f.find(a,this[c],e);if(c>0)for(h=g;h<e.length;h++)for(i=0;i<g;i++)if(e[i]===e[h]){e.splice(h--,1);break}}return e},has:function(a){var b=f(a);return this.filter(function(){for(var a=0,c=b.length;a<c;a++)if(f.contains(this,b[a]))return!0})},not:function(a){return this.pushStack(T(this,a,!1),"not",a)},filter:function(a){return this.pushStack(T(this,a,!0),"filter",a)},is:function(a){return!!a&&(typeof a=="string"?Q.test(a)?f(a,this.context).index(this[0])>=0:f.filter(a,this).length>0:this.filter(a).length>0)},closest:function(a,b){var c=[],d,e,g=this[0];if(f.isArray(a)){var h=1;while(g&&g.ownerDocument&&g!==b){for(d=0;d<a.length;d++)f(g).is(a[d])&&c.push({selector:a[d],elem:g,level:h});g=g.parentNode,h++}return c}var i=Q.test(a)||typeof a!="string"?f(a,b||this.context):0;for(d=0,e=this.length;d<e;d++){g=this[d];while(g){if(i?i.index(g)>-1:f.find.matchesSelector(g,a)){c.push(g);break}g=g.parentNode;if(!g||!g.ownerDocument||g===b||g.nodeType===11)break}}c=c.length>1?f.unique(c):c;return this.pushStack(c,"closest",a)},index:function(a){if(!a)return this[0]&&this[0].parentNode?this.prevAll().length:-1;if(typeof a=="string")return f.inArray(this[0],f(a));return f.inArray(a.jquery?a[0]:a,this)},add:function(a,b){var c=typeof a=="string"?f(a,b):f.makeArray(a&&a.nodeType?[a]:a),d=f.merge(this.get(),c);return this.pushStack(S(c[0])||S(d[0])?d:f.unique(d))},andSelf:function(){return this.add(this.prevObject)}}),f.each({parent:function(a){var b=a.parentNode;return b&&b.nodeType!==11?b:null},parents:function(a){return f.dir(a,"parentNode")},parentsUntil:function(a,b,c){return f.dir(a,"parentNode",c)},next:function(a){return f.nth(a,2,"nextSibling")},prev:function(a){return f.nth(a,2,"previousSibling")},nextAll:function(a){return f.dir(a,"nextSibling")},prevAll:function(a){return f.dir(a,"previousSibling")},nextUntil:function(a,b,c){return f.dir(a,"nextSibling",c)},prevUntil:function(a,b,c){return f.dir(a,"previousSibling",c)},siblings:function(a){return f.sibling(a.parentNode.firstChild,a)},children:function(a){return f.sibling(a.firstChild)},contents:function(a){return f.nodeName(a,"iframe")?a.contentDocument||a.contentWindow.document:f.makeArray(a.childNodes)}},function(a,b){f.fn[a]=function(c,d){var e=f.map(this,b,c);L.test(a)||(d=c),d&&typeof d=="string"&&(e=f.filter(d,e)),e=this.length>1&&!R[a]?f.unique(e):e,(this.length>1||N.test(d))&&M.test(a)&&(e=e.reverse());return this.pushStack(e,a,P.call(arguments).join(","))}}),f.extend({filter:function(a,b,c){c&&(a=":not("+a+")");return b.length===1?f.find.matchesSelector(b[0],a)?[b[0]]:[]:f.find.matches(a,b)},dir:function(a,c,d){var e=[],g=a[c];while(g&&g.nodeType!==9&&(d===b||g.nodeType!==1||!f(g).is(d)))g.nodeType===1&&e.push(g),g=g[c];return e},nth:function(a,b,c,d){b=b||1;var e=0;for(;a;a=a[c])if(a.nodeType===1&&++e===b)break;return a},sibling:function(a,b){var c=[];for(;a;a=a.nextSibling)a.nodeType===1&&a!==b&&c.push(a);return c}});var V="abbr|article|aside|audio|canvas|datalist|details|figcaption|figure|footer|header|hgroup|mark|meter|nav|output|progress|section|summary|time|video",W=/ jQuery\d+="(?:\d+|null)"/g,X=/^\s+/,Y=/<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/ig,Z=/<([\w:]+)/,$=/<tbody/i,_=/<|&#?\w+;/,ba=/<(?:script|style)/i,bb=/<(?:script|object|embed|option|style)/i,bc=new RegExp("<(?:"+V+")","i"),bd=/checked\s*(?:[^=]|=\s*.checked.)/i,be=/\/(java|ecma)script/i,bf=/^\s*<!(?:\[CDATA\[|\-\-)/,bg={option:[1,"<select multiple='multiple'>","</select>"],legend:[1,"<fieldset>","</fieldset>"],thead:[1,"<table>","</table>"],tr:[2,"<table><tbody>","</tbody></table>"],td:[3,"<table><tbody><tr>","</tr></tbody></table>"],col:[2,"<table><tbody></tbody><colgroup>","</colgroup></table>"],area:[1,"<map>","</map>"],_default:[0,"",""]},bh=U(c);bg.optgroup=bg.option,bg.tbody=bg.tfoot=bg.colgroup=bg.caption=bg.thead,bg.th=bg.td,f.support.htmlSerialize||(bg._default=[1,"div<div>","</div>"]),f.fn.extend({text:function(a){if(f.isFunction(a))return this.each(function(b){var c=f(this);c.text(a.call(this,b,c.text()))});if(typeof a!="object"&&a!==b)return this.empty().append((this[0]&&this[0].ownerDocument||c).createTextNode(a));return f.text(this)},wrapAll:function(a){if(f.isFunction(a))return this.each(function(b){f(this).wrapAll(a.call(this,b))});if(this[0]){var b=f(a,this[0].ownerDocument).eq(0).clone(!0);this[0].parentNode&&b.insertBefore(this[0]),b.map(function(){var a=this;while(a.firstChild&&a.firstChild.nodeType===1)a=a.firstChild;return a}).append(this)}return this},wrapInner:function(a){if(f.isFunction(a))return this.each(function(b){f(this).wrapInner(a.call(this,b))});return this.each(function(){var b=f(this),c=b.contents();c.length?c.wrapAll(a):b.append(a)})},wrap:function(a){var b=f.isFunction(a);return this.each(function(c){f(this).wrapAll(b?a.call(this,c):a)})},unwrap:function(){return this.parent().each(function(){f.nodeName(this,"body")||f(this).replaceWith(this.childNodes)}).end()},append:function(){return this.domManip(arguments,!0,function(a){this.nodeType===1&&this.appendChild(a)})},prepend:function(){return this.domManip(arguments,!0,function(a){this.nodeType===1&&this.insertBefore(a,this.firstChild)})},before:function(){if(this[0]&&this[0].parentNode)return this.domManip(arguments,!1,function(a){this.parentNode.insertBefore(a,this)});if(arguments.length){var a=f.clean(arguments);a.push.apply(a,this.toArray());return this.pushStack(a,"before",arguments)}},after:function(){if(this[0]&&this[0].parentNode)return this.domManip(arguments,!1,function(a){this.parentNode.insertBefore(a,this.nextSibling)});if(arguments.length){var a=this.pushStack(this,"after",arguments);a.push.apply(a,f.clean(arguments));return a}},remove:function(a,b){for(var c=0,d;(d=this[c])!=null;c++)if(!a||f.filter(a,[d]).length)!b&&d.nodeType===1&&(f.cleanData(d.getElementsByTagName("*")),f.cleanData([d])),d.parentNode&&d.parentNode.removeChild(d);return this},empty:function()
{for(var a=0,b;(b=this[a])!=null;a++){b.nodeType===1&&f.cleanData(b.getElementsByTagName("*"));while(b.firstChild)b.removeChild(b.firstChild)}return this},clone:function(a,b){a=a==null?!1:a,b=b==null?a:b;return this.map(function(){return f.clone(this,a,b)})},html:function(a){if(a===b)return this[0]&&this[0].nodeType===1?this[0].innerHTML.replace(W,""):null;if(typeof a=="string"&&!ba.test(a)&&(f.support.leadingWhitespace||!X.test(a))&&!bg[(Z.exec(a)||["",""])[1].toLowerCase()]){a=a.replace(Y,"<$1></$2>");try{for(var c=0,d=this.length;c<d;c++)this[c].nodeType===1&&(f.cleanData(this[c].getElementsByTagName("*")),this[c].innerHTML=a)}catch(e){this.empty().append(a)}}else f.isFunction(a)?this.each(function(b){var c=f(this);c.html(a.call(this,b,c.html()))}):this.empty().append(a);return this},replaceWith:function(a){if(this[0]&&this[0].parentNode){if(f.isFunction(a))return this.each(function(b){var c=f(this),d=c.html();c.replaceWith(a.call(this,b,d))});typeof a!="string"&&(a=f(a).detach());return this.each(function(){var b=this.nextSibling,c=this.parentNode;f(this).remove(),b?f(b).before(a):f(c).append(a)})}return this.length?this.pushStack(f(f.isFunction(a)?a():a),"replaceWith",a):this},detach:function(a){return this.remove(a,!0)},domManip:function(a,c,d){var e,g,h,i,j=a[0],k=[];if(!f.support.checkClone&&arguments.length===3&&typeof j=="string"&&bd.test(j))return this.each(function(){f(this).domManip(a,c,d,!0)});if(f.isFunction(j))return this.each(function(e){var g=f(this);a[0]=j.call(this,e,c?g.html():b),g.domManip(a,c,d)});if(this[0]){i=j&&j.parentNode,f.support.parentNode&&i&&i.nodeType===11&&i.childNodes.length===this.length?e={fragment:i}:e=f.buildFragment(a,this,k),h=e.fragment,h.childNodes.length===1?g=h=h.firstChild:g=h.firstChild;if(g){c=c&&f.nodeName(g,"tr");for(var l=0,m=this.length,n=m-1;l<m;l++)d.call(c?bi(this[l],g):this[l],e.cacheable||m>1&&l<n?f.clone(h,!0,!0):h)}k.length&&f.each(k,bp)}return this}}),f.buildFragment=function(a,b,d){var e,g,h,i,j=a[0];b&&b[0]&&(i=b[0].ownerDocument||b[0]),i.createDocumentFragment||(i=c),a.length===1&&typeof j=="string"&&j.length<512&&i===c&&j.charAt(0)==="<"&&!bb.test(j)&&(f.support.checkClone||!bd.test(j))&&(f.support.html5Clone||!bc.test(j))&&(g=!0,h=f.fragments[j],h&&h!==1&&(e=h)),e||(e=i.createDocumentFragment(),f.clean(a,i,e,d)),g&&(f.fragments[j]=h?e:1);return{fragment:e,cacheable:g}},f.fragments={},f.each({appendTo:"append",prependTo:"prepend",insertBefore:"before",insertAfter:"after",replaceAll:"replaceWith"},function(a,b){f.fn[a]=function(c){var d=[],e=f(c),g=this.length===1&&this[0].parentNode;if(g&&g.nodeType===11&&g.childNodes.length===1&&e.length===1){e[b](this[0]);return this}for(var h=0,i=e.length;h<i;h++){var j=(h>0?this.clone(!0):this).get();f(e[h])[b](j),d=d.concat(j)}return this.pushStack(d,a,e.selector)}}),f.extend({clone:function(a,b,c){var d,e,g,h=f.support.html5Clone||!bc.test("<"+a.nodeName)?a.cloneNode(!0):bo(a);if((!f.support.noCloneEvent||!f.support.noCloneChecked)&&(a.nodeType===1||a.nodeType===11)&&!f.isXMLDoc(a)){bk(a,h),d=bl(a),e=bl(h);for(g=0;d[g];++g)e[g]&&bk(d[g],e[g])}if(b){bj(a,h);if(c){d=bl(a),e=bl(h);for(g=0;d[g];++g)bj(d[g],e[g])}}d=e=null;return h},clean:function(a,b,d,e){var g;b=b||c,typeof b.createElement=="undefined"&&(b=b.ownerDocument||b[0]&&b[0].ownerDocument||c);var h=[],i;for(var j=0,k;(k=a[j])!=null;j++){typeof k=="number"&&(k+="");if(!k)continue;if(typeof k=="string")if(!_.test(k))k=b.createTextNode(k);else{k=k.replace(Y,"<$1></$2>");var l=(Z.exec(k)||["",""])[1].toLowerCase(),m=bg[l]||bg._default,n=m[0],o=b.createElement("div");b===c?bh.appendChild(o):U(b).appendChild(o),o.innerHTML=m[1]+k+m[2];while(n--)o=o.lastChild;if(!f.support.tbody){var p=$.test(k),q=l==="table"&&!p?o.firstChild&&o.firstChild.childNodes:m[1]==="<table>"&&!p?o.childNodes:[];for(i=q.length-1;i>=0;--i)f.nodeName(q[i],"tbody")&&!q[i].childNodes.length&&q[i].parentNode.removeChild(q[i])}!f.support.leadingWhitespace&&X.test(k)&&o.insertBefore(b.createTextNode(X.exec(k)[0]),o.firstChild),k=o.childNodes}var r;if(!f.support.appendChecked)if(k[0]&&typeof (r=k.length)=="number")for(i=0;i<r;i++)bn(k[i]);else bn(k);k.nodeType?h.push(k):h=f.merge(h,k)}if(d){g=function(a){return!a.type||be.test(a.type)};for(j=0;h[j];j++)if(e&&f.nodeName(h[j],"script")&&(!h[j].type||h[j].type.toLowerCase()==="text/javascript"))e.push(h[j].parentNode?h[j].parentNode.removeChild(h[j]):h[j]);else{if(h[j].nodeType===1){var s=f.grep(h[j].getElementsByTagName("script"),g);h.splice.apply(h,[j+1,0].concat(s))}d.appendChild(h[j])}}return h},cleanData:function(a){var b,c,d=f.cache,e=f.event.special,g=f.support.deleteExpando;for(var h=0,i;(i=a[h])!=null;h++){if(i.nodeName&&f.noData[i.nodeName.toLowerCase()])continue;c=i[f.expando];if(c){b=d[c];if(b&&b.events){for(var j in b.events)e[j]?f.event.remove(i,j):f.removeEvent(i,j,b.handle);b.handle&&(b.handle.elem=null)}g?delete i[f.expando]:i.removeAttribute&&i.removeAttribute(f.expando),delete d[c]}}}});var bq=/alpha\([^)]*\)/i,br=/opacity=([^)]*)/,bs=/([A-Z]|^ms)/g,bt=/^-?\d+(?:px)?$/i,bu=/^-?\d/,bv=/^([\-+])=([\-+.\de]+)/,bw={position:"absolute",visibility:"hidden",display:"block"},bx=["Left","Right"],by=["Top","Bottom"],bz,bA,bB;f.fn.css=function(a,c){if(arguments.length===2&&c===b)return this;return f.access(this,a,c,!0,function(a,c,d){return d!==b?f.style(a,c,d):f.css(a,c)})},f.extend({cssHooks:{opacity:{get:function(a,b){if(b){var c=bz(a,"opacity","opacity");return c===""?"1":c}return a.style.opacity}}},cssNumber:{fillOpacity:!0,fontWeight:!0,lineHeight:!0,opacity:!0,orphans:!0,widows:!0,zIndex:!0,zoom:!0},cssProps:{"float":f.support.cssFloat?"cssFloat":"styleFloat"},style:function(a,c,d,e){if(!!a&&a.nodeType!==3&&a.nodeType!==8&&!!a.style){var g,h,i=f.camelCase(c),j=a.style,k=f.cssHooks[i];c=f.cssProps[i]||i;if(d===b){if(k&&"get"in k&&(g=k.get(a,!1,e))!==b)return g;return j[c]}h=typeof d,h==="string"&&(g=bv.exec(d))&&(d=+(g[1]+1)*+g[2]+parseFloat(f.css(a,c)),h="number");if(d==null||h==="number"&&isNaN(d))return;h==="number"&&!f.cssNumber[i]&&(d+="px");if(!k||!("set"in k)||(d=k.set(a,d))!==b)try{j[c]=d}catch(l){}}},css:function(a,c,d){var e,g;c=f.camelCase(c),g=f.cssHooks[c],c=f.cssProps[c]||c,c==="cssFloat"&&(c="float");if(g&&"get"in g&&(e=g.get(a,!0,d))!==b)return e;if(bz)return bz(a,c)},swap:function(a,b,c){var d={};for(var e in b)d[e]=a.style[e],a.style[e]=b[e];c.call(a);for(e in b)a.style[e]=d[e]}}),f.curCSS=f.css,f.each(["height","width"],function(a,b){f.cssHooks[b]={get:function(a,c,d){var e;if(c){if(a.offsetWidth!==0)return bC(a,b,d);f.swap(a,bw,function(){e=bC(a,b,d)});return e}},set:function(a,b){if(!bt.test(b))return b;b=parseFloat(b);if(b>=0)return b+"px"}}}),f.support.opacity||(f.cssHooks.opacity={get:function(a,b){return br.test((b&&a.currentStyle?a.currentStyle.filter:a.style.filter)||"")?parseFloat(RegExp.$1)/100+"":b?"1":""},set:function(a,b){var c=a.style,d=a.currentStyle,e=f.isNumeric(b)?"alpha(opacity="+b*100+")":"",g=d&&d.filter||c.filter||"";c.zoom=1;if(b>=1&&f.trim(g.replace(bq,""))===""){c.removeAttribute("filter");if(d&&!d.filter)return}c.filter=bq.test(g)?g.replace(bq,e):g+" "+e}}),f(function(){f.support.reliableMarginRight||(f.cssHooks.marginRight={get:function(a,b){var c;f.swap(a,{display:"inline-block"},function(){b?c=bz(a,"margin-right","marginRight"):c=a.style.marginRight});return c}})}),c.defaultView&&c.defaultView.getComputedStyle&&(bA=function(a,b){var c,d,e;b=b.replace(bs,"-$1").toLowerCase(),(d=a.ownerDocument.defaultView)&&(e=d.getComputedStyle(a,null))&&(c=e.getPropertyValue(b),c===""&&!f.contains(a.ownerDocument.documentElement,a)&&(c=f.style(a,b)));return c}),c.documentElement.currentStyle&&(bB=function(a,b){var c,d,e,f=a.currentStyle&&a.currentStyle[b],g=a.style;f===null&&g&&(e=g[b])&&(f=e),!bt.test(f)&&bu.test(f)&&(c=g.left,d=a.runtimeStyle&&a.runtimeStyle.left,d&&(a.runtimeStyle.left=a.currentStyle.left),g.left=b==="fontSize"?"1em":f||0,f=g.pixelLeft+"px",g.left=c,d&&(a.runtimeStyle.left=d));return f===""?"auto":f}),bz=bA||bB,f.expr&&f.expr.filters&&(f.expr.filters.hidden=function(a){var b=a.offsetWidth,c=a.offsetHeight;return b===0&&c===0||!f.support.reliableHiddenOffsets&&(a.style&&a.style.display||f.css(a,"display"))==="none"},f.expr.filters.visible=function(a){return!f.expr.filters.hidden(a)});var bD=/%20/g,bE=/\[\]$/,bF=/\r?\n/g,bG=/#.*$/,bH=/^(.*?):[ \t]*([^\r\n]*)\r?$/mg,bI=/^(?:color|date|datetime|datetime-local|email|hidden|month|number|password|range|search|tel|text|time|url|week)$/i,bJ=/^(?:about|app|app\-storage|.+\-extension|file|res|widget):$/,bK=/^(?:GET|HEAD)$/,bL=/^\/\//,bM=/\?/,bN=/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,bO=/^(?:select|textarea)/i,bP=/\s+/,bQ=/([?&])_=[^&]*/,bR=/^([\w\+\.\-]+:)(?:\/\/([^\/?#:]*)(?::(\d+))?)?/,bS=f.fn.load,bT={},bU={},bV,bW,bX=["*/"]+["*"];try{bV=e.href}catch(bY){bV=c.createElement("a"),bV.href="",bV=bV.href}bW=bR.exec(bV.toLowerCase())||[],f.fn.extend({load:function(a,c,d){if(typeof a!="string"&&bS)return bS.apply(this,arguments);if(!this.length)return this;var e=a.indexOf(" ");if(e>=0){var g=a.slice(e,a.length);a=a.slice(0,e)}var h="GET";c&&(f.isFunction(c)?(d=c,c=b):typeof c=="object"&&(c=f.param(c,f.ajaxSettings.traditional),h="POST"));var i=this;f.ajax({url:a,type:h,dataType:"html",data:c,complete:function(a,b,c){c=a.responseText,a.isResolved()&&(a.done(function(a){c=a}),i.html(g?f("<div>").append(c.replace(bN,"")).find(g):c)),d&&i.each(d,[c,b,a])}});return this},serialize:function(){return f.param(this.serializeArray())},serializeArray:function(){return this.map(function(){return this.elements?f.makeArray(this.elements):this}).filter(function(){return this.name&&!this.disabled&&(this.checked||bO.test(this.nodeName)||bI.test(this.type))}).map(function(a,b){var c=f(this).val();return c==null?null:f.isArray(c)?f.map(c,function(a,c){return{name:b.name,value:a.replace(bF,"\r\n")}}):{name:b.name,value:c.replace(bF,"\r\n")}}).get()}}),f.each("ajaxStart ajaxStop ajaxComplete ajaxError ajaxSuccess ajaxSend".split(" "),function(a,b){f.fn[b]=function(a){return this.on(b,a)}}),f.each(["get","post"],function(a,c){f[c]=function(a,d,e,g){f.isFunction(d)&&(g=g||e,e=d,d=b);return f.ajax({type:c,url:a,data:d,success:e,dataType:g})}}),f.extend({getScript:function(a,c){return f.get(a,b,c,"script")},getJSON:function(a,b,c){return f.get(a,b,c,"json")},ajaxSetup:function(a,b){b?b_(a,f.ajaxSettings):(b=a,a=f.ajaxSettings),b_(a,b);return a},ajaxSettings:{url:bV,isLocal:bJ.test(bW[1]),global:!0,type:"GET",contentType:"application/x-www-form-urlencoded",processData:!0,async:!0,accepts:{xml:"application/xml, text/xml",html:"text/html",text:"text/plain",json:"application/json, text/javascript","*":bX},contents:{xml:/xml/,html:/html/,json:/json/},responseFields:{xml:"responseXML",text:"responseText"},converters:{"* text":a.String,"text html":!0,"text json":f.parseJSON,"text xml":f.parseXML},flatOptions:{context:!0,url:!0}},ajaxPrefilter:bZ(bT),ajaxTransport:bZ(bU),ajax:function(a,c){function w(a,c,l,m){if(s!==2){s=2,q&&clearTimeout(q),p=b,n=m||"",v.readyState=a>0?4:0;var o,r,u,w=c,x=l?cb(d,v,l):b,y,z;if(a>=200&&a<300||a===304){if(d.ifModified){if(y=v.getResponseHeader("Last-Modified"))f.lastModified[k]=y;if(z=v.getResponseHeader("Etag"))f.etag[k]=z}if(a===304)w="notmodified",o=!0;else try{r=cc(d,x),w="success",o=!0}catch(A){w="parsererror",u=A}}else{u=w;if(!w||a)w="error",a<0&&(a=0)}v.status=a,v.statusText=""+(c||w),o?h.resolveWith(e,[r,w,v]):h.rejectWith(e,[v,w,u]),v.statusCode(j),j=b,t&&g.trigger("ajax"+(o?"Success":"Error"),[v,d,o?r:u]),i.fireWith(e,[v,w]),t&&(g.trigger("ajaxComplete",[v,d]),--f.active||f.event.trigger("ajaxStop"))}}typeof a=="object"&&(c=a,a=b),c=c||{};var d=f.ajaxSetup({},c),e=d.context||d,g=e!==d&&(e.nodeType||e instanceof f)?f(e):f.event,h=f.Deferred(),i=f.Callbacks("once memory"),j=d.statusCode||{},k,l={},m={},n,o,p,q,r,s=0,t,u,v={readyState:0,setRequestHeader:function(a,b){if(!s){var c=a.toLowerCase();a=m[c]=m[c]||a,l[a]=b}return this},getAllResponseHeaders:function(){return s===2?n:null},getResponseHeader:function(a){var c;if(s===2){if(!o){o={};while(c=bH.exec(n))o[c[1].toLowerCase()]=c[2]}c=o[a.toLowerCase()]}return c===b?null:c},overrideMimeType:function(a){s||(d.mimeType=a);return this},abort:function(a){a=a||"abort",p&&p.abort(a),w(0,a);return this}};h.promise(v),v.success=v.done,v.error=v.fail,v.complete=i.add,v.statusCode=function(a){if(a){var b;if(s<2)for(b in a)j[b]=[j[b],a[b]];else b=a[v.status],v.then(b,b)}return this},d.url=((a||d.url)+"").replace(bG,"").replace(bL,bW[1]+"//"),d.dataTypes=f.trim(d.dataType||"*").toLowerCase().split(bP),d.crossDomain==null&&(r=bR.exec(d.url.toLowerCase()),d.crossDomain=!(!r||r[1]==bW[1]&&r[2]==bW[2]&&(r[3]||(r[1]==="http:"?80:443))==(bW[3]||(bW[1]==="http:"?80:443)))),d.data&&d.processData&&typeof d.data!="string"&&(d.data=f.param(d.data,d.traditional)),b$(bT,d,c,v);if(s===2)return!1;t=d.global,d.type=d.type.toUpperCase(),d.hasContent=!bK.test(d.type),t&&f.active++===0&&f.event.trigger("ajaxStart");if(!d.hasContent){d.data&&(d.url+=(bM.test(d.url)?"&":"?")+d.data,delete d.data),k=d.url;if(d.cache===!1){var x=f.now(),y=d.url.replace(bQ,"$1_="+x);d.url=y+(y===d.url?(bM.test(d.url)?"&":"?")+"_="+x:"")}}(d.data&&d.hasContent&&d.contentType!==!1||c.contentType)&&v.setRequestHeader("Content-Type",d.contentType),d.ifModified&&(k=k||d.url,f.lastModified[k]&&v.setRequestHeader("If-Modified-Since",f.lastModified[k]),f.etag[k]&&v.setRequestHeader("If-None-Match",f.etag[k])),v.setRequestHeader("Accept",d.dataTypes[0]&&d.accepts[d.dataTypes[0]]?d.accepts[d.dataTypes[0]]+(d.dataTypes[0]!=="*"?", "+bX+"; q=0.01":""):d.accepts["*"]);for(u in d.headers)v.setRequestHeader(u,d.headers[u]);if(d.beforeSend&&(d.beforeSend.call(e,v,d)===!1||s===2)){v.abort();return!1}for(u in{success:1,error:1,complete:1})v[u](d[u]);p=b$(bU,d,c,v);if(!p)w(-1,"No Transport");else{v.readyState=1,t&&g.trigger("ajaxSend",[v,d]),d.async&&d.timeout>0&&(q=setTimeout(function(){v.abort("timeout")},d.timeout));try{s=1,p.send(l,w)}catch(z){if(s<2)w(-1,z);else throw z}}return v},param:function(a,c){var d=[],e=function(a,b){b=f.isFunction(b)?b():b,d[d.length]=encodeURIComponent(a)+"="+encodeURIComponent(b)};c===b&&(c=f.ajaxSettings.traditional);if(f.isArray(a)||a.jquery&&!f.isPlainObject(a))f.each(a,function(){e(this.name,this.value)});else for(var g in a)ca(g,a[g],c,e);return d.join("&").replace(bD,"+")}}),f.extend({active:0,lastModified:{},etag:{}});var cd=f.now(),ce=/(\=)\?(&|$)|\?\?/i;f.ajaxSetup({jsonp:"callback",jsonpCallback:function(){return f.expando+"_"+cd++}}),f.ajaxPrefilter("json jsonp",function(b,c,d){var e=b.contentType==="application/x-www-form-urlencoded"&&typeof b.data=="string";if(b.dataTypes[0]==="jsonp"||b.jsonp!==!1&&(ce.test(b.url)||e&&ce.test(b.data))){var g,h=b.jsonpCallback=f.isFunction(b.jsonpCallback)?b.jsonpCallback():b.jsonpCallback,i=a[h],j=b.url,k=b.data,l="$1"+h+"$2";b.jsonp!==!1&&(j=j.replace(ce,l),b.url===j&&(e&&(k=k.replace(ce,l)),b.data===k&&(j+=(/\?/.test(j)?"&":"?")+b.jsonp+"="+h))),b.url=j,b.data=k,a[h]=function(a){g=[a]},d.always(function(){a[h]=i,g&&f.isFunction(i)&&a[h](g[0])}),b.converters["script json"]=function(){g||f.error(h+" was not called");return g[0]},b.dataTypes[0]="json";return"script"}}),f.ajaxSetup({accepts:{script:"text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"},contents:{script:/javascript|ecmascript/},converters:{"text script":function(a){f.globalEval(a);return a}}}),f.ajaxPrefilter("script",function(a){a.cache===b&&(a.cache=!1),a.crossDomain&&(a.type="GET",a.global=!1)}),f.ajaxTransport("script",function(a){if(a.crossDomain){var d,e=c.head||c.getElementsByTagName("head")[0]||c.documentElement;return{send:function(f,g){d=c.createElement("script"),d.async="async",a.scriptCharset&&(d.charset=a.scriptCharset),d.src=a.url,d.onload=d.onreadystatechange=function(a,c){if(c||!d.readyState||/loaded|complete/.test(d.readyState))d.onload=d.onreadystatechange=null,e&&d.parentNode&&e.removeChild(d),d=b,c||g(200,"success")},e.insertBefore(d,e.firstChild)},abort:function(){d&&d.onload(0,1)}}}});var cf=a.ActiveXObject?function(){for(var a in ch)ch[a](0,1)}:!1,cg=0,ch;f.ajaxSettings.xhr=a.ActiveXObject?function(){return!this.isLocal&&ci()||cj()}:ci,function(a){f.extend(f.support,{ajax:!!a,cors:!!a&&"withCredentials"in a})}(f.ajaxSettings.xhr()),f.support.ajax&&f.ajaxTransport(function(c){if(!c.crossDomain||f.support.cors){var d;return{send:function(e,g){var h=c.xhr(),i,j;c.username?h.open(c.type,c.url,c.async,c.username,c.password):h.open(c.type,c.url,c.async);if(c.xhrFields)for(j in c.xhrFields)h[j]=c.xhrFields[j];c.mimeType&&h.overrideMimeType&&h.overrideMimeType(c.mimeType),!c.crossDomain&&!e["X-Requested-With"]&&(e["X-Requested-With"]="XMLHttpRequest");try{for(j in e)h.setRequestHeader(j,e[j])}catch(k){}h.send(c.hasContent&&c.data||null),d=function(a,e){var j,k,l,m,n;try{if(d&&(e||h.readyState===4)){d=b,i&&(h.onreadystatechange=f.noop,cf&&delete ch[i]);if(e)h.readyState!==4&&h.abort();else{j=h.status,l=h.getAllResponseHeaders(),m={},n=h.responseXML,n&&n.documentElement&&(m.xml=n),m.text=h.responseText;try{k=h.statusText}catch(o){k=""}!j&&c.isLocal&&!c.crossDomain?j=m.text?200:404:j===1223&&(j=204)}}}catch(p){e||g(-1,p)}m&&g(j,k,m,l)},!c.async||h.readyState===4?d():(i=++cg,cf&&(ch||(ch={},f(a).unload(cf)),ch[i]=d),h.onreadystatechange=d)},abort:function(){d&&d(0,1)}}}});var ck={},cl,cm,cn=/^(?:toggle|show|hide)$/,co=/^([+\-]=)?([\d+.\-]+)([a-z%]*)$/i,cp,cq=[["height","marginTop","marginBottom","paddingTop","paddingBottom"],["width","marginLeft","marginRight","paddingLeft","paddingRight"],["opacity"]],cr;f.fn.extend({show:function(a,b,c){var d,e;if(a||a===0)return this.animate(cu("show",3),a,b,c);for(var g=0,h=this.length;g<h;g++)d=this[g],d.style&&(e=d.style.display,!f._data(d,"olddisplay")&&e==="none"&&(e=d.style.display=""),e===""&&f.css(d,"display")==="none"&&f._data(d,"olddisplay",cv(d.nodeName)));for(g=0;g<h;g++){d=this[g];if(d.style){e=d.style.display;if(e===""||e==="none")d.style.display=f._data(d,"olddisplay")||""}}return this},hide:function(a,b,c){if(a||a===0)return this.animate(cu("hide",3),a,b,c);var d,e,g=0,h=this.length;for(;g<h;g++)d=this[g],d.style&&(e=f.css(d,"display"),e!=="none"&&!f._data(d,"olddisplay")&&f._data(d,"olddisplay",e));for(g=0;g<h;g++)this[g].style&&(this[g].style.display="none");return this},_toggle:f.fn.toggle,toggle:function(a,b,c){var d=typeof a=="boolean";f.isFunction(a)&&f.isFunction(b)?this._toggle.apply(this,arguments):a==null||d?this.each(function(){var b=d?a:f(this).is(":hidden");f(this)[b?"show":"hide"]()}):this.animate(cu("toggle",3),a,b,c);return this},fadeTo:function(a,b,c,d){return this.filter(":hidden").css("opacity",0).show().end().animate({opacity:b},a,c,d)},animate:function(a,b,c,d){function g(){e.queue===!1&&f._mark(this);var b=f.extend({},e),c=this.nodeType===1,d=c&&f(this).is(":hidden"),g,h,i,j,k,l,m,n,o;b.animatedProperties={};for(i in a){g=f.camelCase(i),i!==g&&(a[g]=a[i],delete a[i]),h=a[g],f.isArray(h)?(b.animatedProperties[g]=h[1],h=a[g]=h[0]):b.animatedProperties[g]=b.specialEasing&&b.specialEasing[g]||b.easing||"swing";if(h==="hide"&&d||h==="show"&&!d)return b.complete.call(this);c&&(g==="height"||g==="width")&&(b.overflow=[this.style.overflow,this.style.overflowX,this.style.overflowY],f.css(this,"display")==="inline"&&f.css(this,"float")==="none"&&(!f.support.inlineBlockNeedsLayout||cv(this.nodeName)==="inline"?this.style.display="inline-block":this.style.zoom=1))}b.overflow!=null&&(this.style.overflow="hidden");for(i in a)j=new f.fx(this,b,i),h=a[i],cn.test(h)?(o=f._data(this,"toggle"+i)||(h==="toggle"?d?"show":"hide":0),o?(f._data(this,"toggle"+i,o==="show"?"hide":"show"),j[o]()):j[h]()):(k=co.exec(h),l=j.cur(),k?(m=parseFloat(k[2]),n=k[3]||(f.cssNumber[i]?"":"px"),n!=="px"&&(f.style(this,i,(m||1)+n),l=(m||1)/j.cur()*l,f.style(this,i,l+n)),k[1]&&(m=(k[1]==="-="?-1:1)*m+l),j.custom(l,m,n)):j.custom(l,h,""));return!0}var e=f.speed(b,c,d);if(f.isEmptyObject(a))return this.each(e.complete,[!1]);a=f.extend({},a);return e.queue===!1?this.each(g):this.queue(e.queue,g)},stop:function(a,c,d){typeof a!="string"&&(d=c,c=a,a=b),c&&a!==!1&&this.queue(a||"fx",[]);return this.each(function(){function h(a,b,c){var e=b[c];f.removeData(a,c,!0),e.stop(d)}var b,c=!1,e=f.timers,g=f._data(this);d||f._unmark(!0,this);if(a==null)for(b in g)g[b]&&g[b].stop&&b.indexOf(".run")===b.length-4&&h(this,g,b);else g[b=a+".run"]&&g[b].stop&&h(this,g,b);for(b=e.length;b--;)e[b].elem===this&&(a==null||e[b].queue===a)&&(d?e[b](!0):e[b].saveState(),c=!0,e.splice(b,1));(!d||!c)&&f.dequeue(this,a)})}}),f.each({slideDown:cu("show",1),slideUp:cu("hide",1),slideToggle:cu("toggle",1),fadeIn:{opacity:"show"},fadeOut:{opacity:"hide"},fadeToggle:{opacity:"toggle"}},function(a,b){f.fn[a]=function(a,c,d){return this.animate(b,a,c,d)}}),f.extend({speed:function(a,b,c){var d=a&&typeof a=="object"?f.extend({},a):{complete:c||!c&&b||f.isFunction(a)&&a,duration:a,easing:c&&b||b&&!f.isFunction(b)&&b};d.duration=f.fx.off?0:typeof d.duration=="number"?d.duration:d.duration in f.fx.speeds?f.fx.speeds[d.duration]:f.fx.speeds._default;if(d.queue==null||d.queue===!0)d.queue="fx";d.old=d.complete,d.complete=function(a){f.isFunction(d.old)&&d.old.call(this),d.queue?f.dequeue(this,d.queue):a!==!1&&f._unmark(this)};return d},easing:{linear:function(a,b,c,d){return c+d*a},swing:function(a,b,c,d){return(-Math.cos(a*Math.PI)/2+.5)*d+c}},timers:[],fx:function(a,b,c){this.options=b,this.elem=a,this.prop=c,b.orig=b.orig||{}}}),f.fx.prototype={update:function(){this.options.step&&this.options.step.call(this.elem,this.now,this),(f.fx.step[this.prop]||f.fx.step._default)(this)},cur:function(){if(this.elem[this.prop]!=null&&(!this.elem.style||this.elem.style[this.prop]==null))return this.elem[this.prop];var a,b=f.css(this.elem,this.prop);return isNaN(a=parseFloat(b))?!b||b==="auto"?0:b:a},custom:function(a,c,d){function h(a){return e.step(a)}var e=this,g=f.fx;this.startTime=cr||cs(),this.end=c,this.now=this.start=a,this.pos=this.state=0,this.unit=d||this.unit||(f.cssNumber[this.prop]?"":"px"),h.queue=this.options.queue,h.elem=this.elem,h.saveState=function(){e.options.hide&&f._data(e.elem,"fxshow"+e.prop)===b&&f._data(e.elem,"fxshow"+e.prop,e.start)},h()&&f.timers.push(h)&&!cp&&(cp=setInterval(g.tick,g.interval))},show:function(){var a=f._data(this.elem,"fxshow"+this.prop);this.options.orig[this.prop]=a||f.style(this.elem,this.prop),this.options.show=!0,a!==b?this.custom(this.cur(),a):this.custom(this.prop==="width"||this.prop==="height"?1:0,this.cur()),f(this.elem).show()},hide:function(){this.options.orig[this.prop]=f._data(this.elem,"fxshow"+this.prop)||f.style(this.elem,this.prop),this.options.hide=!0,this.custom(this.cur(),0)},step:function(a){var b,c,d,e=cr||cs(),g=!0,h=this.elem,i=this.options;if(a||e>=i.duration+this.startTime){this.now=this.end,this.pos=this.state=1,this.update(),i.animatedProperties[this.prop]=!0;for(b in i.animatedProperties)i.animatedProperties[b]!==!0&&(g=!1);if(g){i.overflow!=null&&!f.support.shrinkWrapBlocks&&f.each(["","X","Y"],function(a,b){h.style["overflow"+b]=i.overflow[a]}),i.hide&&f(h).hide();if(i.hide||i.show)for(b in i.animatedProperties)f.style(h,b,i.orig[b]),f.removeData(h,"fxshow"+b,!0),f.removeData(h,"toggle"+b,!0);d=i.complete,d&&(i.complete=!1,d.call(h))}return!1}i.duration==Infinity?this.now=e:(c=e-this.startTime,this.state=c/i.duration,this.pos=f.easing[i.animatedProperties[this.prop]](this.state,c,0,1,i.duration),this.now=this.start+(this.end-this.start)*this.pos),this.update();return!0}},f.extend(f.fx,{tick:function(){var a,b=f.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||f.fx.stop()},interval:13,stop:function(){clearInterval(cp),cp=null},speeds:{slow:600,fast:200,_default:400},step:{opacity:function(a){f.style(a.elem,"opacity",a.now)},_default:function(a){a.elem.style&&a.elem.style[a.prop]!=null?a.elem.style[a.prop]=a.now+a.unit:a.elem[a.prop]=a.now}}}),f.each(["width","height"],function(a,b){f.fx.step[b]=function(a){f.style(a.elem,b,Math.max(0,a.now)+a.unit)}}),f.expr&&f.expr.filters&&(f.expr.filters.animated=function(a){return f.grep(f.timers,function(b){return a===b.elem}).length});var cw=/^t(?:able|d|h)$/i,cx=/^(?:body|html)$/i;"getBoundingClientRect"in c.documentElement?f.fn.offset=function(a){var b=this[0],c;if(a)return this.each(function(b){f.offset.setOffset(this,a,b)});if(!b||!b.ownerDocument)return null;if(b===b.ownerDocument.body)return f.offset.bodyOffset(b);try{c=b.getBoundingClientRect()}catch(d){}var e=b.ownerDocument,g=e.documentElement;if(!c||!f.contains(g,b))return c?{top:c.top,left:c.left}:{top:0,left:0};var h=e.body,i=cy(e),j=g.clientTop||h.clientTop||0,k=g.clientLeft||h.clientLeft||0,l=i.pageYOffset||f.support.boxModel&&g.scrollTop||h.scrollTop,m=i.pageXOffset||f.support.boxModel&&g.scrollLeft||h.scrollLeft,n=c.top+l-j,o=c.left+m-k;return{top:n,left:o}}:f.fn.offset=function(a){var b=this[0];if(a)return this.each(function(b){f.offset.setOffset(this,a,b)});if(!b||!b.ownerDocument)return null;if(b===b.ownerDocument.body)return f.offset.bodyOffset(b);var c,d=b.offsetParent,e=b,g=b.ownerDocument,h=g.documentElement,i=g.body,j=g.defaultView,k=j?j.getComputedStyle(b,null):b.currentStyle,l=b.offsetTop,m=b.offsetLeft;while((b=b.parentNode)&&b!==i&&b!==h){if(f.support.fixedPosition&&k.position==="fixed")break;c=j?j.getComputedStyle(b,null):b.currentStyle,l-=b.scrollTop,m-=b.scrollLeft,b===d&&(l+=b.offsetTop,m+=b.offsetLeft,f.support.doesNotAddBorder&&(!f.support.doesAddBorderForTableAndCells||!cw.test(b.nodeName))&&(l+=parseFloat(c.borderTopWidth)||0,m+=parseFloat(c.borderLeftWidth)||0),e=d,d=b.offsetParent),f.support.subtractsBorderForOverflowNotVisible&&c.overflow!=="visible"&&(l+=parseFloat(c.borderTopWidth)||0,m+=parseFloat(c.borderLeftWidth)||0),k=c}if(k.position==="relative"||k.position==="static")l+=i.offsetTop,m+=i.offsetLeft;f.support.fixedPosition&&k.position==="fixed"&&(l+=Math.max(h.scrollTop,i.scrollTop),m+=Math.max(h.scrollLeft,i.scrollLeft));return{top:l,left:m}},f.offset={bodyOffset:function(a){var b=a.offsetTop,c=a.offsetLeft;f.support.doesNotIncludeMarginInBodyOffset&&(b+=parseFloat(f.css(a,"marginTop"))||0,c+=parseFloat(f.css(a,"marginLeft"))||0);return{top:b,left:c}},setOffset:function(a,b,c){var d=f.css(a,"position");d==="static"&&(a.style.position="relative");var e=f(a),g=e.offset(),h=f.css(a,"top"),i=f.css(a,"left"),j=(d==="absolute"||d==="fixed")&&f.inArray("auto",[h,i])>-1,k={},l={},m,n;j?(l=e.position(),m=l.top,n=l.left):(m=parseFloat(h)||0,n=parseFloat(i)||0),f.isFunction(b)&&(b=b.call(a,c,g)),b.top!=null&&(k.top=b.top-g.top+m),b.left!=null&&(k.left=b.left-g.left+n),"using"in b?b.using.call(a,k):e.css(k)}},f.fn.extend({position:function(){if(!this[0])return null;var a=this[0],b=this.offsetParent(),c=this.offset(),d=cx.test(b[0].nodeName)?{top:0,left:0}:b.offset();c.top-=parseFloat(f.css(a,"marginTop"))||0,c.left-=parseFloat(f.css(a,"marginLeft"))||0,d.top+=parseFloat(f.css(b[0],"borderTopWidth"))||0,d.left+=parseFloat(f.css(b[0],"borderLeftWidth"))||0;return{top:c.top-d.top,left:c.left-d.left}},offsetParent:function(){return this.map(function(){var a=this.offsetParent||c.body;while(a&&!cx.test(a.nodeName)&&f.css(a,"position")==="static")a=a.offsetParent;return a})}}),f.each(["Left","Top"],function(a,c){var d="scroll"+c;f.fn[d]=function(c){var e,g;if(c===b){e=this[0];if(!e)return null;g=cy(e);return g?"pageXOffset"in g?g[a?"pageYOffset":"pageXOffset"]:f.support.boxModel&&g.document.documentElement[d]||g.document.body[d]:e[d]}return this.each(function(){g=cy(this),g?g.scrollTo(a?f(g).scrollLeft():c,a?c:f(g).scrollTop()):this[d]=c})}}),f.each(["Height","Width"],function(a,c){var d=c.toLowerCase();f.fn["inner"+c]=function(){var a=this[0];return a?a.style?parseFloat(f.css(a,d,"padding")):this[d]():null},f.fn["outer"+c]=function(a){var b=this[0];return b?b.style?parseFloat(f.css(b,d,a?"margin":"border")):this[d]():null},f.fn[d]=function(a){var e=this[0];if(!e)return a==null?null:this;if(f.isFunction(a))return this.each(function(b){var c=f(this);c[d](a.call(this,b,c[d]()))});if(f.isWindow(e)){var g=e.document.documentElement["client"+c],h=e.document.body;return e.document.compatMode==="CSS1Compat"&&g||h&&h["client"+c]||g}if(e.nodeType===9)return Math.max(e.documentElement["client"+c],e.body["scroll"+c],e.documentElement["scroll"+c],e.body["offset"+c],e.documentElement["offset"+c]);if(a===b){var i=f.css(e,d),j=parseFloat(i);return f.isNumeric(j)?j:i}return this.css(d,typeof a=="string"?a:a+"px")}}),a.jQuery=a.$=f,typeof define=="function"&&define.amd&&define.amd.jQuery&&define("jquery",[],function(){return f})})(window);// Penner Easing Equations
jQuery.easing["jswing"]=jQuery.easing["swing"];jQuery.extend(jQuery.easing,{def:"easeOutQuad",swing:function(x,t,b,c,d){return jQuery.easing[jQuery.easing.def](x,t,b,c,d);},easeInQuad:function(x,t,b,c,d){return c*(t/=d)*t+b;},easeOutQuad:function(x,t,b,c,d){return -c*(t/=d)*(t-2)+b;},easeInOutQuad:function(x,t,b,c,d){if((t/=d/2)<1){return c/2*t*t+b;}return -c/2*((--t)*(t-2)-1)+b;},easeInCubic:function(x,t,b,c,d){return c*(t/=d)*t*t+b;},easeOutCubic:function(x,t,b,c,d){return c*((t=t/d-1)*t*t+1)+b;},easeInOutCubic:function(x,t,b,c,d){if((t/=d/2)<1){return c/2*t*t*t+b;}return c/2*((t-=2)*t*t+2)+b;},easeInQuart:function(x,t,b,c,d){return c*(t/=d)*t*t*t+b;},easeOutQuart:function(x,t,b,c,d){return -c*((t=t/d-1)*t*t*t-1)+b;},easeInOutQuart:function(x,t,b,c,d){if((t/=d/2)<1){return c/2*t*t*t*t+b;}return -c/2*((t-=2)*t*t*t-2)+b;},easeInQuint:function(x,t,b,c,d){return c*(t/=d)*t*t*t*t+b;},easeOutQuint:function(x,t,b,c,d){return c*((t=t/d-1)*t*t*t*t+1)+b;},easeInOutQuint:function(x,t,b,c,d){if((t/=d/2)<1){return c/2*t*t*t*t*t+b;}return c/2*((t-=2)*t*t*t*t+2)+b;},easeInSine:function(x,t,b,c,d){return -c*Math.cos(t/d*(Math.PI/2))+c+b;},easeOutSine:function(x,t,b,c,d){return c*Math.sin(t/d*(Math.PI/2))+b;},easeInOutSine:function(x,t,b,c,d){return -c/2*(Math.cos(Math.PI*t/d)-1)+b;},easeInExpo:function(x,t,b,c,d){return (t==0)?b:c*Math.pow(2,10*(t/d-1))+b;},easeOutExpo:function(x,t,b,c,d){return (t==d)?b+c:c*(-Math.pow(2,-10*t/d)+1)+b;},easeInOutExpo:function(x,t,b,c,d){if(t==0){return b;}if(t==d){return b+c;}if((t/=d/2)<1){return c/2*Math.pow(2,10*(t-1))+b;}return c/2*(-Math.pow(2,-10*--t)+2)+b;},easeInCirc:function(x,t,b,c,d){return -c*(Math.sqrt(1-(t/=d)*t)-1)+b;},easeOutCirc:function(x,t,b,c,d){return c*Math.sqrt(1-(t=t/d-1)*t)+b;},easeInOutCirc:function(x,t,b,c,d){if((t/=d/2)<1){return -c/2*(Math.sqrt(1-t*t)-1)+b;}return c/2*(Math.sqrt(1-(t-=2)*t)+1)+b;},easeInElastic:function(x,t,b,c,d){var s=1.70158;var p=0;var a=c;if(t==0){return b;}if((t/=d)==1){return b+c;}if(!p){p=d*0.3;}if(a<Math.abs(c)){a=c;var s=p/4;}else{var s=p/(2*Math.PI)*Math.asin(c/a);}return -(a*Math.pow(2,10*(t-=1))*Math.sin((t*d-s)*(2*Math.PI)/p))+b;},easeOutElastic:function(x,t,b,c,d){var s=1.70158;var p=0;var a=c;if(t==0){return b;}if((t/=d)==1){return b+c;}if(!p){p=d*0.3;}if(a<Math.abs(c)){a=c;var s=p/4;}else{var s=p/(2*Math.PI)*Math.asin(c/a);}return a*Math.pow(2,-10*t)*Math.sin((t*d-s)*(2*Math.PI)/p)+c+b;},easeInOutElastic:function(x,t,b,c,d){var s=1.70158;var p=0;var a=c;if(t==0){return b;}if((t/=d/2)==2){return b+c;}if(!p){p=d*(0.3*1.5);}if(a<Math.abs(c)){a=c;var s=p/4;}else{var s=p/(2*Math.PI)*Math.asin(c/a);}if(t<1){return -0.5*(a*Math.pow(2,10*(t-=1))*Math.sin((t*d-s)*(2*Math.PI)/p))+b;}return a*Math.pow(2,-10*(t-=1))*Math.sin((t*d-s)*(2*Math.PI)/p)*0.5+c+b;},easeInBack:function(x,t,b,c,d,s){if(s==undefined){s=1.70158;}return c*(t/=d)*t*((s+1)*t-s)+b;},easeOutBack:function(x,t,b,c,d,s){if(s==undefined){s=1.70158;}return c*((t=t/d-1)*t*((s+1)*t+s)+1)+b;},easeInOutBack:function(x,t,b,c,d,s){if(s==undefined){s=1.70158;}if((t/=d/2)<1){return c/2*(t*t*(((s*=(1.525))+1)*t-s))+b;}return c/2*((t-=2)*t*(((s*=(1.525))+1)*t+s)+2)+b;},easeInBounce:function(x,t,b,c,d){return c-jQuery.easing.easeOutBounce(x,d-t,0,c,d)+b;},easeOutBounce:function(x,t,b,c,d){if((t/=d)<(1/2.75)){return c*(7.5625*t*t)+b;}else{if(t<(2/2.75)){return c*(7.5625*(t-=(1.5/2.75))*t+0.75)+b;}else{if(t<(2.5/2.75)){return c*(7.5625*(t-=(2.25/2.75))*t+0.9375)+b;}else{return c*(7.5625*(t-=(2.625/2.75))*t+0.984375)+b;}}}},easeInOutBounce:function(x,t,b,c,d){if(t<d/2){return jQuery.easing.easeInBounce(x,t*2,0,c,d)*0.5+b;}return jQuery.easing.easeOutBounce(x,t*2-d,0,c,d)*0.5+c*0.5+b;}});
/*
 * jQuery doTimeout: Like setTimeout, but better! - v1.0 - 3/3/2010
 * http://benalman.com/projects/jquery-dotimeout-plugin/
 * 
 * Copyright (c) 2010 "Cowboy" Ben Alman
 * Dual licensed under the MIT and GPL licenses.
 * http://benalman.com/about/license/
 */
(function($){var a={},c="doTimeout",d=Array.prototype.slice;$[c]=function(){return b.apply(window,[0].concat(d.call(arguments)))};$.fn[c]=function(){var f=d.call(arguments),e=b.apply(this,[c+f[0]].concat(f));return typeof f[0]==="number"||typeof f[1]==="number"?this:e};function b(l){var m=this,h,k={},g=l?$.fn:$,n=arguments,i=4,f=n[1],j=n[2],p=n[3];if(typeof f!=="string"){i--;f=l=0;j=n[1];p=n[2]}if(l){h=m.eq(0);h.data(l,k=h.data(l)||{})}else{if(f){k=a[f]||(a[f]={})}}k.id&&clearTimeout(k.id);delete k.id;function e(){if(l){h.removeData(l)}else{if(f){delete a[f]}}}function o(){k.id=setTimeout(function(){k.fn()},j)}if(p){k.fn=function(q){if(typeof p==="string"){p=g[p]}p.apply(m,d.call(n,i))===true&&!q?o():e()};o()}else{if(k.fn){j===undefined?e():k.fn(j===false);return true}else{e()}}}})(jQuery);
/*
 * jQuery Address Plugin v1.4
 * http://www.asual.com/jquery/address/
 *
 * Copyright (c) 2009-2010 Rostislav Hristov
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 *
 * Date: 2011-05-04 14:22:12 +0300 (Wed, 04 May 2011)
 */
(function(c){c.address=function(){var v=function(a){c(c.address).trigger(c.extend(c.Event(a),function(){for(var b={},e=c.address.parameterNames(),f=0,p=e.length;f<p;f++)b[e[f]]=c.address.parameter(e[f]);return{value:c.address.value(),path:c.address.path(),pathNames:c.address.pathNames(),parameterNames:e,parameters:b,queryString:c.address.queryString()}}.call(c.address)))},w=function(){c().bind.apply(c(c.address),Array.prototype.slice.call(arguments));return c.address},r=function(){return M.pushState&&
d.state!==k},s=function(){return("/"+g.pathname.replace(new RegExp(d.state),"")+g.search+(D()?"#"+D():"")).replace(U,"/")},D=function(){var a=g.href.indexOf("#");return a!=-1?B(g.href.substr(a+1),l):""},u=function(){return r()?s():D()},ha=function(){return"javascript"},N=function(a){a=a.toString();return(d.strict&&a.substr(0,1)!="/"?"/":"")+a},B=function(a,b){if(d.crawlable&&b)return(a!==""?"!":"")+a;return a.replace(/^\!/,"")},x=function(a,b){return parseInt(a.css(b),10)},V=function(a){for(var b,
e,f=0,p=a.childNodes.length;f<p;f++){try{if("src"in a.childNodes[f]&&a.childNodes[f].src)b=String(a.childNodes[f].src)}catch(J){}if(e=V(a.childNodes[f]))b=e}return b},F=function(){if(!K){var a=u();if(h!=a)if(y&&q<7)g.reload();else{y&&q<8&&d.history&&t(O,50);h=a;E(l)}}},E=function(a){v(W);v(a?X:Y);t(Z,10)},Z=function(){if(d.tracker!=="null"&&d.tracker!==null){var a=c.isFunction(d.tracker)?d.tracker:j[d.tracker],b=(g.pathname+g.search+(c.address&&!r()?c.address.value():"")).replace(/\/\//,"/").replace(/^\/$/,
"");if(c.isFunction(a))a(b);else if(c.isFunction(j.urchinTracker))j.urchinTracker(b);else if(j.pageTracker!==k&&c.isFunction(j.pageTracker._trackPageview))j.pageTracker._trackPageview(b);else j._gaq!==k&&c.isFunction(j._gaq.push)&&j._gaq.push(["_trackPageview",decodeURI(b)])}},O=function(){var a=ha()+":"+l+";document.open();document.writeln('<html><head><title>"+n.title.replace("'","\\'")+"</title><script>var "+C+' = "'+encodeURIComponent(u())+(n.domain!=g.hostname?'";document.domain="'+n.domain:
"")+"\";<\/script></head></html>');document.close();";if(q<7)m.src=a;else m.contentWindow.location.replace(a)},aa=function(){if(G&&$!=-1){var a,b=G.substr($+1).split("&");for(i=0;i<b.length;i++){a=b[i].split("=");if(/^(autoUpdate|crawlable|history|strict|wrap)$/.test(a[0]))d[a[0]]=isNaN(a[1])?/^(true|yes)$/i.test(a[1]):parseInt(a[1],10)!==0;if(/^(state|tracker)$/.test(a[0]))d[a[0]]=a[1]}G=null}h=u()},ca=function(){if(!ba){ba=o;aa();var a=function(){ia.call(this);ja.call(this)},b=c("body").ajaxComplete(a);
a();if(d.wrap){c("body > *").wrapAll('<div style="padding:'+(x(b,"marginTop")+x(b,"paddingTop"))+"px "+(x(b,"marginRight")+x(b,"paddingRight"))+"px "+(x(b,"marginBottom")+x(b,"paddingBottom"))+"px "+(x(b,"marginLeft")+x(b,"paddingLeft"))+'px;" />').parent().wrap('<div id="'+C+'" style="height:100%;overflow:auto;position:relative;'+(H&&!window.statusbar.visible?"resize:both;":"")+'" />');c("html, body").css({height:"100%",margin:0,padding:0,overflow:"hidden"});H&&c('<style type="text/css" />').appendTo("head").text("#"+
C+"::-webkit-resizer { background-color: #fff; }")}if(y&&q<8){a=n.getElementsByTagName("frameset")[0];m=n.createElement((a?"":"i")+"frame");if(a){a.insertAdjacentElement("beforeEnd",m);a[a.cols?"cols":"rows"]+=",0";m.noResize=o;m.frameBorder=m.frameSpacing=0}else{m.style.display="none";m.style.width=m.style.height=0;m.tabIndex=-1;n.body.insertAdjacentElement("afterBegin",m)}t(function(){c(m).bind("load",function(){var e=m.contentWindow;h=e[C]!==k?e[C]:"";if(h!=u()){E(l);g.hash=B(h,o)}});m.contentWindow[C]===
k&&O()},50)}t(function(){v("init");E(l)},1);if(!r())if(y&&q>7||!y&&"on"+I in j)if(j.addEventListener)j.addEventListener(I,F,l);else j.attachEvent&&j.attachEvent("on"+I,F);else ka(F,50)}},ia=function(){var a,b=c("a"),e=b.size(),f=-1,p=function(){if(++f!=e){a=c(b.get(f));a.is('[rel*="address:"]')&&a.address();t(p,1)}};t(p,1)},la=function(){if(h!=u()){h=u();E(l)}},ma=function(){if(j.removeEventListener)j.removeEventListener(I,F,l);else j.detachEvent&&j.detachEvent("on"+I,F)},ja=function(){if(d.crawlable){var a=
g.pathname.replace(/\/$/,"");c("body").html().indexOf("_escaped_fragment_")!=-1&&c('a[href]:not([href^=http]), a[href*="'+document.domain+'"]').each(function(){var b=c(this).attr("href").replace(/^http:/,"").replace(new RegExp(a+"/?$"),"");if(b===""||b.indexOf("_escaped_fragment_")!=-1)c(this).attr("href","#"+b.replace(/\/(.*)\?_escaped_fragment_=(.*)$/,"!$2"))})}},k,C="jQueryAddress",I="hashchange",W="change",X="internalChange",Y="externalChange",o=true,l=false,d={autoUpdate:o,crawlable:l,history:o,
strict:o,wrap:l},z=c.browser,q=parseFloat(c.browser.version),da=z.mozilla,y=z.msie,ea=z.opera,H=z.webkit||z.safari,P=l,j=function(){try{return top.document!==k?top:window}catch(a){return window}}(),n=j.document,M=j.history,g=j.location,ka=setInterval,t=setTimeout,U=/\/{2,9}/g;z=navigator.userAgent;var m,G=V(document),$=G?G.indexOf("?"):-1,Q=n.title,K=l,ba=l,R=o,fa=o,L=l,h=u();if(y){q=parseFloat(z.substr(z.indexOf("MSIE")+4));if(n.documentMode&&n.documentMode!=q)q=n.documentMode!=8?7:8;var ga=n.onpropertychange;
n.onpropertychange=function(){ga&&ga.call(n);if(n.title!=Q&&n.title.indexOf("#"+u())!=-1)n.title=Q}}if(P=da&&q>=1||y&&q>=6||ea&&q>=9.5||H&&q>=523){if(ea)history.navigationMode="compatible";if(document.readyState=="complete")var na=setInterval(function(){if(c.address){ca();clearInterval(na)}},50);else{aa();c(ca)}c(window).bind("popstate",la).bind("unload",ma)}else!P&&D()!==""?g.replace(g.href.substr(0,g.href.indexOf("#"))):Z();return{bind:function(a,b,e){return w(a,b,e)},init:function(a){return w("init",
a)},change:function(a){return w(W,a)},internalChange:function(a){return w(X,a)},externalChange:function(a){return w(Y,a)},baseURL:function(){var a=g.href;if(a.indexOf("#")!=-1)a=a.substr(0,a.indexOf("#"));if(/\/$/.test(a))a=a.substr(0,a.length-1);return a},autoUpdate:function(a){if(a!==k){d.autoUpdate=a;return this}return d.autoUpdate},crawlable:function(a){if(a!==k){d.crawlable=a;return this}return d.crawlable},history:function(a){if(a!==k){d.history=a;return this}return d.history},state:function(a){if(a!==
k){d.state=a;var b=s();if(d.state!==k)if(M.pushState)b.substr(0,3)=="/#/"&&g.replace(d.state.replace(/^\/$/,"")+b.substr(2));else b!="/"&&b.replace(/^\/#/,"")!=D()&&t(function(){g.replace(d.state.replace(/^\/$/,"")+"/#"+b)},1);return this}return d.state},strict:function(a){if(a!==k){d.strict=a;return this}return d.strict},tracker:function(a){if(a!==k){d.tracker=a;return this}return d.tracker},wrap:function(a){if(a!==k){d.wrap=a;return this}return d.wrap},update:function(){L=o;this.value(h);L=l;return this},
title:function(a){if(a!==k){t(function(){Q=n.title=a;if(fa&&m&&m.contentWindow&&m.contentWindow.document){m.contentWindow.document.title=a;fa=l}if(!R&&da)g.replace(g.href.indexOf("#")!=-1?g.href:g.href+"#");R=l},50);return this}return n.title},value:function(a){if(a!==k){a=N(a);if(a=="/")a="";if(h==a&&!L)return;R=o;h=a;if(d.autoUpdate||L){E(o);if(r())M[d.history?"pushState":"replaceState"]({},"",d.state.replace(/\/$/,"")+(h===""?"/":h));else{K=o;if(H)if(d.history)g.hash="#"+B(h,o);else g.replace("#"+
B(h,o));else if(h!=u())if(d.history)g.hash="#"+B(h,o);else g.replace("#"+B(h,o));y&&q<8&&d.history&&t(O,50);if(H)t(function(){K=l},1);else K=l}}return this}if(!P)return null;return N(h)},path:function(a){if(a!==k){var b=this.queryString(),e=this.hash();this.value(a+(b?"?"+b:"")+(e?"#"+e:""));return this}return N(h).split("#")[0].split("?")[0]},pathNames:function(){var a=this.path(),b=a.replace(U,"/").split("/");if(a.substr(0,1)=="/"||a.length===0)b.splice(0,1);a.substr(a.length-1,1)=="/"&&b.splice(b.length-
1,1);return b},queryString:function(a){if(a!==k){var b=this.hash();this.value(this.path()+(a?"?"+a:"")+(b?"#"+b:""));return this}a=h.split("?");return a.slice(1,a.length).join("?").split("#")[0]},parameter:function(a,b,e){var f,p;if(b!==k){var J=this.parameterNames();p=[];b=b?b.toString():"";for(f=0;f<J.length;f++){var S=J[f],A=this.parameter(S);if(typeof A=="string")A=[A];if(S==a)A=b===null||b===""?[]:e?A.concat([b]):[b];for(var T=0;T<A.length;T++)p.push(S+"="+A[T])}c.inArray(a,J)==-1&&b!==null&&
b!==""&&p.push(a+"="+b);this.queryString(p.join("&"));return this}if(b=this.queryString()){e=[];p=b.split("&");for(f=0;f<p.length;f++){b=p[f].split("=");b[0]==a&&e.push(b.slice(1).join("="))}if(e.length!==0)return e.length!=1?e:e[0]}},parameterNames:function(){var a=this.queryString(),b=[];if(a&&a.indexOf("=")!=-1){a=a.split("&");for(var e=0;e<a.length;e++){var f=a[e].split("=")[0];c.inArray(f,b)==-1&&b.push(f)}}return b},hash:function(a){if(a!==k){this.value(h.split("#")[0]+(a?"#"+a:""));return this}a=
h.split("#");return a.slice(1,a.length).join("#")}}}();c.fn.address=function(v){if(!c(this).attr("address")){var w=function(r){if(r.shiftKey||r.ctrlKey||r.metaKey)return true;if(c(this).is("a")){var s=v?v.call(this):/address:/.test(c(this).attr("rel"))?c(this).attr("rel").split("address:")[1].split(" ")[0]:c.address.state()!==undefined&&c.address.state()!="/"?c(this).attr("href").replace(new RegExp("^(.*"+c.address.state()+"|\\.)"),""):c(this).attr("href").replace(/^(#\!?|\.)/,"");c.address.value(s);
r.preventDefault()}};c(this).click(w).live("click",w).live("submit",function(r){if(c(this).is("form")){var s=c(this).attr("action");s=v?v.call(this):(s.indexOf("?")!=-1?s.replace(/&$/,""):s+"?")+c(this).serialize();c.address.value(s);r.preventDefault()}}).attr("address",true)}return this}})(jQuery);
/*
 * JavaScript Debug - v0.4 - 6/22/2010
 * http://benalman.com/projects/javascript-debug-console-log/
 * 
 * Copyright (c) 2010 "Cowboy" Ben Alman
 * Dual licensed under the MIT and GPL licenses.
 * http://benalman.com/about/license/
 * 
 * With lots of help from Paul Irish!
 * http://paulirish.com/
 */
window.debug=(function(){var i=this,b=Array.prototype.slice,d=i.console,h={},f,g,m=9,c=["error","warn","info","debug","log"],l="assert clear count dir dirxml exception group groupCollapsed groupEnd profile profileEnd table time timeEnd trace".split(" "),j=l.length,a=[];while(--j>=0){(function(n){h[n]=function(){m!==0&&d&&d[n]&&d[n].apply(d,arguments)}})(l[j])}j=c.length;while(--j>=0){(function(n,o){h[o]=function(){var q=b.call(arguments),p=[o].concat(q);a.push(p);e(p);if(!d||!k(n)){return}d.firebug?d[o].apply(i,q):d[o]?d[o](q):d.log(q)}})(j,c[j])}function e(n){if(f&&(g||!d||!d.log)){f.apply(i,n)}}h.setLevel=function(n){m=typeof n==="number"?n:9};function k(n){return m>0?m>n:c.length+m<=n}h.setCallback=function(){var o=b.call(arguments),n=a.length,p=n;f=o.shift()||null;g=typeof o[0]==="boolean"?o.shift():false;p-=typeof o[0]==="number"?o.shift():n;while(p<n){e(a[p++])}};return h})();var MCBM = MCBM || {}; // Minecraft Bookmarklet Global object scope definition

// tracking
MCBM.GA_ACCOUNT = "UA-26457160-5";
MCBM.PAGE_URI = "/js/mc-bookmarklet.js";
MCBM.PAGE_TITLE = "Sony Xperia Minecraft Bookmarklet";
MCBM.DEBUG = false;

// social sharing
MCBM.fbShareURL = {
  eng: "http://campaigns.sonymobile.com/minecraft/like_eng.html?2",
  esp: "http://campaigns.sonymobile.com/minecraft/like_esp.html"
};

MCBM.fbShareCopy = {
  eng: "Play Minecraft™ Anywhere http://campaigns.sonymobile.com/minecraft Time to kill? Take it out on the web.",
  esp: "Juega Minecraft™ donde quiera sea http://campaigns.sonymobile.com/minecraft Si tienes tiempo de sobra, desquítate con el Internet."
};

MCBM.twShareURL = {
  eng: "http://campaigns.sonymobile.com/minecraft/index.php?l=en",
  esp: "http://campaigns.sonymobile.com/minecraft/index.php?l=sp"
};

MCBM.twShareCopy = {
  eng: "I just wreaked havoc with the the new Minecraft browser game from Sony Mobile.",
  esp: "Acabo de causar estragos con el nuevo juego de navegador Minecraft de Sony móvil."
};

if (typeof window.mcbmLang === "undefined") {
  MCBM.language = "eng";
} else {
  MCBM.language = window.mcbmLang;
}

MCBM.shareFbURI = "http://www.facebook.com/sharer.php?u="+encodeURIComponent(MCBM.fbShareURL[MCBM.language])+"&t="+encodeURIComponent(MCBM.fbShareCopy[MCBM.language]);
MCBM.shareTwitterURI = "http://twitter.com/home?status="+encodeURIComponent(MCBM.twShareCopy[MCBM.language])+" "+encodeURIComponent(MCBM.twShareURL[MCBM.language]);

// location
MCBM.initLocationURI = window.location;

if (typeof window.mcbmRootURI === "undefined") {
  var href = window.location.href;
  MCBM.rootURI = href.substring(0, href.lastIndexOf('/'));
} else {
  MCBM.rootURI = window.mcbmRootURI.substring(0, window.mcbmRootURI.lastIndexOf('/'));
}

// Bookmarklet events
MCBM.events = {};

// loading events
MCBM.events.ITEM_LOADED = "mcbmItemLoaded";
MCBM.events.LOAD_ERROR = "mcbmLoadError";

// creeper game events 
MCBM.events.CREEPER_LOADED = "creeperLoaded";
MCBM.events.CREEPER_AUDIO_LOAD_COMPLETE = "audioLoadComplete.creeper";
MCBM.events.CREEPER_AUDIO_LOAD_ERROR = "audioLoadError.creeper";
MCBM.events.CREEPER_EXPLODED = "creeperExploded";
MCBM.events.EXPLOSION_COMPLETE = "explosionComplete";

//pickaxe game events
MCBM.events.MINE_START = "mine-start";
MCBM.events.MINE_END = "mine-end";
MCBM.events.PICKAXE_AUDIO_LOAD_COMPLETE  = "audioLoadComplete.pickaxe";
MCBM.events.PICKAXE_AUDIO_LOAD_ERROR = "audioLoadError.pickaxe";

// ui events
MCBM.events.OPEN_UI = "mcbmOpenUI";
MCBM.events.OPEN_UI_COMPLETE = "mcbmOpenUIComplete";
MCBM.events.CLOSE_UI_COMPLETE = "mcbmCloseUIComplete";
MCBM.events.PLAY_CREEPER_CLICK = "playCreeperClick";
MCBM.events.PLAY_PICKAXE_CLICK = "playPickaxeClick";
MCBM.events.EXIT_CLICK = "mcbmExitClick";
MCBM.events.UI_MOUSE_MOVE = "mcbmUIMouseMove";

// config
MCBM.LOAD_TIMEOUT = 5000;
MCBM.MAX_WIDTH = 2000;
MCBM.MAX_HEIGHT = 1200;
MCBM.webGLenabled = false;
MCBM.errorDimensions = {
  'eng': { width: 365, height: 162 },
  'esp': { width: 365, height: 208 }
}

// timer
MCBM.startTime = 0;
// Numbers in seconds to define actual program running time values when duration is tracked
// based on 22squareds def:
// 0 secs (called in init) = 1 min
// 61 secs = 2 min
// 121 secs = 3 min
// 181 secs = 4 min
// 241 secs = 5 min
MCBM.trackDurations = [61, 121, 181, 241];
MCBM.curDurationIndex = 0;

// utility functions
MCBM.randomInRange = function(min, max) {
	return min + (Math.random() * (max - min));
};

MCBM.randomFromArray = function(array) {
 return	array[Math.floor(Math.random() * array.length)];
};

MCBM.getDuration = function() {
  var duration = new Date().getTime() - MCBM.startTime,
      durSec = Math.floor(duration / 1000),
      durMin = Math.floor(durSec / 60),
      durationStr = (durMin + 1) + ' min';
  
  //debug.log('get duration: '+duration+' sec: '+durSec+' min: '+durMin+' durationStr: '+durationStr);
  
  return durationStr;
}

MCBM.getTrackDurationDelay = function() {
  var elapsed = new Date().getTime() - MCBM.startTime,
      delay = MCBM.trackDurations[MCBM.curDurationIndex] * 1000 - elapsed;
  
  //debug.log('getTrackDurationDelay: '+delay);
  
  return delay;
}

MCBM.trackDurationCallback = function() {
  MCBM.gaTrackEvent('game', 'duration', MCBM.getDuration());
    
  MCBM.curDurationIndex++;
    
  if (MCBM.curDurationIndex < MCBM.trackDurations.length) {
    setTimeout(MCBM.trackDurationCallback, MCBM.getTrackDurationDelay());
  }
}

MCBM.gaTrackPage = function(pageTitle) {
      
    var trackvars = '&utmdt='+pageTitle+'&utmp='+MCBM.PAGE_URI;
    
    if (MCBM.DEBUG) {
      debug.log('GA track page: '+pageTitle+' page uri: '+MCBM.PAGE_URI);
      return;
    }
    
    MCBM.gaUrchinCall(trackvars);
  
};

MCBM.gaTrackEvent = function(category, action, label, value) {
  
  var _label = (typeof label !== "undefined") ? '*'+label : '',
      _val = (typeof value !== "undefined") ?  '('+value+')' : '',
      utme = '5('+category+'*'+action+_label+')'+_val,
      trackvars = '&utmdt='+MCBM.PAGE_TITLE+'&utmp='+MCBM.PAGE_URI+'&utmt=event&utme='+utme;
  
 if (MCBM.DEBUG) {
    debug.log('GA track event: category: '+category+' action: '+action+' label: '+label+' value: '+_val);
    return;
  }
  
  MCBM.gaUrchinCall(trackvars);
  
};

MCBM.gaUrchinCall = function(trackvars) {
  
  var i=1000000000,
      utmn=MCBM.randomInRange(i,9999999999)|0, //random request number
      cookie=MCBM.randomInRange(10000000,99999999)|0, //random cookie number
      random=MCBM.randomInRange(i,2147483647)|0, //number under 2147483647
      today=(new Date()).getTime(),
      win = window.location,
      img = new Image(),
      urchinBaseURL = 'http://www.google-analytics.com/__utm.gif?'+
      'utmwv=5.2.0'+
      '&utmn='+utmn+
      '&utmsr=-&utmsc=-&utmul=-&utmje=0&utmfl=-'+
      '&utmhn='+MCBM.rootURI+
      '&utmr='+win+
      '{trackvars}'+
      '&utmac='+MCBM.GA_ACCOUNT+
      '&utmcc=__utma%3D'+cookie+'.'+random+'.'+today+'.'+today+'.'
      +today+'.2%3B%2B__utmb%3D'
      +cookie+'%3B%2B__utmc%3D'
      +cookie+'%3B%2B__utmz%3D'
      +cookie+'.'+today
      +'.2.2.utmccn%3D(referral)%7Cutmcsr%3D' + win.host + '%7Cutmcct%3D' + win.pathname + '%7Cutmcmd%3Dreferral%3B%2B__utmv%3D'
      +cookie+'.-%3B',
      urchinUrl = urchinBaseURL.split('{trackvars}').join(trackvars);
      
      // trigger the tracking
      img.src = urchinUrl;
};

(function($){

  MCBM.init = function() {

    var $win = $(window),
        $doc = $(document),
        $body = $('body'),
        _baseStyles = '\
  body { position: relative; }\
\
  #mcbm-container {\
    position: absolute;\
    top: 0px;\
    left: 0px;\
    width: 100%;\
    height: 100%;\
    overflow: hidden;\
    z-index: 9999999!important;\
  }\
\
  #mcbm-bedrock {\
    position: absolute;\
    top: 0px;\
    left: 0px;\
    width: 100%;\
    height: 0px;\
    overflow: hidden;\
    background:url('+MCBM.rootURI+'/img/textures/minecraft/bedrock.png);\
    z-index: 9999998!important;\
  }\
\
  #mcbm-loading {\
    position: absolute;\
    top: 0px;\
    left: 0px;\
    width: 259px;\
    height: 36px;\
  }\
\
  #mcbm-error {\
    position: absolute;\
    top: 0px;\
    left: 0px;\
    width: '+MCBM.errorDimensions[MCBM.language].width+'px;\
    height: '+MCBM.errorDimensions[MCBM.language].height+'px;\
    opacity:0;\
  }\
\
  #mcbm-container img {\
    margin: 0;\
  }\
\
  .mcbm-hidden {\
    visibility:hidden;\
    display:none;\
  }';
  
    $('head').append('<style>'+_baseStyles+'</style>');
  
    BrowserDetect.init();
  
    MCBM.$container = $( '<div id="mcbm-container"></div>' );
    MCBM.$loading = $( '<div id="mcbm-loading"><img src="'+MCBM.rootURI+'/img/ui/loading-'+MCBM.language+'.gif" width="259" height="36"></div>' );
    MCBM.$error = $( '<div id="mcbm-error"><img src="'+MCBM.rootURI+'/img/ui/error-'+MCBM.language+'.gif"></div>' );
    
    $body.append( MCBM.$container );
    MCBM.$container.append(MCBM.$loading);
    MCBM.$loading.css({
      top: $win.height() * 0.5 - 18,
      left: $win.width() * 0.5 - 130
    });
       
    MCBM.$container.append(MCBM.$error);
    MCBM.$error.css({
      top: ($win.height() - MCBM.errorDimensions[MCBM.language].height) * 0.5,
      left: ($win.width() - MCBM.errorDimensions[MCBM.language].width) * 0.5
    });
    MCBM.$error.addClass('mcbm-hidden');
    
    MCBM.$container.addClass(MCBM.language);
    
    if (MCBM.$container.outerWidth() > MCBM.MAX_WIDTH) {
      MCBM.$container.css({
        'width': MCBM.MAX_WIDTH+'px',
        'left': '50%',
        'margin-left': Math.floor(-MCBM.MAX_WIDTH * 0.5) + 'px'
      });
    }
    
    var docH = $doc.height();
    if ( (docH < $win.height()) || 
         (MCBM.$container.outerHeight() < $win.height()) ) {
      
      MCBM.$container.css('height', $win.height()+'px');
      
    } else if (docH > MCBM.MAX_HEIGHT) {
      
      // create "bedrock" area below to denote end of interactive area
      var bedrockHeight = docH - MCBM.MAX_HEIGHT;
      MCBM.$bedrock = $( '<div id="mcbm-bedrock"></div>' );
      MCBM.$bedrock.css({
        top:MCBM.MAX_HEIGHT,
        height:bedrockHeight
      });
      
      MCBM.$container.css('height', MCBM.MAX_HEIGHT+'px');
      $body.append( MCBM.$bedrock );
      
    }
    
    // track page view
    MCBM.gaTrackPage(MCBM.PAGE_TITLE);

    // start tracking durations
    MCBM.startTime = new Date().getTime();
    setTimeout(MCBM.trackDurationCallback, MCBM.getTrackDurationDelay());
    
    // track the first 0sec duration
    MCBM.gaTrackEvent('game', 'duration', MCBM.getDuration());
  };
  
})(jQuery);

// start when ready
jQuery.noConflict();
jQuery(function($) {
  
  // This is only used for testing as a standalone page
  // make sure we're not calling this in the actual bookmarklet
  // it will get initialized by mcbm-load.js
  if (typeof window.mcbmScriptURI === "undefined") { 
    
    // kick-off the app
    MCBM.init();
        
    if (typeof MCBM.main === 'function') {
      MCBM.main();
    } else {
      //debug.log("MCBM.main not defined");
    }
  }

});// ====================================================================
// Display - setup for canvas display used for bookmarklet 
//   - handles adding display elements (canvas, container divs, etc.) to DOM
//   - handles resizing elements 
//
// author: Nate Horstmann nate@natehorstmann.com
// ====================================================================

(function($){ // requires jQuery
  
  // ====================================================================
  // @testDisplay object
  // ====================================================================
  MCBM.display = function(showStats, use3D) {
    
    var $body = $('body'),
        displayCanvas = document.createElement('canvas'),
        displayCanvasCtx = displayCanvas.getContext((use3D === true) ? 'experimental-webgl' : '2d'),
        $stats = null;
    
    var  pScope = {};
    
    pScope.canvas = displayCanvas;
    pScope.dirty = false;
    
    displayCanvas.width = MCBM.$container.outerWidth();
    displayCanvas.height = MCBM.$container.outerHeight();
    
    $displayCanvas = $(displayCanvas);
    $displayCanvas.css({
      'position':"absolute",
      'top':'0px',
      'left':'0px'
    });
    MCBM.$container.append($displayCanvas);
    
    // framerate display
    if (showStats) {
      pScope.stats = new Stats();
      $stats = $(pScope.stats.domElement);
      $stats.css({
        'position': 'absolute',
        'top': '0px'
      });
      MCBM.$container.append( $stats );
    }
    
    pScope.getContext = function() {
      return displayCanvasCtx;
    };
    
    pScope.getCanvas = function() {
      return displayCanvas;
    };
    
    pScope.getContainer = function() {
      return $container;
    };
    
    pScope.clear = function() {
      
      displayCanvasCtx.clearRect(0, 0, displayCanvas.width, displayCanvas.height);
      pScope.dirty = false;
      
    };
    
    pScope.resize = function(w, h) {      
      displayCanvas.width = w;
    };
    
    return pScope;
    
  };
  
})(jQuery);// ====================================================================
// Sprite Object for animating spritesheets
// 
// author: Nate Horstmann nate@natehorstmann.com
// ====================================================================

// ====================================================================
// @sprite object
// ====================================================================
MCBM.sprite = function(img, frameWidth, frameHeight, baseScale, sequenceData, registration) {
  
  var _image = img, //document.createElement('img'),
      _frameWidth = frameWidth,
      _frameHeight = frameHeight,
      _baseScale = baseScale || 1,
      _scale = _baseScale,
      _flipScale = null,
      _registration = (typeof registration !== "undefined") ? new THREE.Vector2(-registration.x, -registration.y ) : new THREE.Vector2(-_frameWidth * 0.5, -_frameHeight * 0.5),
      _pos = new THREE.Vector2(0, 0),
      _cols = 0,
      _rows = 0,
      
      _startFrame = 0,
      _endFrame = 0,
      _curFrame = 0, // actual frame in relation the whole sprite sheet
      _sequenceData = sequenceData,
      _curSequence,
      _totalFrames = 0,
      _tStart = 0,
      _duration = 0,
      _loop = false,
      _isReady = false,
      _isPlaying = false,
      _hasPlayed = false,
      _queuedDrawCtx = null;
  
  var pScope = {};
  
  // ----------------------------------------------------------------
  // private functions
  // ----------------------------------------------------------------
    
  function _init() {
    
    _cols = _image.width/_frameWidth;
    _rows = _image.height/_frameHeight;
    
    _totalFrames = _rows * _cols;
    _endFrame = _totalFrames;
    
    _isReady = true;
    
  };
  
  // ----------------------------------------------------------------
  
  function _setFrame(frame) {
        
    if (_curFrame == frame) {      
      return;
    }
    
    _curFrame = frame;
    
    if (_curFrame > _endFrame) {
      if (_loop) {
        _curFrame = _startFrame;
      } else {
        _curFrame = _endFrame;
        _isPlaying = false;
      }
    }
    
    if (_curFrame <= _startFrame) {
      if (_loop) {
        _curFrame = _endFrame;
      } else {
        _curFrame = 1;
        _isPlaying = false;
      }
    }
    
  };
  
  // ----------------------------------------------------------------
  
  function _draw(targetCtx) {
    
    var col = (_curFrame - 1)%_cols;
    var row = (_curFrame - 1)/_cols|0;
    
    var destW = _frameWidth * _scale;
    var destH = _frameHeight * _scale;
            
    var sX = col * _frameWidth;
    var sY = row * _frameHeight;
    var destX = _pos.x + (_registration.x * _scale);
    var destY = _pos.y + (_registration.y * _scale);
      
    if (_flipScale != null) {  
      targetCtx.save();
      targetCtx.scale(_flipScale.x, _flipScale.y);
      if (_flipScale.x < 0) {
        destX = _flipScale.x * (_pos.x - _registration.x);
      }
      
      if (_flipScale.y < 0) {
        destY = _flipScale.y * (_pos.y - _registration.y);
      }
    }
    
    //debug.log("destW,destH: "+destW+", "+destH);
    //debug.log("x,y: "+col * _frameWidth+", "+row * _frameHeight);
    //debug.log("sX,sY: "+sX+", "+sY);
        
    targetCtx.drawImage(pScope.getImage(), sX, sY, _frameWidth, _frameHeight, destX, destY, destW, destH);
    
    if (_flipScale != null) {
      targetCtx.restore();
    }
    
    _queuedDrawCtx = null;    
    
  };
  
  // ----------------------------------------------------------------
  
  _init();
  
  // ----------------------------------------------------------------
  // public functions
  // ----------------------------------------------------------------
  
  pScope.getImage = function() {
    return _image;
  };
  
  // ----------------------------------------------------------------
  
  pScope.setScale = function(scale) {
    
    _scale = scale;
    
  };
  
  // ----------------------------------------------------------------
  
  pScope.getBaseScale = function() {
    return _baseScale;
  };
  
  // ----------------------------------------------------------------
  
  pScope.setPosition = function( pos ) {
    _pos = pos;
  };
  
  // ----------------------------------------------------------------
    
  pScope.setDuration = function( duration ) {
    _duration = duration;
  };
  
  // ----------------------------------------------------------------
  
  pScope.setLooping = function( val ) {
    _loop = val;
  };
      
  pScope.update = function(tCur) {
    
    //debug.log("Sprite :: update()");
    if (!_isPlaying) {
      return;
    }
    
    var elapsed = tCur - _tStart;
    elapsed = (_loop) ? elapsed%_duration : elapsed;
    
    // can update current frame based on tween or just regular increment
    if (_sequenceData == null) {
      
      var destFrame = ((elapsed/_duration) * _totalFrames)|0;
      _setFrame( destFrame + 1 );
      
    } else {
      
      var destFrame = ((elapsed/_duration) * _totalFrames)|0;
            
      _setFrame( _startFrame + destFrame );
      
    }
    
  };
  
  // ----------------------------------------------------------------
  
  pScope.draw = function(targetCtx) {
    
    if (_isReady) {
      _draw(targetCtx);
    } else {
      _queuedDrawCtx = targetCtx;
    }
    
  };
  
  // ----------------------------------------------------------------
  
  pScope.play = function(duration) {
    
    if (_isPlaying) {
      return;
    }
    
    _curFrame = 1;
    
    _isPlaying = _hasPlayed = true;
    _duration = duration;
    _tStart = new Date().getTime();
    
    
  };
  
  // ----------------------------------------------------------------
  
  pScope.stop = function() {
    _isPlaying = false;
    
  };
  
  // ----------------------------------------------------------------
  
  pScope.getHasPlayed = function() {
    return _hasPlayed;
  };
  
  // ----------------------------------------------------------------
  
  pScope.getIsPlaying = function() {
    return _isPlaying;
  };
  
  // ----------------------------------------------------------------
  
  pScope.setSequence = function(sequenceName) {
    
    if (typeof _sequenceData == "undefined") {
      //debug.log("Sprite.setSequence :: WARNING no sequence data has been defined: ");
      return;
    }
    
    var sequence = _sequenceData[sequenceName];
    
    if (typeof sequence == "undefined") {
      //debug.log("Sprite.setSequence :: WARNING no sequence found for: "+sequenceName);
      return;
    }
      
    _curSequence = sequence;
    _flipScale = null;
        
    _startFrame = _curSequence.frameBounds[0];
    _endFrame = _curSequence.frameBounds[1];
    _totalFrames = _endFrame - _startFrame + 1;
    
    if (_curSequence.flipHorizontal || _curSequence.flipVertical) {
      _flipScale = {
        x:(_curSequence.flipHorizontal) ? -1 : 1,
        y:(_curSequence.flipVertical) ? -1 : 1
      };
    }
    
  };
  
  return pScope;
    
};// Basic Particle Object
// 
// author: Nate Horstmann nate@natehorstmann.com
// ====================================================================

// ====================================================================
// @particle object
// ====================================================================
MCBM.particle = function(pos, vel) {

    var _pos = pos || new THREE.Vector3(0, 0, 0),
        _vel = vel || new THREE.Vector3(0, 0, 0);
    
    var pScope = {};
    
    // ----------------------------------------------------------------
    // public functions 
    // ----------------------------------------------------------------
    
    pScope.update = function() {
      
      _pos.addSelf(_vel);
      
    };
    
    // ----------------------------------------------------------------
    
    pScope.getPosition = function() {
      return _pos;
    };
    
    // ----------------------------------------------------------------
    
    pScope.setPosition = function( pos ) {
      _pos.copy(pos);
    };
    
    // ----------------------------------------------------------------
    
    pScope.getVelocity = function() {
      return _vel;
    };
    
    // ----------------------------------------------------------------
    
    pScope.setVelocity = function( vel ) {
      _vel.copy(vel);
    };
    
    // ----------------------------------------------------------------
    
    pScope.destroy = function() {
      _pos = null;
      _vel = null;
    };
    
    return pScope;
};// ====================================================================
// Voxel Utilites
// 
// author: Nate Horstmann nate@natehorstmann.com
// ====================================================================

// ====================================================================
// @voxelGrid object
// ====================================================================
MCBM.voxelGrid = function() {
  
  var _posData = [],
      _voxelData = {};
  
  var pScope = {};
  
  function _getPosId(gridPos) {
    return gridPos.x + ',' + gridPos.y + ',' + gridPos.z;
  };
  
  /** 
    Adds a position of type THREE.Vector3 to the grid 
  */
  pScope.addVoxel = function(gridPos, voxel) {
    
    var posId = _getPosId(gridPos);
    
    // dont add the position id if its already stored
    if (!pScope.hasPos(gridPos)) { 
      _posData.push(posId);
    }
    
    // add or overwrite existing voxe
    _voxelData[posId] = voxel;
    
  };
  
  pScope.getVoxelByPos = function(gridPos) {
    return _voxelData[_getPosId(gridPos)];
  }
  
  /** 
    Checks for a position of type THREE.Vector3 in the grid 
  */
  pScope.hasPos = function(gridPos) {

    return (_posData.indexOf(_getPosId(gridPos)) == -1 ) ? false : true;
    
  };
  
  /** 
    Returns an object that contains boolean values for the sides that a position shares with other existing positions in the grid
  */
  pScope.getSharedSidesForPos = function(gridPos) {
    
    var sharedSides = {
      px: pScope.hasPos( new THREE.Vector3( gridPos.x + 1, gridPos.y, gridPos.z ) ),
      nx: pScope.hasPos( new THREE.Vector3( gridPos.x - 1, gridPos.y, gridPos.z ) ),
      py: pScope.hasPos( new THREE.Vector3( gridPos.x, gridPos.y + 1, gridPos.z ) ),
      ny: pScope.hasPos( new THREE.Vector3( gridPos.x, gridPos.y - 1, gridPos.z ) ),
      pz: pScope.hasPos( new THREE.Vector3( gridPos.x, gridPos.y, gridPos.z + 1 ) ),
      nz: pScope.hasPos( new THREE.Vector3( gridPos.x, gridPos.y, gridPos.z - 1 ) )
    };
    
    return sharedSides;
  };
  
  return pScope;
};// ====================================================================
// Playfield Grid - Three.js implementation of the 3D blocks
// 
// author: Nate Horstmann nate@natehorstmann.com
// ====================================================================

(function($){
  
  // ====================================================================
  // @playfieldGrid object
  // ====================================================================
  MCBM.playfieldGrid = function(displayCanvas, gridCellPixelSize) {
    
    var DEBUG = false;
    
    // ----------------------------------------------------------------
    // Define private vars
    // ----------------------------------------------------------------

    // DOM and canvas vars
    var $body = $('body'),
        _displayCanvas = displayCanvas,
        $displayCanvas = $(_displayCanvas),
        _displayCanvasCtx = _displayCanvas.getContext("2d"),
        _renderCanvas,
        _maskCanvas,
        _w = _displayCanvas.width,
        _h = _displayCanvas.height;
        
    // 3D scene vars
    var _aspect = _w/_h,
        _fov = 25,
        _camera,
        _scene,
        _renderer,
        _refPlane,
        _maskScene,
        _maskPlane,
        _maskRenderer;
      
     // textures
    var _grassDirtTex = null,
        _dirtTex = null,
        _stoneTex = null,
        _gravelTex = null,
        _coalOreTex = null,
        _ironOreTex = null,
        _goldOreTex = null,
        _lavaTex = null;
        
    // texture -> material association
    var _texturesLookup = null,
        _materialTypeLookup = null,
        //_materialsLookup = null,
        _randomMaterialTypes = null;

    // interactivity vars
    var _projector,
        _ray,
        _mouse2D,
        _mouse3D;
  
    // playfield grid definition vars
    var _gridCellPixelSize = gridCellPixelSize,
        _cols = Math.ceil(MCBM.MAX_WIDTH / _gridCellPixelSize),
        _rows = Math.ceil(MCBM.MAX_HEIGHT / _gridCellPixelSize),
        _gridCellSize = 0, // needs to be converted from pixel size based on 3d world coordinates
        _gridW = 0, // based on _gridCellSize
        _gridH = 0,
        _camZ = 1000,
        _layers = 7,
        _voxelGrid = null;
    
    
    var pScope = {};
    pScope.isDirty = true;
    
    // ----------------------------------------------------------------
    // private methods
    // ----------------------------------------------------------------

    function _init() {
    
      _initMainDisplayScene();
              
      _initTextures();
      
      // voxel grid object stores data about which voxels have been created
      _voxelGrid = MCBM.voxelGrid();
      
      // interactivity
      _drawReferenceGrid();
      _mouse2D = new THREE.Vector3( 0, 0, 0 );
  
    };
    
    function _reset() {
      
      _scene = new THREE.Scene();
      _scene.addObject( _refPlane );
      
      _maskScene = new THREE.Scene();
      _maskPlane = new THREE.Mesh( new THREE.PlaneGeometry( _gridW, _gridH, _rows, _cols ), new THREE.MeshFaceMaterial() );
      _maskScene.addObject( _maskPlane );
      
      _voxelGrid = MCBM.voxelGrid(_cols, _rows, _layers);
      
      _maskRenderer.render( _maskScene, _camera );
      _renderer.render( _scene, _camera );
      
    };
    
    // ----------------------------------------------------------------
  
    function _initMainDisplayScene() {
      
      _renderCanvas = document.createElement( 'canvas' );
      
      _camera = new THREE.Camera( _fov, _aspect, 1, 10000 );
      _camera.position.z = _camZ;
      _camera.target.position.z = 0;

      _scene = new THREE.Scene();
      
      _renderer = ( MCBM.webGLenabled ) ? new THREE.WebGLRenderer({canvas:_renderCanvas}) : new THREE.CanvasRenderer({canvas:_renderCanvas});
      _renderer.setSize(_w, _h);
      
      // render once to get updated matrices
      _renderer.render( _scene, _camera );
      _projector = new THREE.Projector();
      _ray = new THREE.Ray( _camera.position, null );
      
      // figure out the ratio of world coordinates to screen coordinates so that our _gridCellSize remains true to its value in pixels
      var viewMaxX3D = new THREE.Vector3( 1, 0, 0 );
      viewMaxX3D = _projector.unprojectVector( viewMaxX3D.clone(), _camera );
      _ray.direction = viewMaxX3D.subSelf( _camera.position ).normalize();
      var worldMaxX = _ray.direction.x * (-_ray.origin.z / _ray.direction.z );
      //debug.log("worldMaxX: "+worldMaxX);
      
      var viewMinX3D = new THREE.Vector3( -1, 0, 0 );
      viewMinX3D = _projector.unprojectVector( viewMinX3D, _camera );
      _ray.direction = viewMinX3D.subSelf( _camera.position ).normalize();
      var worldMinX = _ray.direction.x * (-_ray.origin.z / _ray.direction.z );
      //debug.log("worldMinX: "+worldMinX);
      
      var worldWidth = worldMaxX - worldMinX;
      
      var worldToScreenPx = worldWidth/_w;
      _gridCellSize = _gridCellPixelSize * worldToScreenPx;
      _gridW = _cols * _gridCellSize;
      _gridH = _rows * _gridCellSize;
      
      //debug.log("MCBM.playfieldGrid :: _cols: "+_cols+" _rows: "+_rows);
      
      _initMaskScene();
      
    };
    
    // ----------------------------------------------------------------
    
    function _updateMainDisplaySize() {
      
      _aspect = _w/_h;
      _camera.aspect = _aspect;
      _camera.updateProjectionMatrix();
      _renderer.setSize(_w, _h);
      
      // render once to get updated matrices
      _renderer.render( _scene, _camera );
      _ray = new THREE.Ray( _camera.position, null );
      
      // figure out the ratio of world coordinates to screen coordinates so that our _gridCellSize remains true to its value in pixels
      var viewMaxX3D = new THREE.Vector3( 1, 0, 0 );
      viewMaxX3D = _projector.unprojectVector( viewMaxX3D.clone(), _camera );
      _ray.direction = viewMaxX3D.subSelf( _camera.position ).normalize();
      var worldMaxX = _ray.direction.x * (-_ray.origin.z / _ray.direction.z );
      //debug.log("worldMaxX: "+worldMaxX);
      
      var viewMinX3D = new THREE.Vector3( -1, 0, 0 );
      viewMinX3D = _projector.unprojectVector( viewMinX3D, _camera );
      _ray.direction = viewMinX3D.subSelf( _camera.position ).normalize();
      var worldMinX = _ray.direction.x * (-_ray.origin.z / _ray.direction.z );
      //debug.log("worldMinX: "+worldMinX);
      
      var worldWidth = worldMaxX - worldMinX;
      
      var worldToScreenPx = worldWidth/_w;
      _gridCellSize = _gridCellPixelSize * worldToScreenPx;
      _gridW = _cols * _gridCellSize;
      _gridH = _rows * _gridCellSize;
      //debug.log("MCBM.playfieldGrid :: _cols: "+_cols+" _rows: "+_rows);
      
      _maskRenderer.setSize( _w, _h );
      
      _render();
    };
    
    // ----------------------------------------------------------------
  
    function _initMaskScene() {
      
      _maskCanvas = document.createElement( 'canvas' );
      _maskScene = new THREE.Scene();
      _maskPlane = new THREE.Mesh( new THREE.PlaneGeometry( _gridW, _gridH, _rows, _cols ), new THREE.MeshFaceMaterial() );
      _maskScene.addObject( _maskPlane );
      _maskRenderer = new THREE.CanvasRenderer({canvas:_maskCanvas}); // using canvas for the mask buffer runs faster for some reason
      _maskRenderer.setSize( _w, _h );

    };
    
    // ----------------------------------------------------------------
  
    function _initTextures() {
      
      // textures
      _grassDirtTex = _loadTexture( MCBM.rootURI + '/img/textures/minecraft/grass_dirt.png' ),
      _dirtTex = _loadTexture( MCBM.rootURI + '/img/textures/minecraft/dirt.png' );
      _stoneTex = _loadTexture( MCBM.rootURI + '/img/textures/minecraft/stone.png' );
      _gravelTex = _loadTexture( MCBM.rootURI + '/img/textures/minecraft/gravel.png' );
      _coalOreTex = _loadTexture( MCBM.rootURI + '/img/textures/minecraft/coal.png' );
      _ironOreTex = _loadTexture( MCBM.rootURI + '/img/textures/minecraft/iron.png' );
      _goldOreTex = _loadTexture( MCBM.rootURI + '/img/textures/minecraft/gold.png' );
      _lavaTex = _loadTexture( MCBM.rootURI + '/img/textures/minecraft/lava.png' );
      _bedrockTex = _loadTexture( MCBM.rootURI + '/img/textures/minecraft/bedrock.png' );
      //waterTex = _loadTexture( MCBM.rootURI + '/img/textures/minecraft/water.png' );
      
      _randomMaterialTypes = [
        "gravel",
        "stone",
        "coal",
        "iron",
        "gold"
      ];
      
      _texturesLookup = {
        grassDirt: _grassDirtTex,
        dirt: _dirtTex,
        gravel: _gravelTex,
        stone: _stoneTex,
        coal: _coalOreTex,
        iron: _ironOreTex,
        gold: _goldOreTex,
        lava: _lavaTex,
        bedrock: _bedrockTex,
      };
      
      _generateGridMaterials();
      
    };
  
    // ----------------------------------------------------------------
  
    function _loadTexture( path ) {
    
      var image = new Image();
      var texture  = new THREE.Texture( image, new THREE.UVMapping(), THREE.ClampToEdgeWrapping, THREE.ClampToEdgeWrapping, THREE.NearestFilter, THREE.NearestFilter );
          
      image.onload = function () { texture.needsUpdate = true; };
      image.crossOrigin = '';
      image.src = path;
        
       return (MCBM.webGLenabled) ? new THREE.MeshLambertMaterial( { map: texture } ) : new THREE.MeshBasicMaterial( { map: texture } );

    };
    
    // ----------------------------------------------------------------
    
    function _generateGridMaterials() {
          
      var layer = 0,
          row = 0,
          col = 0;
      
      // initialize arrays
      //_materialsLookup = [];
      _materialTypeLookup = [];
      for (layer = 0; layer <= _layers; layer++) {
        _materialTypeLookup[layer] = [];
        //_materialsLookup[layer] = [];  
        for (row = 0; row < _rows; row++) {
          _materialTypeLookup[layer][row] = [];
          //_materialsLookup[layer][row] = [];
        };
      };      
      
      // top(0) layer - all grassDirt
      layer = 0;
      for (row = 0; row < _rows; row++) {
        for (col = 0; col < _cols; col++) {
          _materialTypeLookup[layer][row][col] = "grassDirt";
        };
      };
      
      // second(1) layer - all dirt
      layer = 1;
      for (row = 0; row < _rows; row++) {
        for (col = 0; col < _cols; col++) {
          _materialTypeLookup[layer][row][col] = "dirt";
        };
      };
      
     // fill the rest of the layers with stone
      for (layer = 2; layer < _layers; layer++) {    
        for (row = 0; row < _rows; row++) {
          for (col = 0; col < _cols; col++) {

            _materialTypeLookup[layer][row][col] = "stone";

          };
        };
      };
      
      //======================================================
      // Randomize Ore distribution in middle grid levels
      //======================================================
      // Instead of dealing with 3D noise data let's just pick some random row x col locations in different layers
      // and then add a few blocks of the same material clustered around those spots to mimic ore "veins"
      
      var halfPad = 0; //(_rowColPadding*0.5)|0,
          rRow = 0,
          rCol = 0,
          layer = 0;
      
      var numDirts = 30; // add some random dirt into the third layer
      for(i=0; i<numDirts; i++) {
        rRow = MCBM.randomInRange(0, _rows-halfPad)|0;
        rCol = MCBM.randomInRange(halfPad, _cols-halfPad)|0;
        layer = 2; 
         _generateOreVein("dirt", rRow, rCol, layer,  MCBM.randomInRange(2, 5)|0);
      }
      
      var numCoalVeins = 15; // first coal layer
      for(i=0; i<numCoalVeins; i++) {
        rRow = MCBM.randomInRange(halfPad, _rows-halfPad)|0;
        rCol = MCBM.randomInRange(halfPad, _cols-halfPad)|0;
        layer = 2; 
        _generateOreVein("coal", rRow, rCol, layer,  MCBM.randomInRange(2, 4)|0);
      }
      
      for(i=0; i<numCoalVeins; i++) {  // second coal layer
        rRow = MCBM.randomInRange(halfPad, _rows-halfPad)|0;
        rCol = MCBM.randomInRange(halfPad, _cols-halfPad)|0;
        layer = 3; 
        _generateOreVein("coal", rRow, rCol, layer,  MCBM.randomInRange(2, 4)|0);
      }
      
      var numIronVeins = 5; // first iron layer
      for(i=0; i<numIronVeins; i++) {  
        rRow = MCBM.randomInRange(halfPad, _rows-halfPad)|0;
        rCol = MCBM.randomInRange(halfPad, _cols-halfPad)|0;
        layer = 3; 
        _generateOreVein("iron", rRow, rCol, layer,  MCBM.randomInRange(2, 4)|0);
      }
      
      numIronVeins = 7; // second iron layer
      for(i=0; i<numIronVeins; i++) {  
        rRow = MCBM.randomInRange(halfPad, _rows-halfPad)|0;
        rCol = MCBM.randomInRange(halfPad, _cols-halfPad)|0;
        layer = 4; 
        _generateOreVein("iron", rRow, rCol, layer,  MCBM.randomInRange(2, 4)|0);
      }
      
      var numGoldVeins = 3; // first gold layer
      for(i=0; i<numGoldVeins; i++) {  
        rRow = MCBM.randomInRange(halfPad, _rows-halfPad)|0;
        rCol = MCBM.randomInRange(halfPad, _cols-halfPad)|0;
        layer = 5; 
        _generateOreVein("gold", rRow, rCol, layer,  MCBM.randomInRange(1, 3)|0);
      }
      
      var numGoldVeins = 2; // second gold layer
      for(i=0; i<numGoldVeins; i++) {  
        rRow = MCBM.randomInRange(halfPad, _rows-halfPad)|0;
        rCol = MCBM.randomInRange(halfPad, _cols-halfPad)|0;
        layer = 6; 
        _generateOreVein("gold", rRow, rCol, layer,  2|0);
      }
           
    };
    
    // ----------------------------------------------------------------
    
    function _generateOreVein(materialName, row, col, layer, length) {
      //debug.log("_generateOreVein :: "+materialName+": pos: "+row+", "+col+", "+layer+" length: "+length);
      
      //pick an axis
      var axis = (Math.random() >= 0.5) ? "x" : "y";
    
      for (var i=0; i <= length; i++) {
      
        if (axis == "x") {
        
          col++;
          if (col >= _cols) {
            col = _cols - 1;
          }
        
        } else {
        
          row++
          if (row >= _rows) {
            row = _rows - 1;
          }
        
        }
                
        _materialTypeLookup[layer][row][col] = materialName;
      }
      
    };
    
    // ----------------------------------------------------------------
    
    function _getMaterialsByGridPos(gridPos) {
    
      var col = gridPos.x,
          row = gridPos.y,
          layer = gridPos.z;
                
      try {          
        var pxCol = (col < _cols - 1 ) ? col + 1 : col;
        var nxCol = (col > 0) ? col - 1 : col;
      
        var pxTex = _texturesLookup[ _materialTypeLookup[layer][row][pxCol] ];
        var nxTex = _texturesLookup[ _materialTypeLookup[layer][row][nxCol] ];
      
        var pyRow = (row < _rows - 1 ) ? row + 1 : row;
        var nyRow = (row > 0) ? row - 1 : row;
      
        var pyTex = _texturesLookup[ _materialTypeLookup[layer][pyRow][col] ];
        var nyTex = (row > 0) ? _texturesLookup[ _materialTypeLookup[layer][nyRow][col] ] : _texturesLookup["bedrock"];
      
        var pzLayer = (layer > 0) ? layer - 1 : layer;
        var nzLayer = (layer < _layers - 1) ? layer + 1 : layer;
      
        var pzTex = _texturesLookup[ _materialTypeLookup[pzLayer][row][col] ];
        // bottom(_layers) layer - all lava
        var nzTex = (layer != _layers - 1) ? _texturesLookup[ _materialTypeLookup[nzLayer][row][col] ] : _texturesLookup["lava"];
      
        var materials = [
          pxTex,
          nxTex,

          pyTex,
          nyTex,

          pzTex,
          nzTex,
        ];
        
        return materials;
        
      } catch(e) {
        
        return undefined;
        
      }
            
      //return _materialsLookup[gridPos.z][gridPos.y][gridPos.x];
      
    };
  
  // ----------------------------------------------------------------

    function _drawReferenceGrid() {
    
      // opacity can be turned on while mask is diabled to see where playfield "tiles" are  
      var material = new THREE.MeshLambertMaterial( { color: 0x00ff00, opacity: (DEBUG) ? 1 : 0, shading: THREE.FlatShading } );
      material.wireframe = true;
    
      // this plane is used to capture the 3D location of mouse interaction to set mask tiles and voxel geometry
      _refPlane = new THREE.Mesh( new THREE.PlaneGeometry( _gridW, _gridH, _cols, _rows ), material );
      _refPlane.name = "refPlane";
      _refPlane.position.z = -1;
      _scene.addObject( _refPlane );
    
    }
    
    // ----------------------------------------------------------------
    
    function _getGridPosition(position) {
      var offsetX = position.x + _gridW * 0.5;
      var offsetY = position.y + _gridH * 0.5;
      var col = (offsetX/_gridCellSize)|0;
      var row = (offsetY/_gridCellSize)|0;
            
      //debug.log("attempting to create new voxel at grid pos : ("+col+", "+row+")");
  
      return new THREE.Vector3( col, row, 0);
    };
    
    // ----------------------------------------------------------------
    
    function _getPosition3D(gridPosition) {
      var x = _gridCellSize * 0.5 + (gridPosition.x * _gridCellSize) - _gridW * 0.5;
      var y = _gridCellSize * 0.5 + (gridPosition.y * _gridCellSize) - _gridH * 0.5;
      var z = -gridPosition.z * _gridCellSize - _gridCellSize * 0.5;
      
      return new THREE.Vector3( x, y, z);
    }

    // ----------------------------------------------------------------
    
    function _getVoxelName(gridPos) {
      return "voxel:"+gridPos.x + ","+gridPos.y + ","+gridPos.z;
    };
    
    // ----------------------------------------------------------------
  
    function _createVoxelAtGridPos(destGridPos) {
      
      var position = _getPosition3D(destGridPos);
      //debug.log("_createVoxelAtGridPos :: position: ("+position.x+", "+position.y+", "+position.z+") ");
      
      // when creating a voxel at the top layer only draw the mask tile once for a grid pos 
      if (destGridPos.z == 0 && !_voxelGrid.hasPos(destGridPos)) {
        _createMaskTile(position);
      }
    
      //debug.log("an empty grid position exists at :: ("+destGridPos.x+", "+destGridPos.y+", "+destGridPos.z+")");
  
      var materials = _getMaterialsByGridPos(destGridPos);
  
      var sharedSides = _voxelGrid.getSharedSidesForPos(destGridPos);
      var displayedSides = _getDisplayedFromSharedSides(sharedSides);
   
    
      var voxel = _createVoxelGeometry(materials, displayedSides, position);
      voxel.name = _getVoxelName(destGridPos);
      _scene.addObject( voxel );
      _voxelGrid.addVoxel(destGridPos, voxel);
  
      // update preexisting voxels geomtry at shared sides
      var updateGridPos =  new THREE.Vector3();
      for (side in sharedSides) {
    
        if ( sharedSides[side] ) { // side is shared
          // use the corrent position and shared side data to define the position that needs to be updated
          updateGridPos.copy(destGridPos);
      
          var sideComponents = side.split("");
          var offset = (sideComponents[0] == "p" ) ? 1 : -1;
          var prop = sideComponents[1];
              
          updateGridPos[prop] += offset;
          var updateMaterials = _getMaterialsByGridPos(updateGridPos);
          
          if (updateMaterials !== undefined) { // grid material will be undefined if try to dig past the edge of the grid
            var updatedDisplayedSides = _getDisplayedFromSharedSides( _voxelGrid.getSharedSidesForPos(updateGridPos) );
                
            // only generate new geometry if at least one side is displayed otherwise just set to null
            var isVoxelDisplayed = false;
            for (side in updatedDisplayedSides) {
              isVoxelDisplayed = updatedDisplayedSides[side];
              if (isVoxelDisplayed)
                break;
            }
      
            // store the position data for the voxel, then remove it and replace with updated geometry 
            var oldVoxel = _voxelGrid.getVoxelByPos(updateGridPos);
            if (oldVoxel) {
              var oldPosition = new THREE.Vector3();
              oldPosition.copy(oldVoxel.position);
              _scene.removeObject( oldVoxel );
            }
      
            var updatedVoxel = (isVoxelDisplayed) ? _createVoxelGeometry(updateMaterials, updatedDisplayedSides, oldPosition) : null;
            if (updatedVoxel) {
              updatedVoxel.name = _getVoxelName(updateGridPos);
              _scene.addObject( updatedVoxel );
            }
      
            _voxelGrid.addVoxel(updateGridPos, updatedVoxel);
          }
        }
      }
  
      pScope.isDirty = true;
  
    };
    
    function _createVoxelGeometry(materials, displayedSides, position) {
    
      // make the new voxel geometry
      var voxel = new THREE.Mesh( new THREE.CustomCubeGeometry( _gridCellSize, _gridCellSize, _gridCellSize, 1, 1, 1, materials, true, displayedSides ), new THREE.MeshFaceMaterial() );
      voxel.position.x = position.x;
      voxel.position.y = position.y;
      voxel.position.z = position.z;
      voxel.name = name
      voxel.matrixAutoUpdate = false;
      voxel.updateMatrix();
      voxel.overdraw = true;
  
      return voxel;
    
    };
    
    // ----------------------------------------------------------------
  
    function _getDisplayedFromSharedSides(sharedSides) {
   
      var displayedSides =  {
        px: !sharedSides.px, 
        nx: !sharedSides.nx, 

        py: !sharedSides.py, 
        ny: !sharedSides.ny, 

        pz: !sharedSides.nz, // z - is switched because grid count starts at 0 and increases for deeper layers while actual scene coordinates decrease
        nz: !sharedSides.pz
      };
    
      return displayedSides;
    
    };
  
    // ----------------------------------------------------------------
  
    function _createMaskTile(position) {
    
      // black tile
      var material = new THREE.MeshLambertMaterial( { color: 0xffffff, opacity: 1, shading: THREE.FlatShading } ); 
      var _maskPlane = new THREE.Mesh( new THREE.PlaneGeometry( _gridCellSize + 1, _gridCellSize + 1, 1, 1 ), material);
      _maskPlane.position.x = position.x;
      _maskPlane.position.y = position.y;
      _maskPlane.position.z = 0;
    
      _maskScene.addObject( _maskPlane );
    
    };
  
    // ----------------------------------------------------------------
  
    function _mineAtPosition( x, y ) {
      
     // get normalized device x,y coords
      _mouse2D.x = ( x / _w ) * 2 - 1;
      _mouse2D.y = -( y / _h ) * 2 + 1;
                
      // get the 3d mouse position and a create a ray based on _camera position to find intersections
      _mouse3D = _projector.unprojectVector( _mouse2D.clone(), _camera );
      _ray.direction = _mouse3D.subSelf( _camera.position ).normalize();
      
      var intersects = _ray.intersectScene( _scene );
      var l = intersects.length;
    
      if ( l > 0 ) {
      
        var destPosition3D = intersects[ 0 ].face.centroid.clone();
        var destGridPosition = _getGridPosition(destPosition3D);
        //debug.log("refPlane intersection: ");
        //debug.log("- destPosition3D: ("+destPosition3D.x+", "+destPosition3D.y+", "+destPosition3D.z+")" );
        //debug.log("- destGridPosition: ("+destGridPosition.x+", "+destGridPosition.y+", "+destGridPosition.z+")" );
      
        // check if there are more intersections and if grid has already position here
        if ( _voxelGrid.hasPos(destGridPosition) && (l > 1) ) {
                  
          var intersectedVoxel = intersects[ 1 ].object;
          if (typeof intersectedVoxel.name !== 'undefined') {
            var intersectedVoxelFacePos = intersects[ 1 ].face.centroid.clone();
            var intersectedGridPosArr = intersectedVoxel.name.split(":")[1].split(",");
            var intersectedGridPos = new THREE.Vector3(parseInt(intersectedGridPosArr[0], 10), parseInt(intersectedGridPosArr[1], 10), parseInt(intersectedGridPosArr[2], 10));
          } else {
            
            debug.log('Error: unable to resolve intersectedVoxel name');
            debug.log(intersectedVoxel);
            
            return;
          }
          
          destGridPosition.x = intersectedGridPos.x;
          destGridPosition.y = intersectedGridPos.y;
          destGridPosition.z = intersectedGridPos.z;
          
          // add offet to grid positioned based on which face was intersected
          var destOffsetX = (intersectedVoxelFacePos.x != 0) ? intersectedVoxelFacePos.x / Math.abs(intersectedVoxelFacePos.x) : 0;
          destGridPosition.x += destOffsetX;
          
          var destOffsetY = (intersectedVoxelFacePos.y != 0) ? intersectedVoxelFacePos.y / Math.abs(intersectedVoxelFacePos.y) : 0;
          destGridPosition.y += destOffsetY;
          
          var destOffsetZ = (intersectedVoxelFacePos.z != 0) ? -intersectedVoxelFacePos.z / Math.abs(intersectedVoxelFacePos.z) : 0;
          destGridPosition.z += destOffsetZ;
          
          //debug.log("destGridPosition: ("+destGridPosition.x+", "+destGridPosition.y+", "+destGridPosition.z+")" );
        }
        
        if (destGridPosition.z < _layers) {
          
          var material = undefined;
          
          try {
            
            material = _materialTypeLookup[destGridPosition.z][destGridPosition.y][destGridPosition.x];
            
          } catch(e) {
            //debug.log("trying to mine past edge of grid");
          }
                    
          if (material !== undefined ) {
            _createVoxelAtGridPos(destGridPosition);
          }
          
          return material;
        
        } else {
          
          //debug.log("you have reached the maximum layers at this grid position :: ");
          return "lava";
          
        }
              
      }
     
    };
    
    // ----------------------------------------------------------------
    
    function _generateCreeperDamage( pos ) {
    
     // get normalized device x,y coords
     var explosionCenter2D = new THREE.Vector3(0, 0, 0);
     
      explosionCenter2D.x = ( pos.x / _w ) * 2 - 1;
      explosionCenter2D.y = -( pos.y / _h ) * 2 + 1;
                
      // get the 3d mouse position and a create a ray based on _camera position to find intersections
       var explosionCenter3D = _projector.unprojectVector( explosionCenter2D.clone(), _camera );
      _ray.direction = explosionCenter3D.subSelf( _camera.position ).normalize();
      
      var intersects = _ray.intersectScene( _scene );
      var l = intersects.length;
    
      if ( l > 0 ) {
      
        var explosionPosition3D = intersects[ 0 ].face.centroid.clone(),
            explosionGridPosition = _getGridPosition(explosionPosition3D),
            explosionPositions = [],
            rowStartPosition,
            rowPosition,
            rowCols = 0,
            startXOffset = 0,
            i = 0;
      
        //row1
        rowCols = (Math.random() > 0.5 ) ? 3 : 2;
        startXOffset = (rowCols == 3) ? -1 : (Math.random() > 0.5 ) ? -1 : 0;
        rowStartPosition = explosionGridPosition.clone();
        rowStartPosition.y += 2;
        rowStartPosition.x += startXOffset;
        
        for (i=0; i < rowCols; i++) {
          rowPosition = rowStartPosition.clone();
          rowPosition.x += i;
          explosionPositions.push(rowPosition.clone());
        };
        
        //row2
        rowCols = MCBM.randomInRange(rowCols + 1, 5)|0;
        startXOffset = (rowCols == 5) ? -2 : (Math.random() > 0.5 ) ? -2 : -1;
        startXOffset = (rowCols == 3) ? -1 : startXOffset;
        rowStartPosition = explosionGridPosition.clone();
        rowStartPosition.y += 1;
        rowStartPosition.x += startXOffset;
        
        for (i=0; i < rowCols; i++) {
          rowPosition = rowStartPosition.clone();
          rowPosition.x += i;
          explosionPositions.push(rowPosition.clone());
        };
        
        //row3
        rowCols = 5;
        startXOffset = -2;
        rowStartPosition = explosionGridPosition.clone();
        rowStartPosition.x += startXOffset;
        
        for (i=0; i < rowCols; i++) {
          rowPosition = rowStartPosition.clone();
          rowPosition.x += i;
          explosionPositions.push(rowPosition.clone());
        };
        
        //row4
        rowCols = MCBM.randomInRange(3, 5)|0;
        startXOffset = (rowCols == 5) ? -2 : (Math.random() > 0.5 ) ? -2 : -1;
        startXOffset = (rowCols == 3) ? -1 : startXOffset;
        rowStartPosition = explosionGridPosition.clone();
        rowStartPosition.y -= 1;
        rowStartPosition.x += startXOffset;
        
        for (i=0; i < rowCols; i++) {
          rowPosition = rowStartPosition.clone();
          rowPosition.x += i;
          explosionPositions.push(rowPosition.clone());
        };
        
        //row5
        rowCols = (rowCols == 3) ? 2 : (Math.random() > 0.5 ) ? 3 : 2;
        startXOffset = (rowCols == 3) ? -1 : (Math.random() > 0.5 ) ? -1 : 0;
        rowStartPosition = explosionGridPosition.clone();
        rowStartPosition.y -= 2;
        rowStartPosition.x += startXOffset;
        
        for (i=0; i < rowCols; i++) {
          rowPosition = rowStartPosition.clone();
          rowPosition.x += i;
          explosionPositions.push(rowPosition.clone());
        };
        
        //row1Layer2
        rowCols = 3;
        rowStartPosition = explosionGridPosition.clone();
        rowStartPosition.y += 1;
        rowStartPosition.x -= 1;
        rowStartPosition.z += 1;
        
        for (i=0; i < rowCols; i++) {
          rowPosition = rowStartPosition.clone();
          rowPosition.x += i;
          explosionPositions.push(rowPosition.clone());
        };
        
        //row2Layer2
        rowCols = 3;
        rowStartPosition = explosionGridPosition.clone();
        rowStartPosition.x -= 1;
        rowStartPosition.z += 1;
        
        for (i=0; i < rowCols; i++) {
          rowPosition = rowStartPosition.clone();
          rowPosition.x += i;
          explosionPositions.push(rowPosition.clone());
        };
        
        //row3Layer2
        rowCols = 3;
        rowStartPosition = explosionGridPosition.clone();
        rowStartPosition.y -= 1;
        rowStartPosition.x -= 1;
        rowStartPosition.z += 1;
        
        for (i=0; i < rowCols; i++) {
          rowPosition = rowStartPosition.clone();
          rowPosition.x += i;
          explosionPositions.push(rowPosition.clone());
        };
                
        //row1Layer3
        rowCols = 1;
        rowStartPosition = explosionGridPosition.clone();
        rowStartPosition.y += 1;
        rowStartPosition.z += 2;
        
        for (i=0; i < rowCols; i++) {
          rowPosition = rowStartPosition.clone();
          rowPosition.x += i;
          explosionPositions.push(rowPosition.clone());
        };
        
        //row2Layer3
        rowCols = 3;
        rowStartPosition = explosionGridPosition.clone();
        rowStartPosition.x -= 1;
        rowStartPosition.z += 2;
        
        for (i=0; i < rowCols; i++) {
          rowPosition = rowStartPosition.clone();
          rowPosition.x += i;
          explosionPositions.push(rowPosition.clone());
        };
        
        //row3Layer3
        rowCols = 1;
        rowStartPosition = explosionGridPosition.clone();
        rowStartPosition.y -= 1;
        rowStartPosition.z += 2;
        
        for (i=0; i < rowCols; i++) {
          rowPosition = rowStartPosition.clone();
          rowPosition.x += i;
          explosionPositions.push(rowPosition.clone());
        };
        
        //row1Layer4
        rowStartPosition = explosionGridPosition.clone();
        rowStartPosition.z += 3;
        explosionPositions.push(rowStartPosition.clone());
        
        var len = explosionPositions.length;
        for (var i=0; i < len; i++) {
          _createVoxelAtGridPos(explosionPositions[i]);
        };
      }
     
    };
    
    // ----------------------------------------------------------------
    
    function _onMouseUp(event) {
      event.preventDefault();
      
      $body.trigger(MCBM.events.MINE_END);
    };
    
    // ----------------------------------------------------------------
  
    function _render() {

      // render 3D scenes
      _maskRenderer.render( _maskScene, _camera );
      _renderer.render( _scene, _camera );
        
      //*/
      // create a composite image on display canvas with the rendered scene and mask
      _displayCanvasCtx.clearRect(0, 0, _w, _h); 
      _displayCanvasCtx.save();

        // draw mask shapes
        _displayCanvasCtx.globalCompositeOperation = 'source-over';
        _displayCanvasCtx.drawImage(_maskCanvas, 0, 0);

        // composite rendered scene
        _displayCanvasCtx.globalCompositeOperation = 'source-in';
        _displayCanvasCtx.drawImage(_renderCanvas, 0, 0);
   
      _displayCanvasCtx.restore();
      //*/

      pScope.isDirty = false;
      //debug.log("playfieldGrid :: render :: pScope.isDirty: "+pScope.isDirty);
    };
  
    // ----------------------------------------------------------------
    
    function _debugRender() {
     
      // render 3D scenes
      _maskRenderer.render( _maskScene, _camera );
      _renderer.render( _scene, _camera );
        
      //*/
      // create a composite image on display canvas with the rendered scene and mask
      _displayCanvasCtx.clearRect(0, 0, _w, _h); 
      _displayCanvasCtx.save();

        // draw mask shapes
        //_displayCanvasCtx.globalCompositeOperation = 'source-over';
        //_displayCanvasCtx.drawImage(_maskCanvas, 0, 0);

        // composite rendered scene
        //_displayCanvasCtx.globalCompositeOperation = 'source-in';
        _displayCanvasCtx.drawImage(_renderCanvas, 0, 0);
   
      _displayCanvasCtx.restore();
      //*/

      pScope.isDirty = false;
      
    };
  
    _init();
  
    // ----------------------------------------------------------------
    // public methods
    // ----------------------------------------------------------------
    
    pScope.mineAtPosition = function(mouseX, mouseY) {
      return _mineAtPosition(mouseX, mouseY); // returns block type as string
    };
    
    pScope.render = function() {
      
      if (!DEBUG) {
        _render();
      } else {
        _debugRender();      
      }
      
    };
    
    pScope.resize = function(w) {
    
      _w = w;
      
      _updateMainDisplaySize();
      
    };
    
    pScope.reset = function() {
      _reset();
    };
    
    pScope.generateCreeperDamage = function(pos) {
      _generateCreeperDamage(pos);
    };
    
    return pScope;
    
  };
  
})(jQuery);
// Explosion Animation Object
// 
// author: Nate Horstmann nate@natehorstmann.com
// ====================================================================

// ====================================================================
// @explosion object
// ====================================================================

(function($) {

  MCBM.explosion = function(pos, targetCtx) {
  
    var $body = $('body'),
        _pos = pos,
        _targetCtx = targetCtx,
        _numImageLoads = 0,
        _imagesLoaded = 0,
        _explosionImages = [],
        _smokeImages = [],
        _numExplosionParticles = 10,
        _numSmokeParticles = 20,
        _spriteParticles = [],
        _numSpriteParticles = 0,
        _dampening = { explosion: 0.95, smoke: 0.97},
        _playQueued = false,
        _isPlaying = false,
        _isReady = false,
        _focalLength = 1000,
        _tStart;
  
    var pScope = {};
        pScope.isPlaying = _isPlaying;
      
    // ----------------------------------------------------------------
    // private functions
    // ----------------------------------------------------------------
  
    function _init() {
  
      // load images
      var explosionImageURIs = [
       MCBM.rootURI + '/img/sprites/explosion-light-gray.png',
       MCBM.rootURI + '/img/sprites/explosion-dark-gray.png'
      ];
    
      var smokeImageURIs = [
        MCBM.rootURI + '/img/sprites/smoke.png',
        MCBM.rootURI + '/img/sprites/smoke-dark-gray.png'
      ]
    
      _numImageLoads = explosionImageURIs.length + smokeImageURIs.length;
    
      var i;
      for (i = 0; i < explosionImageURIs.length; i++) {
        var explosionSpriteURI = explosionImageURIs[i];
        var explosionImg = document.createElement('img');
        explosionImg.crossOrigin = '';
        explosionImg.onload = _onImageLoaded;
        explosionImg.src = explosionSpriteURI;
        _explosionImages.push(explosionImg);
      };
    
      for (i = 0; i < smokeImageURIs.length; i++) {
        var smokeSpriteURI = smokeImageURIs[i];
        var smokeImg = document.createElement('img');
        smokeImg.crossOrigin = '';
        smokeImg.onload = _onImageLoaded;
        smokeImg.src = smokeSpriteURI;
        _smokeImages.push(smokeImg);
      };
    
    };
  
    // ----------------------------------------------------------------
  
    function _reset() {
      _spriteParticles = [];
      _createSpriteParticles();
    }
  
    // ----------------------------------------------------------------
  
    function _onImageLoaded() {
    
      _imagesLoaded++;
    
      if (_imagesLoaded == _numImageLoads) {
        // images loaded
        _createSpriteParticles();
      }
                
    };
  
    // ----------------------------------------------------------------
  
    function _createSpriteParticles() {
    
      // explosion particles ("shockwave" looking sprite)
      for (var i=0; i < _numExplosionParticles; i++) {
      
        var baseScale = MCBM.randomInRange(0.25,5);
        var sprite = MCBM.sprite(MCBM.randomFromArray(_explosionImages), 64, 64, baseScale);
        var pos = new THREE.Vector3(MCBM.randomInRange(-80, 80), MCBM.randomInRange(-80, 80), 0.5);
    
        //use pos relative to "origin" as the heading for velocity and set it's magnitude
        var vel = new THREE.Vector3(0, 0, 0);
        vel.copy(pos);
        vel.setLength(MCBM.randomInRange(3,15));
    
        var particle = MCBM.particle(pos, vel);
    
        var spriteParticle = {
          type:"explosion",
          sprite:sprite,
          particle:particle,
          delay:MCBM.randomInRange(0,150),
          duration:MCBM.randomInRange(300,450),
        }
      
        _spriteParticles.push(spriteParticle);
      }
    
      // smoke particles
      for (var i=0; i < _numSmokeParticles; i++) {
      
        var baseScale = MCBM.randomInRange(0.5,2);
        var sprite = MCBM.sprite(MCBM.randomFromArray(_smokeImages), 24, 24, baseScale);
        var pos = new THREE.Vector3(MCBM.randomInRange(-100, 100), MCBM.randomInRange(-100, 100), 0.5);
    
        //use pos relative to "origin" as the heading for velocity and set it's magnitude
        var vel = new THREE.Vector3(0, 0, 0);
        vel.copy(pos);
        vel.setLength(MCBM.randomInRange(3,10));
    
        var particle = MCBM.particle(pos, vel);
    
        var spriteParticle = {
          type:"smoke",
          sprite:sprite,
          particle:particle,
          delay:MCBM.randomInRange(25,170),
          duration:MCBM.randomInRange(1000,1600),
        }
      
        _spriteParticles.push(spriteParticle);
      }
        
      _numSpriteParticles = _spriteParticles.length;
    
      _isReady = true;
        
      if (_playQueued) {
        pScope.play();
      }
    
    };
  
    _init();
  
    // ----------------------------------------------------------------
    // public functions
    // ----------------------------------------------------------------
  
    pScope.update = function(tCur) {
      var elapsed = tCur - _tStart;
    
      if (!_isPlaying) {
        //debug.log("explosion :: update :: called when not playing - return ");
        return;
      }
    
      //debug.log("explosion :: update :: _numSpriteParticles: "+_numSpriteParticles);
    
      var i = _numSpriteParticles;
      while (i--) {
        var spriteParticle = _spriteParticles[i];
        var sprite = spriteParticle.sprite;
        var particle = spriteParticle.particle;
      
        // start sprites that have finished their delay
        if (!sprite.getHasPlayed()) {
          if (elapsed >= spriteParticle.delay) {
            sprite.play(spriteParticle.duration);
          }
        }
      
        var dampening = _dampening[spriteParticle.type];
        var pVel = particle.getVelocity();
        particle.setVelocity(pVel.multiplyScalar(dampening));
        particle.update(tCur);
      
        // update position & scale based on particle pos  
        var particlePos = particle.getPosition();
      
        // do a quick and dirty 3D projection with the particle position    
        if (0 < particlePos.z && particlePos.z < _focalLength) {
        
          var sz = _focalLength / (_focalLength - particlePos.z);
          var x = _pos.x + (particlePos.x * sz);
          var y = _pos.y + (particlePos.y * sz);
          var scale = sprite.getBaseScale() * sz;
                
          sprite.setScale(scale);
          sprite.setPosition(new THREE.Vector2(x, y));
          sprite.update(tCur);
        
        } else {
          // particle has moved beyond visible region - need to stop sprites play state
        }
      
      }
    
    };
  
    // ----------------------------------------------------------------
  
    pScope.setPosition = function(pos) {
      _pos.copy(pos);
    };
  
    // ----------------------------------------------------------------
  
    pScope.render = function() {
    
      if (!_isPlaying) {
        return;
      }
    
      //debug.log("Explosion :: render");
      _isPlaying = false; // assume play is finished unless a sprite needs drawing
    
      var i = _numSpriteParticles;
      while (i--) {
        var sprite = _spriteParticles[i].sprite;
      
        if (sprite.getIsPlaying()) {
          sprite.draw(_targetCtx);
          _isPlaying = true; // continue playing explosion as long as a sprite needs drawing
         } else if ( !sprite.getHasPlayed() ) {
          _isPlaying = true; // continue playing as long as a sprite hasnt played yet
        }
      }
    
    
      if (_isPlaying == false) {
        $body.trigger(MCBM.events.EXPLOSION_COMPLETE);
      };
    
      pScope.isPlaying = _isPlaying;
    
    };
  
    // ----------------------------------------------------------------
  
    pScope.play = function() {
    
      if (!_isReady) {
        _playQueued = true;
        return;
      }
    
      if (_isPlaying) {
        return;
      }
    
      _playQueued = false;
      pScope.isPlaying = _isPlaying = true;
    
      _tStart = new Date().getTime();
      pScope.update(_tStart);
    
    };
  
    pScope.stop = function() {
      pScope.isPlaying = _isPlaying = false;
    };
  
    pScope.reset = function() {
      _reset();
    }
  
    // ----------------------------------------------------------------
  
    return pScope;
  
  };

})(jQuery);
(function($){

  MCBM.creeper = function(targetCtx) {
    
    var $win = $(window),
        $body = $('body'),
        _targetCtx = targetCtx,
        _pos = null,
        _registration = new THREE.Vector2(55, 140),
        _vel = new THREE.Vector2(0, 0),
        _speed = 0,
        _dir,
        _duration = 0,
        _mousePos,
        _activateDist = 500,  // <------  !! IMPORTANT; remeber that for optimization these should get pre-squared for distance checking in init()
        _contactRadius = 20,  // <------
        _isChasing = false,
        _dirChangeReady = false,
        _dirChangeTimeout = null,
        _explodeTimeout = null,
        _explodeDelay = 2500,
        _boundsMargin = 50,
        _bounds = { // will need to make this resizeable
          min: new THREE.Vector2(_boundsMargin, _boundsMargin),
          max: new THREE.Vector2( MCBM.$container.outerWidth() - _boundsMargin,  MCBM.$container.outerHeight() - _boundsMargin)
        };
        
    
    // audio vars
    var fuseAudio,
        explodeAudio,
        _audioElementsLoaded = 0,
        _numAudioElements = 0,
        _audioAvailable = $('html').hasClass('audio');
        
    
    // sprite vars
    var _creeperSpriteURI = MCBM.rootURI + '/img/sprites/creeper.png',
        _creeperSpriteImg,
        _spriteDuration = 0,
        _sprite;
      
    var _spriteSequenceData = {
      up: { frameBounds:[1, 12] },
      upRight: { frameBounds:[13, 24] },
      right: { frameBounds:[25, 36] },
      downRight: { frameBounds:[37, 48] },
      down: { frameBounds:[49, 60] },
      upLeft: { frameBounds:[85, 96  ] },
      left: { frameBounds:[73, 84] },
      downLeft: { frameBounds:[61, 72] }  
    };
    
    var _movementTypes = {
      walk: {
              duration: 750,
              speed: 0.6
            },
          
      run: {
              duration: 470,
              speed: 3
            }
    };
  
    var unit45 = 0.707106781186548; // precomputed x,y component of unit vector at 45 degrees
    var _directions = {
      up: new THREE.Vector2(0, -1),
      upLeft: new THREE.Vector2(-unit45, -unit45),
      upRight: new THREE.Vector2(unit45, -unit45),
      left: new THREE.Vector2(-1, 0),
      right: new THREE.Vector2(1, 0),
      downLeft: new THREE.Vector2(-unit45, unit45),
      downRight: new THREE.Vector2(unit45, unit45),
      down: new THREE.Vector2(0, 1)
    };
    var _directionsArray = [
    "up",
    "upLeft",
    "upRight",
    "left",
    "right",
    "downLeft",
    "downRight",
    "down"
    ];
        
    var pScope = {};
  
    pScope.isAlive = false;
    
    // ----------------------------------------------------------------
    // ----------------------------------------------------------------
  
    function _init() {
      _activateDist = _activateDist*_activateDist; // square the activate distance so we can check against dist squared and avoid taking square root for speed
      _contactRadius = _contactRadius*_contactRadius;
      
      _mousePos = new THREE.Vector2(0, 0);
      
      $body.bind(MCBM.events.CREEPER_AUDIO_LOAD_COMPLETE, _initImages);
      $body.bind(MCBM.events.CREEPER_AUDIO_LOAD_ERROR, _initImages);
      
      if (_audioAvailable) {
        _initAudio();
      } else {
        _onAudioLoadError();
      }
    };
    
    // ----------------------------------------------------------------
    
    function _reset() {
      _pos = new THREE.Vector2( 
                                MCBM.randomInRange(_boundsMargin*2,  MCBM.$container.outerWidth() - _boundsMargin*2), 
                                MCBM.randomInRange(_boundsMargin*2,  $win.height() - _boundsMargin*2)
                              );
                                    
      _dir = MCBM.randomFromArray(_directionsArray);
      _speed = _movementTypes["walk"].speed;
      _duration = _movementTypes["walk"].duration;
      
      _vel.copy(_directions[_dir]);
      _vel.multiplyScalar(_speed);
      
      _sprite.setPosition(_pos);
      _sprite.setSequence(_dir);
      
      _isChasing = false;
      
      // reset explosion
    };
        
    // ----------------------------------------------------------------
      
    function _initAudio() {
    
      fuseAudio = document.createElement('audio');
      explodeAudio = document.createElement('audio');
        
      var audioElements = [
        {
          filename:"fuse",
          element:fuseAudio
        },
        {
          filename:"explode",
          element:explodeAudio
        }
      ];
    
      _numAudioElements = audioElements.length;
    
      for (var i=0; i < _numAudioElements; i++) {
        var audioElement = audioElements[i].element;
        var filename = audioElements[i].filename;
      
        audioElement.addEventListener("loadeddata", _onAudioLoaded, false);
        audioElement.addEventListener("error", _onAudioLoadError, false);
            
        if (audioElement.canPlayType) {
     
          var filetype = "";
          if (audioElement.canPlayType('audio/ogg; codecs="vorbis"') != "") {
            filetype = ".ogg";
          } else if (audioElement.canPlayType('audio/mpeg') != "") {
            filetype = ".mp3";
          } else {
            // audio filetype not supported
            _onAudioLoadError();
          }
        
        }
    
        audioElement.src = MCBM.rootURI + "/audio/"+filename+filetype;;
        audioElement.load();
      }
  
    };
    
    // ----------------------------------------------------------------
    
    function _onAudioLoaded(e) {
      _audioElementsLoaded++;
    
      if (_audioElementsLoaded == _numAudioElements) {
        // audio load complete
        $body.trigger(MCBM.events.CREEPER_AUDIO_LOAD_COMPLETE);
      }
    };
    
    function _onAudioLoadError(e) {
      // handle error
      //debug.log('Unable to load Creeper Audio');
      
      $body.trigger(MCBM.events.LOAD_ERROR); 
      
      // if we wanted to get more granular, we could still play without audio
      //_audioAvailable = false;
      //$body.trigger(MCBM.events.CREEPER_AUDIO_LOAD_ERROR);
      //$body.trigger(MCBM.events.CREEPER_AUDIO_LOAD_COMPLETE);
    };
    
    
    // ----------------------------------------------------------------
    
    function _checkFuseEnded() {
      // for some reason checking the "ended" attribute on the audio element
      // fixes a bug where the audio was getting cut-off prematurely
    
      var ended = fuseAudio.ended;
      if (!ended) {
        setTimeout(_checkFuseEnded, 500);
      }
    };
    
    // ----------------------------------------------------------------
  
    function _onFuseAudioEnded(e) {
      fuseAudio.removeEventListener("ended", _onFuseAudioEnded, false);
      _explode();
    };
    
    // ----------------------------------------------------------------
    
    function _initImages() {
      // load image
      _creeperSpriteImg = document.createElement('img');
      _creeperSpriteImg.crossOrigin = '';
    
      _creeperSpriteImg.onload = _onImageLoaded;
      _creeperSpriteImg.src = _creeperSpriteURI;
    };
  
    function _onImageLoaded(e) {
      // setup sprite
        
      _sprite = MCBM.sprite(_creeperSpriteImg, 225, 200, 1, _spriteSequenceData, _registration);
      _sprite.setLooping(true);
      _reset();
      
      $body.trigger(MCBM.events.CREEPER_LOADED);
    };
  
    function _onMouseMove(e) {
      if (!pScope.isAlive) {
        return;
      }
      
      _mousePos.x = e.pageX - MCBM.$container.offset().left;
      _mousePos.y = e.pageY;
      
      var d = _pos.distanceToSquared(_mousePos);
      
      // check distance to mouse
      if (!_isChasing) {
        
        if (d < _activateDist) {
          
          if (_dirChangeTimeout !== null) {
            clearTimeout(_dirChangeTimeout);
            _dirChangeTimeout = null;
          }
          
          _isChasing = true;
          _dirChangeReady = true;
          _speed = _movementTypes.run.speed;
          _duration = _movementTypes.run.duration;
          _sprite.setDuration(_duration);
          _setDirection(_dir);
        
          // explode timer
          if (_audioAvailable) {
            _checkFuseEnded();
            fuseAudio.addEventListener("ended", _onFuseAudioEnded, false);
            fuseAudio.play();
          } else {
            _explodeTimeout = setTimeout(_explode, _explodeDelay);
          }
        }
        
      } else if (d > _activateDist) {
        _stopChasing();
      }
    
    };
    
    function _onMouseLeave() {
      if (!pScope.isAlive) {
        return;
      }
      
      if (_isChasing) {
        _stopChasing();
      }
    };
        
    function _stopChasing() {
      
      _clearChaseTimeouts()
      
      _dirChangeReady = false;
      _dirChangeTimeout = setTimeout(  _onDirectionChangeTimeout, MCBM.randomInRange(1000, 3000)  );
      
      _speed = _movementTypes.walk.speed;
      _duration = _movementTypes.walk.duration;
      _sprite.setDuration(_duration);
      _setDirection(_dir);
    };
    
    function _clearChaseTimeouts() {
      if (_explodeTimeout !== null) {
        clearTimeout(_explodeTimeout);
        _explodeTimeout = null;
      }
      
      _isChasing = false;
      
      if (_audioAvailable) {
        fuseAudio.currentTime = 0;
        fuseAudio.pause();
      }
     
      if (_dirChangeTimeout !== null) {
        clearTimeout(_dirChangeTimeout);
        _dirChangeTimeout = null;
      }
    };
  
    function _getDirection(fromVec2, toVec2) {
      // use precomputed values for tan to speed things up
      //   62.5 deg = 2.4142
      //   22.5 deg = 0.4142

      var dirVec2 = new THREE.Vector2(0, 0);
      dirVec2.sub(toVec2, fromVec2);

      var dir;

      if (dirVec2.x == 0) {
        dir = (dirVec2.y < 0) ? "up" : "down"; // y flipped in browser coordinate space where y increases moving down the page
      } else {
        var t = Math.abs(dirVec2.y / dirVec2.x);

        if (t > 2.4142) { // vertical

          dir = (dirVec2.y < 0) ? "up" : "down";

        } else if (t <= 0.4142) { // horizontal

          dir = (dirVec2.x > 0) ? "right" : "left";

        } else if (0.4142 < t && t <= 2.4142) { // angular

          dir = (dirVec2.y < 0) ? "up" : "down";
          dir = (dirVec2.x > 0) ? dir+"Right" : dir+"Left";

        }
      }

      //debug.log("direction: "+dir);
      return dir; //directions[dir];
    };
    
    function _setDirection(newDir) {
      // change velocity vector
      _vel.copy(_directions[newDir]);
      _vel.multiplyScalar(_speed);

      // set sprite sequence based on direction
      _sprite.setSequence(newDir);
      _dir = newDir;
    };
    
    function _onDirectionChangeTimeout() {
      _dirChangeTimeout = null;
      _dirChangeReady = true;
    };
  
    function _explode() {
      
      if (_audioAvailable) {
        explodeAudio.play();
      }
      
      pScope.isAlive = false;
      _sprite.stop();
      
      _clearChaseTimeouts();
      
      $body.trigger(MCBM.events.CREEPER_EXPLODED);
      
    };
    
    function _checkOutOfBounds() {
      return (_pos.x < _bounds.min.x ||
              _pos.x > _bounds.max.x ||
              _pos.y < _bounds.min.y ||
              _pos.y > _bounds.max.y);
    };
  
    _init();
  
    // ----------------------------------------------------------------
    // ----------------------------------------------------------------
  
    pScope.getPosition = function() {
      return _pos.clone();
    };
  
    // ----------------------------------------------------------------
  
    pScope.update = function(tCur) {
      
      // update sprite frame
      if (!_sprite.getIsPlaying()) {
        return;
      }
      
      if (_isChasing) {
        var d = _pos.distanceToSquared(_mousePos);

        if (d < _contactRadius) {
          _explode();
        }
      }
        
      if (_checkOutOfBounds()) {
        
        //debug.log("out of bounds");
        if (_dirChangeTimeout !== null) {
          clearTimeout(_dirChangeTimeout);
          _dirChangeTimeout = null;
        }
        
        // get direction based on center of window
        var newDir = _getDirection(_pos, new THREE.Vector2( $win.width() * 0.5, $win.height() * 0.5 ) );
        _setDirection(newDir);
        
        _dirChangeReady = false;
        _dirChangeTimeout = setTimeout(  _onDirectionChangeTimeout, 5000  );
        
      } else if (_isChasing && _dirChangeReady) {
        
        // get direction based on mouse position
        var newDir = _getDirection(_pos, _mousePos);
    
        // check if direction has changed
        if (_dir != newDir) {
          
          _setDirection(newDir);
          
          _dirChangeReady = false;
          _dirChangeTimeout = setTimeout(  _onDirectionChangeTimeout, 500);
        }
        
      } else if (_dirChangeReady) {
        
        // get direction from wandering
        var newDir = MCBM.randomFromArray(_directionsArray);

        if (_dir != newDir) {
          
          _setDirection(newDir);
          
           _dirChangeReady = false;
           _dirChangeTimeout = setTimeout(  _onDirectionChangeTimeout, MCBM.randomInRange(2000, 5000)  );
        }
      }
          
      // update position
      _pos.addSelf(_vel);
      _sprite.setPosition(_pos);
      _sprite.update(tCur);
    
    };
  
    // ----------------------------------------------------------------
  
    pScope.render = function() {
    
      if (_sprite.getIsPlaying()) {
        _sprite.draw(_targetCtx);
      }
      
    };
    
    pScope.play = function() {
      _sprite.play(_duration);
      
      _dirChangeReady = true;
      pScope.isAlive = true;
      
      // setup mousemove handler to check mouse proximity to see if chasing
      $body.bind("mousemove.creeper", _onMouseMove);
      $body.bind("mouseleave.creeper", _onMouseLeave);
    }
    
    pScope.stop = function() {

      if (_isChasing) {
        _stopChasing();
      }
      
      _sprite.stop();
      
      pScope.isAlive = false;
      
      $body.unbind("mousemove.creeper", _onMouseMove);
      $body.unbind("mouseleave.creeper", _onMouseLeave);
    };
    
    pScope.reset = function() {
      _reset();
    };
    
    pScope.resizeBounds = function(w) {
      _bounds.max = new THREE.Vector2(w - _boundsMargin,  $win.height() - _boundsMargin)
    }
  
    return pScope;
  
  };

})(jQuery);(function($){
  
  MCBM.gameCreeper = function(display) {
    
    var $win = $(window),
        $body = $('body'),
        _w,
        _display = display,
        _displayCtx = _display.getContext(),
        _creeperDisplay = null,
        _creeperDisplayCtx = null
        _creeper = null,
        _explosion = null,
        _playfieldGrid = null,
        _gridCellSize = 80,
        _isGameRunning = false,
        _queuedResize = false,
        _isExplosionComplete = false;
        
    var pScope = {};
        pScope.id = "gameCreeper";
    
    // ----------------------------------------------------------------
    // private functions
    // ----------------------------------------------------------------
    
    function _init() {
        
      $body.bind(MCBM.events.CREEPER_EXPLODED, _onCreeperExplode);
      
      _creeperDisplay = MCBM.display();
      _creeperDisplayCtx = _creeperDisplay.getContext();
      
      _playfieldGrid = MCBM.playfieldGrid(_display.getCanvas(), _gridCellSize);
      
      $body.bind(MCBM.events.CREEPER_LOADED, _onCreeperLoaded);
      _creeper = MCBM.creeper( _creeperDisplayCtx );
      _explosion = MCBM.explosion(new THREE.Vector2(0, 0), _creeperDisplayCtx);
              
    };
    
    function _onCreeperLoaded() {
      //debug.log("gameCreeper loaded");
      $body.trigger(MCBM.events.ITEM_LOADED);
    }
    
    // ----------------------------------------------------------------
        
    function _onCreeperExplode() {
        var creeperPos = _creeper.getPosition();

        _playfieldGrid.generateCreeperDamage(creeperPos.clone());
        
        _explosion.setPosition(creeperPos.clone());
        _explosion.play();
    };
    
    function _onCreeperExplodeComplete() {
      
      _isExplosionComplete = true;
      $body.trigger(MCBM.events.OPEN_UI);
      
    };
    
    function _startGame() {
      //debug.log("gameCreeper :: _startGame");
      
      $body.bind(MCBM.events.EXPLOSION_COMPLETE, _onCreeperExplodeComplete);
      
      _isExplosionComplete = false;
      _isGameRunning = true;
      
      if (_queuedResize) {
        _resize();
        _queuedResize = false;
      }
      
      _creeper.reset();
      _creeper.play();
          
      _animate();
      
    };
    
    function _endGame() {
      
      _creeper.stop();
      
      _explosion.stop();
      _explosion.reset(); 
      
      _playfieldGrid.reset();     
      
      _isGameRunning = false;
      _display.clear();
      _creeperDisplay.clear();
    };
    
    function _animate() {
      
      if (!_isExplosionComplete) {
        requestAnimationFrame( _animate );
      };
      
      _render();
      
      if (typeof _display.stats != "undefined") {
        _display.stats.update();
      }
      
      var tCur = new Date().getTime();
      
      if (_creeper.isAlive) {
        _creeper.update(tCur);
      }
      
      if (_explosion.isPlaying) {
        _explosion.update(tCur);
      }
    };
    
    function _render() {
        
      if (_playfieldGrid.isDirty) {
        _playfieldGrid.render();
      }
      
      if (_creeperDisplay.dirty) {
        _creeperDisplay.clear();
      }
      
      if (_creeper.isAlive) {
        _creeper.render();
        _creeperDisplay.dirty = true;
      }
      
      if (_explosion.isPlaying) {
        _explosion.render();
        _creeperDisplay.dirty = true;
      }
                  
    };
    
    function _resize() {
      if (_isGameRunning) {
        
        _creeper.resizeBounds(_w);
        _creeperDisplay.resize(_w);
        _playfieldGrid.resize(_w);
        _queuedResize = false;
        
      } else {
        _queuedResize = true;
      }
    }
    
    _init();
    
    // ----------------------------------------------------------------
    // public methods
    // ----------------------------------------------------------------
    
    pScope.newGame = function() {
     
      if (_isGameRunning) {
        
        _endGame();
        $.doTimeout( 'newGame.creeper', 250, _startGame);
        
      } else {
        
        _startGame();
        
      }
           
    };
    
    pScope.endGame = function() {
      
      _endGame();
            
    };
    
    pScope.destroy = function() {
            
    };
    
    pScope.getIsRunning = function() {
      return !_isExplosionComplete;
    };
    
    pScope.resize = function(w) {
      
      _w = w;
      
      _resize();
      
    };
    
    return pScope;
    
  };
  
})(jQuery);(function($){

  MCBM.pickaxe = function() {
    
    var $pickaxeCursorDiv,
        _swingInterval = null,
        _swingDuration = 125,
        _isDown = false,
        _isPaused = true,
        _tStart = 0;
    
    var pScope = {};
    
    function _init() {
    
      $pickaxeCursorDiv = $('<div id="pickaxe"></div>');
      $pickaxeCursorDiv.css({
        'position':'absolute',
        top:0,
        left:0,
        width:315,
        height:340,
        'cursor': 'crosshair',
        'background':'url('+MCBM.rootURI+'/img/sprites/pickaxe.png)'
      });
      MCBM.$container.append($pickaxeCursorDiv);
    
      $pickaxeCursorDiv.css('display', 'none');
    };
    
    function _swingCycle() {
      
      if (_isDown) {
        _swingUp();
      } else {
        _swingDown();
      }
      
      _tStart = new Date().getTime();
      
    }
    
    function _swingDown() {
      _isDown = true;
      $pickaxeCursorDiv.css('background-position','0 -340px');
    };
    
    function _swingUp() {
      _isDown = false;
      $pickaxeCursorDiv.css('background-position','0 0');
    };
    
    _init();
    
    pScope.start = function() {
      if (_isPaused) {
        _isPaused = false;
        _tStart = new Date().getTime();
      
        _swingDown();
      } else {
        return;
      }
    };
    
    pScope.stop = function() {
      
      if (_isPaused) {
        return;
      }
      
      _isPaused = true;
      
      _swingUp();
    };
    
    pScope.setPosition = function(x, y) {
      $pickaxeCursorDiv.css({
        left:x-5,
        top:y-253
      });
      
      $pickaxeCursorDiv.css('display', 'block');
    };
    
    pScope.update = function(tCur) {
      if (_isPaused) {
        return;
      }
      
      if (tCur - _tStart > _swingDuration) {
        _swingCycle();
      }
    };
    
    pScope.hide = function() {
      $pickaxeCursorDiv.css('display', 'none');
    };
    
    return pScope;
  }

})(jQuery);// Explosion Animation Object
// 
// author: Nate Horstmann nate@natehorstmann.com
// ====================================================================

// ====================================================================
// @explosion object
// ====================================================================

(function($) {
  
  MCBM.blockBreak = function(type, pos) {
    
    var _type = type,
        _pos = pos,
        _tStart = 0,
        _dampening = 0.97,
        _grav = 0.71,
        _numParticles = MCBM.randomInRange(10, 20)|0,
        _particleArray = [];
    
    var pScope = {};
        pScope.running = true;
    
    function _init() {
     
      var i=0;
      for (i; i < _numParticles; i++) {
      
        var startPos = new THREE.Vector3(MCBM.randomInRange(-25, 25), MCBM.randomInRange(-55, 10), 0.5);
    
        //use pos relative to "origin" as the heading for velocity and set it's magnitude
        var vel = new THREE.Vector3(0, 0, 0);
        vel.copy(startPos);
        vel.setLength(MCBM.randomInRange(3,10));
    
        var particle = MCBM.particle(startPos, vel);
        var $div = $('<div></div>');
        
        var size = MCBM.randomInRange(5, 15)|0;
        var imageOffsetX = MCBM.randomInRange(0, 64 - size)|0;
        var imageOffsetY = MCBM.randomInRange(0, 64 - size)|0;
        
        var x = _pos.x+startPos.x;
        var y = _pos.y+startPos.y;
        
        $div.css({
          'position':'absolute',
          'left':x+'px',
          'top':y+'px',
          'width':size+'px',
          'height':size+'px',
          'background':'url('+MCBM.rootURI+'/img/textures/minecraft/'+_type+'.png) no-repeat -'+imageOffsetX+'px -'+imageOffsetY+'px',
          'display':'none'
        });
        
        MCBM.$container.append($div);
      
        var delay = MCBM.randomInRange(0,100)|0;
        var end = delay + MCBM.randomInRange(500,750)|0;
        
        var divParticle = {
          $div:$div,
          particle:particle,
          delay:delay,
          end:end
        };
      
        _particleArray.push(divParticle);
      }
      
      _tStart = new Date().getTime();
      
    }
    
    _init();
    
    // ----------------------------------------------------------------
    // public functions
    // ----------------------------------------------------------------
    
    pScope.update = function(tCur) {
      var elapsed = tCur - _tStart,
          particlesEnded = 0,
          i=0;
      
      for (i; i < _numParticles; i++) {
        var divParticle = _particleArray[i];
        var $div = divParticle.$div;
        
        if (divParticle.delay < elapsed && elapsed < divParticle.end) {
        
          var particle = divParticle.particle;
        
          if ($div.css('display') == 'none') {
            $div.css('display', 'block');
          }
        
          var pVel = particle.getVelocity();
          pVel.x *= _dampening;
          pVel.y += _grav;
          particle.setVelocity(pVel);
          particle.update(tCur);

          // update position & scale based on particle pos  
          var particlePos = particle.getPosition();
        
          var x = _pos.x + particlePos.x;
          var y = _pos.y + particlePos.y;
          $div.css({
            'left':x+'px',
            'top':y+'px',
          });
          
        } else if (elapsed > divParticle.end) {
          particlesEnded++;
          $div.css('display', 'none');
        }
        
        if (particlesEnded == _numParticles) {
          pScope.running = false; 
        }
        
      }
      
    };
    
    pScope.destroy = function() {
      //debug.log("blockBreak :: destroy()"); 
      var i=0;
      
      for (i; i < _numParticles; i++) {
        var divParticle = _particleArray[i];
        
        divParticle.$div.remove();
        divParticle.$div = null;
        divParticle.particle.destroy();
        divParticle.particle = null;
      }
      
      _particleArray = null;
      _pos = null;
    };
    
    return pScope;
    
  };
  
})(jQuery);(function($){

  MCBM.gamePickaxe = function(display) {
    
    var $win = $(window),
        $body = $('body'),
        _display = display,
        $displayCanvas = $(_display.getCanvas()),
        _playfieldGrid = null,
        _pickaxe = null,
        _mouseX,
        _mouseY,
        _w,
        _queuedResize = false,
        _blockBreaks = [],
        _stoneBreakAudio = null,
        _dirtBreakAudio = null,
        _audioElementsLoaded = 0,
        _numAudioElements = 0,
        _audioAvailable = $('html').hasClass('audio'),
        _audioLoaded = false,
        _audioLookup = {},
        _continueBreaking = false,
        _isGameRunning = false,
        _isMouseDownReady = true;
        
    var pScope = {};
        pScope.id = "gamePickaxe";
    
    // ----------------------------------------------------------------
    // private functions
    // ----------------------------------------------------------------
    
    function _init() {
      
      $body.bind(MCBM.events.PICKAXE_AUDIO_LOAD_COMPLETE, _onAudioLoadComplete);
      
      // create playfieldGrid instance
      _playfieldGrid = MCBM.playfieldGrid(_display.getCanvas(), 80);
      
      _pickaxe = MCBM.pickaxe();
      
      if (_audioAvailable) {
        _initAudio();
      } else {
        _onAudioLoadError();
      }
    };
    
    function _initAudio() {
          
      _stoneBreakAudio = document.createElement('audio');
      _dirtBreakAudio = document.createElement('audio');
    
      var audioElements = [
        {
          filename:"stone2",
          element:_stoneBreakAudio
        },
        {
          filename:"grass2",
          element:_dirtBreakAudio
        }
      ];
      
      _audioLookup.stone = _stoneBreakAudio;
      _audioLookup.dirt = _dirtBreakAudio;
    
      _numAudioElements = audioElements.length;
    
      for (var i=0; i < _numAudioElements; i++) {
        var audioElement = audioElements[i].element;
        var filename = audioElements[i].filename;
      
        audioElement.addEventListener("loadeddata", _onAudioElementLoaded, false);
        audioElement.addEventListener("error", _onAudioLoadError, false);
                  
        if (audioElement.canPlayType) {
     
          var filetype = "";
          if (audioElement.canPlayType('audio/ogg; codecs="vorbis"') != "") {
            filetype = ".ogg";
          } else if (audioElement.canPlayType('audio/mpeg') != "") {
            filetype = ".mp3";
          } else {
            // audio filetype not supported
            _onAudioLoadError() 
          }
        
        }
    
        audioElement.src = MCBM.rootURI + "/audio/"+filename+filetype;
        audioElement.load();
      }
  
    };
    
    // ----------------------------------------------------------------
    
    function _onAudioElementLoaded(e) {
      _audioElementsLoaded++;
      
      if (_audioElementsLoaded == _numAudioElements) {
        // audio load complete
        $body.trigger(MCBM.events.PICKAXE_AUDIO_LOAD_COMPLETE);
        _audioLoaded = true;
        _audioAvailable = true;
      }
    };
    
    function _onAudioLoadError(e) {
      // handle error
      //debug.log('Unable to load Pickaxe Audio');
            
      $body.trigger(MCBM.events.LOAD_ERROR); 
      
      // if we wanted to get more granular, we could still play without audio
      // _audioAvailable = false;
      //$body.trigger(MCBM.events.PICKAXE_AUDIO_LOAD_ERROR); 
      //_onAudioLoadComplete();
    };
    
    function _onAudioLoadComplete() {
      //debug.log("gamePickaxe loaded");
      $body.trigger(MCBM.events.ITEM_LOADED);
    }
    
    function _startGame() {
      //debug.log("pickaxeGame :: _startGame");
      
      $displayCanvas.css('display', 'none');
      
      // bind events 
      $body.bind('mousemove.gamePickaxe', _onMouseMove);
      //$body.bind( 'mousedown.gamePickaxe', _onMouseDown );
      //$body.bind( 'mouseup.gamePickaxe', _onMouseUp );
      
      $body.bind( 'mousedown', _onMouseDown );
      $body.bind( 'mouseup', _onMouseUp );
      $body.bind( 'mouseleave', _onMouseUp );
      
      // setup resize handler
      $win.bind('resize.gamePickaxe', _onResize);
      
      _isGameRunning = true;
      if (_queuedResize) {
        _resize();
        _queuedResize = false;
      }
      
      _animate();
      
    };
    
    function _endGame() {
      //debug.log("pickaxeGame :: _endGame");
      
      // unbind events 
      $body.unbind('mousemove.gamePickaxe', _onMouseMove);
      //$body.unbind( 'mousedown.gamePickaxe', _onMouseDown );
      //$body.unbind( 'mouseup.gamePickaxe', _onMouseUp );
      
      $body.unbind( 'mousedown', _onMouseDown );
      $body.unbind( 'mouseup', _onMouseUp );
      $body.unbind( 'mouseleave', _onMouseUp );
      
      // setup resize handler
      $win.unbind('resize.gamePickaxe', _onResize);
      
      _pickaxe.stop();
      _pickaxe.hide();
      
      _isGameRunning = false;
      _playfieldGrid.reset();
      _display.clear();
    };
    
    function _onMouseMove(e) {
      $displayCanvas.css({
       'display': 'block',
       'cursor': 'crosshair'
      });
            
      _mouseX = e.pageX - MCBM.$container.offset().left;
      _mouseY = e.pageY;
      _pickaxe.setPosition(_mouseX, _mouseY);
    };
    
    function _onMouseDown(e) {
      e.preventDefault();
      
      _mouseX = e.pageX - MCBM.$container.offset().left; //clientX + scrollLeft;
      _mouseY = e.pageY; //clientY + scrollTop;
      
      // rate limit mouse input
      if (_isMouseDownReady) {
        _isMouseDownReady = false;
        _doMouseDown();
        $.doTimeout(300, function () { _isMouseDownReady = true; });
      }
      
    };
        
    function _doMouseDown() {
      var scrollTop = $win.scrollTop();
      var scrollLeft = $win.scrollLeft();
     
      _continueBreaking = true;
      _doBlockBreak();
      
      $.doTimeout("breakInterval", 500, _doBlockBreak);
      _pickaxe.start();
    }
    
    function _doBlockBreak() {
      
      var type = _playfieldGrid.mineAtPosition(_mouseX, _mouseY);  
      if (type != "lava" && type !== undefined) {
        
        if (type == "grassDirt" || typeof type == "undefined") {
          type = "dirt";
        }
        
        if (_audioLoaded) {
          var audioType = (type == "dirt") ? type : "stone",
              audioElement = _audioLookup[audioType];
          audioElement.pause();
          audioElement.currentTime = 0;
          audioElement.play();
        }
                 
        var blockbreak = MCBM.blockBreak(type, new THREE.Vector3(_mouseX, _mouseY, 0.5));
        _blockBreaks.push(blockbreak);
      }
      
      if (_continueBreaking) {
        return true;
      } else {
        return false;
      }
    };
    
    function _onMouseUp(e) {
      e.preventDefault();
      
      _continueBreaking = false;
      $.doTimeout("breakInterval");
      
      _pickaxe.stop();
    };
    
    function _onResize() {
            
    };
    
    function _animate() {
      
      if (_isGameRunning) {
        requestAnimationFrame( _animate );
      };
      
      _render();
      
      if (typeof _display.stats != "undefined") {
        _display.stats.update();
      }
            
      var tCur = new Date().getTime();
      
      _pickaxe.update(tCur);
      
      /*
      if (_playfieldGrid.isDirty) {
        _playfieldGrid.update(tCur);
      }
      */
      
      var i = _blockBreaks.length;
      while (i--) {
      
        var blockbreak = _blockBreaks[i];
        if (blockbreak.running) {
          blockbreak.update(tCur);
        } else {
          blockbreak.destroy();
          _blockBreaks.splice(i, 1);
        }        

      };
      
            
    };
    
    function _render() {
      
      if (_playfieldGrid.isDirty) {
        _playfieldGrid.render();
      }
      
    };
    
    function _resize() {
      if (_isGameRunning) {
        _playfieldGrid.resize(_w); 
      } else {
        _queuedResize = true;
      }
    }
    
    
    _init();
    
    // ----------------------------------------------------------------
    // public methods
    // ----------------------------------------------------------------
    
    pScope.newGame = function() {
      
      if (_isGameRunning) {
        //debug.log("game running: delay new game");
        _endGame();
        
        $.doTimeout( 'newGame.pickaxe', 250, _startGame);
      } else {
        //debug.log("pickaxe :: newGame");
        _startGame();
        
      }
                  
    };
    
    pScope.endGame = function() {
      
      _endGame();
            
    };
    
    pScope.destroy = function() {
            
    };
    
    pScope.getIsRunning = function() {
      return _isGameRunning;
    };
    
    pScope.resize = function(w) {
      
      _w = w;
      
      _resize();
    };
    
    return pScope;
    
  };
  
})(jQuery);
(function($){

  MCBM.phoneDisplay = function() {
    
    var _styles = ''+
      '#mcbm-phone-container {'+
        'position: fixed;'+
        'top: 0px;'+
        'left: 15px;'+
        'width: 100%;'+
        'height: 350px;'+
        'overflow: hidden;'+
        'z-index: 10002;'+
      '}'+
      
      '#mcbm-phone {'+
        'position: relative;'+
        'margin: -200px auto 0;'+
        'width: 358px;'+
        'height: 315px;'+
      '}'+
      
      '#mcbm-phone-shadow {'+
        'position: absolute;'+
        'top: 0px;'+
        'left: 0px;'+
        'width: 358px;'+
        'height: 194px;'+
      '}'+
      
      '#mcbm-phone-display {'+
        'position: absolute;'+
        'top: 16px;'+
        'left: 16px;'+
        'width: 304px;'+
        'height: 153px;'+
        'background: url("'+MCBM.rootURI+'/img/phone/display.png") no-repeat 0 0 transparent;'+
      '}'+
      
      '#mcbm-phone-screen {'+
        'position: absolute;'+
        'top: 11px;'+
        'left: 44px;'+
        'width: 229px;'+
        'height: 130px;'+
      '}'+
            
      '#mcbm-phone-controller {'+
        'position: absolute;'+
        'top: 40px;'+
        'left: 15px;'+
        'width: 306px;'+
        'height: 129px;'+
        'background: url("'+MCBM.rootURI+'/img/phone/controller.png") no-repeat 0 0 transparent;'+
      '}';

    var _phoneHtml = ''+    
    '<div id="mcbm-phone-container">'+

      '<div id="mcbm-phone">'+
        
        '<div id="mcbm-phone-shadow">'+
          '<img src="'+MCBM.rootURI+'/img/phone/shadow.png" width="100%" height="100%">'+
        '</div>'+
        
        '<div id="mcbm-phone-controller"></div>'+
        
        '<div id="mcbm-phone-display">'+
          '<div id="mcbm-phone-screen">'+
            '<img src="'+MCBM.rootURI+'/img/phone/minecraft-screen.jpg" width="229" height="130">'+
          '</div>'+
        '</div>'+        

      '</div>'+
  
    '</div>';
    
    var $body = $('body'),
        $phoneContainer = $(_phoneHtml),
        $phone = $phoneContainer.find('#mcbm-phone'),
        $phoneShadow = $phoneContainer.find('#mcbm-phone-shadow'),
        $phoneDisplay = $phoneContainer.find('#mcbm-phone-display'),
        $phoneController = $phoneContainer.find('#mcbm-phone-controller'),
        _firstOpen = true;
    
    var pScope = {};
    
    function _init() {
            
      $('head').append('<style>'+_styles+'</style>');
      
      MCBM.$container.append($phoneContainer);
      $phoneContainer = $('#mcbm-phone-container');
      
    };
    
    function _transitionIn() {
      var duration = 700;
      
      $phoneContainer.css({
        'visibility': 'visible',
        'display': 'block'
      });
      
      $phone.stop().animate({marginTop: 0}, duration, "easeOutBack", _transitionInComplete);
      
      if (_firstOpen) {
        setTimeout(_transitionOpen, 450);
      } else {
        _transitionOpen();
      }
    };
    
    function _transitionOut() {
      var duration = 450;
      
      $phone.animate({marginTop: -300}, duration, "easeInOutExpo", _transitionOutComplete);
    };
    
    function _transitionOpen() {
      _firstOpen = false;
      var duration = 500;
      
      $phoneController.stop().animate({top: 146}, duration, "easeInOutExpo");
      $phoneShadow.stop().animate({height: 311}, duration, "easeInOutExpo");
      
    };    
    
    function _transitionClose() {
      var duration = 400;
      
      $phoneController.animate({top: 40}, duration, "easeInOutExpo");
      $phoneShadow.animate({height: 194}, duration, "easeInOutExpo");

    };
    
    function _transitionInComplete() {
      
    };
    
    function _transitionOutComplete() {
      $phoneContainer.css({
        'visibility': 'hidden',
        'display': 'none'
      });
    };
        
    _init();
    
    // ----------------------------------------------------------------
    // public methods
    // ----------------------------------------------------------------
    
    pScope.transitionIn = function () {
      _transitionIn();
    };
    
    pScope.transitionOut = function() {
      _transitionOut();
    };
    
    return pScope;
  };

})(jQuery);(function($){

  MCBM.ui = function() {
  
    
    var _styles = ''+
      '#mcbm-ui-container {'+
        'position: fixed;'+
        'bottom: 0px;'+
        'left: 0px;'+
        'width: 100%;'+
        'min-width: 1224px;'+
        'height: 73px;'+
        'overflow: hidden;'+
        'z-index: 10001;'+
      '}'+
      
      '#mcbm-ui {'+
        'position: absolute;'+
        'bottom: -73px;'+
        'left: 0px;'+
        'width: 100%;'+
        'height: 73px;'+
        'background: #444444;'+
      '}'+
      
      '#mcbm-ui-container a { text-indent: -9999px; overflow: hidden; }'+
      
      '#mcbm-ui-button-area {'+
        'position: relative;'+
        'margin: 0 205px 0 0;'+
        'overflow: hidden;'+
        'height: 93px;'+
      '}'+
      
      '#mcbm-dirt-bg {'+
        'position: absolute;'+
        'top: 0px;'+
        'left: 0px;'+
        'width: 100%;'+
        'height: 93px;'+
      '}'+
      
      '#mcbm-dirt-bg-left {'+
        'float: left;'+
        'width: 119px;'+
        'height: 93px;'+
        'background: url("'+MCBM.rootURI+'/img/ui/dirt-bg-sides.jpg") no-repeat 0 0;'+
      '}'+
      
      '#mcbm-dirt-bg-mid {'+
        'margin: 0 122px 0 119px;'+
        'height: 93px;'+
        'background: url("'+MCBM.rootURI+'/img/ui/dirt-bg-repeat-x.jpg") repeat-x;'+
      '}'+
      
      '#mcbm-dirt-bg-right {'+
        'position: absolute;'+
        'top: 0px;'+
        'right: 0px;'+
        'width: 122px;'+
        'height: 93px;'+
        'background: url("'+MCBM.rootURI+'/img/ui/dirt-bg-sides.jpg") no-repeat -119px 0;'+
      '}'+
      
      '#mcbm-ui-button-container {'+
        'position: absolute;'+
        'top: 0px;'+
        'left: 0px;'+
        'width: 100%;'+
        'height: 93px;'+
      '}'+
      
      '#mcbm-ui-buttons {'+
        'margin: 21px auto 0;'+
        'width: 888px;'+
        'height: 40px;'+
      '}'+
      
      '.mcbm-ui-button {'+
        'background: url("'+MCBM.rootURI+'/img/ui/ui-buttons.png") no-repeat;'+
      '}'+
      
      '.esp .mcbm-ui-button, .esp .mcbm-ui-button:hover {'+
        'background: url("'+MCBM.rootURI+'/img/ui/ui-buttons-esp.png") no-repeat;'+
      '}'+
      
      '#mcbm-play-creeper {'+
        'float:left;'+
        'margin-right: 21px;'+
        'width: 296px;'+
        'height: 36px;'+
        'background-position:0px 0px;'+
      '}'+
      
      '#mcbm-play-creeper:hover {'+
        'background-position: 0px -38px;'+
      '}'+
            
      '#mcbm-play-pickaxe {'+
        'float:left;'+
        'margin-right: 52px;'+
        'width: 296px;'+
        'height: 36px;'+
        'background-position: -298px 0px;'+
      '}'+
      
      '#mcbm-play-pickaxe:hover {'+
        'background-position: -298px -38px;'+
      '}'+
      
      '#mcbm-exit {'+
        'float:left;'+
        'width: 106px;'+
        'height: 36px;'+
        'background-position: -596px 0px;'+
      '}'+
      
      '#mcbm-exit:hover {'+
        'background-position: -596px -38px;'+
      '}'+
            
      '#mcbm-social {'+
        'float:left;'+
        'margin: 3px 23px 0 0;'+
      '}'+
      
      '#mcbm-fb {'+
        'float:left;'+
        'margin-right: 5px;'+
        'width: 28px;'+
        'height: 28px;'+
        'background: url("'+MCBM.rootURI+'/img/ui/share-icons.png") no-repeat 0 0;'+
      '}'+
      
      '#mcbm-fb:hover {'+
        'background-position: 0 -28px;'+
      '}'+
      
      '#mcbm-gplus {'+
        'float:left;'+
        'margin-right: 5px;'+
        'width: 28px;'+
        'height: 28px;'+
      '}'+
      
      '#mcbm-twitter {'+
        'float:left;'+
        'width: 28px;'+
        'height: 28px;'+
        'background: url("'+MCBM.rootURI+'/img/ui/share-icons.png") no-repeat -56px 0;'+
      '}'+
      
      '#mcbm-twitter:hover {'+
        'background-position: -56px -28px;'+
      '}'+
      
      '#mcbm-xperia-logo {'+
        'position: absolute;'+
        'top: 0px;'+
        'right: 0px;'+
        'width: 205px;'+
        'height: 73px;'+
      '}'+
      
      '#mcbm-show-ui {'+
        'position: absolute;'+
        'bottom: -31px;'+
        'left: 0px;'+
        'width: 203px;'+
        'height: 31px;'+
        'background: url("'+MCBM.rootURI+'/img/ui/show-ui-tab.png") no-repeat 0 0;'+
      '}'+
      
      '.esp #mcbm-show-ui {'+
        'background: url("'+MCBM.rootURI+'/img/ui/show-ui-tab-esp.png") no-repeat 0 0;'+
      '}';

    var _uiHtml = ''+    
    '<div id="mcbm-ui-container">'+
    
      '<a id="mcbm-show-ui" href="#">Show Controls</a>'+
      
      '<div id="mcbm-ui">'+      
        
        '<div id="mcbm-ui-button-area"> <!-- contains dirt background, buttons, stretches to fill area to left of logo -->'+
        
          '<div id="mcbm-dirt-bg">'+
            '<div id="mcbm-dirt-bg-left"></div>'+
            '<div id="mcbm-dirt-bg-mid"></div>'+
            '<div id="mcbm-dirt-bg-right"></div>'+
          '</div>'+
          
          '<div id="mcbm-ui-button-container">'+
            '<div id="mcbm-ui-buttons"> <!-- centered in container -->'+
              '<a id="mcbm-play-creeper" class="mcbm-ui-button" href="#">Unleash the creeper!</a>'+
              '<a id="mcbm-play-pickaxe" class="mcbm-ui-button" href="#">Get you pickaxe!</a>'+

              '<div id="mcbm-social">'+
                '<a id="mcbm-fb" href="'+MCBM.shareFbURI+'" target="_blank">Share on Facebook</a>'+
                //'<div id="mcbm-gplus"><g:plusone size="small" annotation="none"></g:plusone></div>'+
                '<a id="mcbm-twitter" href="'+MCBM.shareTwitterURI+'" target="_blank">Share on Twitter</a>'+
              '</div>'+

              '<a id="mcbm-exit" class="mcbm-ui-button" href="#">Exit</a>'+
            '</div>'+
          '</div>'+
          
        '</div>'+

        '<div id="mcbm-xperia-logo">'+
          '<img src="'+MCBM.rootURI+'/img/ui/xperia-logo.png" width+"205" height="73">'+
        '</div> <!-- anchored to the right -->'+

      '</div>'+

    '</div>';
    
    var $body = $('body'),
        $uiContainer = $(_uiHtml),
        $ui = $uiContainer.find('#mcbm-ui'),
        $dirtBg = $uiContainer.find('##mcbm-dirt-bg'),
        $playCreeperButton = $uiContainer.find('#mcbm-play-creeper'),
        $playPickaxeButton = $uiContainer.find('#mcbm-play-pickaxe'),
        $exitButton = $uiContainer.find('#mcbm-exit'),
        $showUIButton = $uiContainer.find('#mcbm-show-ui'),
        _mouseInUI = false,
        _mouseInUITab = false;
    
    var pScope = {};
    
    function _init() {
            
      $('head').append('<style>'+_styles+'</style>');
      
      MCBM.$container.append($uiContainer);
      $uiContainer = $('#mcbm-ui-container');  
      
      $playCreeperButton.bind('click', _onPlayCreeperClick);
      $playPickaxeButton.bind('click', _onPlayPickaxeClick);
      $exitButton.bind('click', _onExitClick);
      $showUIButton.bind('click', _onShowUIClick);
      
      $ui.bind('mouseenter', function () { _mouseInUI = true; } );
      $ui.bind('mouseleave', function () { _mouseInUI = false; } );
      $ui.bind('mousemove', function () { $body.trigger(MCBM.events.UI_MOUSE_MOVE); } );
      $showUIButton.bind('mouseenter', function () { _mouseInUITab = true; } );
      $showUIButton.bind('mouseleave', function () { _mouseInUITab = false; } );
      $body.bind( 'mousedown', _onMouseDown );
      
      // track share events
      $('#mcbm-fb').bind('click', function() { MCBM.gaTrackEvent('game', 'share', 'Facebook'); } );
      $('#mcbm-twitter').bind('click', function() { MCBM.gaTrackEvent('game', 'share', 'Twitter'); } );
    };
    
    function _onMouseDown(e) {
      
      if (_mouseInUI || _mouseInUITab) {
        e.stopImmediatePropagation();
      }
      
    };
    
    function _transitionUIOpen() {
      var duration = 800;
            
      $showUIButton.stop().animate({bottom: -31}, 300, "easeOutExpo");
      
      $dirtBg.stop().animate({top: 0}, duration, "easeOutExpo");
      $ui.stop().animate({bottom: 0}, duration, "easeOutExpo", _transitionUIOpenComplete);
      
    };
    
    function _transitionUIOpenComplete() {
      $body.trigger(MCBM.events.OPEN_UI_COMPLETE);      
    };
    
    function _transitionUIClose() {    
      var duration = 500;
      
      $showUIButton.stop().animate({bottom: 0}, 500, "easeInOutExpo");
       
      $dirtBg.stop().animate({top: -32}, duration, "easeInOutExpo");
      $ui.stop().animate({bottom: -63}, duration, "easeInOutExpo", _transitionUICloseComplete);

    };
    
    function _transitionUICloseComplete() {
      //debug.log("_transitionUICloseComplete");
      $body.trigger(MCBM.events.CLOSE_UI_COMPLETE);
    };
    
    function _onPlayCreeperClick(e) {
      e.preventDefault();
      
      $body.trigger(MCBM.events.PLAY_CREEPER_CLICK);
    };
    
    function _onPlayPickaxeClick(e) {
      e.preventDefault();
      
      $body.trigger(MCBM.events.PLAY_PICKAXE_CLICK);
    };
        
    function _onExitClick(e) {
      e.preventDefault();
      
      $body.trigger(MCBM.events.EXIT_CLICK);
    };
    
    function _onShowUIClick(e) {
      e.preventDefault();
      
      $body.trigger(MCBM.events.OPEN_UI);
    };
    
    
        
    _init();
    
    // ----------------------------------------------------------------
    // public methods
    // ----------------------------------------------------------------
    
    pScope.open = function () {
      _transitionUIOpen();
    };
    
    pScope.close = function() {
      _transitionUIClose();
    };
    
    return pScope;
  };

})(jQuery);(function($){

  MCBM.main = function() {
    
    var $win = $(window),
        $body = $('body'),
        _ui  = null,
        _phone = null,
        _gameDisplay = null,
        _gameCreeper = null,
        _gamePickaxe = null,
        _curGame = null,
        _queuedGame = null,
        _hasUIOpened = false,
        _isAutoClosingUi = false,
        _autoCloseUIDelay = 1500,
        _autoCloseUITimeout = null,
        _itemsLoaded = 0,
        _numLoadItems = 0;
        
    // ----------------------------------------------------------------
    
    function _init() {
      //debug.log("MCBM.main :: _init()");

      _gameDisplay = MCBM.display(false);
      
      _ui = MCBM.ui();
      _phone = MCBM.phoneDisplay();
      
      _numLoadItems = 2;
      $body.bind(MCBM.events.ITEM_LOADED, _onItemLoaded);
      $body.bind(MCBM.events.LOAD_ERROR, _onLoadError);
      
      _gameCreeper = MCBM.gameCreeper(_gameDisplay);
      _gamePickaxe = MCBM.gamePickaxe(_gameDisplay);
                
      $body.bind(MCBM.events.PLAY_CREEPER_CLICK, _onPlayCreeper);
      $body.bind(MCBM.events.PLAY_PICKAXE_CLICK, _onPlayPickaxe);
      $body.bind(MCBM.events.EXIT_CLICK, _onExit);
      $body.bind(MCBM.events.OPEN_UI, _onOpenUI);
      
      $body.bind(MCBM.events.OPEN_UI_COMPLETE, _onOpenUIComplete);
      $body.bind(MCBM.events.CLOSE_UI_COMPLETE, _onCloseUIComplete);
      
      $.doTimeout('loadTimeout', MCBM.LOAD_TIMEOUT, _loadTimeout);
    }
    
    function _onItemLoaded() {
      
      _itemsLoaded++;
      
      if (_itemsLoaded === _numLoadItems) {
        _onLoadComplete();
      }
      
    }
    
    function _loadTimeout() {
      //debug.log('Loading timed out');
      $body.trigger(MCBM.events.LOAD_ERROR);
    }
    
    function _onLoadError() {
      $body.unbind(MCBM.events.ITEM_LOADED, _onItemLoaded);
      $body.unbind(MCBM.events.LOAD_ERROR, _onLoadError);
      
      // swap loader for error message
      MCBM.$loading.animate({opacity:0}, 350, "easeOutQuad", function() { 
        
        MCBM.$loading.addClass('mcbm-hidden');
        
        MCBM.$error.removeClass('mcbm-hidden');
        MCBM.$error.animate({opacity:1}, 350, "easeOutQuad");
        
      });
    }
    
    function _onLoadComplete() {
      
      // cancel timeout
      $.doTimeout('loadTimeout');
      
      // hide loader
      MCBM.$loading.animate({opacity:0}, 350, "easeOutQuad", function() { } ); //$(this).remove();
      
      _ui.open();
      _phone.transitionIn();
      
      $win.bind('resize', _onResize);
    }
    
    // ----------------------------------------------------------------
    
    function _onPlayCreeper() {
      
      //debug.log("_onPlayCreeper");
      MCBM.gaTrackEvent('game', 'play', 'Creeper Game');
      _swapGames(_gameCreeper);
      
    }
    
    // ----------------------------------------------------------------
    
    function _onPlayPickaxe() {
      
      //debug.log("_onPlayPickaxe");
      MCBM.gaTrackEvent('game', 'play', 'Pickaxe Game');
      _swapGames(_gamePickaxe);
      
    }
    
    // ----------------------------------------------------------------
    
    function _swapGames(newGame) {
      
      _queuedGame = newGame;
      
      if (_curGame !== null) {
        _curGame.endGame();
        _curGame = null;
      }
      
      _closeUI();      
    }
    
    // ----------------------------------------------------------------
    
    function _closeUI() {
      if (_autoCloseUITimeout != null) {
        clearTimeout(_autoCloseUITimeout);
        _autoCloseUITimeout = null;
      }
      
      _ui.close();
      _phone.transitionOut();
    }
    
    function _onCloseUIComplete() {
      
      if (_queuedGame == null) {
        return;
      }
      
      _curGame = _queuedGame;
      _queuedGame = null;
      _curGame.newGame();
      
    }
    
    // ----------------------------------------------------------------
    
    function _onOpenUIComplete() {
      
      if (_curGame != null) {
        _isAutoClosingUi = _curGame.getIsRunning();
      }
      
      if (_hasUIOpened && _isAutoClosingUi) {
        // start auto close timer
        // add ui mouse movement listener to clear auto close timer
        $body.bind(MCBM.events.UI_MOUSE_MOVE, _onUIMouseMove);
        _autoCloseUITimeout = setTimeout(_autoCloseUI, _autoCloseUIDelay);
      } else {
        _hasUIOpened = true;
      }
      
    }
    
    function _onUIMouseMove() {
      
      if (_autoCloseUITimeout != null) {
        clearTimeout(_autoCloseUITimeout);
        _autoCloseUITimeout = null;
      }
      
      _autoCloseUITimeout = setTimeout(_autoCloseUI, _autoCloseUIDelay);
    }
    
    // ----------------------------------------------------------------
    
    function _autoCloseUI() {
      $body.unbind(MCBM.events.UI_MOUSE_MOVE, _onUIMouseMove);
      
      if (_autoCloseUITimeout != null) {
        clearTimeout(_autoCloseUITimeout);
        _autoCloseUITimeout = null;
      }
      
      if (_curGame != null) {
        if (_curGame.getIsRunning()) { // game may have ended during timeout, only close if game is still running
          _closeUI();
        }
      }
      
    }
    
    // ----------------------------------------------------------------
    
    function _onOpenUI() {
      if (_autoCloseUITimeout != null) {
        clearTimeout(_autoCloseUITimeout);
        _autoCloseUITimeout = null;
      }
      
      _phone.transitionIn(); 
      _ui.open();
      
    }
    
    // ----------------------------------------------------------------
    
    function _onExit() {
      
      // clear events
      $body.unbind(MCBM.events.PLAY_CREEPER_CLICK, _onPlayCreeper);
      $body.unbind(MCBM.events.PLAY_PICKAXE_CLICK, _onPlayPickaxe);
      $body.unbind(MCBM.events.EXIT_CLICK, _onExit);
      $body.unbind(MCBM.events.OPEN_UI, _onOpenUI);
      
      $body.unbind(MCBM.events.OPEN_UI_COMPLETE, _onOpenUIComplete);
      $body.unbind(MCBM.events.CLOSE_UI_COMPLETE, _onCloseUIComplete);
      
      //debug.log("_onExit");
      if (_autoCloseUITimeout != null) {
        clearTimeout(_autoCloseUITimeout);
        _autoCloseUITimeout = null;
      }
      
      if (_curGame !== null) {
          _curGame.endGame();
          _curGame = null;
      }
      
      MCBM.$container.remove();
      
      MCBM.gaTrackEvent('game', 'exit', MCBM.getDuration());
      
      window.location.reload(true);
      
    }
    
    // ----------------------------------------------------------------
    
    function _onResize() {
      // debounce the resize
      $.doTimeout( 'resize', 250, function(){
        
        // only updating the width, height is determined by container size or MAX_HEIGHT
        if ($win.width() > MCBM.MAX_WIDTH) {
          MCBM.$container.css({
            'width': MCBM.MAX_WIDTH+'px',
            'left': '50%',
            'margin-left': Math.floor(-MCBM.MAX_WIDTH * 0.5) + 'px'
          });
        } else {
          MCBM.$container.css({
            'width': '100%',
            'left': '0',
            'margin-left': '0'
          });
        }
        
        var w = MCBM.$container.outerWidth();
        
        _gameDisplay.resize(w);
        _gameCreeper.resize(w);
        _gamePickaxe.resize(w);
        
      });      
    }
    
    // ----------------------------------------------------------------
    // ----------------------------------------------------------------
    
    _init();
    
  };

})(jQuery);
This is all of the source I could find for Minecraft Anywhere. 
This package is split into parts:

AT /: you will find mcbm.js and mcbm-load.js -> these two files are all you need, and they are NOT  minified, however still created with bookmarklets in mind. They come pre-packed with their dependencies.

AT decomp-src/: you will find many files of source code. I could not sift through everything, so it may not even BE everything, however these should be what go into mcbm.js (as I pulled them from dev page).

AT indev/: you will find files related to the development of this game that have nothing to do with the release.

AT min/: you will find the initially deployed files, that you would have actually USED to run Minecraft Anywhere. 

AT assets/: you will find all used assets.

There are many dependencies that exist in MCAnywhere. In the main js files these can be ignored, however if you are looking into indev/ or decomp-src/ this will become something you need to note:
 - Stats.js : mrdoob
 - Three.js : mrdoob
 - CustomCube.js : mrdoob
 - Debug.js

Enjoy looking through this!!!

 - luphoria // luphoria.com
if (typeof window.MCBM == 'undefined') {

  // Declare our global scope object
  var MCBM = {};

  // Begin script inclusion statements for dynamic loading of libaries.
  MCBM.rootURI = window.mcbmRootURI.replace(/\/$/, '');
  
  MCBM.mcbmScriptURI = window.mcbmScriptURI;
  MCBM.include = [
        
    [ MCBM.rootURI + '/js/'+MCBM.mcbmScriptURI, 'window.MCBM.main' ]
    
  ];

  // -----------------------------------------
  // Dynamic JavaScript loading utility method
  // -----------------------------------------
  MCBM.require = function(file, globalPropertyName, callback) {
    
    // Check for existence of property name before attempting to load.
    if( typeof eval(globalPropertyName) == 'undefined' ) {
  
      var script = document.getElementsByTagName('script')[0],
          newjs = document.createElement('script');
      
      newjs.onload = function() { callback(); };
      newjs.src = file;
      script.parentNode.insertBefore(newjs, script);
      
    } else {
      
      callback();
      
    }
    
  };

  // Track the # of scripts loaded.
  MCBM.scriptLoadCount = -1;

  // -----------------------------------------
  // Dynamic JavaScript loading callback
  // -----------------------------------------
  MCBM.handleScriptLoaded = function() {
  
    MCBM.scriptLoadCount++;
    
    if(MCBM.scriptLoadCount < MCBM.include.length) {
      var scriptObj = MCBM.include[MCBM.scriptLoadCount];
      MCBM.require( scriptObj[0], scriptObj[1], MCBM.handleScriptLoaded );
    } else {
      MCBM.initialize();
    }
  
  };

 
  // ====================================================================
  //
  // Initialize the bookmarklet
  //
  // ====================================================================
  MCBM.initialize = function() {
    
    jQuery.noConflict();
    jQuery(function($) {
      
      MCBM.init();
      MCBM.main();
    
    });
  
  };

  
  // Start loading our scripts.
  MCBM.handleScriptLoaded();

}